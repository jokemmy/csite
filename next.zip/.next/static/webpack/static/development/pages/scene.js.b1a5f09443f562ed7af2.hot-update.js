webpackHotUpdate("static/development/pages/scene.js",{

/***/ "./components/ResizeImage/index.js":
/*!*****************************************!*\
  !*** ./components/ResizeImage/index.js ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/extends */ "./node_modules/@babel/runtime-corejs2/helpers/esm/extends.js");
/* harmony import */ var _babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime-corejs2/core-js/object/keys */ "./node_modules/@babel/runtime-corejs2/core-js/object/keys.js");
/* harmony import */ var _babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/objectWithoutProperties */ "./node_modules/@babel/runtime-corejs2/helpers/esm/objectWithoutProperties.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/classCallCheck */ "./node_modules/@babel/runtime-corejs2/helpers/esm/classCallCheck.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/possibleConstructorReturn */ "./node_modules/@babel/runtime-corejs2/helpers/esm/possibleConstructorReturn.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/getPrototypeOf */ "./node_modules/@babel/runtime-corejs2/helpers/esm/getPrototypeOf.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/assertThisInitialized */ "./node_modules/@babel/runtime-corejs2/helpers/esm/assertThisInitialized.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/createClass */ "./node_modules/@babel/runtime-corejs2/helpers/esm/createClass.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/inherits */ "./node_modules/@babel/runtime-corejs2/helpers/esm/inherits.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/defineProperty */ "./node_modules/@babel/runtime-corejs2/helpers/esm/defineProperty.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var object_pick__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! object.pick */ "./node_modules/object.pick/index.js");
/* harmony import */ var object_pick__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(object_pick__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! rc-util/lib/Dom/css */ "./node_modules/rc-util/lib/Dom/css.js");
/* harmony import */ var rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var rc_util_lib_Dom_addEventListener__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! rc-util/lib/Dom/addEventListener */ "./node_modules/rc-util/lib/Dom/addEventListener.js");
/* harmony import */ var rc_util_lib_Dom_addEventListener__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(rc_util_lib_Dom_addEventListener__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _components_Themes__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @components/Themes */ "./components/Themes/index.js");
/* harmony import */ var _lib_requestAnimationFrame__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @lib/requestAnimationFrame */ "./lib/requestAnimationFrame.js");
/* harmony import */ var _resizeImage_less__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./resizeImage.less */ "./components/ResizeImage/resizeImage.less");
/* harmony import */ var _resizeImage_less__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_resizeImage_less__WEBPACK_IMPORTED_MODULE_16__);










var _jsxFileName = "/Users/rainx/Documents/Github/csite/components/ResizeImage/index.js";








var ResizeImage =
/*#__PURE__*/
function (_React$Component) {
  Object(_babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_8__["default"])(ResizeImage, _React$Component);

  Object(_babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_7__["default"])(ResizeImage, null, [{
    key: "getDerivedStateFromProps",
    value: function getDerivedStateFromProps(props, state) {
      if (props.width && !state.width) {
        return {
          width: props.width
        };
      }

      return null;
    }
  }]);

  function ResizeImage(props) {
    var _this;

    Object(_babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_3__["default"])(this, ResizeImage);

    _this = Object(_babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__["default"])(this, Object(_babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__["default"])(ResizeImage).call(this, props));

    Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_9__["default"])(Object(_babel_runtime_corejs2_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_6__["default"])(_this), "handleResize", function () {
      return Object(_lib_requestAnimationFrame__WEBPACK_IMPORTED_MODULE_15__["requestAnimationFrame"])(function () {
        console.log("1:", 1);
        var width = _this.state.width;
        var wrap = _this.wrapRef.current;
        var target = _this.containerRef.current;
        var currentWidth = Object(rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_12__["get"])(wrap, 'width');
        var scale = currentWidth / width;
        Object(rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_12__["set"])(target, 'transform', "scale(".concat(scale, ")"));
      });
    });

    _this.wrapRef = react__WEBPACK_IMPORTED_MODULE_10___default.a.createRef();
    _this.containerRef = react__WEBPACK_IMPORTED_MODULE_10___default.a.createRef();
    _this.state = {
      width: null,
      height: null
    };
    return _this;
  }

  Object(_babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_7__["default"])(ResizeImage, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      var _this2 = this;

      var width = this.state.width;
      var themeVariables = this.context.themeVariables;
      this.state.width = width === null ? +themeVariables['@page-width'].replace(/px$/, '') - 24 * 2 : width;
      this.resizeHandler = rc_util_lib_Dom_addEventListener__WEBPACK_IMPORTED_MODULE_13___default()(window, 'resize', function () {
        return _this2.handleResize;
      });
      this.handleResize();
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      if (this.resizeHandler) {
        this.resizeHandler.remove();
        this.resizeHandler = null;
      }
    }
  }, {
    key: "render",
    value: function render() {
      var _this$state = this.state,
          width = _this$state.width,
          height = _this$state.height;
      var themeVariables = this.context.themeVariables;

      var _this$props = this.props,
          children = _this$props.children,
          props = Object(_babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_2__["default"])(_this$props, ["children"]); // width 一定要设置默认


      var style = {
        // 最大宽度减 pandding
        width: width === null ? +themeVariables['@page-width'].replace(/px$/, '') - 24 * 2 : width,
        height: height
      };
      style = object_pick__WEBPACK_IMPORTED_MODULE_11___default()(style, _babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_1___default()(style).filter(function (key) {
        return style[key];
      }));
      return react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", Object(_babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__["default"])({}, props, {
        ref: this.wrapRef,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 71
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
        style: style,
        className: _resizeImage_less__WEBPACK_IMPORTED_MODULE_16___default.a.container,
        ref: this.containerRef,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 72
        },
        __self: this
      }, children));
    }
  }]);

  return ResizeImage;
}(react__WEBPACK_IMPORTED_MODULE_10___default.a.Component);

Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_9__["default"])(ResizeImage, "contextType", _components_Themes__WEBPACK_IMPORTED_MODULE_14__["ThemeContext"]);

/* harmony default export */ __webpack_exports__["default"] = (ResizeImage);

/***/ })

})
//# sourceMappingURL=scene.js.b1a5f09443f562ed7af2.hot-update.js.map