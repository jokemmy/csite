webpackHotUpdate("static/development/pages/hardware.js",{

/***/ "./pages/hardware/index.js":
/*!*********************************!*\
  !*** ./pages/hardware/index.js ***!
  \*********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime-corejs2/core-js/object/keys */ "./node_modules/@babel/runtime-corejs2/core-js/object/keys.js");
/* harmony import */ var _babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime-corejs2/regenerator */ "./node_modules/@babel/runtime-corejs2/regenerator/index.js");
/* harmony import */ var _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/asyncToGenerator */ "./node_modules/@babel/runtime-corejs2/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/slicedToArray */ "./node_modules/@babel/runtime-corejs2/helpers/esm/slicedToArray.js");
/* harmony import */ var _babel_runtime_corejs2_core_js_object_entries__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @babel/runtime-corejs2/core-js/object/entries */ "./node_modules/@babel/runtime-corejs2/core-js/object/entries.js");
/* harmony import */ var _babel_runtime_corejs2_core_js_object_entries__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_core_js_object_entries__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_objectSpread__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/objectSpread */ "./node_modules/@babel/runtime-corejs2/helpers/esm/objectSpread.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/classCallCheck */ "./node_modules/@babel/runtime-corejs2/helpers/esm/classCallCheck.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/createClass */ "./node_modules/@babel/runtime-corejs2/helpers/esm/createClass.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/possibleConstructorReturn */ "./node_modules/@babel/runtime-corejs2/helpers/esm/possibleConstructorReturn.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/getPrototypeOf */ "./node_modules/@babel/runtime-corejs2/helpers/esm/getPrototypeOf.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/assertThisInitialized */ "./node_modules/@babel/runtime-corejs2/helpers/esm/assertThisInitialized.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/inherits */ "./node_modules/@babel/runtime-corejs2/helpers/esm/inherits.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/defineProperty */ "./node_modules/@babel/runtime-corejs2/helpers/esm/defineProperty.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! classnames */ "./node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _components_SvgIcon__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @components/SvgIcon */ "./components/SvgIcon/index.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! next/router */ "./node_modules/next/dist/client/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _components_Themes__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @components/Themes */ "./components/Themes/index.js");
/* harmony import */ var rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! rc-util/lib/Dom/css */ "./node_modules/rc-util/lib/Dom/css.js");
/* harmony import */ var rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var _lib_requestAnimationFrame__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @lib/requestAnimationFrame */ "./lib/requestAnimationFrame.js");
/* harmony import */ var _assets_images_hardware_category_1_jpg__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @assets/images/hardware/category-1.jpg */ "./assets/images/hardware/category-1.jpg");
/* harmony import */ var _assets_images_hardware_category_1_jpg__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(_assets_images_hardware_category_1_jpg__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var _assets_images_hardware_category_2_jpg__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @assets/images/hardware/category-2.jpg */ "./assets/images/hardware/category-2.jpg");
/* harmony import */ var _assets_images_hardware_category_2_jpg__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(_assets_images_hardware_category_2_jpg__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var _assets_images_hardware_category_3_jpg__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @assets/images/hardware/category-3.jpg */ "./assets/images/hardware/category-3.jpg");
/* harmony import */ var _assets_images_hardware_category_3_jpg__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(_assets_images_hardware_category_3_jpg__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var _assets_images_hardware_category_4_jpg__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @assets/images/hardware/category-4.jpg */ "./assets/images/hardware/category-4.jpg");
/* harmony import */ var _assets_images_hardware_category_4_jpg__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(_assets_images_hardware_category_4_jpg__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var _assets_images_hardware_category_5_jpg__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @assets/images/hardware/category-5.jpg */ "./assets/images/hardware/category-5.jpg");
/* harmony import */ var _assets_images_hardware_category_5_jpg__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(_assets_images_hardware_category_5_jpg__WEBPACK_IMPORTED_MODULE_24__);
/* harmony import */ var _assets_images_hardware_category_6_jpg__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @assets/images/hardware/category-6.jpg */ "./assets/images/hardware/category-6.jpg");
/* harmony import */ var _assets_images_hardware_category_6_jpg__WEBPACK_IMPORTED_MODULE_25___default = /*#__PURE__*/__webpack_require__.n(_assets_images_hardware_category_6_jpg__WEBPACK_IMPORTED_MODULE_25__);
/* harmony import */ var _assets_images_hardware_category_icon_1_svg_sprite__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @assets/images/hardware/category-icon-1.svg?sprite */ "./assets/images/hardware/category-icon-1.svg?sprite");
/* harmony import */ var _assets_images_hardware_category_icon_1_svg_sprite__WEBPACK_IMPORTED_MODULE_26___default = /*#__PURE__*/__webpack_require__.n(_assets_images_hardware_category_icon_1_svg_sprite__WEBPACK_IMPORTED_MODULE_26__);
/* harmony import */ var _assets_images_hardware_category_icon_2_svg_sprite__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @assets/images/hardware/category-icon-2.svg?sprite */ "./assets/images/hardware/category-icon-2.svg?sprite");
/* harmony import */ var _assets_images_hardware_category_icon_2_svg_sprite__WEBPACK_IMPORTED_MODULE_27___default = /*#__PURE__*/__webpack_require__.n(_assets_images_hardware_category_icon_2_svg_sprite__WEBPACK_IMPORTED_MODULE_27__);
/* harmony import */ var _assets_images_hardware_category_icon_3_svg_sprite__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! @assets/images/hardware/category-icon-3.svg?sprite */ "./assets/images/hardware/category-icon-3.svg?sprite");
/* harmony import */ var _assets_images_hardware_category_icon_3_svg_sprite__WEBPACK_IMPORTED_MODULE_28___default = /*#__PURE__*/__webpack_require__.n(_assets_images_hardware_category_icon_3_svg_sprite__WEBPACK_IMPORTED_MODULE_28__);
/* harmony import */ var _assets_images_hardware_category_icon_4_svg_sprite__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! @assets/images/hardware/category-icon-4.svg?sprite */ "./assets/images/hardware/category-icon-4.svg?sprite");
/* harmony import */ var _assets_images_hardware_category_icon_4_svg_sprite__WEBPACK_IMPORTED_MODULE_29___default = /*#__PURE__*/__webpack_require__.n(_assets_images_hardware_category_icon_4_svg_sprite__WEBPACK_IMPORTED_MODULE_29__);
/* harmony import */ var _assets_images_hardware_category_icon_5_svg_sprite__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! @assets/images/hardware/category-icon-5.svg?sprite */ "./assets/images/hardware/category-icon-5.svg?sprite");
/* harmony import */ var _assets_images_hardware_category_icon_5_svg_sprite__WEBPACK_IMPORTED_MODULE_30___default = /*#__PURE__*/__webpack_require__.n(_assets_images_hardware_category_icon_5_svg_sprite__WEBPACK_IMPORTED_MODULE_30__);
/* harmony import */ var _assets_images_hardware_category_icon_6_svg_sprite__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! @assets/images/hardware/category-icon-6.svg?sprite */ "./assets/images/hardware/category-icon-6.svg?sprite");
/* harmony import */ var _assets_images_hardware_category_icon_6_svg_sprite__WEBPACK_IMPORTED_MODULE_31___default = /*#__PURE__*/__webpack_require__.n(_assets_images_hardware_category_icon_6_svg_sprite__WEBPACK_IMPORTED_MODULE_31__);
/* harmony import */ var _productions__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! ./productions */ "./pages/hardware/productions/index.js");
/* harmony import */ var _category__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! ./category */ "./pages/hardware/category.js");
/* harmony import */ var _hardware_less__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! ./hardware.less */ "./pages/hardware/hardware.less");
/* harmony import */ var _hardware_less__WEBPACK_IMPORTED_MODULE_34___default = /*#__PURE__*/__webpack_require__.n(_hardware_less__WEBPACK_IMPORTED_MODULE_34__);














var _class,
    _class2,
    _temp,
    _jsxFileName = "/Users/rainx/Documents/Github/csite/pages/hardware/index.js";























var images = [_assets_images_hardware_category_1_jpg__WEBPACK_IMPORTED_MODULE_20___default.a, _assets_images_hardware_category_2_jpg__WEBPACK_IMPORTED_MODULE_21___default.a, _assets_images_hardware_category_3_jpg__WEBPACK_IMPORTED_MODULE_22___default.a, _assets_images_hardware_category_4_jpg__WEBPACK_IMPORTED_MODULE_23___default.a, _assets_images_hardware_category_5_jpg__WEBPACK_IMPORTED_MODULE_24___default.a, _assets_images_hardware_category_6_jpg__WEBPACK_IMPORTED_MODULE_25___default.a];
var icons = [_assets_images_hardware_category_icon_1_svg_sprite__WEBPACK_IMPORTED_MODULE_26___default.a, _assets_images_hardware_category_icon_2_svg_sprite__WEBPACK_IMPORTED_MODULE_27___default.a, _assets_images_hardware_category_icon_3_svg_sprite__WEBPACK_IMPORTED_MODULE_28___default.a, _assets_images_hardware_category_icon_4_svg_sprite__WEBPACK_IMPORTED_MODULE_29___default.a, _assets_images_hardware_category_icon_5_svg_sprite__WEBPACK_IMPORTED_MODULE_30___default.a, _assets_images_hardware_category_icon_6_svg_sprite__WEBPACK_IMPORTED_MODULE_31___default.a];

var Hardware = Object(next_router__WEBPACK_IMPORTED_MODULE_16__["withRouter"])(_class = (_temp = _class2 =
/*#__PURE__*/
function (_React$Component) {
  Object(_babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_11__["default"])(Hardware, _React$Component);

  function Hardware(props) {
    var _this;

    Object(_babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_6__["default"])(this, Hardware);

    _this = Object(_babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_8__["default"])(this, Object(_babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_9__["default"])(Hardware).call(this, props));

    Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_12__["default"])(Object(_babel_runtime_corejs2_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_10__["default"])(_this), "handleClick", function (_ref) {
      var index = _ref.index,
          title = _ref.title,
          image = _ref.image,
          className = _ref.className;
      return function (_ref2) {
        var currentTarget = _ref2.currentTarget;
        var selected = _this.state.selected;

        if (!selected.animIn && !selected.animating) {
          _this.state.selected = {
            // eslint-disable-line
            index: index,
            title: title,
            image: image,
            className: className,
            dom: currentTarget
          };

          _this.forceUpdate(function () {
            next_router__WEBPACK_IMPORTED_MODULE_16___default.a.push("/hardware?category=".concat(index), "/hardware/".concat(index), {
              shallow: true
            });
          });
        }
      };
    });

    Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_12__["default"])(Object(_babel_runtime_corejs2_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_10__["default"])(_this), "handleImageLoad", function () {
      var selected = _this.state.selected;
      var position = selected.dom.getBoundingClientRect();

      var fixedStyle = _this.getBlockStyle(position);

      var imageSize = _this.getImageSize();

      var clientSize = Object(rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_18__["getClientSize"])();

      var fixedImageStyle = Object(_babel_runtime_corejs2_helpers_esm_objectSpread__WEBPACK_IMPORTED_MODULE_5__["default"])({
        opacity: 0,
        visibility: 'visible'
      }, _this.getImageStyle(imageSize, position));

      var fixedFakeContantStyle = {
        // opacity: 0,
        transform: 'translateY(100vh) scale(0.6)'
      };
      var fixedFakeContantLastStyle = {
        // opacity: 1,
        transform: 'translateY(350px) scale(1)'
      };
      var fixedLastStyle = {
        transition: _this.getTransition(true),
        transform: 'translateX(0) translateY(0) translateZ(0)',
        height: '100vh',
        width: '100vw'
      };
      var fixedImageLastStyle = {
        opacity: 1,
        visibility: 'visible',
        transition: _this.getImageTransition(true),
        transform: _this.getImageCoverTransform(imageSize, {
          width: clientSize.width,
          height: 350
        })
      };
      _this.state.selected = Object(_babel_runtime_corejs2_helpers_esm_objectSpread__WEBPACK_IMPORTED_MODULE_5__["default"])({}, selected, {
        animating: true,
        animIn: true
      }); // eslint-disable-line

      _this.forceUpdate(function () {
        Object(rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_18__["set"])(_this.pageRef.current, fixedStyle);
        Object(rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_18__["set"])(_this.pageImageRef.current, fixedImageStyle);
        Object(rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_18__["set"])(_this.pageFakeContantRef.current, fixedFakeContantStyle); // 火狐延迟一帧

        Object(_lib_requestAnimationFrame__WEBPACK_IMPORTED_MODULE_19__["requestAnimationFrame"])(function () {
          Object(_lib_requestAnimationFrame__WEBPACK_IMPORTED_MODULE_19__["requestAnimationFrame"])(function () {
            Object(rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_18__["set"])(_this.pageRef.current, fixedLastStyle);
            Object(rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_18__["set"])(_this.pageImageRef.current, fixedImageLastStyle);
            Object(rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_18__["set"])(_this.pageFakeContantRef.current, fixedFakeContantLastStyle);
          });
        });
      });
    });

    Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_12__["default"])(Object(_babel_runtime_corejs2_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_10__["default"])(_this), "handleBack", function () {
      var selected = _this.state.selected;

      if (selected.animIn && !selected.animating) {
        var position = selected.dom.getBoundingClientRect();
        var bannerPosition = _category__WEBPACK_IMPORTED_MODULE_33__["default"].getBannerPosition();

        var imageSize = _this.getImageSize();

        var imageCoverSize = _this.getImageSize(bannerPosition);

        var imageStyle = _this.getImageStyle(imageSize, bannerPosition);

        var fixedStyle = {
          width: "".concat(imageCoverSize.width, "px"),
          height: "".concat(imageCoverSize.height, "px"),
          transform: "translateX(".concat((bannerPosition.width - imageCoverSize.width) / 2, "px) translateY(").concat((bannerPosition.height - imageCoverSize.height) / 2, "px) translateZ(0)")
        };

        var fixedImageStyle = Object(_babel_runtime_corejs2_helpers_esm_objectSpread__WEBPACK_IMPORTED_MODULE_5__["default"])({
          opacity: 1,
          visibility: 'visible'
        }, imageStyle);

        var fixedFakeContantStyle = {
          opacity: 0.999,
          transform: 'translateY(350px) scale(1)'
        };
        var fixedFakeContantLastStyle = {
          opacity: 0.001,
          transform: 'translateY(100vh) scale(0.8)'
        };
        var fixedLastStyle = {
          transition: _this.getTransition(false),
          width: "".concat(position.width, "px"),
          height: "".concat(position.height, "px"),
          transform: "translateX(".concat(position.left, "px) translateY(").concat(position.top, "px) translateZ(0)")
        };
        var fixedImageLastStyle = {
          opacity: 0,
          visibility: 'visible',
          transition: _this.getImageTransition(false),
          transform: _this.getImageCoverTransform(imageSize, position)
        };
        _this.state.selected = Object(_babel_runtime_corejs2_helpers_esm_objectSpread__WEBPACK_IMPORTED_MODULE_5__["default"])({}, selected, {
          animating: true,
          animIn: false
        }); // eslint-disable-line

        _this.forceUpdate(function () {
          Object(rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_18__["set"])(_this.pageRef.current, fixedStyle);
          Object(rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_18__["set"])(_this.pageImageRef.current, fixedImageStyle);
          Object(rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_18__["set"])(_this.pageFakeContantRef.current, fixedFakeContantStyle);
          Object(_lib_requestAnimationFrame__WEBPACK_IMPORTED_MODULE_19__["requestAnimationFrame"])(function () {
            Object(_lib_requestAnimationFrame__WEBPACK_IMPORTED_MODULE_19__["requestAnimationFrame"])(function () {
              Object(rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_18__["set"])(_this.pageRef.current, fixedLastStyle);
              Object(rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_18__["set"])(_this.pageImageRef.current, fixedImageLastStyle);
              Object(rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_18__["set"])(_this.pageFakeContantRef.current, fixedFakeContantLastStyle);
            });
          });
        });
      }
    });

    Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_12__["default"])(Object(_babel_runtime_corejs2_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_10__["default"])(_this), "handleTransitionEnd", function (animIn) {
      return function (e) {
        var selected = _this.state.selected;
        var isTransform = e.nativeEvent.propertyName === 'transform';
        var isOpacity = e.nativeEvent.propertyName === 'opacity';

        if (e.target === e.currentTarget) {
          e.preventDefault();
          e.stopPropagation();
        }

        if (isOpacity && e.target === e.currentTarget) {
          _this.state.selected = {}; // eslint-disable-line

          Object(_lib_requestAnimationFrame__WEBPACK_IMPORTED_MODULE_19__["requestAnimationFrame"])(function () {
            _this.pageRef.current.removeAttribute('style');

            _this.pageImageRef.current.removeAttribute('style');

            _this.pageFakeContantRef.current.removeAttribute('style');

            _this.forceUpdate();
          });
        } else if (selected.animating && e.target === e.currentTarget) {
          if (isTransform) {
            if (animIn) {
              _this.state.selected = Object(_babel_runtime_corejs2_helpers_esm_objectSpread__WEBPACK_IMPORTED_MODULE_5__["default"])({}, selected, {
                animating: false
              }); // eslint-disable-line

              _this.setState({
                index: selected.index
              }, function () {
                Object(_lib_requestAnimationFrame__WEBPACK_IMPORTED_MODULE_19__["requestAnimationFrame"])(function () {
                  _this.pageRef.current.setAttribute('style', 'height:100vh;width:100vw;');
                });
              });
            } else {
              _this.setState({
                index: 0,
                toBack: false
              }, function () {
                Object(_lib_requestAnimationFrame__WEBPACK_IMPORTED_MODULE_19__["requestAnimationFrame"])(function () {
                  Object(rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_18__["set"])(_this.pageRef.current, {
                    opacity: 0.001
                  });
                });
              });
            }
          }
        }
      };
    });

    Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_12__["default"])(Object(_babel_runtime_corejs2_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_10__["default"])(_this), "getTransition", function (isIn) {
      var _this$context = _this.context,
          themeVariables = _this$context.themeVariables,
          themeEasings = _this$context.themeEasings;
      var animSpeed = themeVariables['@anim-speed-3'].replace('ms', '');
      var ease = isIn ? themeEasings['@easeOutExpo'] : themeEasings['@easeOutCirc'];
      return _babel_runtime_corejs2_core_js_object_entries__WEBPACK_IMPORTED_MODULE_4___default()({
        width: {
          ease: ease,
          duration: animSpeed
        },
        height: {
          ease: ease,
          duration: animSpeed
        },
        transform: {
          ease: ease,
          duration: animSpeed
        },
        opacity: {
          ease: '',
          duration: animSpeed / 4
        }
      }).map(function (_ref3) {
        var _ref4 = Object(_babel_runtime_corejs2_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_3__["default"])(_ref3, 2),
            property = _ref4[0],
            _ref4$ = _ref4[1],
            ease = _ref4$.ease,
            duration = _ref4$.duration;

        return "".concat(property, " ").concat(duration, "ms ").concat(ease);
      }).join(',');
    });

    Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_12__["default"])(Object(_babel_runtime_corejs2_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_10__["default"])(_this), "getImageTransition", function (isIn) {
      var _this$context2 = _this.context,
          themeVariables = _this$context2.themeVariables,
          themeEasings = _this$context2.themeEasings;
      var animSpeed = themeVariables['@anim-speed-3'].replace('ms', '');
      return _babel_runtime_corejs2_core_js_object_entries__WEBPACK_IMPORTED_MODULE_4___default()({
        opacity: {
          ease: '',
          duration: animSpeed
        },
        transform: {
          ease: isIn ? themeEasings['@easeOutCirc'] : themeEasings['@easeOutExpo'],
          duration: animSpeed
        }
      }).map(function (_ref5) {
        var _ref6 = Object(_babel_runtime_corejs2_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_3__["default"])(_ref5, 2),
            property = _ref6[0],
            _ref6$ = _ref6[1],
            ease = _ref6$.ease,
            duration = _ref6$.duration;

        return "".concat(property, " ").concat(duration, "ms ").concat(ease);
      }).join(',');
    });

    Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_12__["default"])(Object(_babel_runtime_corejs2_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_10__["default"])(_this), "getBlockStyle", function (position) {
      return {
        width: "".concat(position.width, "px"),
        height: "".concat(position.height, "px"),
        transform: "translateX(".concat(position.left, "px) translateY(").concat(position.top, "px) translateZ(0)")
      };
    });

    Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_12__["default"])(Object(_babel_runtime_corejs2_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_10__["default"])(_this), "getImageSize", function (cover) {
      var image = _this.pageImageRef.current;

      var _ref7 = cover || Object(rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_18__["getClientSize"])(),
          width = _ref7.width,
          height = _ref7.height;

      var imageRatio = image.width / image.height;
      var targetRatio = width / height;
      return {
        width: imageRatio > targetRatio ? imageRatio * height : width,
        height: imageRatio > targetRatio ? height : width / imageRatio
      };
    });

    Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_12__["default"])(Object(_babel_runtime_corejs2_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_10__["default"])(_this), "getImageStyle", function (coverSize, target, percent) {
      return Object(_babel_runtime_corejs2_helpers_esm_objectSpread__WEBPACK_IMPORTED_MODULE_5__["default"])({}, coverSize, {
        transform: _this.getImageCoverTransform(coverSize, target, percent)
      });
    });

    Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_12__["default"])(Object(_babel_runtime_corejs2_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_10__["default"])(_this), "getImageCoverTransform", function (image, target) {
      var percent = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 0.5;
      var imageRatio = image.width / image.height;
      var targetRatio = target.width / target.height;

      if (imageRatio > targetRatio) {
        var _scale = target.height / image.height;

        var imageWidth = image.width * _scale;
        var w = (imageWidth - target.width) * -percent;
        return "translateX(".concat(w, "px) translateY(0) translateZ(0) scale(").concat(Math.ceil(_scale * 1000) / 1000, ")");
      }

      var scale = target.width / image.width;
      var imageHeight = image.height * scale;
      var h = (imageHeight - target.height) * -percent;
      return "translateX(0) translateY(".concat(h, "px) translateZ(0) scale(").concat(Math.ceil(scale * 1000) / 1000, ")");
    });

    var router = _this.props.router;

    var _index = ~~router.query.category;

    _this.state = {
      toBack: false,
      toFront: false,
      index: _index || 0,
      animating: false,
      selected: {}
    };
    _this.pageRef = react__WEBPACK_IMPORTED_MODULE_13___default.a.createRef();
    _this.categoryRef = react__WEBPACK_IMPORTED_MODULE_13___default.a.createRef();
    _this.pageImageRef = react__WEBPACK_IMPORTED_MODULE_13___default.a.createRef();
    _this.pageFakeContantRef = react__WEBPACK_IMPORTED_MODULE_13___default.a.createRef();
    return _this;
  }

  Object(_babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_7__["default"])(Hardware, [{
    key: "componentDidUpdate",
    value: function componentDidUpdate(prevProps_, prevState) {
      var _this$state = this.state,
          toBack = _this$state.toBack,
          toFront = _this$state.toFront,
          selected = _this$state.selected;

      if (!prevState.toBack && toBack) {
        this.setState({
          toBack: false,
          selected: Object(_babel_runtime_corejs2_helpers_esm_objectSpread__WEBPACK_IMPORTED_MODULE_5__["default"])({}, selected, {
            dom: this.categoryRef.current
          })
        }, this.handleBack);
      }

      if (!prevState.toFront && toFront) {
        this.setState({
          toFront: false,
          selected: Object(_babel_runtime_corejs2_helpers_esm_objectSpread__WEBPACK_IMPORTED_MODULE_5__["default"])({}, selected, {
            dom: this.categoryRef.current
          })
        });
      }
    }
  }, {
    key: "render",
    value: function render() {
      var _classnames,
          _this2 = this;

      var _this$state2 = this.state,
          index = _this$state2.index,
          selected = _this$state2.selected;
      return react__WEBPACK_IMPORTED_MODULE_13___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_13___default.a.Fragment, null, react__WEBPACK_IMPORTED_MODULE_13___default.a.createElement("section", {
        className: _hardware_less__WEBPACK_IMPORTED_MODULE_34___default.a.view,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 357
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_13___default.a.createElement("div", {
        className: _hardware_less__WEBPACK_IMPORTED_MODULE_34___default.a.navigation,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 358
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_13___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_14___default()(_hardware_less__WEBPACK_IMPORTED_MODULE_34___default.a.category, (_classnames = {}, Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_12__["default"])(_classnames, _hardware_less__WEBPACK_IMPORTED_MODULE_34___default.a.hover, !selected.animating && !selected.animIn), Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_12__["default"])(_classnames, _hardware_less__WEBPACK_IMPORTED_MODULE_34___default.a.unVisibility, selected.animIn && !selected.animating), Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_12__["default"])(_classnames, 'no-events', selected.animating || selected.animIn), _classnames)),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 359
        },
        __self: this
      }, _productions__WEBPACK_IMPORTED_MODULE_32__["categorys"].map(function (_ref8, index) {
        var name = _ref8.name,
            products = _ref8.products;
        return react__WEBPACK_IMPORTED_MODULE_13___default.a.createElement("div", {
          key: name,
          ref: index + 1 === selected.index ? _this2.categoryRef : null,
          onClick: _this2.handleClick({
            title: name,
            index: index + 1,
            image: images[index],
            className: _hardware_less__WEBPACK_IMPORTED_MODULE_34___default.a["itemImage".concat(index + 1)]
          }),
          className: classnames__WEBPACK_IMPORTED_MODULE_14___default()(_hardware_less__WEBPACK_IMPORTED_MODULE_34___default.a.item, _hardware_less__WEBPACK_IMPORTED_MODULE_34___default.a["itemImage".concat(index + 1)]),
          __source: {
            fileName: _jsxFileName,
            lineNumber: 366
          },
          __self: this
        }, react__WEBPACK_IMPORTED_MODULE_13___default.a.createElement("h2", {
          className: _hardware_less__WEBPACK_IMPORTED_MODULE_34___default.a.categoryTitle,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 376
          },
          __self: this
        }, name), react__WEBPACK_IMPORTED_MODULE_13___default.a.createElement("p", {
          className: _hardware_less__WEBPACK_IMPORTED_MODULE_34___default.a.categoryProducts,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 377
          },
          __self: this
        }, products), react__WEBPACK_IMPORTED_MODULE_13___default.a.createElement(_components_SvgIcon__WEBPACK_IMPORTED_MODULE_15__["default"], {
          className: _hardware_less__WEBPACK_IMPORTED_MODULE_34___default.a.categoryIcon,
          icon: icons[index],
          __source: {
            fileName: _jsxFileName,
            lineNumber: 378
          },
          __self: this
        }));
      })))), react__WEBPACK_IMPORTED_MODULE_13___default.a.createElement("section", {
        ref: this.pageRef,
        className: _hardware_less__WEBPACK_IMPORTED_MODULE_34___default.a.container,
        onTransitionEnd: this.handleTransitionEnd(selected.animIn),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 385
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_13___default.a.createElement("img", {
        alt: "",
        src: selected.image,
        ref: this.pageImageRef,
        onLoad: !selected.animIn ? this.handleImageLoad : null,
        style: selected.animIn && !selected.animating ? {
          display: 'none'
        } : {},
        className: _hardware_less__WEBPACK_IMPORTED_MODULE_34___default.a.containerImage,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 389
        },
        __self: this
      })), react__WEBPACK_IMPORTED_MODULE_13___default.a.createElement("div", {
        ref: this.pageFakeContantRef,
        className: _hardware_less__WEBPACK_IMPORTED_MODULE_34___default.a.fakeContant,
        style: !selected.animating ? {
          display: 'none'
        } : {},
        __source: {
          fileName: _jsxFileName,
          lineNumber: 401
        },
        __self: this
      }), selected.animIn && index !== 0 ? react__WEBPACK_IMPORTED_MODULE_13___default.a.createElement(_category__WEBPACK_IMPORTED_MODULE_33__["default"], {
        index: index,
        router: this.props.router,
        category: _productions__WEBPACK_IMPORTED_MODULE_32__["categorys"][index - 1],
        bannerImage: selected.image,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 406
        },
        __self: this
      }) : null);
    }
  }]);

  return Hardware;
}(react__WEBPACK_IMPORTED_MODULE_13___default.a.Component), Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_12__["default"])(_class2, "contextType", _components_Themes__WEBPACK_IMPORTED_MODULE_17__["ThemeContext"]), Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_12__["default"])(_class2, "getInitialProps",
/*#__PURE__*/
function () {
  var _ref9 = Object(_babel_runtime_corejs2_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_2__["default"])(
  /*#__PURE__*/
  _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_1___default.a.mark(function _callee(ctx_) {
    var layoutProps;
    return _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_1___default.a.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            layoutProps = {
              pageProps: {
                scrollClass: {
                  '>=0': 'page-header-hold',
                  '>=(300 - 64)': 'page-header-dark banner-menu-fixed'
                }
              },
              header: {
                transparent: true
              },
              footer: false,
              title: '智能硬件'
            };
            return _context.abrupt("return", {
              layoutProps: layoutProps
            });

          case 2:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));

  return function (_x) {
    return _ref9.apply(this, arguments);
  };
}()), Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_12__["default"])(_class2, "getDerivedStateFromProps", function (props, state) {
  // 参数 category: >=1&<=6
  var router = props.router;
  var index = ~~router.query.category;

  if (index > 0 && index <= _productions__WEBPACK_IMPORTED_MODULE_32__["categorys"].length) {
    if (state.index === 0 && _babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_0___default()(state.selected).length) {
      return null;
    } else if (state.index === 0) {
      return {
        toFront: true,
        selected: {
          index: index,
          title: _productions__WEBPACK_IMPORTED_MODULE_32__["categorys"][index - 1].name,
          image: images[index - 1],
          className: _hardware_less__WEBPACK_IMPORTED_MODULE_34___default.a["itemImage".concat(index)],
          dom: null
        }
      };
    }

    return {
      index: index,
      selected: {
        index: index,
        title: _productions__WEBPACK_IMPORTED_MODULE_32__["categorys"][index - 1].name,
        image: images[index - 1],
        className: _hardware_less__WEBPACK_IMPORTED_MODULE_34___default.a["itemImage".concat(index)],
        animIn: true,
        animating: false,
        dom: null
      }
    };
  } else if (state.index !== index && index === 0) {
    return !state.toBack ? {
      toBack: true
    } : null;
  } else if (router.query.category) {
    next_router__WEBPACK_IMPORTED_MODULE_16___default.a.replace('/hardware', '/hardware', {
      shallow: true
    });
  }

  return null;
}), _temp)) || _class;

/* harmony default export */ __webpack_exports__["default"] = (Hardware);

/***/ })

})
//# sourceMappingURL=hardware.js.6493a0a85b2ffd240c6e.hot-update.js.map