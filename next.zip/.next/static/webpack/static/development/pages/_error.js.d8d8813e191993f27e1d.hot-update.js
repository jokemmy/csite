webpackHotUpdate("static/development/pages/_error.js",{

/***/ "./node_modules/next/dist/build/webpack/loaders/next-client-pages-loader.js?page=%2F_error&absolutePagePath=%2FUsers%2Frainx%2FDocuments%2FGithub%2Fcsite%2Fpages%2F_error.js!./":
false,

/***/ "./pages/_error.js":
false,

/***/ 19:
false

})
//# sourceMappingURL=_error.js.d8d8813e191993f27e1d.hot-update.js.map