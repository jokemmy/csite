module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../../../../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 13);
/******/ })
/************************************************************************/
/******/ ({

/***/ "/+P4":
/***/ (function(module, exports, __webpack_require__) {

var _Object$getPrototypeOf = __webpack_require__("Bhuq");

var _Object$setPrototypeOf = __webpack_require__("TRZx");

function _getPrototypeOf(o) {
  module.exports = _getPrototypeOf = _Object$setPrototypeOf ? _Object$getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || _Object$getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}

module.exports = _getPrototypeOf;

/***/ }),

/***/ "/+oN":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/get-prototype-of");

/***/ }),

/***/ "/HRN":
/***/ (function(module, exports) {

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

module.exports = _classCallCheck;

/***/ }),

/***/ "0iUn":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _classCallCheck; });
function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

/***/ }),

/***/ "1+QS":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/classCallCheck.js
var classCallCheck = __webpack_require__("0iUn");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/createClass.js
var createClass = __webpack_require__("sLSF");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/possibleConstructorReturn.js + 1 modules
var possibleConstructorReturn = __webpack_require__("MI3g");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/getPrototypeOf.js
var getPrototypeOf = __webpack_require__("a7VT");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/assertThisInitialized.js
var assertThisInitialized = __webpack_require__("AT/M");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/inherits.js + 1 modules
var inherits = __webpack_require__("Tit0");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/defineProperty.js
var defineProperty = __webpack_require__("vYYK");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/extends.js
var esm_extends = __webpack_require__("kOwS");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/objectWithoutProperties.js + 1 modules
var objectWithoutProperties = __webpack_require__("qNsG");

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__("cDcd");
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);

// EXTERNAL MODULE: external "whatitis"
var external_whatitis_ = __webpack_require__("lOhm");
var external_whatitis_default = /*#__PURE__*/__webpack_require__.n(external_whatitis_);

// EXTERNAL MODULE: external "omit.js"
var external_omit_js_ = __webpack_require__("LSCY");
var external_omit_js_default = /*#__PURE__*/__webpack_require__.n(external_omit_js_);

// EXTERNAL MODULE: external "rc-animate"
var external_rc_animate_ = __webpack_require__("Vam4");
var external_rc_animate_default = /*#__PURE__*/__webpack_require__.n(external_rc_animate_);

// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__("K2gz");
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);

// EXTERNAL MODULE: external "react-hammerjs"
var external_react_hammerjs_ = __webpack_require__("BgYr");
var external_react_hammerjs_default = /*#__PURE__*/__webpack_require__.n(external_react_hammerjs_);

// EXTERNAL MODULE: external "rc-tween-one"
var external_rc_tween_one_ = __webpack_require__("VNO/");
var external_rc_tween_one_default = /*#__PURE__*/__webpack_require__.n(external_rc_tween_one_);

// EXTERNAL MODULE: external "rc-util/lib/Dom/addEventListener"
var addEventListener_ = __webpack_require__("BI0l");
var addEventListener_default = /*#__PURE__*/__webpack_require__.n(addEventListener_);

// EXTERNAL MODULE: ./lib/requestAnimationFrame.js
var requestAnimationFrame = __webpack_require__("ushU");

// EXTERNAL MODULE: ./assets/motions/cScale.less
var cScale = __webpack_require__("SC1p");

// EXTERNAL MODULE: ./assets/motions/cSlideUp.less
var cSlideUp = __webpack_require__("Te8+");

// EXTERNAL MODULE: ./assets/motions/cSlideDown.less
var cSlideDown = __webpack_require__("Qnt8");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/objectSpread.js
var objectSpread = __webpack_require__("zrwo");

// EXTERNAL MODULE: ./components/Carousel/points.less
var Carousel_points = __webpack_require__("2crN");
var points_default = /*#__PURE__*/__webpack_require__.n(Carousel_points);

// CONCATENATED MODULE: ./components/Carousel/points.js












var points_Points =
/*#__PURE__*/
function (_React$Component) {
  Object(inherits["a" /* default */])(Points, _React$Component);

  function Points() {
    var _getPrototypeOf2;

    var _this;

    Object(classCallCheck["a" /* default */])(this, Points);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = Object(possibleConstructorReturn["a" /* default */])(this, (_getPrototypeOf2 = Object(getPrototypeOf["a" /* default */])(Points)).call.apply(_getPrototypeOf2, [this].concat(args)));

    Object(defineProperty["a" /* default */])(Object(assertThisInitialized["a" /* default */])(_this), "handleClick", function (i) {
      return function () {
        var _this$props = _this.props,
            onChange = _this$props.onChange,
            index = _this$props.index;

        if (index !== i) {
          onChange(i);
        }
      };
    });

    return _this;
  }

  Object(createClass["a" /* default */])(Points, [{
    key: "render",
    value: function render() {
      var _this2 = this;

      var _this$props2 = this.props,
          points = _this$props2.points,
          index = _this$props2.index,
          size = _this$props2.size;
      var sizeStyle = {
        height: "".concat(100 / points.length, "%")
      };

      var blockProps = function blockProps(i) {
        return {
          className: points_default.a.block,
          onClick: _this2.handleClick(i),
          style: sizeStyle
        };
      };

      return external_react_default.a.createElement("div", {
        className: points_default.a.track,
        style: {
          height: size
        }
      }, points.map(function (point, i) {
        return i === index ? external_react_default.a.createElement("div", Object(esm_extends["a" /* default */])({
          key: "point-".concat(i)
        }, blockProps(i))) : external_react_default.a.createElement("div", Object(esm_extends["a" /* default */])({
          key: "active-point-".concat(i)
        }, blockProps(i)));
      }), external_react_default.a.createElement("div", {
        className: points_default.a.thumb,
        style: Object(objectSpread["a" /* default */])({
          top: "".concat(index * 100 / points.length, "%")
        }, sizeStyle)
      }));
    }
  }]);

  return Points;
}(external_react_default.a.Component);

/* harmony default export */ var components_Carousel_points = (points_Points);
// EXTERNAL MODULE: ./components/Carousel/carousel.less
var carousel = __webpack_require__("Pnzm");
var carousel_default = /*#__PURE__*/__webpack_require__.n(carousel);

// CONCATENATED MODULE: ./components/Carousel/index.js
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CarouselContext; });























var TweenOneGroup = external_rc_tween_one_default.a.TweenOneGroup;
var CarouselContext = external_react_default.a.createContext({
  isEnable: true
});

function HammerHoc(_ref) {
  var disabled = _ref.disabled,
      children = _ref.children,
      props = Object(objectWithoutProperties["a" /* default */])(_ref, ["disabled", "children"]);

  return disabled ? children : external_react_default.a.createElement(external_react_hammerjs_default.a, Object(esm_extends["a" /* default */])({}, props, {
    direction: "DIRECTION_VERTICAL"
  }), children);
}

var Carousel_Carousel =
/*#__PURE__*/
function (_React$Component) {
  Object(inherits["a" /* default */])(Carousel, _React$Component);

  function Carousel() {
    var _getPrototypeOf2;

    var _this;

    Object(classCallCheck["a" /* default */])(this, Carousel);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = Object(possibleConstructorReturn["a" /* default */])(this, (_getPrototypeOf2 = Object(getPrototypeOf["a" /* default */])(Carousel)).call.apply(_getPrototypeOf2, [this].concat(args)));

    Object(defineProperty["a" /* default */])(Object(assertThisInitialized["a" /* default */])(_this), "state", {
      index: 0,
      scrolling: false,
      isEnable: true
    });

    Object(defineProperty["a" /* default */])(Object(assertThisInitialized["a" /* default */])(_this), "handleWheel", function (e) {
      // 正数页面向上,负数页面向下
      var delta = (whatenvis.firefox ? 3 : 1) * e.delta;
      var _this$props = _this.props,
          children = _this$props.children,
          disabled = _this$props.disabled;
      var _this$state = _this.state,
          index = _this$state.index,
          scrolling = _this$state.scrolling;
      var count = external_react_default.a.Children.toArray(children).length - 1;

      if (!disabled && scrolling === false) {
        if (delta > 0 && index > 0) {
          _this.handleChange(index - 1);
        } else if (delta < 0 && index < count) {
          _this.handleChange(index + 1);
        }
      }
    });

    Object(defineProperty["a" /* default */])(Object(assertThisInitialized["a" /* default */])(_this), "handleScrollEnd", function (_, exists) {
      if (exists) {
        var onEnd = _this.props.onEnd;
        _this.state.scrolling = false; // eslint-disable-line

        _this.setState({
          isEnable: true
        }, external_whatitis_default.a.Function(onEnd) ? onEnd : null);
      }
    });

    Object(defineProperty["a" /* default */])(Object(assertThisInitialized["a" /* default */])(_this), "handleChange", function (targetIndex) {
      var _this$props2 = _this.props,
          index = _this$props2.index,
          onChange = _this$props2.onChange;

      if (external_whatitis_default.a.Number(index) && index >= 0) {
        external_whatitis_default.a.Function(onChange) && onChange(targetIndex);
      } else {
        var _this$state2 = _this.state,
            _index = _this$state2.index,
            scrolling = _this$state2.scrolling;

        if (scrolling === false) {
          _this.state.scrolling = true; // eslint-disable-line

          _this.setState({
            isEnable: false
          }, function () {
            _this.rafHandle = Object(requestAnimationFrame["b" /* requestAnimationFrame */])(function () {
              _this.rafHandle = null;

              _this.setState({
                index: targetIndex,
                direction: targetIndex > _index ? 1 : 0
              });
            });
          });
        }
      }
    });

    Object(defineProperty["a" /* default */])(Object(assertThisInitialized["a" /* default */])(_this), "handleSwipe", function (event) {
      var index = _this.state.index;
      var children = _this.props.children;
      var count = external_react_default.a.Children.toArray(children).length;
      var offsetDirection = event.offsetDirection;
      event.preventDefault();

      if (offsetDirection === 8 && index < count - 1) {
        // 上
        _this.handleChange(index + 1);
      }

      if (offsetDirection === 16 && index > 0) {
        // 下
        _this.handleChange(index - 1);
      }
    });

    Object(defineProperty["a" /* default */])(Object(assertThisInitialized["a" /* default */])(_this), "handleSlider", function () {
      var children = _this.props.children;
      var _this$state3 = _this.state,
          index = _this$state3.index,
          scrolling = _this$state3.scrolling;
      var count = external_react_default.a.Children.toArray(children).length - 1;

      if (scrolling === false) {
        if (index < count) {
          _this.handleChange(index + 1);
        }
      }
    });

    return _this;
  }

  Object(createClass["a" /* default */])(Carousel, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      var eventName = whatenvis.firefox ? 'DOMMouseScroll' : 'mousewheel';
      this.wheelListener = addEventListener_default()(document.body, eventName, this.handleWheel);
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      if (this.wheelListener) {
        this.wheelListener.remove();
        this.wheelListener = null;
      }

      if (this.rafHandle) {
        Object(requestAnimationFrame["a" /* cancelAnimationFrame */])(this.rafHandle);
        this.rafHandle = null;
      }
    }
  }, {
    key: "render",
    value: function render() {
      var _this$state4 = this.state,
          index = _this$state4.index,
          direction = _this$state4.direction,
          isEnable = _this$state4.isEnable;

      var _omit = external_omit_js_default()(this.props, ['onEnd']),
          children = _omit.children,
          className = _omit.className,
          disabled = _omit.disabled,
          showPoints = _omit.showPoints,
          showArrow = _omit.showArrow,
          props = Object(objectWithoutProperties["a" /* default */])(_omit, ["children", "className", "disabled", "showPoints", "showArrow"]);

      var childArray = external_react_default.a.Children.toArray(children);
      var count = childArray.length;
      var child = childArray.find(function (_, i) {
        return i === index;
      });
      return external_react_default.a.createElement(CarouselContext.Provider, {
        value: {
          isEnable: isEnable
        }
      }, external_react_default.a.createElement(HammerHoc, {
        onSwipe: this.handleSwipe,
        disabled: disabled
      }, external_react_default.a.createElement("div", Object(esm_extends["a" /* default */])({}, props, {
        className: external_classnames_default()(className, carousel_default.a.carousel)
      }), external_react_default.a.createElement(external_rc_animate_default.a, {
        component: "div",
        transitionAppear: false,
        onEnd: this.handleScrollEnd,
        transitionName: direction ? 'c-slide-up' : 'c-slide-down'
      }, external_react_default.a.createElement("div", {
        key: "".concat(index),
        className: carousel_default.a.paper
      }, external_react_default.a.createElement("div", {
        className: "c-scale"
      }, child))), showPoints ? external_react_default.a.createElement(components_Carousel_points, {
        size: "100%",
        index: index,
        onChange: this.handleChange,
        points: Array(count).fill(1)
      }) : null, external_react_default.a.createElement(TweenOneGroup, {
        component: "",
        enter: {
          opacity: 0,
          type: 'from',
          duration: 2000
        },
        leave: {
          opacity: 0,
          duration: 2000
        }
      }, showArrow && count - 1 > index ? external_react_default.a.createElement("div", {
        key: "arrow",
        className: carousel_default.a.arrowDown,
        onClick: this.handleSlider
      }, external_react_default.a.createElement("div", {
        className: carousel_default.a.arrowDownAnim
      }, external_react_default.a.createElement("em", null), external_react_default.a.createElement("em", null), external_react_default.a.createElement("em", null))) : null))));
    }
  }]);

  return Carousel;
}(external_react_default.a.Component);

Object(defineProperty["a" /* default */])(Carousel_Carousel, "defaultProps", {
  showArrow: true,
  showPoints: true
});

Object(defineProperty["a" /* default */])(Carousel_Carousel, "getDerivedStateFromProps", function (props, state) {
  if (external_whatitis_default.a.Number(props.index) && props.index >= 0 && state.index !== props.index) {
    return {
      index: props.index,
      direction: props.index > state.index ? 1 : 0,
      scrolling: false,
      isEnable: false
    };
  }

  return null;
});

/* harmony default export */ var components_Carousel = __webpack_exports__["b"] = (Carousel_Carousel);

/***/ }),

/***/ 13:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("bKMw");


/***/ }),

/***/ "2crN":
/***/ (function(module, exports) {

module.exports = {
	"track": "_1ujYANvT",
	"block": "_1_K01DDo",
	"thumb": "_3m-xWWqN"
};

/***/ }),

/***/ "4Q3z":
/***/ (function(module, exports) {

module.exports = require("next/router");

/***/ }),

/***/ "4mXO":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("k1wZ");

/***/ }),

/***/ "9Jkg":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("fozc");

/***/ }),

/***/ "AT/M":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _assertThisInitialized; });
function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

/***/ }),

/***/ "BE5S":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return Icon; });
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("kOwS");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("qNsG");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("K2gz");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _svgIcon_less__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("flPq");
/* harmony import */ var _svgIcon_less__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_svgIcon_less__WEBPACK_IMPORTED_MODULE_4__);





function Icon(_ref) {
  var icon = _ref.icon,
      className = _ref.className,
      props = Object(_babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(_ref, ["icon", "className"]);

  return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("svg", Object(_babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])({
    "aria-hidden": "true"
  }, props, {
    className: classnames__WEBPACK_IMPORTED_MODULE_3___default()(_svgIcon_less__WEBPACK_IMPORTED_MODULE_4___default.a.svgIcon, className)
  }), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("use", {
    xlinkHref: "#".concat(icon.id)
  }));
}

/***/ }),

/***/ "BI0l":
/***/ (function(module, exports) {

module.exports = require("rc-util/lib/Dom/addEventListener");

/***/ }),

/***/ "BgYr":
/***/ (function(module, exports) {

module.exports = require("react-hammerjs");

/***/ }),

/***/ "Bhuq":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("/+oN");

/***/ }),

/***/ "IMUT":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("kOwS");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("qNsG");
/* harmony import */ var _babel_runtime_corejs2_core_js_object_assign__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("UXZV");
/* harmony import */ var _babel_runtime_corejs2_core_js_object_assign__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_core_js_object_assign__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("0iUn");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("sLSF");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("MI3g");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("a7VT");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__("Tit0");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__("vYYK");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var omit_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__("LSCY");
/* harmony import */ var omit_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(omit_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var parallax_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__("W0Av");
/* harmony import */ var parallax_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(parallax_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _components_Carousel__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__("1+QS");












 //https://ken.artbees.net/wide-parallax-startup/

var Scene =
/*#__PURE__*/
function (_React$Component) {
  Object(_babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_7__[/* default */ "a"])(Scene, _React$Component);

  function Scene(props) {
    var _this;

    Object(_babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"])(this, Scene);

    _this = Object(_babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"])(this, Object(_babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_6__[/* default */ "a"])(Scene).call(this, props));
    _this.sceneRef = react__WEBPACK_IMPORTED_MODULE_9___default.a.createRef();
    return _this;
  }

  Object(_babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_4__[/* default */ "a"])(Scene, [{
    key: "componentDidUpdate",
    value: function componentDidUpdate() {
      var isEnable = this.context.isEnable;

      if (isEnable) {
        this.createParallax();
      } else {
        this.destroyParallax();
      }
    }
  }, {
    key: "componentDidMount",
    value: function componentDidMount() {
      var isEnable = this.context.isEnable;

      if (isEnable) {
        this.createParallax();
      }
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      this.destroyParallax();
    }
  }, {
    key: "createParallax",
    value: function createParallax() {
      var defaultOptions = {
        selector: '.paper'
      };
      var options = this.props.options;
      this.parallaxInstance = new parallax_js__WEBPACK_IMPORTED_MODULE_11___default.a(this.sceneRef.current, _babel_runtime_corejs2_core_js_object_assign__WEBPACK_IMPORTED_MODULE_2___default()(defaultOptions, options));
    }
  }, {
    key: "destroyParallax",
    value: function destroyParallax() {
      if (this.parallaxInstance) {
        this.parallaxInstance.destroy();
        this.parallaxInstance = null;
      }
    }
  }, {
    key: "render",
    value: function render() {
      var _omit = omit_js__WEBPACK_IMPORTED_MODULE_10___default()(this.props, ['options']),
          children = _omit.children,
          className = _omit.className,
          props = Object(_babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(_omit, ["children", "className"]);

      return react__WEBPACK_IMPORTED_MODULE_9___default.a.createElement("div", Object(_babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])({}, props, {
        ref: this.sceneRef,
        className: "".concat(className ? "".concat(className, " ") : '', "scene")
      }), children);
    }
  }]);

  return Scene;
}(react__WEBPACK_IMPORTED_MODULE_9___default.a.Component);

Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_8__[/* default */ "a"])(Scene, "contextType", _components_Carousel__WEBPACK_IMPORTED_MODULE_12__[/* CarouselContext */ "a"]);

/* harmony default export */ __webpack_exports__["a"] = (Scene);

/***/ }),

/***/ "Jo+v":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("Z6Kq");

/***/ }),

/***/ "K2gz":
/***/ (function(module, exports) {

module.exports = require("classnames");

/***/ }),

/***/ "K47E":
/***/ (function(module, exports) {

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

module.exports = _assertThisInitialized;

/***/ }),

/***/ "KI45":
/***/ (function(module, exports) {

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    default: obj
  };
}

module.exports = _interopRequireDefault;

/***/ }),

/***/ "LSCY":
/***/ (function(module, exports) {

module.exports = require("omit.js");

/***/ }),

/***/ "MI3g":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/symbol/iterator.js
var iterator = __webpack_require__("XVgq");
var iterator_default = /*#__PURE__*/__webpack_require__.n(iterator);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/symbol.js
var symbol = __webpack_require__("Z7t5");
var symbol_default = /*#__PURE__*/__webpack_require__.n(symbol);

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/typeof.js



function typeof_typeof2(obj) { if (typeof symbol_default.a === "function" && typeof iterator_default.a === "symbol") { typeof_typeof2 = function _typeof2(obj) { return typeof obj; }; } else { typeof_typeof2 = function _typeof2(obj) { return obj && typeof symbol_default.a === "function" && obj.constructor === symbol_default.a && obj !== symbol_default.a.prototype ? "symbol" : typeof obj; }; } return typeof_typeof2(obj); }

function typeof_typeof(obj) {
  if (typeof symbol_default.a === "function" && typeof_typeof2(iterator_default.a) === "symbol") {
    typeof_typeof = function _typeof(obj) {
      return typeof_typeof2(obj);
    };
  } else {
    typeof_typeof = function _typeof(obj) {
      return obj && typeof symbol_default.a === "function" && obj.constructor === symbol_default.a && obj !== symbol_default.a.prototype ? "symbol" : typeof_typeof2(obj);
    };
  }

  return typeof_typeof(obj);
}
// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/assertThisInitialized.js
var assertThisInitialized = __webpack_require__("AT/M");

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/possibleConstructorReturn.js
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _possibleConstructorReturn; });


function _possibleConstructorReturn(self, call) {
  if (call && (typeof_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return Object(assertThisInitialized["a" /* default */])(self);
}

/***/ }),

/***/ "N9n2":
/***/ (function(module, exports, __webpack_require__) {

var _Object$create = __webpack_require__("SqZg");

var setPrototypeOf = __webpack_require__("vjea");

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = _Object$create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) setPrototypeOf(subClass, superClass);
}

module.exports = _inherits;

/***/ }),

/***/ "Pnzm":
/***/ (function(module, exports) {

module.exports = {
	"carousel": "QIruQvWN",
	"paper": "IDE1NymA",
	"arrow-down": "_11U8PP3q",
	"arrowDown": "_11U8PP3q",
	"arrow-down-anim": "OiG04KV1",
	"arrowDownAnim": "OiG04KV1",
	"arrowDownAnimKF": "_2nZLV2q0",
	"arrowDownAnimKf": "_2nZLV2q0"
};

/***/ }),

/***/ "QAmA":
/***/ (function(module, exports) {

module.exports = require("svg-baker-runtime/symbol");

/***/ }),

/***/ "QncY":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("kOwS");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("qNsG");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("0iUn");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("sLSF");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("MI3g");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("a7VT");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("Tit0");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);









var Paper =
/*#__PURE__*/
function (_React$Component) {
  Object(_babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_6__[/* default */ "a"])(Paper, _React$Component);

  function Paper() {
    Object(_babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_2__[/* default */ "a"])(this, Paper);

    return Object(_babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__[/* default */ "a"])(this, Object(_babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"])(Paper).apply(this, arguments));
  }

  Object(_babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"])(Paper, [{
    key: "render",
    value: function render() {
      var _this$props = this.props,
          depth = _this$props.depth,
          children = _this$props.children,
          className = _this$props.className,
          props = Object(_babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(_this$props, ["depth", "children", "className"]);

      return react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", Object(_babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])({}, props, {
        className: "".concat(className ? "".concat(className, " ") : '', "paper"),
        "data-depth": depth
      }), children);
    }
  }]);

  return Paper;
}(react__WEBPACK_IMPORTED_MODULE_7___default.a.Component);

/* harmony default export */ __webpack_exports__["a"] = (Paper);

/***/ }),

/***/ "Qnt8":
/***/ (function(module, exports) {

module.exports = {
	"cslideDownIn": "_33bJsfF1",
	"cslideDownOut": "_26zD-TbW"
};

/***/ }),

/***/ "S3+N":
/***/ (function(module, exports, __webpack_require__) {

/* eslint-disable */
var React = __webpack_require__("cDcd");
var SpriteSymbol = __webpack_require__("QAmA");
var sprite = __webpack_require__("TQFg");

var symbol = new SpriteSymbol({
  "id": "1iJgNdIp--sprite",
  "use": "1iJgNdIp--sprite-usage",
  "viewBox": "0 0 1000.637 1000.678",
  "content": "<symbol xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 1000.637 1000.678\" id=\"1iJgNdIp--sprite\"><path d=\"M600.035 774.771l-86.167-86.167a1154.955 1154.955 0 0 1-72.125 43.009L269.049 558.919a964.174 964.174 0 0 1 42.475-72.66l-85.643-85.643c-7.946-7.945-7.951-20.832-.02-28.773l.019-.019 71.948-71.948c55.244-55.194 141.896-63.391 206.515-19.541 128.376-91.134 259.239-119.139 297.139-81.2 37.89 37.93 9.924 168.791-81.205 297.133 43.85 64.619 35.657 151.276-19.54 206.515l-71.949 71.947c-7.927 7.947-20.786 7.965-28.753.041zm-143.91-460.503c-31.787-31.797-83.335-31.796-115.127-.004l-57.556 57.556c-7.951 7.939-7.961 20.831-.026 28.788l.015.015 43.169 43.169zm302.211-71.946c-18.318-18.319-69.745-12.332-130.481 13.41l117.061 117.062c25.814-60.728 31.896-112.078 13.482-130.473zm-31.973 169.497L588.84 274.294a571.686 571.686 0 0 0-134.099 98.933 980.288 980.288 0 0 0-135.316 178.478l129.528 129.528A1068.426 1068.426 0 0 0 627.434 545.92c39.357-39.641 72.722-84.814 98.979-134.111zM686.384 659.65c31.803-31.782 31.798-83.328.007-115.117L556.866 674.057l43.159 43.158c7.956 7.956 20.838 7.956 28.783.012l.021-.021zM484.903 515.755c-31.792-31.792-31.792-83.342-.001-115.132 31.792-31.792 83.341-31.792 115.133 0 31.791 31.79 31.781 83.331-.001 115.132-31.786 31.745-83.29 31.739-115.071-.002zm86.355-86.355c-15.891-15.901-41.667-15.91-57.567-.01-15.9 15.891-15.901 41.665-.005 57.562 15.885 15.895 41.665 15.9 57.57.015l.006-.005c15.896-15.896 15.931-41.655.056-57.562zM182.817 817.899s-3.009-112.122 28.783-143.914c31.792-31.791 83.336-31.798 115.132-.001 31.792 31.792 31.791 83.341-.001 115.133-31.851 31.852-143.914 28.782-143.914 28.782zM297.95 702.768c-15.896-15.896-41.661-15.896-57.562.006-15.89 15.891-28.787 86.344-28.787 86.344s70.447-12.903 86.338-28.793c15.841-15.9 15.819-41.625-.051-57.495z\" fill=\"#fff\" /></symbol>"
});
sprite.add(symbol);

var SvgSpriteIcon = function SvgSpriteIcon(props) {
  return React.createElement(
    'svg',
    Object.assign({
      viewBox: symbol.viewBox
    }, props),
    React.createElement(
      'use',
      {
        xlinkHref: '#' + symbol.id
      }
    )
  );
};

SvgSpriteIcon.viewBox = symbol.viewBox;
SvgSpriteIcon.id = symbol.id;
SvgSpriteIcon.content = symbol.content;
SvgSpriteIcon.url = symbol.url;
SvgSpriteIcon.toString = symbol.toString;

module.exports = SvgSpriteIcon;
module.exports.default = SvgSpriteIcon;


/***/ }),

/***/ "SC1p":
/***/ (function(module, exports) {

module.exports = {
	"cScaleIn": "yzEr1rWc",
	"cScaleOut": "_34mAihAf"
};

/***/ }),

/***/ "SLvO":
/***/ (function(module, exports, __webpack_require__) {

/* eslint-disable */
var React = __webpack_require__("cDcd");
var SpriteSymbol = __webpack_require__("QAmA");
var sprite = __webpack_require__("TQFg");

var symbol = new SpriteSymbol({
  "id": "21uW6yUi--sprite",
  "use": "21uW6yUi--sprite-usage",
  "viewBox": "0 0 1000.637 1000.678",
  "content": "<symbol xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 1000.637 1000.678\" id=\"21uW6yUi--sprite\"><g fill=\"#fff\"><path d=\"M784.324 221.6c-119.518-13.541-209.432-45.867-267.232-96.125l-15.219-13.229-16.401 11.719c-90.606 64.696-180.215 97.469-266.305 97.469h-25.551v357.819c0 109.696 96.712 209.184 295.677 304.177l10.473 5.004 10.636-4.56C707.248 799.3 807.02 696.852 807.02 579.252V224.17zm-28.418 357.652c0 93.283-85.785 178.412-255.055 253.025C330.889 749.39 244.73 664.283 244.73 579.252V271.733c83.606-5.414 168.984-37.293 254.381-95.003 61.29 46.727 147.508 77.89 256.795 92.836z\" /><path d=\"M372.437 466.348c-9.354-10.573-25.501-11.577-36.081-2.224-10.599 9.354-11.583 25.508-2.23 36.093l97.264 110.08c10.091 11.372 24.12 17.207 38.292 17.207a51.312 51.312 0 0 0 39.653-18.756l157.862-193.88c8.906-10.943 7.245-27.036-3.706-35.96-10.938-8.9-27.03-7.265-35.949 3.698L469.7 576.414z\" /></g></symbol>"
});
sprite.add(symbol);

var SvgSpriteIcon = function SvgSpriteIcon(props) {
  return React.createElement(
    'svg',
    Object.assign({
      viewBox: symbol.viewBox
    }, props),
    React.createElement(
      'use',
      {
        xlinkHref: '#' + symbol.id
      }
    )
  );
};

SvgSpriteIcon.viewBox = symbol.viewBox;
SvgSpriteIcon.id = symbol.id;
SvgSpriteIcon.content = symbol.content;
SvgSpriteIcon.url = symbol.url;
SvgSpriteIcon.toString = symbol.toString;

module.exports = SvgSpriteIcon;
module.exports.default = SvgSpriteIcon;


/***/ }),

/***/ "SqZg":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("o5io");

/***/ }),

/***/ "TQFg":
/***/ (function(module, exports) {

module.exports = require("svg-sprite-loader/runtime/sprite.build");

/***/ }),

/***/ "TRZx":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("Wk4r");

/***/ }),

/***/ "TUA0":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/define-property");

/***/ }),

/***/ "Te8+":
/***/ (function(module, exports) {

module.exports = {
	"cslideUpIn": "_1BDx8_C5",
	"cslideUpOut": "_1Ck_eq3l"
};

/***/ }),

/***/ "Tit0":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/create.js
var create = __webpack_require__("SqZg");
var create_default = /*#__PURE__*/__webpack_require__.n(create);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/set-prototype-of.js
var set_prototype_of = __webpack_require__("TRZx");
var set_prototype_of_default = /*#__PURE__*/__webpack_require__.n(set_prototype_of);

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/setPrototypeOf.js

function _setPrototypeOf(o, p) {
  _setPrototypeOf = set_prototype_of_default.a || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}
// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/inherits.js
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _inherits; });


function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = create_default()(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

/***/ }),

/***/ "UXZV":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("dGr4");

/***/ }),

/***/ "VNO/":
/***/ (function(module, exports) {

module.exports = require("rc-tween-one");

/***/ }),

/***/ "Vam4":
/***/ (function(module, exports) {

module.exports = require("rc-animate");

/***/ }),

/***/ "W0Av":
/***/ (function(module, exports) {

module.exports = require("parallax-js");

/***/ }),

/***/ "WaGi":
/***/ (function(module, exports, __webpack_require__) {

var _Object$defineProperty = __webpack_require__("hfKm");

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;

    _Object$defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

module.exports = _createClass;

/***/ }),

/***/ "Wk4r":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/set-prototype-of");

/***/ }),

/***/ "XVgq":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("gHn/");

/***/ }),

/***/ "YFqc":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("cTJO")


/***/ }),

/***/ "Z6Kq":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/get-own-property-descriptor");

/***/ }),

/***/ "Z7t5":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("vqFK");

/***/ }),

/***/ "ZDA2":
/***/ (function(module, exports, __webpack_require__) {

var _typeof = __webpack_require__("iZP3");

var assertThisInitialized = __webpack_require__("K47E");

function _possibleConstructorReturn(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return assertThisInitialized(self);
}

module.exports = _possibleConstructorReturn;

/***/ }),

/***/ "a7VT":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _getPrototypeOf; });
/* harmony import */ var _core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("Bhuq");
/* harmony import */ var _core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("TRZx");
/* harmony import */ var _core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_1__);


function _getPrototypeOf(o) {
  _getPrototypeOf = _core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_1___default.a ? _core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0___default.a : function _getPrototypeOf(o) {
    return o.__proto__ || _core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0___default()(o);
  };
  return _getPrototypeOf(o);
}

/***/ }),

/***/ "bKMw":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("kOwS");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("qNsG");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("0iUn");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("sLSF");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("MI3g");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("a7VT");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("Tit0");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__("YFqc");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__("K2gz");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _components_SvgIcon__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__("BE5S");
/* harmony import */ var _components_Parallax__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__("IMUT");
/* harmony import */ var _components_Parallax_Paper__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__("QncY");
/* harmony import */ var _assets_images_app_banner_4_banner_4_jpg__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__("sNF/");
/* harmony import */ var _assets_images_app_banner_4_banner_4_jpg__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_assets_images_app_banner_4_banner_4_jpg__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _assets_images_app_banner_4_svg_1_svg_sprite__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__("p+Sj");
/* harmony import */ var _assets_images_app_banner_4_svg_1_svg_sprite__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_assets_images_app_banner_4_svg_1_svg_sprite__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _assets_images_app_banner_4_svg_2_svg_sprite__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__("SLvO");
/* harmony import */ var _assets_images_app_banner_4_svg_2_svg_sprite__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_assets_images_app_banner_4_svg_2_svg_sprite__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _assets_images_app_banner_4_svg_3_svg_sprite__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__("S3+N");
/* harmony import */ var _assets_images_app_banner_4_svg_3_svg_sprite__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_assets_images_app_banner_4_svg_3_svg_sprite__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _parallax_less__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__("za0J");
/* harmony import */ var _parallax_less__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(_parallax_less__WEBPACK_IMPORTED_MODULE_17__);


















var options = {
  // selector: '.paper',
  // relativeInput: true
  // clipRelativeInput: true,
  // scalarX: 10,
  // scalarY: 10,
  limitX: 30,
  limitY: 30 // frictionX: 0.1,
  // frictionY: 0.1

};

var WallPaper =
/*#__PURE__*/
function (_React$Component) {
  Object(_babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_6__[/* default */ "a"])(WallPaper, _React$Component);

  function WallPaper() {
    Object(_babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_2__[/* default */ "a"])(this, WallPaper);

    return Object(_babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__[/* default */ "a"])(this, Object(_babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"])(WallPaper).apply(this, arguments));
  }

  Object(_babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"])(WallPaper, [{
    key: "render",
    value: function render() {
      var _this$props = this.props,
          className = _this$props.className,
          props = Object(_babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(_this$props, ["className"]);

      return react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_components_Parallax__WEBPACK_IMPORTED_MODULE_11__[/* default */ "a"], Object(_babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])({}, props, {
        className: classnames__WEBPACK_IMPORTED_MODULE_9___default()(_parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.scene, className),
        options: options
      }), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_components_Parallax_Paper__WEBPACK_IMPORTED_MODULE_12__[/* default */ "a"], {
        depth: 0.2
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.paperBackground,
        style: {
          backgroundImage: "url(".concat(_assets_images_app_banner_4_banner_4_jpg__WEBPACK_IMPORTED_MODULE_13___default.a, ")")
        }
      })), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.leftContent
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_9___default()(_parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.topic, 'AppSiYuan')
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("h1", {
        className: classnames__WEBPACK_IMPORTED_MODULE_9___default()(_parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.topicTitle, 'AppSiYuan')
      }, "\u667A\u6167\u5E94\u7528"), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("p", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.topicDesc
      }, "\u56F4\u7ED5\u6838\u5FC3\u529F\u80FD\uFF0C\u5206\u7C7B\u6784\u5EFA\u529F\u80FD\u5E94\u7528\u4F53\u7CFB\uFF0C\u6D89\u53CA\u591A\u4E2A\u4E1A\u52A1\u9886\u57DF\uFF0C\u4E3A\u7528\u6237\u5E26\u6765\u7EDF\u4E00\u9AD8\u6548\u7684\u7BA1\u7406\u3002"), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.topicExtend
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.topicIcon
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_components_SvgIcon__WEBPACK_IMPORTED_MODULE_10__[/* default */ "a"], {
        icon: _assets_images_app_banner_4_svg_1_svg_sprite__WEBPACK_IMPORTED_MODULE_14___default.a
      }), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.topicLabel
      }, "\u516C\u4E91\u670D\u52A1")), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.topicIcon
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_components_SvgIcon__WEBPACK_IMPORTED_MODULE_10__[/* default */ "a"], {
        icon: _assets_images_app_banner_4_svg_2_svg_sprite__WEBPACK_IMPORTED_MODULE_15___default.a
      }), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.topicLabel
      }, "\u7B80\u5355\u5B89\u5168")), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.topicIcon
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_components_SvgIcon__WEBPACK_IMPORTED_MODULE_10__[/* default */ "a"], {
        icon: _assets_images_app_banner_4_svg_3_svg_sprite__WEBPACK_IMPORTED_MODULE_16___default.a
      }), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.topicLabel
      }, "\u7EDF\u4E00\u9AD8\u6548"))), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.topicAction
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(next_link__WEBPACK_IMPORTED_MODULE_8___default.a, {
        as: "/store",
        href: "/store"
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("a", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.topicButton
      }, "\u4E86\u89E3\u66F4\u591A"))))));
    }
  }]);

  return WallPaper;
}(react__WEBPACK_IMPORTED_MODULE_7___default.a.Component);

/* harmony default export */ __webpack_exports__["default"] = (WallPaper);

/***/ }),

/***/ "bzos":
/***/ (function(module, exports) {

module.exports = require("url");

/***/ }),

/***/ "cDcd":
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "cTJO":
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/* global __NEXT_DATA__ */

var _interopRequireDefault = __webpack_require__("KI45");

var _stringify = _interopRequireDefault(__webpack_require__("9Jkg"));

var _classCallCheck2 = _interopRequireDefault(__webpack_require__("/HRN"));

var _createClass2 = _interopRequireDefault(__webpack_require__("WaGi"));

var _possibleConstructorReturn2 = _interopRequireDefault(__webpack_require__("ZDA2"));

var _getPrototypeOf2 = _interopRequireDefault(__webpack_require__("/+P4"));

var _inherits2 = _interopRequireDefault(__webpack_require__("N9n2"));

var __importStar = void 0 && (void 0).__importStar || function (mod) {
  if (mod && mod.__esModule) return mod;
  var result = {};
  if (mod != null) for (var k in mod) {
    if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
  }
  result["default"] = mod;
  return result;
};

var __importDefault = void 0 && (void 0).__importDefault || function (mod) {
  return mod && mod.__esModule ? mod : {
    "default": mod
  };
};

Object.defineProperty(exports, "__esModule", {
  value: true
});

var url_1 = __webpack_require__("bzos");

var react_1 = __importStar(__webpack_require__("cDcd"));

var prop_types_1 = __importDefault(__webpack_require__("rf6O"));

var router_1 = __importStar(__webpack_require__("4Q3z"));

var utils_1 = __webpack_require__("p8BD");

function isLocal(href) {
  var url = url_1.parse(href, false, true);
  var origin = url_1.parse(utils_1.getLocationOrigin(), false, true);
  return !url.host || url.protocol === origin.protocol && url.host === origin.host;
}

function memoizedFormatUrl(formatFunc) {
  var lastHref = null;
  var lastAs = null;
  var lastResult = null;
  return function (href, as) {
    if (href === lastHref && as === lastAs) {
      return lastResult;
    }

    var result = formatFunc(href, as);
    lastHref = href;
    lastAs = as;
    lastResult = result;
    return result;
  };
}

function formatUrl(url) {
  return url && typeof url === 'object' ? utils_1.formatWithValidation(url) : url;
}

var Link =
/*#__PURE__*/
function (_react_1$Component) {
  (0, _inherits2.default)(Link, _react_1$Component);

  function Link() {
    var _this;

    (0, _classCallCheck2.default)(this, Link);
    _this = (0, _possibleConstructorReturn2.default)(this, (0, _getPrototypeOf2.default)(Link).apply(this, arguments)); // The function is memoized so that no extra lifecycles are needed
    // as per https://reactjs.org/blog/2018/06/07/you-probably-dont-need-derived-state.html

    _this.formatUrls = memoizedFormatUrl(function (href, asHref) {
      return {
        href: formatUrl(href),
        as: formatUrl(asHref, true)
      };
    });

    _this.linkClicked = function (e) {
      var _e$currentTarget = e.currentTarget,
          nodeName = _e$currentTarget.nodeName,
          target = _e$currentTarget.target;

      if (nodeName === 'A' && (target && target !== '_self' || e.metaKey || e.ctrlKey || e.shiftKey || e.nativeEvent && e.nativeEvent.which === 2)) {
        // ignore click for new tab / new window behavior
        return;
      }

      var _this$formatUrls = _this.formatUrls(_this.props.href, _this.props.as),
          href = _this$formatUrls.href,
          as = _this$formatUrls.as;

      if (!isLocal(href)) {
        // ignore click if it's outside our scope
        return;
      }

      var pathname = window.location.pathname;
      href = url_1.resolve(pathname, href);
      as = as ? url_1.resolve(pathname, as) : href;
      e.preventDefault(); //  avoid scroll for urls with anchor refs

      var scroll = _this.props.scroll;

      if (scroll == null) {
        scroll = as.indexOf('#') < 0;
      } // replace state instead of push if prop is present


      router_1.default[_this.props.replace ? 'replace' : 'push'](href, as, {
        shallow: _this.props.shallow
      }).then(function (success) {
        if (!success) return;

        if (scroll) {
          window.scrollTo(0, 0);
          document.body.focus();
        }
      }).catch(function (err) {
        if (_this.props.onError) _this.props.onError(err);
      });
    };

    return _this;
  }

  (0, _createClass2.default)(Link, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      this.prefetch();
    }
  }, {
    key: "componentDidUpdate",
    value: function componentDidUpdate(prevProps) {
      if ((0, _stringify.default)(this.props.href) !== (0, _stringify.default)(prevProps.href)) {
        this.prefetch();
      }
    }
  }, {
    key: "prefetch",
    value: function prefetch() {
      if (!this.props.prefetch) return;
      if (typeof window === 'undefined') return; // Prefetch the JSON page if asked (only in the client)

      var pathname = window.location.pathname;

      var _this$formatUrls2 = this.formatUrls(this.props.href, this.props.as),
          parsedHref = _this$formatUrls2.href;

      var href = url_1.resolve(pathname, parsedHref);
      router_1.default.prefetch(href);
    }
  }, {
    key: "render",
    value: function render() {
      var _this2 = this;

      var children = this.props.children;

      var _this$formatUrls3 = this.formatUrls(this.props.href, this.props.as),
          href = _this$formatUrls3.href,
          as = _this$formatUrls3.as; // Deprecated. Warning shown by propType check. If the childen provided is a string (<Link>example</Link>) we wrap it in an <a> tag


      if (typeof children === 'string') {
        children = react_1.default.createElement("a", null, children);
      } // This will return the first child, if multiple are provided it will throw an error


      var child = react_1.Children.only(children);
      var props = {
        onClick: function onClick(e) {
          if (child.props && typeof child.props.onClick === 'function') {
            child.props.onClick(e);
          }

          if (!e.defaultPrevented) {
            _this2.linkClicked(e);
          }
        }
      }; // If child is an <a> tag and doesn't have a href attribute, or if the 'passHref' property is
      // defined, we specify the current 'href', so that repetition is not needed by the user

      if (this.props.passHref || child.type === 'a' && !('href' in child.props)) {
        props.href = as || href;
      } // Add the ending slash to the paths. So, we can serve the
      // "<page>/index.html" directly.


      if (true) {
        if (props.href && typeof __NEXT_DATA__ !== 'undefined' && __NEXT_DATA__.nextExport) {
          props.href = router_1.Router._rewriteUrlForNextExport(props.href);
        }
      }

      return react_1.default.cloneElement(child, props);
    }
  }]);
  return Link;
}(react_1.Component);

if (false) { var exact, warn; }

exports.default = Link;

/***/ }),

/***/ "dGr4":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/assign");

/***/ }),

/***/ "flPq":
/***/ (function(module, exports) {

module.exports = {
	"svg-icon": "_39UYRa5H",
	"svgIcon": "_39UYRa5H"
};

/***/ }),

/***/ "fozc":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/json/stringify");

/***/ }),

/***/ "gHn/":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/symbol/iterator");

/***/ }),

/***/ "hfKm":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("TUA0");

/***/ }),

/***/ "iZP3":
/***/ (function(module, exports, __webpack_require__) {

var _Symbol$iterator = __webpack_require__("XVgq");

var _Symbol = __webpack_require__("Z7t5");

function _typeof2(obj) { if (typeof _Symbol === "function" && typeof _Symbol$iterator === "symbol") { _typeof2 = function _typeof2(obj) { return typeof obj; }; } else { _typeof2 = function _typeof2(obj) { return obj && typeof _Symbol === "function" && obj.constructor === _Symbol && obj !== _Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof2(obj); }

function _typeof(obj) {
  if (typeof _Symbol === "function" && _typeof2(_Symbol$iterator) === "symbol") {
    module.exports = _typeof = function _typeof(obj) {
      return _typeof2(obj);
    };
  } else {
    module.exports = _typeof = function _typeof(obj) {
      return obj && typeof _Symbol === "function" && obj.constructor === _Symbol && obj !== _Symbol.prototype ? "symbol" : _typeof2(obj);
    };
  }

  return _typeof(obj);
}

module.exports = _typeof;

/***/ }),

/***/ "k1wZ":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/get-own-property-symbols");

/***/ }),

/***/ "kOwS":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _extends; });
/* harmony import */ var _core_js_object_assign__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("UXZV");
/* harmony import */ var _core_js_object_assign__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_assign__WEBPACK_IMPORTED_MODULE_0__);

function _extends() {
  _extends = _core_js_object_assign__WEBPACK_IMPORTED_MODULE_0___default.a || function (target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];

      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }

    return target;
  };

  return _extends.apply(this, arguments);
}

/***/ }),

/***/ "lOhm":
/***/ (function(module, exports) {

module.exports = require("whatitis");

/***/ }),

/***/ "o5io":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/create");

/***/ }),

/***/ "p+Sj":
/***/ (function(module, exports, __webpack_require__) {

/* eslint-disable */
var React = __webpack_require__("cDcd");
var SpriteSymbol = __webpack_require__("QAmA");
var sprite = __webpack_require__("TQFg");

var symbol = new SpriteSymbol({
  "id": "2CYjp8SS--sprite",
  "use": "2CYjp8SS--sprite-usage",
  "viewBox": "0 0 1000.637 1000.678",
  "content": "<symbol xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 1000.637 1000.678\" id=\"2CYjp8SS--sprite\"><g fill=\"#fff\"><path d=\"M414.745 756.688h-97.152c-45.385 0-88.122-17.683-120.225-49.786-32.11-32.114-49.792-74.845-49.792-120.23s17.683-88.116 49.792-120.225c32.103-32.109 74.839-49.793 120.225-49.793 13.438 0 24.288-10.851 24.288-24.287v-.301c0-58.367 22.77-113.324 64.058-154.536 41.29-41.21 96.164-64.058 154.536-64.058 35.067 0 68.618 8.046 99.583 23.907 29.601 15.181 55.786 37.27 75.675 63.982 8.042 10.78 23.221 12.979 34.002 4.935 10.78-8.047 12.974-23.229 4.933-34.002-24.371-32.638-56.32-59.659-92.443-78.177-37.428-19.129-79.471-29.222-121.749-29.222-36.053 0-71.044 7.056-103.984 21.021-31.8 13.436-60.418 32.713-84.932 57.233-24.52 24.514-43.796 53.13-57.228 84.932-11.005 25.954-17.687 53.207-20.042 81.214-49.561 5.235-95.481 27.092-131.231 62.766C121.77 473.354 99 528.299 99 586.671c0 58.373 22.77 113.317 64.059 154.526 41.218 41.297 96.168 64.066 154.535 64.066h97.152c13.437 0 24.288-10.852 24.288-24.288s-10.852-24.287-24.289-24.287z\" /><path d=\"M827.644 368.078H536.187c-26.79 0-48.576 21.786-48.576 48.575v388.611c0 26.791 21.786 48.576 48.576 48.576h291.457c26.791 0 48.576-21.785 48.576-48.576V416.653c0-26.79-21.785-48.575-48.576-48.575zm0 437.186H536.187V708.11h291.457zm0-145.729H536.187v-97.152h291.457zm0-145.728H536.187v-97.231.077h291.457v-.077z\" /><path d=\"M730.49 465.231c0 13.413 10.875 24.288 24.289 24.288 13.413 0 24.288-10.875 24.288-24.288 0-13.415-10.875-24.29-24.288-24.29-13.414 0-24.289 10.875-24.289 24.29zm0 145.728c0 13.412 10.875 24.288 24.289 24.288 13.413 0 24.288-10.876 24.288-24.288 0-13.413-10.875-24.288-24.288-24.288-13.414 0-24.289 10.875-24.289 24.288zm0 145.729c0 13.413 10.875 24.288 24.289 24.288 13.413 0 24.288-10.875 24.288-24.288 0-13.415-10.875-24.288-24.288-24.288-13.414-.001-24.289 10.872-24.289 24.288z\" /></g></symbol>"
});
sprite.add(symbol);

var SvgSpriteIcon = function SvgSpriteIcon(props) {
  return React.createElement(
    'svg',
    Object.assign({
      viewBox: symbol.viewBox
    }, props),
    React.createElement(
      'use',
      {
        xlinkHref: '#' + symbol.id
      }
    )
  );
};

SvgSpriteIcon.viewBox = symbol.viewBox;
SvgSpriteIcon.id = symbol.id;
SvgSpriteIcon.content = symbol.content;
SvgSpriteIcon.url = symbol.url;
SvgSpriteIcon.toString = symbol.toString;

module.exports = SvgSpriteIcon;
module.exports.default = SvgSpriteIcon;


/***/ }),

/***/ "p8BD":
/***/ (function(module, exports) {

module.exports = require("next-server/dist/lib/utils");

/***/ }),

/***/ "pLtp":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("qJj/");

/***/ }),

/***/ "qJj/":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/keys");

/***/ }),

/***/ "qNsG":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/get-own-property-symbols.js
var get_own_property_symbols = __webpack_require__("4mXO");
var get_own_property_symbols_default = /*#__PURE__*/__webpack_require__.n(get_own_property_symbols);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/keys.js
var keys = __webpack_require__("pLtp");
var keys_default = /*#__PURE__*/__webpack_require__.n(keys);

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/objectWithoutPropertiesLoose.js

function _objectWithoutPropertiesLoose(source, excluded) {
  if (source == null) return {};
  var target = {};

  var sourceKeys = keys_default()(source);

  var key, i;

  for (i = 0; i < sourceKeys.length; i++) {
    key = sourceKeys[i];
    if (excluded.indexOf(key) >= 0) continue;
    target[key] = source[key];
  }

  return target;
}
// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/objectWithoutProperties.js
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _objectWithoutProperties; });


function _objectWithoutProperties(source, excluded) {
  if (source == null) return {};
  var target = _objectWithoutPropertiesLoose(source, excluded);
  var key, i;

  if (get_own_property_symbols_default.a) {
    var sourceSymbolKeys = get_own_property_symbols_default()(source);

    for (i = 0; i < sourceSymbolKeys.length; i++) {
      key = sourceSymbolKeys[i];
      if (excluded.indexOf(key) >= 0) continue;
      if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
      target[key] = source[key];
    }
  }

  return target;
}

/***/ }),

/***/ "rf6O":
/***/ (function(module, exports) {

module.exports = require("prop-types");

/***/ }),

/***/ "sLSF":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _createClass; });
/* harmony import */ var _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("hfKm");
/* harmony import */ var _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__);


function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;

    _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default()(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

/***/ }),

/***/ "sNF/":
/***/ (function(module, exports) {

module.exports = "/_next/static/images/banner-4-1c1aeb98ea269980a65581402e773d56.jpg";

/***/ }),

/***/ "ushU":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return requestAnimationFrame; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return cancelAnimationFrame; });
var suffix = 'AnimationFrame';
var vendors = ['', 'moz', 'webkit'];

var getAFFunc = function getAFFunc(name) {
  var func = null;
  return function () {
    if (func) {
      return func.apply(void 0, arguments);
    }

    var win = window;

    for (var i = 0, l = vendors.length; i < l; i++) {
      var prefix = vendors[i];
      var funcName = name + suffix;

      if (prefix) {
        funcName = prefix + funcName.charAt(0).toUpperCase() + funcName.slice(1);
      }

      func = win[funcName];

      if (func) {
        break;
      }
    }

    return func ? func.apply(void 0, arguments) : func;
  };
};

var requestAnimationFrame = getAFFunc('request');
var cancelFunc = getAFFunc('cancel');
var cancelRequestFunc = getAFFunc('cancelRequest');
var cancelAnimationFrame = function cancelAnimationFrame() {
  return cancelFunc.apply(void 0, arguments) || cancelRequestFunc.apply(void 0, arguments);
};

/***/ }),

/***/ "vYYK":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _defineProperty; });
/* harmony import */ var _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("hfKm");
/* harmony import */ var _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__);

function _defineProperty(obj, key, value) {
  if (key in obj) {
    _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default()(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}

/***/ }),

/***/ "vjea":
/***/ (function(module, exports, __webpack_require__) {

var _Object$setPrototypeOf = __webpack_require__("TRZx");

function _setPrototypeOf(o, p) {
  module.exports = _setPrototypeOf = _Object$setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

module.exports = _setPrototypeOf;

/***/ }),

/***/ "vqFK":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/symbol");

/***/ }),

/***/ "za0J":
/***/ (function(module, exports) {

module.exports = {
	"scene": "_1Zxh9h73",
	"paper-background": "_3DuBECud",
	"paperBackground": "_3DuBECud",
	"left-content": "_1LyUV2O_",
	"leftContent": "_1LyUV2O_",
	"center-content": "_242OCfn4",
	"centerContent": "_242OCfn4",
	"topic": "_1mi59G5i",
	"topic-title": "_1bqmkkVN",
	"topicTitle": "_1bqmkkVN",
	"topic-desc": "_2eLjJxyF",
	"topicDesc": "_2eLjJxyF",
	"topic-extend": "XGtqH0oX",
	"topicExtend": "XGtqH0oX",
	"topic-icon": "Fmyt4vOV",
	"topicIcon": "Fmyt4vOV",
	"topic-label": "_2WnbhL6a",
	"topicLabel": "_2WnbhL6a",
	"topic-action": "QHmQ3fB4",
	"topicAction": "QHmQ3fB4",
	"topic-button": "_1pq2TqNo",
	"topicButton": "_1pq2TqNo"
};

/***/ }),

/***/ "zrwo":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _objectSpread; });
/* harmony import */ var _core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("Jo+v");
/* harmony import */ var _core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("4mXO");
/* harmony import */ var _core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _core_js_object_keys__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("pLtp");
/* harmony import */ var _core_js_object_keys__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_keys__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _defineProperty__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("vYYK");




function _objectSpread(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i] != null ? arguments[i] : {};

    var ownKeys = _core_js_object_keys__WEBPACK_IMPORTED_MODULE_2___default()(source);

    if (typeof _core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1___default.a === 'function') {
      ownKeys = ownKeys.concat(_core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1___default()(source).filter(function (sym) {
        return _core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_0___default()(source, sym).enumerable;
      }));
    }

    ownKeys.forEach(function (key) {
      Object(_defineProperty__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"])(target, key, source[key]);
    });
  }

  return target;
}

/***/ })

/******/ });