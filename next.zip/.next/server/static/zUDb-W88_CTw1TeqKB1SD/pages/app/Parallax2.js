module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../../../../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 12);
/******/ })
/************************************************************************/
/******/ ({

/***/ "/+oN":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/get-prototype-of");

/***/ }),

/***/ "0iUn":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _classCallCheck; });
function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

/***/ }),

/***/ "1+QS":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/classCallCheck.js
var classCallCheck = __webpack_require__("0iUn");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/createClass.js
var createClass = __webpack_require__("sLSF");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/possibleConstructorReturn.js + 1 modules
var possibleConstructorReturn = __webpack_require__("MI3g");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/getPrototypeOf.js
var getPrototypeOf = __webpack_require__("a7VT");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/assertThisInitialized.js
var assertThisInitialized = __webpack_require__("AT/M");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/inherits.js + 1 modules
var inherits = __webpack_require__("Tit0");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/defineProperty.js
var defineProperty = __webpack_require__("vYYK");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/extends.js
var esm_extends = __webpack_require__("kOwS");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/objectWithoutProperties.js + 1 modules
var objectWithoutProperties = __webpack_require__("qNsG");

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__("cDcd");
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);

// EXTERNAL MODULE: external "whatitis"
var external_whatitis_ = __webpack_require__("lOhm");
var external_whatitis_default = /*#__PURE__*/__webpack_require__.n(external_whatitis_);

// EXTERNAL MODULE: external "omit.js"
var external_omit_js_ = __webpack_require__("LSCY");
var external_omit_js_default = /*#__PURE__*/__webpack_require__.n(external_omit_js_);

// EXTERNAL MODULE: external "rc-animate"
var external_rc_animate_ = __webpack_require__("Vam4");
var external_rc_animate_default = /*#__PURE__*/__webpack_require__.n(external_rc_animate_);

// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__("K2gz");
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);

// EXTERNAL MODULE: external "react-hammerjs"
var external_react_hammerjs_ = __webpack_require__("BgYr");
var external_react_hammerjs_default = /*#__PURE__*/__webpack_require__.n(external_react_hammerjs_);

// EXTERNAL MODULE: external "rc-tween-one"
var external_rc_tween_one_ = __webpack_require__("VNO/");
var external_rc_tween_one_default = /*#__PURE__*/__webpack_require__.n(external_rc_tween_one_);

// EXTERNAL MODULE: external "rc-util/lib/Dom/addEventListener"
var addEventListener_ = __webpack_require__("BI0l");
var addEventListener_default = /*#__PURE__*/__webpack_require__.n(addEventListener_);

// EXTERNAL MODULE: ./lib/requestAnimationFrame.js
var requestAnimationFrame = __webpack_require__("ushU");

// EXTERNAL MODULE: ./assets/motions/cScale.less
var cScale = __webpack_require__("SC1p");

// EXTERNAL MODULE: ./assets/motions/cSlideUp.less
var cSlideUp = __webpack_require__("Te8+");

// EXTERNAL MODULE: ./assets/motions/cSlideDown.less
var cSlideDown = __webpack_require__("Qnt8");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/objectSpread.js
var objectSpread = __webpack_require__("zrwo");

// EXTERNAL MODULE: ./components/Carousel/points.less
var Carousel_points = __webpack_require__("2crN");
var points_default = /*#__PURE__*/__webpack_require__.n(Carousel_points);

// CONCATENATED MODULE: ./components/Carousel/points.js












var points_Points =
/*#__PURE__*/
function (_React$Component) {
  Object(inherits["a" /* default */])(Points, _React$Component);

  function Points() {
    var _getPrototypeOf2;

    var _this;

    Object(classCallCheck["a" /* default */])(this, Points);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = Object(possibleConstructorReturn["a" /* default */])(this, (_getPrototypeOf2 = Object(getPrototypeOf["a" /* default */])(Points)).call.apply(_getPrototypeOf2, [this].concat(args)));

    Object(defineProperty["a" /* default */])(Object(assertThisInitialized["a" /* default */])(_this), "handleClick", function (i) {
      return function () {
        var _this$props = _this.props,
            onChange = _this$props.onChange,
            index = _this$props.index;

        if (index !== i) {
          onChange(i);
        }
      };
    });

    return _this;
  }

  Object(createClass["a" /* default */])(Points, [{
    key: "render",
    value: function render() {
      var _this2 = this;

      var _this$props2 = this.props,
          points = _this$props2.points,
          index = _this$props2.index,
          size = _this$props2.size;
      var sizeStyle = {
        height: "".concat(100 / points.length, "%")
      };

      var blockProps = function blockProps(i) {
        return {
          className: points_default.a.block,
          onClick: _this2.handleClick(i),
          style: sizeStyle
        };
      };

      return external_react_default.a.createElement("div", {
        className: points_default.a.track,
        style: {
          height: size
        }
      }, points.map(function (point, i) {
        return i === index ? external_react_default.a.createElement("div", Object(esm_extends["a" /* default */])({
          key: "point-".concat(i)
        }, blockProps(i))) : external_react_default.a.createElement("div", Object(esm_extends["a" /* default */])({
          key: "active-point-".concat(i)
        }, blockProps(i)));
      }), external_react_default.a.createElement("div", {
        className: points_default.a.thumb,
        style: Object(objectSpread["a" /* default */])({
          top: "".concat(index * 100 / points.length, "%")
        }, sizeStyle)
      }));
    }
  }]);

  return Points;
}(external_react_default.a.Component);

/* harmony default export */ var components_Carousel_points = (points_Points);
// EXTERNAL MODULE: ./components/Carousel/carousel.less
var carousel = __webpack_require__("Pnzm");
var carousel_default = /*#__PURE__*/__webpack_require__.n(carousel);

// CONCATENATED MODULE: ./components/Carousel/index.js
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CarouselContext; });























var TweenOneGroup = external_rc_tween_one_default.a.TweenOneGroup;
var CarouselContext = external_react_default.a.createContext({
  isEnable: true
});

function HammerHoc(_ref) {
  var disabled = _ref.disabled,
      children = _ref.children,
      props = Object(objectWithoutProperties["a" /* default */])(_ref, ["disabled", "children"]);

  return disabled ? children : external_react_default.a.createElement(external_react_hammerjs_default.a, Object(esm_extends["a" /* default */])({}, props, {
    direction: "DIRECTION_VERTICAL"
  }), children);
}

var Carousel_Carousel =
/*#__PURE__*/
function (_React$Component) {
  Object(inherits["a" /* default */])(Carousel, _React$Component);

  function Carousel() {
    var _getPrototypeOf2;

    var _this;

    Object(classCallCheck["a" /* default */])(this, Carousel);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = Object(possibleConstructorReturn["a" /* default */])(this, (_getPrototypeOf2 = Object(getPrototypeOf["a" /* default */])(Carousel)).call.apply(_getPrototypeOf2, [this].concat(args)));

    Object(defineProperty["a" /* default */])(Object(assertThisInitialized["a" /* default */])(_this), "state", {
      index: 0,
      scrolling: false,
      isEnable: true
    });

    Object(defineProperty["a" /* default */])(Object(assertThisInitialized["a" /* default */])(_this), "handleWheel", function (e) {
      // 正数页面向上,负数页面向下
      var delta = (whatenvis.firefox ? 3 : 1) * e.delta;
      var _this$props = _this.props,
          children = _this$props.children,
          disabled = _this$props.disabled;
      var _this$state = _this.state,
          index = _this$state.index,
          scrolling = _this$state.scrolling;
      var count = external_react_default.a.Children.toArray(children).length - 1;

      if (!disabled && scrolling === false) {
        if (delta > 0 && index > 0) {
          _this.handleChange(index - 1);
        } else if (delta < 0 && index < count) {
          _this.handleChange(index + 1);
        }
      }
    });

    Object(defineProperty["a" /* default */])(Object(assertThisInitialized["a" /* default */])(_this), "handleScrollEnd", function (_, exists) {
      if (exists) {
        var onEnd = _this.props.onEnd;
        _this.state.scrolling = false; // eslint-disable-line

        _this.setState({
          isEnable: true
        }, external_whatitis_default.a.Function(onEnd) ? onEnd : null);
      }
    });

    Object(defineProperty["a" /* default */])(Object(assertThisInitialized["a" /* default */])(_this), "handleChange", function (targetIndex) {
      var _this$props2 = _this.props,
          index = _this$props2.index,
          onChange = _this$props2.onChange;

      if (external_whatitis_default.a.Number(index) && index >= 0) {
        external_whatitis_default.a.Function(onChange) && onChange(targetIndex);
      } else {
        var _this$state2 = _this.state,
            _index = _this$state2.index,
            scrolling = _this$state2.scrolling;

        if (scrolling === false) {
          _this.state.scrolling = true; // eslint-disable-line

          _this.setState({
            isEnable: false
          }, function () {
            _this.rafHandle = Object(requestAnimationFrame["b" /* requestAnimationFrame */])(function () {
              _this.rafHandle = null;

              _this.setState({
                index: targetIndex,
                direction: targetIndex > _index ? 1 : 0
              });
            });
          });
        }
      }
    });

    Object(defineProperty["a" /* default */])(Object(assertThisInitialized["a" /* default */])(_this), "handleSwipe", function (event) {
      var index = _this.state.index;
      var children = _this.props.children;
      var count = external_react_default.a.Children.toArray(children).length;
      var offsetDirection = event.offsetDirection;
      event.preventDefault();

      if (offsetDirection === 8 && index < count - 1) {
        // 上
        _this.handleChange(index + 1);
      }

      if (offsetDirection === 16 && index > 0) {
        // 下
        _this.handleChange(index - 1);
      }
    });

    Object(defineProperty["a" /* default */])(Object(assertThisInitialized["a" /* default */])(_this), "handleSlider", function () {
      var children = _this.props.children;
      var _this$state3 = _this.state,
          index = _this$state3.index,
          scrolling = _this$state3.scrolling;
      var count = external_react_default.a.Children.toArray(children).length - 1;

      if (scrolling === false) {
        if (index < count) {
          _this.handleChange(index + 1);
        }
      }
    });

    return _this;
  }

  Object(createClass["a" /* default */])(Carousel, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      var eventName = whatenvis.firefox ? 'DOMMouseScroll' : 'mousewheel';
      this.wheelListener = addEventListener_default()(document.body, eventName, this.handleWheel);
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      if (this.wheelListener) {
        this.wheelListener.remove();
        this.wheelListener = null;
      }

      if (this.rafHandle) {
        Object(requestAnimationFrame["a" /* cancelAnimationFrame */])(this.rafHandle);
        this.rafHandle = null;
      }
    }
  }, {
    key: "render",
    value: function render() {
      var _this$state4 = this.state,
          index = _this$state4.index,
          direction = _this$state4.direction,
          isEnable = _this$state4.isEnable;

      var _omit = external_omit_js_default()(this.props, ['onEnd']),
          children = _omit.children,
          className = _omit.className,
          disabled = _omit.disabled,
          showPoints = _omit.showPoints,
          showArrow = _omit.showArrow,
          props = Object(objectWithoutProperties["a" /* default */])(_omit, ["children", "className", "disabled", "showPoints", "showArrow"]);

      var childArray = external_react_default.a.Children.toArray(children);
      var count = childArray.length;
      var child = childArray.find(function (_, i) {
        return i === index;
      });
      return external_react_default.a.createElement(CarouselContext.Provider, {
        value: {
          isEnable: isEnable
        }
      }, external_react_default.a.createElement(HammerHoc, {
        onSwipe: this.handleSwipe,
        disabled: disabled
      }, external_react_default.a.createElement("div", Object(esm_extends["a" /* default */])({}, props, {
        className: external_classnames_default()(className, carousel_default.a.carousel)
      }), external_react_default.a.createElement(external_rc_animate_default.a, {
        component: "div",
        transitionAppear: false,
        onEnd: this.handleScrollEnd,
        transitionName: direction ? 'c-slide-up' : 'c-slide-down'
      }, external_react_default.a.createElement("div", {
        key: "".concat(index),
        className: carousel_default.a.paper
      }, external_react_default.a.createElement("div", {
        className: "c-scale"
      }, child))), showPoints ? external_react_default.a.createElement(components_Carousel_points, {
        size: "100%",
        index: index,
        onChange: this.handleChange,
        points: Array(count).fill(1)
      }) : null, external_react_default.a.createElement(TweenOneGroup, {
        component: "",
        enter: {
          opacity: 0,
          type: 'from',
          duration: 2000
        },
        leave: {
          opacity: 0,
          duration: 2000
        }
      }, showArrow && count - 1 > index ? external_react_default.a.createElement("div", {
        key: "arrow",
        className: carousel_default.a.arrowDown,
        onClick: this.handleSlider
      }, external_react_default.a.createElement("div", {
        className: carousel_default.a.arrowDownAnim
      }, external_react_default.a.createElement("em", null), external_react_default.a.createElement("em", null), external_react_default.a.createElement("em", null))) : null))));
    }
  }]);

  return Carousel;
}(external_react_default.a.Component);

Object(defineProperty["a" /* default */])(Carousel_Carousel, "defaultProps", {
  showArrow: true,
  showPoints: true
});

Object(defineProperty["a" /* default */])(Carousel_Carousel, "getDerivedStateFromProps", function (props, state) {
  if (external_whatitis_default.a.Number(props.index) && props.index >= 0 && state.index !== props.index) {
    return {
      index: props.index,
      direction: props.index > state.index ? 1 : 0,
      scrolling: false,
      isEnable: false
    };
  }

  return null;
});

/* harmony default export */ var components_Carousel = __webpack_exports__["b"] = (Carousel_Carousel);

/***/ }),

/***/ 12:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("4LTB");


/***/ }),

/***/ "2crN":
/***/ (function(module, exports) {

module.exports = {
	"track": "_1ujYANvT",
	"block": "_1_K01DDo",
	"thumb": "_3m-xWWqN"
};

/***/ }),

/***/ "4LTB":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("0iUn");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("sLSF");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("MI3g");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("a7VT");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("Tit0");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("K2gz");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _components_SvgIcon__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__("BE5S");
/* harmony import */ var _components_Parallax__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__("IMUT");
/* harmony import */ var _components_Parallax_Paper__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__("QncY");
/* harmony import */ var _assets_images_app_banner_2_banner_2_jpg__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__("hnuN");
/* harmony import */ var _assets_images_app_banner_2_banner_2_jpg__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_assets_images_app_banner_2_banner_2_jpg__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _assets_images_app_banner_2_svg_1_svg_sprite__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__("Wq/1");
/* harmony import */ var _assets_images_app_banner_2_svg_1_svg_sprite__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_assets_images_app_banner_2_svg_1_svg_sprite__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _assets_images_app_banner_2_svg_2_svg_sprite__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__("vF0m");
/* harmony import */ var _assets_images_app_banner_2_svg_2_svg_sprite__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_assets_images_app_banner_2_svg_2_svg_sprite__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _assets_images_app_banner_2_svg_3_svg_sprite__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__("dfL4");
/* harmony import */ var _assets_images_app_banner_2_svg_3_svg_sprite__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_assets_images_app_banner_2_svg_3_svg_sprite__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _assets_images_app_banner_2_svg_4_svg_sprite__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__("Qw6K");
/* harmony import */ var _assets_images_app_banner_2_svg_4_svg_sprite__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_assets_images_app_banner_2_svg_4_svg_sprite__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _assets_images_app_banner_2_svg_5_svg_sprite__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__("Zom5");
/* harmony import */ var _assets_images_app_banner_2_svg_5_svg_sprite__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_assets_images_app_banner_2_svg_5_svg_sprite__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _parallax_less__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__("za0J");
/* harmony import */ var _parallax_less__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_parallax_less__WEBPACK_IMPORTED_MODULE_16__);





 // import Link from 'next/link';












var options = {
  // selector: '.paper',
  // relativeInput: true
  // clipRelativeInput: true,
  // scalarX: 10,
  // scalarY: 10,
  limitX: 30,
  limitY: 30 // frictionX: 0.1,
  // frictionY: 0.1

};

var WallPaper =
/*#__PURE__*/
function (_React$Component) {
  Object(_babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_4__[/* default */ "a"])(WallPaper, _React$Component);

  function WallPaper() {
    Object(_babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(this, WallPaper);

    return Object(_babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__[/* default */ "a"])(this, Object(_babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"])(WallPaper).apply(this, arguments));
  }

  Object(_babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(WallPaper, [{
    key: "render",
    value: function render() {
      return react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement(_components_Parallax__WEBPACK_IMPORTED_MODULE_8__[/* default */ "a"], {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.scene,
        options: options
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement(_components_Parallax_Paper__WEBPACK_IMPORTED_MODULE_9__[/* default */ "a"], {
        depth: 0.2
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.paperBackground,
        style: {
          backgroundImage: "url(".concat(_assets_images_app_banner_2_banner_2_jpg__WEBPACK_IMPORTED_MODULE_10___default.a, ")")
        }
      })), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.leftContent
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_6___default()(_parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.topic, 'AppSiYuan')
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("h1", {
        className: classnames__WEBPACK_IMPORTED_MODULE_6___default()(_parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.topicTitle, 'AppSiYuan')
      }, "\u4E07\u7269\u611F\u77E5 \xB7 \u4E07\u7269\u4E92\u8054 \xB7 \u4E07\u7269\u667A\u80FD"), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("p", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.topicDesc
      }, "DD-IoT\u7269\u8054\u611F\u77E5\u5E73\u53F0\uFF0C\u90E8\u7F72\u5404\u7C7B\u4F20\u611F\u7F51\u667A\u80FD\u786C\u4EF6\u4EA7\u54C1\uFF0C\u53CA\u65F6\u3001\u51C6\u786E\u3001\u5FEB\u901F\u7684\u76D1\u6D4B\u4E00\u5207\u4EBA\u548C\u7269\u3002"), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.topicExtend
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.topicIcon
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement(_components_SvgIcon__WEBPACK_IMPORTED_MODULE_7__[/* default */ "a"], {
        icon: _assets_images_app_banner_2_svg_1_svg_sprite__WEBPACK_IMPORTED_MODULE_11___default.a
      }), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.topicLabel
      }, "\u9AD8\u5E76\u53D1")), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.topicIcon
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement(_components_SvgIcon__WEBPACK_IMPORTED_MODULE_7__[/* default */ "a"], {
        icon: _assets_images_app_banner_2_svg_2_svg_sprite__WEBPACK_IMPORTED_MODULE_12___default.a
      }), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.topicLabel
      }, "\u6D77\u91CF\u5B9E\u65F6\u6570\u636E\u5B58\u50A8")), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.topicIcon
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement(_components_SvgIcon__WEBPACK_IMPORTED_MODULE_7__[/* default */ "a"], {
        icon: _assets_images_app_banner_2_svg_3_svg_sprite__WEBPACK_IMPORTED_MODULE_13___default.a
      }), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.topicLabel
      }, "\u6570\u636E\u6EE4\u6CE2")), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.topicIcon
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement(_components_SvgIcon__WEBPACK_IMPORTED_MODULE_7__[/* default */ "a"], {
        icon: _assets_images_app_banner_2_svg_4_svg_sprite__WEBPACK_IMPORTED_MODULE_14___default.a
      }), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.topicLabel
      }, "\u53EF\u5B9A\u5236\u5316\u9A71\u52A8\u6A21\u578B")), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.topicIcon
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement(_components_SvgIcon__WEBPACK_IMPORTED_MODULE_7__[/* default */ "a"], {
        icon: _assets_images_app_banner_2_svg_5_svg_sprite__WEBPACK_IMPORTED_MODULE_15___default.a
      }), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.topicLabel
      }, "\u53EF\u7F16\u7A0B\u7CFB\u5217\u901A\u8BAF\u7F51\u5173"))))));
    }
  }]);

  return WallPaper;
}(react__WEBPACK_IMPORTED_MODULE_5___default.a.Component);

/* harmony default export */ __webpack_exports__["default"] = (WallPaper);

/***/ }),

/***/ "4mXO":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("k1wZ");

/***/ }),

/***/ "AT/M":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _assertThisInitialized; });
function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

/***/ }),

/***/ "BE5S":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return Icon; });
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("kOwS");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("qNsG");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("K2gz");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _svgIcon_less__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("flPq");
/* harmony import */ var _svgIcon_less__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_svgIcon_less__WEBPACK_IMPORTED_MODULE_4__);





function Icon(_ref) {
  var icon = _ref.icon,
      className = _ref.className,
      props = Object(_babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(_ref, ["icon", "className"]);

  return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("svg", Object(_babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])({
    "aria-hidden": "true"
  }, props, {
    className: classnames__WEBPACK_IMPORTED_MODULE_3___default()(_svgIcon_less__WEBPACK_IMPORTED_MODULE_4___default.a.svgIcon, className)
  }), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("use", {
    xlinkHref: "#".concat(icon.id)
  }));
}

/***/ }),

/***/ "BI0l":
/***/ (function(module, exports) {

module.exports = require("rc-util/lib/Dom/addEventListener");

/***/ }),

/***/ "BgYr":
/***/ (function(module, exports) {

module.exports = require("react-hammerjs");

/***/ }),

/***/ "Bhuq":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("/+oN");

/***/ }),

/***/ "IMUT":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("kOwS");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("qNsG");
/* harmony import */ var _babel_runtime_corejs2_core_js_object_assign__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("UXZV");
/* harmony import */ var _babel_runtime_corejs2_core_js_object_assign__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_core_js_object_assign__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("0iUn");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("sLSF");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("MI3g");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("a7VT");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__("Tit0");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__("vYYK");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var omit_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__("LSCY");
/* harmony import */ var omit_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(omit_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var parallax_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__("W0Av");
/* harmony import */ var parallax_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(parallax_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _components_Carousel__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__("1+QS");












 //https://ken.artbees.net/wide-parallax-startup/

var Scene =
/*#__PURE__*/
function (_React$Component) {
  Object(_babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_7__[/* default */ "a"])(Scene, _React$Component);

  function Scene(props) {
    var _this;

    Object(_babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"])(this, Scene);

    _this = Object(_babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"])(this, Object(_babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_6__[/* default */ "a"])(Scene).call(this, props));
    _this.sceneRef = react__WEBPACK_IMPORTED_MODULE_9___default.a.createRef();
    return _this;
  }

  Object(_babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_4__[/* default */ "a"])(Scene, [{
    key: "componentDidUpdate",
    value: function componentDidUpdate() {
      var isEnable = this.context.isEnable;

      if (isEnable) {
        this.createParallax();
      } else {
        this.destroyParallax();
      }
    }
  }, {
    key: "componentDidMount",
    value: function componentDidMount() {
      var isEnable = this.context.isEnable;

      if (isEnable) {
        this.createParallax();
      }
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      this.destroyParallax();
    }
  }, {
    key: "createParallax",
    value: function createParallax() {
      var defaultOptions = {
        selector: '.paper'
      };
      var options = this.props.options;
      this.parallaxInstance = new parallax_js__WEBPACK_IMPORTED_MODULE_11___default.a(this.sceneRef.current, _babel_runtime_corejs2_core_js_object_assign__WEBPACK_IMPORTED_MODULE_2___default()(defaultOptions, options));
    }
  }, {
    key: "destroyParallax",
    value: function destroyParallax() {
      if (this.parallaxInstance) {
        this.parallaxInstance.destroy();
        this.parallaxInstance = null;
      }
    }
  }, {
    key: "render",
    value: function render() {
      var _omit = omit_js__WEBPACK_IMPORTED_MODULE_10___default()(this.props, ['options']),
          children = _omit.children,
          className = _omit.className,
          props = Object(_babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(_omit, ["children", "className"]);

      return react__WEBPACK_IMPORTED_MODULE_9___default.a.createElement("div", Object(_babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])({}, props, {
        ref: this.sceneRef,
        className: "".concat(className ? "".concat(className, " ") : '', "scene")
      }), children);
    }
  }]);

  return Scene;
}(react__WEBPACK_IMPORTED_MODULE_9___default.a.Component);

Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_8__[/* default */ "a"])(Scene, "contextType", _components_Carousel__WEBPACK_IMPORTED_MODULE_12__[/* CarouselContext */ "a"]);

/* harmony default export */ __webpack_exports__["a"] = (Scene);

/***/ }),

/***/ "Jo+v":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("Z6Kq");

/***/ }),

/***/ "K2gz":
/***/ (function(module, exports) {

module.exports = require("classnames");

/***/ }),

/***/ "LSCY":
/***/ (function(module, exports) {

module.exports = require("omit.js");

/***/ }),

/***/ "MI3g":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/symbol/iterator.js
var iterator = __webpack_require__("XVgq");
var iterator_default = /*#__PURE__*/__webpack_require__.n(iterator);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/symbol.js
var symbol = __webpack_require__("Z7t5");
var symbol_default = /*#__PURE__*/__webpack_require__.n(symbol);

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/typeof.js



function typeof_typeof2(obj) { if (typeof symbol_default.a === "function" && typeof iterator_default.a === "symbol") { typeof_typeof2 = function _typeof2(obj) { return typeof obj; }; } else { typeof_typeof2 = function _typeof2(obj) { return obj && typeof symbol_default.a === "function" && obj.constructor === symbol_default.a && obj !== symbol_default.a.prototype ? "symbol" : typeof obj; }; } return typeof_typeof2(obj); }

function typeof_typeof(obj) {
  if (typeof symbol_default.a === "function" && typeof_typeof2(iterator_default.a) === "symbol") {
    typeof_typeof = function _typeof(obj) {
      return typeof_typeof2(obj);
    };
  } else {
    typeof_typeof = function _typeof(obj) {
      return obj && typeof symbol_default.a === "function" && obj.constructor === symbol_default.a && obj !== symbol_default.a.prototype ? "symbol" : typeof_typeof2(obj);
    };
  }

  return typeof_typeof(obj);
}
// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/assertThisInitialized.js
var assertThisInitialized = __webpack_require__("AT/M");

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/possibleConstructorReturn.js
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _possibleConstructorReturn; });


function _possibleConstructorReturn(self, call) {
  if (call && (typeof_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return Object(assertThisInitialized["a" /* default */])(self);
}

/***/ }),

/***/ "Pnzm":
/***/ (function(module, exports) {

module.exports = {
	"carousel": "QIruQvWN",
	"paper": "IDE1NymA",
	"arrow-down": "_11U8PP3q",
	"arrowDown": "_11U8PP3q",
	"arrow-down-anim": "OiG04KV1",
	"arrowDownAnim": "OiG04KV1",
	"arrowDownAnimKF": "_2nZLV2q0",
	"arrowDownAnimKf": "_2nZLV2q0"
};

/***/ }),

/***/ "QAmA":
/***/ (function(module, exports) {

module.exports = require("svg-baker-runtime/symbol");

/***/ }),

/***/ "QncY":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("kOwS");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("qNsG");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("0iUn");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("sLSF");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("MI3g");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("a7VT");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("Tit0");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);









var Paper =
/*#__PURE__*/
function (_React$Component) {
  Object(_babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_6__[/* default */ "a"])(Paper, _React$Component);

  function Paper() {
    Object(_babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_2__[/* default */ "a"])(this, Paper);

    return Object(_babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__[/* default */ "a"])(this, Object(_babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"])(Paper).apply(this, arguments));
  }

  Object(_babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"])(Paper, [{
    key: "render",
    value: function render() {
      var _this$props = this.props,
          depth = _this$props.depth,
          children = _this$props.children,
          className = _this$props.className,
          props = Object(_babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(_this$props, ["depth", "children", "className"]);

      return react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", Object(_babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])({}, props, {
        className: "".concat(className ? "".concat(className, " ") : '', "paper"),
        "data-depth": depth
      }), children);
    }
  }]);

  return Paper;
}(react__WEBPACK_IMPORTED_MODULE_7___default.a.Component);

/* harmony default export */ __webpack_exports__["a"] = (Paper);

/***/ }),

/***/ "Qnt8":
/***/ (function(module, exports) {

module.exports = {
	"cslideDownIn": "_33bJsfF1",
	"cslideDownOut": "_26zD-TbW"
};

/***/ }),

/***/ "Qw6K":
/***/ (function(module, exports, __webpack_require__) {

/* eslint-disable */
var React = __webpack_require__("cDcd");
var SpriteSymbol = __webpack_require__("QAmA");
var sprite = __webpack_require__("TQFg");

var symbol = new SpriteSymbol({
  "id": "3aI8Gi6J--sprite",
  "use": "3aI8Gi6J--sprite-usage",
  "viewBox": "0 0 1000.637 1000.678",
  "content": "<symbol xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 1000.637 1000.678\" id=\"3aI8Gi6J--sprite\"><path d=\"M830.643 273.016L539.15 110.535c-23.672-13.241-54.005-13.241-77.318 0L170.714 273.016c-23.673 13.242-38.473 38.113-38.473 64.993v324.962c0 26.886 14.8 51.348 38.473 64.596l291.119 162.481c11.843 6.416 25.151 10.026 38.473 10.026a79.134 79.134 0 0 0 38.474-10.026l291.117-162.481c23.685-13.248 38.473-38.112 38.473-64.596V338.009c.745-26.88-14.043-51.751-37.727-64.993zm-10.364 389.563c0 10.015-5.543 18.855-14.429 24.071L514.732 849.116c-8.511 4.828-19.97 4.828-28.482 0L195.126 686.65c-8.874-4.825-14.421-14.057-14.421-24.071V337.605c0-10.026 5.548-18.854 14.421-24.071L486.25 151.055c4.437-2.407 9.246-3.612 14.427-3.612 5.182 0 9.992 1.205 14.055 3.612l291.502 162.479c8.875 4.818 14.429 14.044 14.429 24.071v324.974zm-68.05-322.561L517.69 463.589c-2.212 1.2-4.437 2.399-6.661 4.003-6.648 2.412-14.427 2.412-21.076-.404-1.852-1.201-3.703-2.4-5.927-3.6l-227.121-123.57c-11.47-6.422-26.637-2.413-33.291 8.827-5.548 9.225-3.703 20.458 3.697 27.682 1.479 1.604 3.697 3.208 5.921 4.407l23.673 12.844 206.033 113.139c.384.391 1.118.391 1.491.796 6.661 5.216 10.724 13.235 10.724 21.659l1.107 253.155v2.411c0 .393 0 .796.372 1.2v1.2c0 .402.373.808.373 1.2 0 .403 0 .809.36 1.211 0 .404.384.795.384.795 0 .404.361.81.361 1.2 0 .417.373.417.373.808.372.405.372.81.734 1.605v.404c3.701 6.414 10.735 11.239 18.874 12.034h2.585c7.394 0 14.428-3.208 18.865-8.826 3.33-4.018 5.554-9.231 5.554-15.243v-16.051l.745-236.7c0-8.021 3.692-15.243 9.618-20.46.734-.402 1.84-.808 2.574-1.198l237.496-125.972c11.831-6.428 16.279-20.471 9.618-32.103-6.297-12.033-21.086-16.447-32.917-10.024z\" /></symbol>"
});
sprite.add(symbol);

var SvgSpriteIcon = function SvgSpriteIcon(props) {
  return React.createElement(
    'svg',
    Object.assign({
      viewBox: symbol.viewBox
    }, props),
    React.createElement(
      'use',
      {
        xlinkHref: '#' + symbol.id
      }
    )
  );
};

SvgSpriteIcon.viewBox = symbol.viewBox;
SvgSpriteIcon.id = symbol.id;
SvgSpriteIcon.content = symbol.content;
SvgSpriteIcon.url = symbol.url;
SvgSpriteIcon.toString = symbol.toString;

module.exports = SvgSpriteIcon;
module.exports.default = SvgSpriteIcon;


/***/ }),

/***/ "SC1p":
/***/ (function(module, exports) {

module.exports = {
	"cScaleIn": "yzEr1rWc",
	"cScaleOut": "_34mAihAf"
};

/***/ }),

/***/ "SqZg":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("o5io");

/***/ }),

/***/ "TQFg":
/***/ (function(module, exports) {

module.exports = require("svg-sprite-loader/runtime/sprite.build");

/***/ }),

/***/ "TRZx":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("Wk4r");

/***/ }),

/***/ "TUA0":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/define-property");

/***/ }),

/***/ "Te8+":
/***/ (function(module, exports) {

module.exports = {
	"cslideUpIn": "_1BDx8_C5",
	"cslideUpOut": "_1Ck_eq3l"
};

/***/ }),

/***/ "Tit0":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/create.js
var create = __webpack_require__("SqZg");
var create_default = /*#__PURE__*/__webpack_require__.n(create);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/set-prototype-of.js
var set_prototype_of = __webpack_require__("TRZx");
var set_prototype_of_default = /*#__PURE__*/__webpack_require__.n(set_prototype_of);

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/setPrototypeOf.js

function _setPrototypeOf(o, p) {
  _setPrototypeOf = set_prototype_of_default.a || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}
// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/inherits.js
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _inherits; });


function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = create_default()(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

/***/ }),

/***/ "UXZV":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("dGr4");

/***/ }),

/***/ "VNO/":
/***/ (function(module, exports) {

module.exports = require("rc-tween-one");

/***/ }),

/***/ "Vam4":
/***/ (function(module, exports) {

module.exports = require("rc-animate");

/***/ }),

/***/ "W0Av":
/***/ (function(module, exports) {

module.exports = require("parallax-js");

/***/ }),

/***/ "Wk4r":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/set-prototype-of");

/***/ }),

/***/ "Wq/1":
/***/ (function(module, exports, __webpack_require__) {

/* eslint-disable */
var React = __webpack_require__("cDcd");
var SpriteSymbol = __webpack_require__("QAmA");
var sprite = __webpack_require__("TQFg");

var symbol = new SpriteSymbol({
  "id": "1GGCkgTz--sprite",
  "use": "1GGCkgTz--sprite-usage",
  "viewBox": "0 0 1000.637 1000.678",
  "content": "<symbol xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 1000.637 1000.678\" id=\"1GGCkgTz--sprite\"><path d=\"M500.317 179.837c-153.766 0-275.108 230.997-283.92 531.571v32.95h59.772V714.92c7.324-111.38 54.691-186.61 97.729-186.61 46.771 0 98.774 88.806 98.774 216.204h59.772c0-155.321-69.486-276.921-158.25-276.921-24.981.412-49.053 9.629-68.139 26.09 41.539-157.459 119.546-252.817 194.261-252.817 121.636 0 224.149 230.694 224.149 503.492h59.773c.002-316.589-125.072-564.521-283.921-564.521z\" /><path d=\"M186.51 759.771c0 33.704 26.758 61.029 59.773 61.029 33.009 0 59.773-27.325 59.773-61.029 0-33.702-26.764-61.028-59.773-61.028-33.014 0-59.773 27.326-59.773 61.028zm254.035 0c0 33.704 26.758 61.029 59.772 61.029 33.011 0 59.772-27.325 59.772-61.029 0-33.702-26.762-61.028-59.772-61.028-33.013 0-59.772 27.326-59.772 61.028zm254.035 0c-.02 33.704 26.725 61.049 59.734 61.069 33.02.021 59.793-27.298 59.813-61.001v-.068c0-33.702-26.766-61.028-59.775-61.028-33.008 0-59.772 27.326-59.772 61.028z\" /></symbol>"
});
sprite.add(symbol);

var SvgSpriteIcon = function SvgSpriteIcon(props) {
  return React.createElement(
    'svg',
    Object.assign({
      viewBox: symbol.viewBox
    }, props),
    React.createElement(
      'use',
      {
        xlinkHref: '#' + symbol.id
      }
    )
  );
};

SvgSpriteIcon.viewBox = symbol.viewBox;
SvgSpriteIcon.id = symbol.id;
SvgSpriteIcon.content = symbol.content;
SvgSpriteIcon.url = symbol.url;
SvgSpriteIcon.toString = symbol.toString;

module.exports = SvgSpriteIcon;
module.exports.default = SvgSpriteIcon;


/***/ }),

/***/ "XVgq":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("gHn/");

/***/ }),

/***/ "Z6Kq":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/get-own-property-descriptor");

/***/ }),

/***/ "Z7t5":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("vqFK");

/***/ }),

/***/ "Zom5":
/***/ (function(module, exports, __webpack_require__) {

/* eslint-disable */
var React = __webpack_require__("cDcd");
var SpriteSymbol = __webpack_require__("QAmA");
var sprite = __webpack_require__("TQFg");

var symbol = new SpriteSymbol({
  "id": "I-tRJLaQ--sprite",
  "use": "I-tRJLaQ--sprite-usage",
  "viewBox": "0 0 1000.637 1000.678",
  "content": "<symbol xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 1000.637 1000.678\" id=\"I-tRJLaQ--sprite\"><path d=\"M499.299 904.139c-22.194 0-46.421-10.097-64.604-28.266L121.769 566.957c-34.337-36.341-34.337-94.889 0-131.232L438.73 122.786c16.152-16.138 38.374-26.247 60.568-26.247 22.225 0 46.45 10.108 64.606 28.266l314.973 308.916c34.323 36.342 34.323 94.891 0 131.231l-319.009 312.94c-14.119 16.15-38.345 26.247-60.569 26.247zm1.016-759.889c-13.702 0-25.444 5.87-33.262 15.665L159.883 463.16c-17.612 21.535-17.612 52.837 0 74.358l307.17 303.258c7.832 9.781 19.56 15.651 33.262 15.651 13.703 0 25.432-5.87 33.264-15.651l307.169-301.311c17.611-21.508 17.611-52.823 0-74.343L533.579 159.916c-7.817-9.795-19.56-15.666-33.264-15.666zm0 507.517c-84.797 0-151.421-68.656-151.421-151.433 0-82.767 68.644-151.411 151.421-151.411 84.798 0 151.422 68.645 151.422 151.411 0 82.776-66.624 151.433-151.422 151.433zm0-250.635c-54.911 0-99.216 44.286-99.216 99.202 0 54.925 44.305 99.212 99.216 99.212 54.912 0 99.217-44.287 99.217-99.212 0-54.916-44.304-99.202-99.217-99.202z\" /></symbol>"
});
sprite.add(symbol);

var SvgSpriteIcon = function SvgSpriteIcon(props) {
  return React.createElement(
    'svg',
    Object.assign({
      viewBox: symbol.viewBox
    }, props),
    React.createElement(
      'use',
      {
        xlinkHref: '#' + symbol.id
      }
    )
  );
};

SvgSpriteIcon.viewBox = symbol.viewBox;
SvgSpriteIcon.id = symbol.id;
SvgSpriteIcon.content = symbol.content;
SvgSpriteIcon.url = symbol.url;
SvgSpriteIcon.toString = symbol.toString;

module.exports = SvgSpriteIcon;
module.exports.default = SvgSpriteIcon;


/***/ }),

/***/ "a7VT":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _getPrototypeOf; });
/* harmony import */ var _core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("Bhuq");
/* harmony import */ var _core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("TRZx");
/* harmony import */ var _core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_1__);


function _getPrototypeOf(o) {
  _getPrototypeOf = _core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_1___default.a ? _core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0___default.a : function _getPrototypeOf(o) {
    return o.__proto__ || _core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0___default()(o);
  };
  return _getPrototypeOf(o);
}

/***/ }),

/***/ "cDcd":
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "dGr4":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/assign");

/***/ }),

/***/ "dfL4":
/***/ (function(module, exports, __webpack_require__) {

/* eslint-disable */
var React = __webpack_require__("cDcd");
var SpriteSymbol = __webpack_require__("QAmA");
var sprite = __webpack_require__("TQFg");

var symbol = new SpriteSymbol({
  "id": "GQZgh5xn--sprite",
  "use": "GQZgh5xn--sprite-usage",
  "viewBox": "0 0 1000.637 1000.678",
  "content": "<symbol xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 1000.637 1000.678\" id=\"GQZgh5xn--sprite\"><path d=\"M843.592 475.709h57.23v297.108c.363 10.611-12.115 19.428-27.918 19.684-15.801.257-28.916-8.136-29.313-18.746V475.709zm-114.358 0h57.197V821.48c.393 10.61-12.121 19.415-27.92 19.683-15.801.246-28.916-8.137-29.277-18.746a3.767 3.767 0 0 1 0-.937zm-114.494 0h57.215v273.147c.377 10.608-12.121 19.414-27.902 19.671-15.803.256-28.932-8.137-29.313-18.748v-.923zm-114.426 0h57.211v175.287c.383 10.611-12.115 19.416-27.914 19.685-15.805.246-28.916-8.137-29.297-18.747v-.938zm-371.894-316.2c15.8 0 28.615 8.604 28.615 19.214v296.999H99.807V178.724c0-10.611 12.812-19.215 28.613-19.215zm228.868 194.536c15.801 0 28.614 8.604 28.614 19.214v102.45h-57.229V373.26c-.019-10.599 12.78-19.204 28.583-19.214l.032-.001zm-114.441-60.822c15.799-.01 28.614 8.594 28.614 19.193v163.293h-57.23V312.427c-.001-10.61 12.814-19.204 28.616-19.204zm228.87-12.048c15.799 0 28.613 8.604 28.613 19.215v175.298h-57.229V300.39c0-10.611 12.815-19.215 28.616-19.215z\" /></symbol>"
});
sprite.add(symbol);

var SvgSpriteIcon = function SvgSpriteIcon(props) {
  return React.createElement(
    'svg',
    Object.assign({
      viewBox: symbol.viewBox
    }, props),
    React.createElement(
      'use',
      {
        xlinkHref: '#' + symbol.id
      }
    )
  );
};

SvgSpriteIcon.viewBox = symbol.viewBox;
SvgSpriteIcon.id = symbol.id;
SvgSpriteIcon.content = symbol.content;
SvgSpriteIcon.url = symbol.url;
SvgSpriteIcon.toString = symbol.toString;

module.exports = SvgSpriteIcon;
module.exports.default = SvgSpriteIcon;


/***/ }),

/***/ "flPq":
/***/ (function(module, exports) {

module.exports = {
	"svg-icon": "_39UYRa5H",
	"svgIcon": "_39UYRa5H"
};

/***/ }),

/***/ "gHn/":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/symbol/iterator");

/***/ }),

/***/ "hfKm":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("TUA0");

/***/ }),

/***/ "hnuN":
/***/ (function(module, exports) {

module.exports = "/_next/static/images/banner-2-85379310c8a6bd96273b5d40e4088984.jpg";

/***/ }),

/***/ "k1wZ":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/get-own-property-symbols");

/***/ }),

/***/ "kOwS":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _extends; });
/* harmony import */ var _core_js_object_assign__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("UXZV");
/* harmony import */ var _core_js_object_assign__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_assign__WEBPACK_IMPORTED_MODULE_0__);

function _extends() {
  _extends = _core_js_object_assign__WEBPACK_IMPORTED_MODULE_0___default.a || function (target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];

      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }

    return target;
  };

  return _extends.apply(this, arguments);
}

/***/ }),

/***/ "lOhm":
/***/ (function(module, exports) {

module.exports = require("whatitis");

/***/ }),

/***/ "o5io":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/create");

/***/ }),

/***/ "pLtp":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("qJj/");

/***/ }),

/***/ "qJj/":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/keys");

/***/ }),

/***/ "qNsG":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/get-own-property-symbols.js
var get_own_property_symbols = __webpack_require__("4mXO");
var get_own_property_symbols_default = /*#__PURE__*/__webpack_require__.n(get_own_property_symbols);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/keys.js
var keys = __webpack_require__("pLtp");
var keys_default = /*#__PURE__*/__webpack_require__.n(keys);

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/objectWithoutPropertiesLoose.js

function _objectWithoutPropertiesLoose(source, excluded) {
  if (source == null) return {};
  var target = {};

  var sourceKeys = keys_default()(source);

  var key, i;

  for (i = 0; i < sourceKeys.length; i++) {
    key = sourceKeys[i];
    if (excluded.indexOf(key) >= 0) continue;
    target[key] = source[key];
  }

  return target;
}
// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/objectWithoutProperties.js
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _objectWithoutProperties; });


function _objectWithoutProperties(source, excluded) {
  if (source == null) return {};
  var target = _objectWithoutPropertiesLoose(source, excluded);
  var key, i;

  if (get_own_property_symbols_default.a) {
    var sourceSymbolKeys = get_own_property_symbols_default()(source);

    for (i = 0; i < sourceSymbolKeys.length; i++) {
      key = sourceSymbolKeys[i];
      if (excluded.indexOf(key) >= 0) continue;
      if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
      target[key] = source[key];
    }
  }

  return target;
}

/***/ }),

/***/ "sLSF":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _createClass; });
/* harmony import */ var _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("hfKm");
/* harmony import */ var _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__);


function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;

    _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default()(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

/***/ }),

/***/ "ushU":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return requestAnimationFrame; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return cancelAnimationFrame; });
var suffix = 'AnimationFrame';
var vendors = ['', 'moz', 'webkit'];

var getAFFunc = function getAFFunc(name) {
  var func = null;
  return function () {
    if (func) {
      return func.apply(void 0, arguments);
    }

    var win = window;

    for (var i = 0, l = vendors.length; i < l; i++) {
      var prefix = vendors[i];
      var funcName = name + suffix;

      if (prefix) {
        funcName = prefix + funcName.charAt(0).toUpperCase() + funcName.slice(1);
      }

      func = win[funcName];

      if (func) {
        break;
      }
    }

    return func ? func.apply(void 0, arguments) : func;
  };
};

var requestAnimationFrame = getAFFunc('request');
var cancelFunc = getAFFunc('cancel');
var cancelRequestFunc = getAFFunc('cancelRequest');
var cancelAnimationFrame = function cancelAnimationFrame() {
  return cancelFunc.apply(void 0, arguments) || cancelRequestFunc.apply(void 0, arguments);
};

/***/ }),

/***/ "vF0m":
/***/ (function(module, exports, __webpack_require__) {

/* eslint-disable */
var React = __webpack_require__("cDcd");
var SpriteSymbol = __webpack_require__("QAmA");
var sprite = __webpack_require__("TQFg");

var symbol = new SpriteSymbol({
  "id": "2ggMRxLE--sprite",
  "use": "2ggMRxLE--sprite-usage",
  "viewBox": "0 0 1000.637 1000.678",
  "content": "<symbol xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 1000.637 1000.678\" id=\"2ggMRxLE--sprite\"><path d=\"M500.317 77.019c-234.747 0-423.326 188.565-423.326 423.313 0 234.749 188.579 423.328 423.326 423.328 234.749 0 423.328-188.579 423.328-423.328.001-234.748-188.579-423.313-423.328-423.313zm211.652 101.977v13.473c0 40.404-3.834 78.893-11.529 117.367-26.945 5.778-46.197 28.862-46.197 55.809 0 15.39 5.778 30.779 17.335 40.404-13.474 30.794-26.946 61.572-46.197 90.435-71.184-80.81-121.214-182.8-138.534-296.32 44.251-26.945 92.366-48.113 142.396-61.571 28.861 9.624 57.723 23.082 82.726 40.403zm-80.811 379.06c34.641 32.712 71.198 61.573 111.603 84.672-40.404 7.696-82.74 11.528-126.993 11.528-19.25 0-38.473-1.918-57.725-1.918 0-3.847 0-7.693-1.917-11.541 26.933-25.016 51.948-53.878 75.032-82.741zM500.317 115.492c21.168 0 42.336 1.932 63.504 5.778-26.945 11.541-53.893 23.084-80.822 36.558-1.933-13.474-1.933-26.946-1.933-40.404 5.78-1.932 13.474-1.932 19.251-1.932zm103.909 413.701c-21.167 28.862-44.266 53.879-69.268 78.895-9.624-7.695-21.168-11.557-34.641-11.557-25.016 0-46.184 15.403-53.878 38.502-76.962-19.252-150.076-48.114-215.496-88.518 17.306-65.421 46.169-127.008 82.726-180.871 3.862 0 7.695 1.917 13.474 1.917 32.711 0 57.726-25.016 57.726-57.726 0-7.695-1.917-15.39-3.847-23.085 23.098-23.085 46.183-42.335 71.183-61.572 21.167 115.451 75.059 219.359 152.021 304.015zM173.218 702.37c-34.64-57.726-55.808-123.145-57.726-194.344 23.086 19.251 46.169 38.489 71.185 53.879-7.694 42.336-13.459 86.586-13.459 130.854zm25.001-178.954c-28.861-19.236-53.863-40.405-78.893-63.489 19.252-173.176 153.938-311.71 325.184-338.656 0 21.168 1.93 40.404 3.862 61.572-32.725 23.1-63.504 48.1-92.366 75.046-9.611-5.778-19.251-7.695-28.863-7.695-32.71 0-57.726 25.002-57.726 57.726 0 13.473 5.778 25.001 13.474 36.558-38.489 53.876-67.351 113.518-84.672 178.938zm17.321 234.762c-1.932-21.168-3.848-42.335-3.848-65.418 0-36.572 3.848-73.131 11.542-107.758 69.268 40.392 144.313 71.186 223.205 88.505 0 1.917 0 1.917 1.933 3.847-67.351 44.269-144.313 73.13-227.068 86.589-3.834-1.93-3.834-3.847-5.764-5.765zm284.777 126.979c-94.281 0-178.953-34.626-246.29-90.421 80.81-15.391 153.924-46.183 219.345-90.45 7.694 5.779 17.336 7.694 26.945 7.694 19.253 0 34.641-9.61 46.185-23.083 23.083 1.93 46.182 3.862 69.266 3.862 61.575 0 121.229-7.71 178.955-21.169 13.472 5.763 26.933 13.459 40.404 17.307-65.435 117.381-190.496 196.26-334.81 196.26zm298.238-253.986c-53.862-26.93-103.895-63.502-146.228-105.824 21.167-32.71 38.486-67.351 53.877-101.977h5.765c32.724 0 57.724-25.016 57.724-57.726 0-23.099-13.458-42.336-32.696-51.961 7.696-34.627 11.544-69.268 11.544-105.825 82.74 71.198 134.687 175.092 134.687 292.473 0 38.475-5.778 73.115-15.391 107.757-21.167 9.611-44.252 17.306-69.282 23.083z\" /></symbol>"
});
sprite.add(symbol);

var SvgSpriteIcon = function SvgSpriteIcon(props) {
  return React.createElement(
    'svg',
    Object.assign({
      viewBox: symbol.viewBox
    }, props),
    React.createElement(
      'use',
      {
        xlinkHref: '#' + symbol.id
      }
    )
  );
};

SvgSpriteIcon.viewBox = symbol.viewBox;
SvgSpriteIcon.id = symbol.id;
SvgSpriteIcon.content = symbol.content;
SvgSpriteIcon.url = symbol.url;
SvgSpriteIcon.toString = symbol.toString;

module.exports = SvgSpriteIcon;
module.exports.default = SvgSpriteIcon;


/***/ }),

/***/ "vYYK":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _defineProperty; });
/* harmony import */ var _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("hfKm");
/* harmony import */ var _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__);

function _defineProperty(obj, key, value) {
  if (key in obj) {
    _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default()(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}

/***/ }),

/***/ "vqFK":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/symbol");

/***/ }),

/***/ "za0J":
/***/ (function(module, exports) {

module.exports = {
	"scene": "_1Zxh9h73",
	"paper-background": "_3DuBECud",
	"paperBackground": "_3DuBECud",
	"left-content": "_1LyUV2O_",
	"leftContent": "_1LyUV2O_",
	"center-content": "_242OCfn4",
	"centerContent": "_242OCfn4",
	"topic": "_1mi59G5i",
	"topic-title": "_1bqmkkVN",
	"topicTitle": "_1bqmkkVN",
	"topic-desc": "_2eLjJxyF",
	"topicDesc": "_2eLjJxyF",
	"topic-extend": "XGtqH0oX",
	"topicExtend": "XGtqH0oX",
	"topic-icon": "Fmyt4vOV",
	"topicIcon": "Fmyt4vOV",
	"topic-label": "_2WnbhL6a",
	"topicLabel": "_2WnbhL6a",
	"topic-action": "QHmQ3fB4",
	"topicAction": "QHmQ3fB4",
	"topic-button": "_1pq2TqNo",
	"topicButton": "_1pq2TqNo"
};

/***/ }),

/***/ "zrwo":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _objectSpread; });
/* harmony import */ var _core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("Jo+v");
/* harmony import */ var _core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("4mXO");
/* harmony import */ var _core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _core_js_object_keys__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("pLtp");
/* harmony import */ var _core_js_object_keys__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_keys__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _defineProperty__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("vYYK");




function _objectSpread(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i] != null ? arguments[i] : {};

    var ownKeys = _core_js_object_keys__WEBPACK_IMPORTED_MODULE_2___default()(source);

    if (typeof _core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1___default.a === 'function') {
      ownKeys = ownKeys.concat(_core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1___default()(source).filter(function (sym) {
        return _core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_0___default()(source, sym).enumerable;
      }));
    }

    ownKeys.forEach(function (key) {
      Object(_defineProperty__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"])(target, key, source[key]);
    });
  }

  return target;
}

/***/ })

/******/ });