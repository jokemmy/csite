module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../../../../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 11);
/******/ })
/************************************************************************/
/******/ ({

/***/ "+d49":
/***/ (function(module, exports) {

module.exports = "/_next/static/images/banner-3-ca2e9bd06e17bc23aea1129fc099c59d.jpg";

/***/ }),

/***/ "/+oN":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/get-prototype-of");

/***/ }),

/***/ "0iUn":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _classCallCheck; });
function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

/***/ }),

/***/ "1+QS":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/classCallCheck.js
var classCallCheck = __webpack_require__("0iUn");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/createClass.js
var createClass = __webpack_require__("sLSF");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/possibleConstructorReturn.js + 1 modules
var possibleConstructorReturn = __webpack_require__("MI3g");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/getPrototypeOf.js
var getPrototypeOf = __webpack_require__("a7VT");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/assertThisInitialized.js
var assertThisInitialized = __webpack_require__("AT/M");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/inherits.js + 1 modules
var inherits = __webpack_require__("Tit0");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/defineProperty.js
var defineProperty = __webpack_require__("vYYK");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/extends.js
var esm_extends = __webpack_require__("kOwS");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/objectWithoutProperties.js + 1 modules
var objectWithoutProperties = __webpack_require__("qNsG");

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__("cDcd");
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);

// EXTERNAL MODULE: external "whatitis"
var external_whatitis_ = __webpack_require__("lOhm");
var external_whatitis_default = /*#__PURE__*/__webpack_require__.n(external_whatitis_);

// EXTERNAL MODULE: external "omit.js"
var external_omit_js_ = __webpack_require__("LSCY");
var external_omit_js_default = /*#__PURE__*/__webpack_require__.n(external_omit_js_);

// EXTERNAL MODULE: external "rc-animate"
var external_rc_animate_ = __webpack_require__("Vam4");
var external_rc_animate_default = /*#__PURE__*/__webpack_require__.n(external_rc_animate_);

// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__("K2gz");
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);

// EXTERNAL MODULE: external "react-hammerjs"
var external_react_hammerjs_ = __webpack_require__("BgYr");
var external_react_hammerjs_default = /*#__PURE__*/__webpack_require__.n(external_react_hammerjs_);

// EXTERNAL MODULE: external "rc-tween-one"
var external_rc_tween_one_ = __webpack_require__("VNO/");
var external_rc_tween_one_default = /*#__PURE__*/__webpack_require__.n(external_rc_tween_one_);

// EXTERNAL MODULE: external "rc-util/lib/Dom/addEventListener"
var addEventListener_ = __webpack_require__("BI0l");
var addEventListener_default = /*#__PURE__*/__webpack_require__.n(addEventListener_);

// EXTERNAL MODULE: ./lib/requestAnimationFrame.js
var requestAnimationFrame = __webpack_require__("ushU");

// EXTERNAL MODULE: ./assets/motions/cScale.less
var cScale = __webpack_require__("SC1p");

// EXTERNAL MODULE: ./assets/motions/cSlideUp.less
var cSlideUp = __webpack_require__("Te8+");

// EXTERNAL MODULE: ./assets/motions/cSlideDown.less
var cSlideDown = __webpack_require__("Qnt8");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/objectSpread.js
var objectSpread = __webpack_require__("zrwo");

// EXTERNAL MODULE: ./components/Carousel/points.less
var Carousel_points = __webpack_require__("2crN");
var points_default = /*#__PURE__*/__webpack_require__.n(Carousel_points);

// CONCATENATED MODULE: ./components/Carousel/points.js












var points_Points =
/*#__PURE__*/
function (_React$Component) {
  Object(inherits["a" /* default */])(Points, _React$Component);

  function Points() {
    var _getPrototypeOf2;

    var _this;

    Object(classCallCheck["a" /* default */])(this, Points);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = Object(possibleConstructorReturn["a" /* default */])(this, (_getPrototypeOf2 = Object(getPrototypeOf["a" /* default */])(Points)).call.apply(_getPrototypeOf2, [this].concat(args)));

    Object(defineProperty["a" /* default */])(Object(assertThisInitialized["a" /* default */])(_this), "handleClick", function (i) {
      return function () {
        var _this$props = _this.props,
            onChange = _this$props.onChange,
            index = _this$props.index;

        if (index !== i) {
          onChange(i);
        }
      };
    });

    return _this;
  }

  Object(createClass["a" /* default */])(Points, [{
    key: "render",
    value: function render() {
      var _this2 = this;

      var _this$props2 = this.props,
          points = _this$props2.points,
          index = _this$props2.index,
          size = _this$props2.size;
      var sizeStyle = {
        height: "".concat(100 / points.length, "%")
      };

      var blockProps = function blockProps(i) {
        return {
          className: points_default.a.block,
          onClick: _this2.handleClick(i),
          style: sizeStyle
        };
      };

      return external_react_default.a.createElement("div", {
        className: points_default.a.track,
        style: {
          height: size
        }
      }, points.map(function (point, i) {
        return i === index ? external_react_default.a.createElement("div", Object(esm_extends["a" /* default */])({
          key: "point-".concat(i)
        }, blockProps(i))) : external_react_default.a.createElement("div", Object(esm_extends["a" /* default */])({
          key: "active-point-".concat(i)
        }, blockProps(i)));
      }), external_react_default.a.createElement("div", {
        className: points_default.a.thumb,
        style: Object(objectSpread["a" /* default */])({
          top: "".concat(index * 100 / points.length, "%")
        }, sizeStyle)
      }));
    }
  }]);

  return Points;
}(external_react_default.a.Component);

/* harmony default export */ var components_Carousel_points = (points_Points);
// EXTERNAL MODULE: ./components/Carousel/carousel.less
var carousel = __webpack_require__("Pnzm");
var carousel_default = /*#__PURE__*/__webpack_require__.n(carousel);

// CONCATENATED MODULE: ./components/Carousel/index.js
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CarouselContext; });























var TweenOneGroup = external_rc_tween_one_default.a.TweenOneGroup;
var CarouselContext = external_react_default.a.createContext({
  isEnable: true
});

function HammerHoc(_ref) {
  var disabled = _ref.disabled,
      children = _ref.children,
      props = Object(objectWithoutProperties["a" /* default */])(_ref, ["disabled", "children"]);

  return disabled ? children : external_react_default.a.createElement(external_react_hammerjs_default.a, Object(esm_extends["a" /* default */])({}, props, {
    direction: "DIRECTION_VERTICAL"
  }), children);
}

var Carousel_Carousel =
/*#__PURE__*/
function (_React$Component) {
  Object(inherits["a" /* default */])(Carousel, _React$Component);

  function Carousel() {
    var _getPrototypeOf2;

    var _this;

    Object(classCallCheck["a" /* default */])(this, Carousel);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = Object(possibleConstructorReturn["a" /* default */])(this, (_getPrototypeOf2 = Object(getPrototypeOf["a" /* default */])(Carousel)).call.apply(_getPrototypeOf2, [this].concat(args)));

    Object(defineProperty["a" /* default */])(Object(assertThisInitialized["a" /* default */])(_this), "state", {
      index: 0,
      scrolling: false,
      isEnable: true
    });

    Object(defineProperty["a" /* default */])(Object(assertThisInitialized["a" /* default */])(_this), "handleWheel", function (e) {
      // 正数页面向上,负数页面向下
      var delta = (whatenvis.firefox ? 3 : 1) * e.delta;
      var _this$props = _this.props,
          children = _this$props.children,
          disabled = _this$props.disabled;
      var _this$state = _this.state,
          index = _this$state.index,
          scrolling = _this$state.scrolling;
      var count = external_react_default.a.Children.toArray(children).length - 1;

      if (!disabled && scrolling === false) {
        if (delta > 0 && index > 0) {
          _this.handleChange(index - 1);
        } else if (delta < 0 && index < count) {
          _this.handleChange(index + 1);
        }
      }
    });

    Object(defineProperty["a" /* default */])(Object(assertThisInitialized["a" /* default */])(_this), "handleScrollEnd", function (_, exists) {
      if (exists) {
        var onEnd = _this.props.onEnd;
        _this.state.scrolling = false; // eslint-disable-line

        _this.setState({
          isEnable: true
        }, external_whatitis_default.a.Function(onEnd) ? onEnd : null);
      }
    });

    Object(defineProperty["a" /* default */])(Object(assertThisInitialized["a" /* default */])(_this), "handleChange", function (targetIndex) {
      var _this$props2 = _this.props,
          index = _this$props2.index,
          onChange = _this$props2.onChange;

      if (external_whatitis_default.a.Number(index) && index >= 0) {
        external_whatitis_default.a.Function(onChange) && onChange(targetIndex);
      } else {
        var _this$state2 = _this.state,
            _index = _this$state2.index,
            scrolling = _this$state2.scrolling;

        if (scrolling === false) {
          _this.state.scrolling = true; // eslint-disable-line

          _this.setState({
            isEnable: false
          }, function () {
            _this.rafHandle = Object(requestAnimationFrame["b" /* requestAnimationFrame */])(function () {
              _this.rafHandle = null;

              _this.setState({
                index: targetIndex,
                direction: targetIndex > _index ? 1 : 0
              });
            });
          });
        }
      }
    });

    Object(defineProperty["a" /* default */])(Object(assertThisInitialized["a" /* default */])(_this), "handleSwipe", function (event) {
      var index = _this.state.index;
      var children = _this.props.children;
      var count = external_react_default.a.Children.toArray(children).length;
      var offsetDirection = event.offsetDirection;
      event.preventDefault();

      if (offsetDirection === 8 && index < count - 1) {
        // 上
        _this.handleChange(index + 1);
      }

      if (offsetDirection === 16 && index > 0) {
        // 下
        _this.handleChange(index - 1);
      }
    });

    Object(defineProperty["a" /* default */])(Object(assertThisInitialized["a" /* default */])(_this), "handleSlider", function () {
      var children = _this.props.children;
      var _this$state3 = _this.state,
          index = _this$state3.index,
          scrolling = _this$state3.scrolling;
      var count = external_react_default.a.Children.toArray(children).length - 1;

      if (scrolling === false) {
        if (index < count) {
          _this.handleChange(index + 1);
        }
      }
    });

    return _this;
  }

  Object(createClass["a" /* default */])(Carousel, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      var eventName = whatenvis.firefox ? 'DOMMouseScroll' : 'mousewheel';
      this.wheelListener = addEventListener_default()(document.body, eventName, this.handleWheel);
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      if (this.wheelListener) {
        this.wheelListener.remove();
        this.wheelListener = null;
      }

      if (this.rafHandle) {
        Object(requestAnimationFrame["a" /* cancelAnimationFrame */])(this.rafHandle);
        this.rafHandle = null;
      }
    }
  }, {
    key: "render",
    value: function render() {
      var _this$state4 = this.state,
          index = _this$state4.index,
          direction = _this$state4.direction,
          isEnable = _this$state4.isEnable;

      var _omit = external_omit_js_default()(this.props, ['onEnd']),
          children = _omit.children,
          className = _omit.className,
          disabled = _omit.disabled,
          showPoints = _omit.showPoints,
          showArrow = _omit.showArrow,
          props = Object(objectWithoutProperties["a" /* default */])(_omit, ["children", "className", "disabled", "showPoints", "showArrow"]);

      var childArray = external_react_default.a.Children.toArray(children);
      var count = childArray.length;
      var child = childArray.find(function (_, i) {
        return i === index;
      });
      return external_react_default.a.createElement(CarouselContext.Provider, {
        value: {
          isEnable: isEnable
        }
      }, external_react_default.a.createElement(HammerHoc, {
        onSwipe: this.handleSwipe,
        disabled: disabled
      }, external_react_default.a.createElement("div", Object(esm_extends["a" /* default */])({}, props, {
        className: external_classnames_default()(className, carousel_default.a.carousel)
      }), external_react_default.a.createElement(external_rc_animate_default.a, {
        component: "div",
        transitionAppear: false,
        onEnd: this.handleScrollEnd,
        transitionName: direction ? 'c-slide-up' : 'c-slide-down'
      }, external_react_default.a.createElement("div", {
        key: "".concat(index),
        className: carousel_default.a.paper
      }, external_react_default.a.createElement("div", {
        className: "c-scale"
      }, child))), showPoints ? external_react_default.a.createElement(components_Carousel_points, {
        size: "100%",
        index: index,
        onChange: this.handleChange,
        points: Array(count).fill(1)
      }) : null, external_react_default.a.createElement(TweenOneGroup, {
        component: "",
        enter: {
          opacity: 0,
          type: 'from',
          duration: 2000
        },
        leave: {
          opacity: 0,
          duration: 2000
        }
      }, showArrow && count - 1 > index ? external_react_default.a.createElement("div", {
        key: "arrow",
        className: carousel_default.a.arrowDown,
        onClick: this.handleSlider
      }, external_react_default.a.createElement("div", {
        className: carousel_default.a.arrowDownAnim
      }, external_react_default.a.createElement("em", null), external_react_default.a.createElement("em", null), external_react_default.a.createElement("em", null))) : null))));
    }
  }]);

  return Carousel;
}(external_react_default.a.Component);

Object(defineProperty["a" /* default */])(Carousel_Carousel, "defaultProps", {
  showArrow: true,
  showPoints: true
});

Object(defineProperty["a" /* default */])(Carousel_Carousel, "getDerivedStateFromProps", function (props, state) {
  if (external_whatitis_default.a.Number(props.index) && props.index >= 0 && state.index !== props.index) {
    return {
      index: props.index,
      direction: props.index > state.index ? 1 : 0,
      scrolling: false,
      isEnable: false
    };
  }

  return null;
});

/* harmony default export */ var components_Carousel = __webpack_exports__["b"] = (Carousel_Carousel);

/***/ }),

/***/ 11:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("auXZ");


/***/ }),

/***/ "2bz7":
/***/ (function(module, exports, __webpack_require__) {

/* eslint-disable */
var React = __webpack_require__("cDcd");
var SpriteSymbol = __webpack_require__("QAmA");
var sprite = __webpack_require__("TQFg");

var symbol = new SpriteSymbol({
  "id": "1p4fRT6e--sprite",
  "use": "1p4fRT6e--sprite-usage",
  "viewBox": "0 0 1000.637 1000.678",
  "content": "<symbol xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 1000.637 1000.678\" id=\"1p4fRT6e--sprite\"><path d=\"M743.59 522.013H623.646a43.347 43.347 0 0 1-30.836-12.516l-75.146-70.819c-18.497-16.824-47.136-15.479-63.97 3.02a52.182 52.182 0 0 0-1.549 1.795l-48.17 61.18a44.787 44.787 0 0 1-35.171 17.34H256.567v-43.357h87.669a48.13 48.13 0 0 0 35.65-16.85l66.003-83.83c15.302-19.435 43.472-22.78 62.907-7.478a43.14 43.14 0 0 1 3.081 2.663l96.351 93.457a44.752 44.752 0 0 0 30.824 12.037h102.133z\" /><path d=\"M784.539 702.662H216.105c-29.277 0-52.996-23.719-52.996-52.987V264.288c0-29.259 23.718-52.986 52.996-52.986h568.434c29.27 0 52.988 23.728 52.988 52.986v385.387c0 29.268-23.718 52.987-52.988 52.987zM216.105 259.473c-2.567.23-4.602 2.257-4.823 4.815v385.387a5.303 5.303 0 0 0 5.301 5.301h567.956a5.304 5.304 0 0 0 4.824-5.301V264.288a5.322 5.322 0 0 0-4.824-4.815zm551.096 529.903H227.185c-13.31.016-24.1-10.764-24.108-24.065-.018-13.302 10.762-24.099 24.064-24.106h540.061c13.295.008 24.076 10.805 24.066 24.106-.01 13.283-10.78 24.054-24.067 24.065z\" /></symbol>"
});
sprite.add(symbol);

var SvgSpriteIcon = function SvgSpriteIcon(props) {
  return React.createElement(
    'svg',
    Object.assign({
      viewBox: symbol.viewBox
    }, props),
    React.createElement(
      'use',
      {
        xlinkHref: '#' + symbol.id
      }
    )
  );
};

SvgSpriteIcon.viewBox = symbol.viewBox;
SvgSpriteIcon.id = symbol.id;
SvgSpriteIcon.content = symbol.content;
SvgSpriteIcon.url = symbol.url;
SvgSpriteIcon.toString = symbol.toString;

module.exports = SvgSpriteIcon;
module.exports.default = SvgSpriteIcon;


/***/ }),

/***/ "2crN":
/***/ (function(module, exports) {

module.exports = {
	"track": "_1ujYANvT",
	"block": "_1_K01DDo",
	"thumb": "_3m-xWWqN"
};

/***/ }),

/***/ "4mXO":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("k1wZ");

/***/ }),

/***/ "5dF4":
/***/ (function(module, exports, __webpack_require__) {

/* eslint-disable */
var React = __webpack_require__("cDcd");
var SpriteSymbol = __webpack_require__("QAmA");
var sprite = __webpack_require__("TQFg");

var symbol = new SpriteSymbol({
  "id": "1JYjvWBU--sprite",
  "use": "1JYjvWBU--sprite-usage",
  "viewBox": "0 0 1000.637 1000.678",
  "content": "<symbol xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 1000.637 1000.678\" id=\"1JYjvWBU--sprite\"><path d=\"M479.222 579.314V310.756c0-12.22 9.812-22.143 21.921-22.143 12.112 0 21.919 9.923 21.919 22.143v180.709l74.697-75.45c8.548-8.648 22.44-8.648 30.987 0 8.563 8.635 8.563 22.668 0 31.304L523.062 554.086v165.321c21.784-2.438 33.034-4.541 44.473-8.388l2.179-.691c76.873-22.725 131.812-92.722 135.579-174.301 1.574-42.154-6.673-78.662-24.564-114.794-15.536-31.414-37.375-61.569-73.805-104.042-7.479-8.731-10.837-12.579-28.428-32.632-32.702-35.261-57.734-64.365-77.903-91.932-6.655 8.911-13.918 18.087-21.837 27.705-8.055 9.757-16.575 19.708-27.509 32.205-4.11 4.704-22.537 25.643-27.456 31.289l-1.342 1.467c-48.499 52.063-74.312 83.988-94.013 119.181-23.209 41.394-33.907 82.938-32.1 131.554 3.739 80.929 57.844 150.47 133.757 173.75 19.017 4.233 35.154 7.374 49.129 9.408v-78.549a22.035 22.035 0 0 1-5.097-3.849L367.208 528.817c-8.549-8.664-8.549-22.684 0-31.317a21.783 21.783 0 0 1 31.019 0zm41.232 179.253c-2.435 54.281-38.868 89.985-103.933 105.007-10.747 2.488-21.443-4.365-23.891-15.29-2.444-10.923 4.295-21.809 15.054-24.296 26.061-6.016 44.809-15.353 56.59-27.47 9.762-10.049 15.129-22.435 16.177-38.002-19.06-2.398-39.803-6.648-58.614-10.887-91.912-27.355-159.186-111.681-163.667-211.981-4.48-118.52 58.3-193.735 130.043-271.235 33.624-38.738 67.274-75.216 89.691-113.953 6.715-13.678 24.664-18.246 35.872-9.123 4.481 2.271 6.727 6.839 8.961 9.123 22.43 38.737 56.067 77.487 89.692 113.953 69.508 79.771 134.522 152.715 130.043 271.235-4.481 100.301-71.757 184.626-163.668 211.981-18.846 6.371-37.694 8.794-58.35 10.938z\" /></symbol>"
});
sprite.add(symbol);

var SvgSpriteIcon = function SvgSpriteIcon(props) {
  return React.createElement(
    'svg',
    Object.assign({
      viewBox: symbol.viewBox
    }, props),
    React.createElement(
      'use',
      {
        xlinkHref: '#' + symbol.id
      }
    )
  );
};

SvgSpriteIcon.viewBox = symbol.viewBox;
SvgSpriteIcon.id = symbol.id;
SvgSpriteIcon.content = symbol.content;
SvgSpriteIcon.url = symbol.url;
SvgSpriteIcon.toString = symbol.toString;

module.exports = SvgSpriteIcon;
module.exports.default = SvgSpriteIcon;


/***/ }),

/***/ "AT/M":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _assertThisInitialized; });
function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

/***/ }),

/***/ "BE5S":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return Icon; });
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("kOwS");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("qNsG");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("K2gz");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _svgIcon_less__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("flPq");
/* harmony import */ var _svgIcon_less__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_svgIcon_less__WEBPACK_IMPORTED_MODULE_4__);





function Icon(_ref) {
  var icon = _ref.icon,
      className = _ref.className,
      props = Object(_babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(_ref, ["icon", "className"]);

  return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("svg", Object(_babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])({
    "aria-hidden": "true"
  }, props, {
    className: classnames__WEBPACK_IMPORTED_MODULE_3___default()(_svgIcon_less__WEBPACK_IMPORTED_MODULE_4___default.a.svgIcon, className)
  }), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("use", {
    xlinkHref: "#".concat(icon.id)
  }));
}

/***/ }),

/***/ "BI0l":
/***/ (function(module, exports) {

module.exports = require("rc-util/lib/Dom/addEventListener");

/***/ }),

/***/ "BgYr":
/***/ (function(module, exports) {

module.exports = require("react-hammerjs");

/***/ }),

/***/ "Bhuq":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("/+oN");

/***/ }),

/***/ "IMUT":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("kOwS");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("qNsG");
/* harmony import */ var _babel_runtime_corejs2_core_js_object_assign__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("UXZV");
/* harmony import */ var _babel_runtime_corejs2_core_js_object_assign__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_core_js_object_assign__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("0iUn");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("sLSF");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("MI3g");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("a7VT");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__("Tit0");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__("vYYK");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var omit_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__("LSCY");
/* harmony import */ var omit_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(omit_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var parallax_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__("W0Av");
/* harmony import */ var parallax_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(parallax_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _components_Carousel__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__("1+QS");












 //https://ken.artbees.net/wide-parallax-startup/

var Scene =
/*#__PURE__*/
function (_React$Component) {
  Object(_babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_7__[/* default */ "a"])(Scene, _React$Component);

  function Scene(props) {
    var _this;

    Object(_babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"])(this, Scene);

    _this = Object(_babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"])(this, Object(_babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_6__[/* default */ "a"])(Scene).call(this, props));
    _this.sceneRef = react__WEBPACK_IMPORTED_MODULE_9___default.a.createRef();
    return _this;
  }

  Object(_babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_4__[/* default */ "a"])(Scene, [{
    key: "componentDidUpdate",
    value: function componentDidUpdate() {
      var isEnable = this.context.isEnable;

      if (isEnable) {
        this.createParallax();
      } else {
        this.destroyParallax();
      }
    }
  }, {
    key: "componentDidMount",
    value: function componentDidMount() {
      var isEnable = this.context.isEnable;

      if (isEnable) {
        this.createParallax();
      }
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      this.destroyParallax();
    }
  }, {
    key: "createParallax",
    value: function createParallax() {
      var defaultOptions = {
        selector: '.paper'
      };
      var options = this.props.options;
      this.parallaxInstance = new parallax_js__WEBPACK_IMPORTED_MODULE_11___default.a(this.sceneRef.current, _babel_runtime_corejs2_core_js_object_assign__WEBPACK_IMPORTED_MODULE_2___default()(defaultOptions, options));
    }
  }, {
    key: "destroyParallax",
    value: function destroyParallax() {
      if (this.parallaxInstance) {
        this.parallaxInstance.destroy();
        this.parallaxInstance = null;
      }
    }
  }, {
    key: "render",
    value: function render() {
      var _omit = omit_js__WEBPACK_IMPORTED_MODULE_10___default()(this.props, ['options']),
          children = _omit.children,
          className = _omit.className,
          props = Object(_babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(_omit, ["children", "className"]);

      return react__WEBPACK_IMPORTED_MODULE_9___default.a.createElement("div", Object(_babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])({}, props, {
        ref: this.sceneRef,
        className: "".concat(className ? "".concat(className, " ") : '', "scene")
      }), children);
    }
  }]);

  return Scene;
}(react__WEBPACK_IMPORTED_MODULE_9___default.a.Component);

Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_8__[/* default */ "a"])(Scene, "contextType", _components_Carousel__WEBPACK_IMPORTED_MODULE_12__[/* CarouselContext */ "a"]);

/* harmony default export */ __webpack_exports__["a"] = (Scene);

/***/ }),

/***/ "Jo+v":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("Z6Kq");

/***/ }),

/***/ "K2gz":
/***/ (function(module, exports) {

module.exports = require("classnames");

/***/ }),

/***/ "LSCY":
/***/ (function(module, exports) {

module.exports = require("omit.js");

/***/ }),

/***/ "MI3g":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/symbol/iterator.js
var iterator = __webpack_require__("XVgq");
var iterator_default = /*#__PURE__*/__webpack_require__.n(iterator);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/symbol.js
var symbol = __webpack_require__("Z7t5");
var symbol_default = /*#__PURE__*/__webpack_require__.n(symbol);

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/typeof.js



function typeof_typeof2(obj) { if (typeof symbol_default.a === "function" && typeof iterator_default.a === "symbol") { typeof_typeof2 = function _typeof2(obj) { return typeof obj; }; } else { typeof_typeof2 = function _typeof2(obj) { return obj && typeof symbol_default.a === "function" && obj.constructor === symbol_default.a && obj !== symbol_default.a.prototype ? "symbol" : typeof obj; }; } return typeof_typeof2(obj); }

function typeof_typeof(obj) {
  if (typeof symbol_default.a === "function" && typeof_typeof2(iterator_default.a) === "symbol") {
    typeof_typeof = function _typeof(obj) {
      return typeof_typeof2(obj);
    };
  } else {
    typeof_typeof = function _typeof(obj) {
      return obj && typeof symbol_default.a === "function" && obj.constructor === symbol_default.a && obj !== symbol_default.a.prototype ? "symbol" : typeof_typeof2(obj);
    };
  }

  return typeof_typeof(obj);
}
// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/assertThisInitialized.js
var assertThisInitialized = __webpack_require__("AT/M");

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/possibleConstructorReturn.js
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _possibleConstructorReturn; });


function _possibleConstructorReturn(self, call) {
  if (call && (typeof_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return Object(assertThisInitialized["a" /* default */])(self);
}

/***/ }),

/***/ "Pnzm":
/***/ (function(module, exports) {

module.exports = {
	"carousel": "QIruQvWN",
	"paper": "IDE1NymA",
	"arrow-down": "_11U8PP3q",
	"arrowDown": "_11U8PP3q",
	"arrow-down-anim": "OiG04KV1",
	"arrowDownAnim": "OiG04KV1",
	"arrowDownAnimKF": "_2nZLV2q0",
	"arrowDownAnimKf": "_2nZLV2q0"
};

/***/ }),

/***/ "QAmA":
/***/ (function(module, exports) {

module.exports = require("svg-baker-runtime/symbol");

/***/ }),

/***/ "QncY":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("kOwS");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("qNsG");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("0iUn");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("sLSF");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("MI3g");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("a7VT");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("Tit0");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);









var Paper =
/*#__PURE__*/
function (_React$Component) {
  Object(_babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_6__[/* default */ "a"])(Paper, _React$Component);

  function Paper() {
    Object(_babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_2__[/* default */ "a"])(this, Paper);

    return Object(_babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__[/* default */ "a"])(this, Object(_babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"])(Paper).apply(this, arguments));
  }

  Object(_babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"])(Paper, [{
    key: "render",
    value: function render() {
      var _this$props = this.props,
          depth = _this$props.depth,
          children = _this$props.children,
          className = _this$props.className,
          props = Object(_babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(_this$props, ["depth", "children", "className"]);

      return react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", Object(_babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])({}, props, {
        className: "".concat(className ? "".concat(className, " ") : '', "paper"),
        "data-depth": depth
      }), children);
    }
  }]);

  return Paper;
}(react__WEBPACK_IMPORTED_MODULE_7___default.a.Component);

/* harmony default export */ __webpack_exports__["a"] = (Paper);

/***/ }),

/***/ "Qnt8":
/***/ (function(module, exports) {

module.exports = {
	"cslideDownIn": "_33bJsfF1",
	"cslideDownOut": "_26zD-TbW"
};

/***/ }),

/***/ "SC1p":
/***/ (function(module, exports) {

module.exports = {
	"cScaleIn": "yzEr1rWc",
	"cScaleOut": "_34mAihAf"
};

/***/ }),

/***/ "SqZg":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("o5io");

/***/ }),

/***/ "TQFg":
/***/ (function(module, exports) {

module.exports = require("svg-sprite-loader/runtime/sprite.build");

/***/ }),

/***/ "TRZx":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("Wk4r");

/***/ }),

/***/ "TUA0":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/define-property");

/***/ }),

/***/ "Te8+":
/***/ (function(module, exports) {

module.exports = {
	"cslideUpIn": "_1BDx8_C5",
	"cslideUpOut": "_1Ck_eq3l"
};

/***/ }),

/***/ "Tit0":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/create.js
var create = __webpack_require__("SqZg");
var create_default = /*#__PURE__*/__webpack_require__.n(create);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/set-prototype-of.js
var set_prototype_of = __webpack_require__("TRZx");
var set_prototype_of_default = /*#__PURE__*/__webpack_require__.n(set_prototype_of);

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/setPrototypeOf.js

function _setPrototypeOf(o, p) {
  _setPrototypeOf = set_prototype_of_default.a || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}
// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/inherits.js
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _inherits; });


function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = create_default()(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

/***/ }),

/***/ "UXZV":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("dGr4");

/***/ }),

/***/ "VNO/":
/***/ (function(module, exports) {

module.exports = require("rc-tween-one");

/***/ }),

/***/ "Vam4":
/***/ (function(module, exports) {

module.exports = require("rc-animate");

/***/ }),

/***/ "W0Av":
/***/ (function(module, exports) {

module.exports = require("parallax-js");

/***/ }),

/***/ "Wk4r":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/set-prototype-of");

/***/ }),

/***/ "XVgq":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("gHn/");

/***/ }),

/***/ "Z4xq":
/***/ (function(module, exports, __webpack_require__) {

/* eslint-disable */
var React = __webpack_require__("cDcd");
var SpriteSymbol = __webpack_require__("QAmA");
var sprite = __webpack_require__("TQFg");

var symbol = new SpriteSymbol({
  "id": "XKKiZiT3--sprite",
  "use": "XKKiZiT3--sprite-usage",
  "viewBox": "0 0 1000.637 1000.678",
  "content": "<symbol xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 1000.637 1000.678\" id=\"XKKiZiT3--sprite\"><path d=\"M289.583 826.415h-26.51c-41.229 0-74.758-38.69-74.758-86.233V395.289c0-47.554 33.529-86.233 74.758-86.233h26.51c41.218 0 74.746 38.673 74.746 86.227v344.899c-.001 47.543-33.529 86.233-74.746 86.233zm-26.511-470.339c-17.247 0-31.261 17.575-31.261 39.189v344.917c0 21.598 14.014 39.194 31.261 39.194h26.51c17.222 0 31.248-17.597 31.248-39.194V395.289c0-21.62-14.037-39.195-31.248-39.195zm250.574 470.339h-26.465c-41.192 0-74.699-38.69-74.699-86.233V489.339c0-47.555 33.506-86.226 74.699-86.226h26.465c41.203 0 74.684 38.671 74.684 86.226v250.856c0 47.53-33.492 86.22-74.684 86.22zm-26.465-376.272c-17.223 0-31.225 17.576-31.225 39.196v250.856c0 21.595 14.002 39.195 31.225 39.195h26.465c17.221 0 31.232-17.601 31.232-39.195V489.339c0-21.621-14.012-39.196-31.232-39.196zM737.73 826.415h-26.451c-41.123 0-74.582-38.69-74.582-86.233V238.49c0-47.554 33.459-86.227 74.582-86.227h26.451c41.135 0 74.592 38.673 74.592 86.227v501.692c0 47.543-33.457 86.233-74.592 86.233zm-26.451-627.12c-17.188 0-31.178 17.575-31.178 39.195v501.692c0 21.598 13.99 39.194 31.178 39.194h26.451c17.188 0 31.178-17.597 31.178-39.194V238.49c0-21.62-13.979-39.195-31.178-39.195z\" /></symbol>"
});
sprite.add(symbol);

var SvgSpriteIcon = function SvgSpriteIcon(props) {
  return React.createElement(
    'svg',
    Object.assign({
      viewBox: symbol.viewBox
    }, props),
    React.createElement(
      'use',
      {
        xlinkHref: '#' + symbol.id
      }
    )
  );
};

SvgSpriteIcon.viewBox = symbol.viewBox;
SvgSpriteIcon.id = symbol.id;
SvgSpriteIcon.content = symbol.content;
SvgSpriteIcon.url = symbol.url;
SvgSpriteIcon.toString = symbol.toString;

module.exports = SvgSpriteIcon;
module.exports.default = SvgSpriteIcon;


/***/ }),

/***/ "Z6Kq":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/get-own-property-descriptor");

/***/ }),

/***/ "Z7t5":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("vqFK");

/***/ }),

/***/ "a7VT":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _getPrototypeOf; });
/* harmony import */ var _core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("Bhuq");
/* harmony import */ var _core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("TRZx");
/* harmony import */ var _core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_1__);


function _getPrototypeOf(o) {
  _getPrototypeOf = _core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_1___default.a ? _core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0___default.a : function _getPrototypeOf(o) {
    return o.__proto__ || _core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0___default()(o);
  };
  return _getPrototypeOf(o);
}

/***/ }),

/***/ "auXZ":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("kOwS");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("qNsG");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("0iUn");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("sLSF");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("MI3g");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("a7VT");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("Tit0");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__("K2gz");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _components_SvgIcon__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__("BE5S");
/* harmony import */ var _components_Parallax__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__("IMUT");
/* harmony import */ var _components_Parallax_Paper__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__("QncY");
/* harmony import */ var _assets_images_app_banner_3_banner_3_jpg__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__("+d49");
/* harmony import */ var _assets_images_app_banner_3_banner_3_jpg__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_assets_images_app_banner_3_banner_3_jpg__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _assets_images_app_banner_3_svg_1_svg_sprite__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__("2bz7");
/* harmony import */ var _assets_images_app_banner_3_svg_1_svg_sprite__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_assets_images_app_banner_3_svg_1_svg_sprite__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _assets_images_app_banner_3_svg_2_svg_sprite__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__("Z4xq");
/* harmony import */ var _assets_images_app_banner_3_svg_2_svg_sprite__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_assets_images_app_banner_3_svg_2_svg_sprite__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _assets_images_app_banner_3_svg_3_svg_sprite__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__("5dF4");
/* harmony import */ var _assets_images_app_banner_3_svg_3_svg_sprite__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_assets_images_app_banner_3_svg_3_svg_sprite__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _parallax_less__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__("za0J");
/* harmony import */ var _parallax_less__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_parallax_less__WEBPACK_IMPORTED_MODULE_16__);







 // import Link from 'next/link';










var options = {
  // selector: '.paper',
  // relativeInput: true
  // clipRelativeInput: true,
  // scalarX: 10,
  // scalarY: 10,
  limitX: 30,
  limitY: 30 // frictionX: 0.1,
  // frictionY: 0.1

};

var WallPaper =
/*#__PURE__*/
function (_React$Component) {
  Object(_babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_6__[/* default */ "a"])(WallPaper, _React$Component);

  function WallPaper() {
    Object(_babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_2__[/* default */ "a"])(this, WallPaper);

    return Object(_babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__[/* default */ "a"])(this, Object(_babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"])(WallPaper).apply(this, arguments));
  }

  Object(_babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"])(WallPaper, [{
    key: "render",
    value: function render() {
      var _this$props = this.props,
          className = _this$props.className,
          props = Object(_babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(_this$props, ["className"]);

      return react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_components_Parallax__WEBPACK_IMPORTED_MODULE_10__[/* default */ "a"], Object(_babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])({}, props, {
        className: classnames__WEBPACK_IMPORTED_MODULE_8___default()(_parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.scene, className),
        options: options
      }), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_components_Parallax_Paper__WEBPACK_IMPORTED_MODULE_11__[/* default */ "a"], {
        depth: 0.2
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.paperBackground,
        style: {
          backgroundImage: "url(".concat(_assets_images_app_banner_3_banner_3_jpg__WEBPACK_IMPORTED_MODULE_12___default.a, ")")
        }
      })), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.leftContent
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_8___default()(_parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.topic, 'AppSiYuan')
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("h1", {
        className: classnames__WEBPACK_IMPORTED_MODULE_8___default()(_parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.topicTitle, 'AppSiYuan')
      }, "\u6570\u636E\u4E2D\u5FC3"), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("p", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.topicDesc
      }, "\u5145\u5206\u5229\u7528\u4E91\u8BA1\u7B97\u548C\u5927\u6570\u636E\u6280\u672F\uFF0C\u9002\u914D\u5404\u4E2A\u884C\u4E1A\u9700\u6C42\uFF0C\u4E3A\u5BA2\u6237\u63D0\u4F9B\u6258\u7BA1\u4E91\u3001\u6DF7\u5408\u4E91\u7B49\u573A\u666F\u4E0B\u7684\u89E3\u51B3\u65B9\u6848\uFF0C\u5B9E\u73B0\u4E1A\u52A1\u5168\u9762\u4E91\u5316\uFF0C\u63A8\u8FDB\u884C\u4E1A\u6570\u5B57\u5316\u8F6C\u578B\u3002"), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.topicExtend
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.topicIcon
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_components_SvgIcon__WEBPACK_IMPORTED_MODULE_9__[/* default */ "a"], {
        icon: _assets_images_app_banner_3_svg_1_svg_sprite__WEBPACK_IMPORTED_MODULE_13___default.a
      }), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.topicLabel
      }, "\u6781\u81F4\u6027\u80FD")), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.topicIcon
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_components_SvgIcon__WEBPACK_IMPORTED_MODULE_9__[/* default */ "a"], {
        icon: _assets_images_app_banner_3_svg_2_svg_sprite__WEBPACK_IMPORTED_MODULE_14___default.a
      }), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.topicLabel
      }, "\u667A\u80FD\u5206\u6790")), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.topicIcon
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_components_SvgIcon__WEBPACK_IMPORTED_MODULE_9__[/* default */ "a"], {
        icon: _assets_images_app_banner_3_svg_3_svg_sprite__WEBPACK_IMPORTED_MODULE_15___default.a
      }), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.topicLabel
      }, "\u8282\u80FD\u73AF\u4FDD"))))));
    }
  }]);

  return WallPaper;
}(react__WEBPACK_IMPORTED_MODULE_7___default.a.Component);

/* harmony default export */ __webpack_exports__["default"] = (WallPaper);

/***/ }),

/***/ "cDcd":
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "dGr4":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/assign");

/***/ }),

/***/ "flPq":
/***/ (function(module, exports) {

module.exports = {
	"svg-icon": "_39UYRa5H",
	"svgIcon": "_39UYRa5H"
};

/***/ }),

/***/ "gHn/":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/symbol/iterator");

/***/ }),

/***/ "hfKm":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("TUA0");

/***/ }),

/***/ "k1wZ":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/get-own-property-symbols");

/***/ }),

/***/ "kOwS":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _extends; });
/* harmony import */ var _core_js_object_assign__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("UXZV");
/* harmony import */ var _core_js_object_assign__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_assign__WEBPACK_IMPORTED_MODULE_0__);

function _extends() {
  _extends = _core_js_object_assign__WEBPACK_IMPORTED_MODULE_0___default.a || function (target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];

      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }

    return target;
  };

  return _extends.apply(this, arguments);
}

/***/ }),

/***/ "lOhm":
/***/ (function(module, exports) {

module.exports = require("whatitis");

/***/ }),

/***/ "o5io":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/create");

/***/ }),

/***/ "pLtp":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("qJj/");

/***/ }),

/***/ "qJj/":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/keys");

/***/ }),

/***/ "qNsG":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/get-own-property-symbols.js
var get_own_property_symbols = __webpack_require__("4mXO");
var get_own_property_symbols_default = /*#__PURE__*/__webpack_require__.n(get_own_property_symbols);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/keys.js
var keys = __webpack_require__("pLtp");
var keys_default = /*#__PURE__*/__webpack_require__.n(keys);

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/objectWithoutPropertiesLoose.js

function _objectWithoutPropertiesLoose(source, excluded) {
  if (source == null) return {};
  var target = {};

  var sourceKeys = keys_default()(source);

  var key, i;

  for (i = 0; i < sourceKeys.length; i++) {
    key = sourceKeys[i];
    if (excluded.indexOf(key) >= 0) continue;
    target[key] = source[key];
  }

  return target;
}
// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/objectWithoutProperties.js
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _objectWithoutProperties; });


function _objectWithoutProperties(source, excluded) {
  if (source == null) return {};
  var target = _objectWithoutPropertiesLoose(source, excluded);
  var key, i;

  if (get_own_property_symbols_default.a) {
    var sourceSymbolKeys = get_own_property_symbols_default()(source);

    for (i = 0; i < sourceSymbolKeys.length; i++) {
      key = sourceSymbolKeys[i];
      if (excluded.indexOf(key) >= 0) continue;
      if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
      target[key] = source[key];
    }
  }

  return target;
}

/***/ }),

/***/ "sLSF":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _createClass; });
/* harmony import */ var _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("hfKm");
/* harmony import */ var _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__);


function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;

    _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default()(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

/***/ }),

/***/ "ushU":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return requestAnimationFrame; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return cancelAnimationFrame; });
var suffix = 'AnimationFrame';
var vendors = ['', 'moz', 'webkit'];

var getAFFunc = function getAFFunc(name) {
  var func = null;
  return function () {
    if (func) {
      return func.apply(void 0, arguments);
    }

    var win = window;

    for (var i = 0, l = vendors.length; i < l; i++) {
      var prefix = vendors[i];
      var funcName = name + suffix;

      if (prefix) {
        funcName = prefix + funcName.charAt(0).toUpperCase() + funcName.slice(1);
      }

      func = win[funcName];

      if (func) {
        break;
      }
    }

    return func ? func.apply(void 0, arguments) : func;
  };
};

var requestAnimationFrame = getAFFunc('request');
var cancelFunc = getAFFunc('cancel');
var cancelRequestFunc = getAFFunc('cancelRequest');
var cancelAnimationFrame = function cancelAnimationFrame() {
  return cancelFunc.apply(void 0, arguments) || cancelRequestFunc.apply(void 0, arguments);
};

/***/ }),

/***/ "vYYK":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _defineProperty; });
/* harmony import */ var _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("hfKm");
/* harmony import */ var _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__);

function _defineProperty(obj, key, value) {
  if (key in obj) {
    _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default()(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}

/***/ }),

/***/ "vqFK":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/symbol");

/***/ }),

/***/ "za0J":
/***/ (function(module, exports) {

module.exports = {
	"scene": "_1Zxh9h73",
	"paper-background": "_3DuBECud",
	"paperBackground": "_3DuBECud",
	"left-content": "_1LyUV2O_",
	"leftContent": "_1LyUV2O_",
	"center-content": "_242OCfn4",
	"centerContent": "_242OCfn4",
	"topic": "_1mi59G5i",
	"topic-title": "_1bqmkkVN",
	"topicTitle": "_1bqmkkVN",
	"topic-desc": "_2eLjJxyF",
	"topicDesc": "_2eLjJxyF",
	"topic-extend": "XGtqH0oX",
	"topicExtend": "XGtqH0oX",
	"topic-icon": "Fmyt4vOV",
	"topicIcon": "Fmyt4vOV",
	"topic-label": "_2WnbhL6a",
	"topicLabel": "_2WnbhL6a",
	"topic-action": "QHmQ3fB4",
	"topicAction": "QHmQ3fB4",
	"topic-button": "_1pq2TqNo",
	"topicButton": "_1pq2TqNo"
};

/***/ }),

/***/ "zrwo":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _objectSpread; });
/* harmony import */ var _core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("Jo+v");
/* harmony import */ var _core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("4mXO");
/* harmony import */ var _core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _core_js_object_keys__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("pLtp");
/* harmony import */ var _core_js_object_keys__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_keys__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _defineProperty__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("vYYK");




function _objectSpread(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i] != null ? arguments[i] : {};

    var ownKeys = _core_js_object_keys__WEBPACK_IMPORTED_MODULE_2___default()(source);

    if (typeof _core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1___default.a === 'function') {
      ownKeys = ownKeys.concat(_core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1___default()(source).filter(function (sym) {
        return _core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_0___default()(source, sym).enumerable;
      }));
    }

    ownKeys.forEach(function (key) {
      Object(_defineProperty__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"])(target, key, source[key]);
    });
  }

  return target;
}

/***/ })

/******/ });