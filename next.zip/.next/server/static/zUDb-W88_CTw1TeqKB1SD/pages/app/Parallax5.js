module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../../../../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 14);
/******/ })
/************************************************************************/
/******/ ({

/***/ "/+P4":
/***/ (function(module, exports, __webpack_require__) {

var _Object$getPrototypeOf = __webpack_require__("Bhuq");

var _Object$setPrototypeOf = __webpack_require__("TRZx");

function _getPrototypeOf(o) {
  module.exports = _getPrototypeOf = _Object$setPrototypeOf ? _Object$getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || _Object$getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}

module.exports = _getPrototypeOf;

/***/ }),

/***/ "/+oN":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/get-prototype-of");

/***/ }),

/***/ "/HRN":
/***/ (function(module, exports) {

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

module.exports = _classCallCheck;

/***/ }),

/***/ "0iUn":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _classCallCheck; });
function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

/***/ }),

/***/ "1+QS":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/classCallCheck.js
var classCallCheck = __webpack_require__("0iUn");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/createClass.js
var createClass = __webpack_require__("sLSF");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/possibleConstructorReturn.js + 1 modules
var possibleConstructorReturn = __webpack_require__("MI3g");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/getPrototypeOf.js
var getPrototypeOf = __webpack_require__("a7VT");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/assertThisInitialized.js
var assertThisInitialized = __webpack_require__("AT/M");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/inherits.js + 1 modules
var inherits = __webpack_require__("Tit0");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/defineProperty.js
var defineProperty = __webpack_require__("vYYK");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/extends.js
var esm_extends = __webpack_require__("kOwS");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/objectWithoutProperties.js + 1 modules
var objectWithoutProperties = __webpack_require__("qNsG");

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__("cDcd");
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);

// EXTERNAL MODULE: external "whatitis"
var external_whatitis_ = __webpack_require__("lOhm");
var external_whatitis_default = /*#__PURE__*/__webpack_require__.n(external_whatitis_);

// EXTERNAL MODULE: external "omit.js"
var external_omit_js_ = __webpack_require__("LSCY");
var external_omit_js_default = /*#__PURE__*/__webpack_require__.n(external_omit_js_);

// EXTERNAL MODULE: external "rc-animate"
var external_rc_animate_ = __webpack_require__("Vam4");
var external_rc_animate_default = /*#__PURE__*/__webpack_require__.n(external_rc_animate_);

// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__("K2gz");
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);

// EXTERNAL MODULE: external "react-hammerjs"
var external_react_hammerjs_ = __webpack_require__("BgYr");
var external_react_hammerjs_default = /*#__PURE__*/__webpack_require__.n(external_react_hammerjs_);

// EXTERNAL MODULE: external "rc-tween-one"
var external_rc_tween_one_ = __webpack_require__("VNO/");
var external_rc_tween_one_default = /*#__PURE__*/__webpack_require__.n(external_rc_tween_one_);

// EXTERNAL MODULE: external "rc-util/lib/Dom/addEventListener"
var addEventListener_ = __webpack_require__("BI0l");
var addEventListener_default = /*#__PURE__*/__webpack_require__.n(addEventListener_);

// EXTERNAL MODULE: ./lib/requestAnimationFrame.js
var requestAnimationFrame = __webpack_require__("ushU");

// EXTERNAL MODULE: ./assets/motions/cScale.less
var cScale = __webpack_require__("SC1p");

// EXTERNAL MODULE: ./assets/motions/cSlideUp.less
var cSlideUp = __webpack_require__("Te8+");

// EXTERNAL MODULE: ./assets/motions/cSlideDown.less
var cSlideDown = __webpack_require__("Qnt8");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/objectSpread.js
var objectSpread = __webpack_require__("zrwo");

// EXTERNAL MODULE: ./components/Carousel/points.less
var Carousel_points = __webpack_require__("2crN");
var points_default = /*#__PURE__*/__webpack_require__.n(Carousel_points);

// CONCATENATED MODULE: ./components/Carousel/points.js












var points_Points =
/*#__PURE__*/
function (_React$Component) {
  Object(inherits["a" /* default */])(Points, _React$Component);

  function Points() {
    var _getPrototypeOf2;

    var _this;

    Object(classCallCheck["a" /* default */])(this, Points);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = Object(possibleConstructorReturn["a" /* default */])(this, (_getPrototypeOf2 = Object(getPrototypeOf["a" /* default */])(Points)).call.apply(_getPrototypeOf2, [this].concat(args)));

    Object(defineProperty["a" /* default */])(Object(assertThisInitialized["a" /* default */])(_this), "handleClick", function (i) {
      return function () {
        var _this$props = _this.props,
            onChange = _this$props.onChange,
            index = _this$props.index;

        if (index !== i) {
          onChange(i);
        }
      };
    });

    return _this;
  }

  Object(createClass["a" /* default */])(Points, [{
    key: "render",
    value: function render() {
      var _this2 = this;

      var _this$props2 = this.props,
          points = _this$props2.points,
          index = _this$props2.index,
          size = _this$props2.size;
      var sizeStyle = {
        height: "".concat(100 / points.length, "%")
      };

      var blockProps = function blockProps(i) {
        return {
          className: points_default.a.block,
          onClick: _this2.handleClick(i),
          style: sizeStyle
        };
      };

      return external_react_default.a.createElement("div", {
        className: points_default.a.track,
        style: {
          height: size
        }
      }, points.map(function (point, i) {
        return i === index ? external_react_default.a.createElement("div", Object(esm_extends["a" /* default */])({
          key: "point-".concat(i)
        }, blockProps(i))) : external_react_default.a.createElement("div", Object(esm_extends["a" /* default */])({
          key: "active-point-".concat(i)
        }, blockProps(i)));
      }), external_react_default.a.createElement("div", {
        className: points_default.a.thumb,
        style: Object(objectSpread["a" /* default */])({
          top: "".concat(index * 100 / points.length, "%")
        }, sizeStyle)
      }));
    }
  }]);

  return Points;
}(external_react_default.a.Component);

/* harmony default export */ var components_Carousel_points = (points_Points);
// EXTERNAL MODULE: ./components/Carousel/carousel.less
var carousel = __webpack_require__("Pnzm");
var carousel_default = /*#__PURE__*/__webpack_require__.n(carousel);

// CONCATENATED MODULE: ./components/Carousel/index.js
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CarouselContext; });























var TweenOneGroup = external_rc_tween_one_default.a.TweenOneGroup;
var CarouselContext = external_react_default.a.createContext({
  isEnable: true
});

function HammerHoc(_ref) {
  var disabled = _ref.disabled,
      children = _ref.children,
      props = Object(objectWithoutProperties["a" /* default */])(_ref, ["disabled", "children"]);

  return disabled ? children : external_react_default.a.createElement(external_react_hammerjs_default.a, Object(esm_extends["a" /* default */])({}, props, {
    direction: "DIRECTION_VERTICAL"
  }), children);
}

var Carousel_Carousel =
/*#__PURE__*/
function (_React$Component) {
  Object(inherits["a" /* default */])(Carousel, _React$Component);

  function Carousel() {
    var _getPrototypeOf2;

    var _this;

    Object(classCallCheck["a" /* default */])(this, Carousel);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = Object(possibleConstructorReturn["a" /* default */])(this, (_getPrototypeOf2 = Object(getPrototypeOf["a" /* default */])(Carousel)).call.apply(_getPrototypeOf2, [this].concat(args)));

    Object(defineProperty["a" /* default */])(Object(assertThisInitialized["a" /* default */])(_this), "state", {
      index: 0,
      scrolling: false,
      isEnable: true
    });

    Object(defineProperty["a" /* default */])(Object(assertThisInitialized["a" /* default */])(_this), "handleWheel", function (e) {
      // 正数页面向上,负数页面向下
      var delta = (whatenvis.firefox ? 3 : 1) * e.delta;
      var _this$props = _this.props,
          children = _this$props.children,
          disabled = _this$props.disabled;
      var _this$state = _this.state,
          index = _this$state.index,
          scrolling = _this$state.scrolling;
      var count = external_react_default.a.Children.toArray(children).length - 1;

      if (!disabled && scrolling === false) {
        if (delta > 0 && index > 0) {
          _this.handleChange(index - 1);
        } else if (delta < 0 && index < count) {
          _this.handleChange(index + 1);
        }
      }
    });

    Object(defineProperty["a" /* default */])(Object(assertThisInitialized["a" /* default */])(_this), "handleScrollEnd", function (_, exists) {
      if (exists) {
        var onEnd = _this.props.onEnd;
        _this.state.scrolling = false; // eslint-disable-line

        _this.setState({
          isEnable: true
        }, external_whatitis_default.a.Function(onEnd) ? onEnd : null);
      }
    });

    Object(defineProperty["a" /* default */])(Object(assertThisInitialized["a" /* default */])(_this), "handleChange", function (targetIndex) {
      var _this$props2 = _this.props,
          index = _this$props2.index,
          onChange = _this$props2.onChange;

      if (external_whatitis_default.a.Number(index) && index >= 0) {
        external_whatitis_default.a.Function(onChange) && onChange(targetIndex);
      } else {
        var _this$state2 = _this.state,
            _index = _this$state2.index,
            scrolling = _this$state2.scrolling;

        if (scrolling === false) {
          _this.state.scrolling = true; // eslint-disable-line

          _this.setState({
            isEnable: false
          }, function () {
            _this.rafHandle = Object(requestAnimationFrame["b" /* requestAnimationFrame */])(function () {
              _this.rafHandle = null;

              _this.setState({
                index: targetIndex,
                direction: targetIndex > _index ? 1 : 0
              });
            });
          });
        }
      }
    });

    Object(defineProperty["a" /* default */])(Object(assertThisInitialized["a" /* default */])(_this), "handleSwipe", function (event) {
      var index = _this.state.index;
      var children = _this.props.children;
      var count = external_react_default.a.Children.toArray(children).length;
      var offsetDirection = event.offsetDirection;
      event.preventDefault();

      if (offsetDirection === 8 && index < count - 1) {
        // 上
        _this.handleChange(index + 1);
      }

      if (offsetDirection === 16 && index > 0) {
        // 下
        _this.handleChange(index - 1);
      }
    });

    Object(defineProperty["a" /* default */])(Object(assertThisInitialized["a" /* default */])(_this), "handleSlider", function () {
      var children = _this.props.children;
      var _this$state3 = _this.state,
          index = _this$state3.index,
          scrolling = _this$state3.scrolling;
      var count = external_react_default.a.Children.toArray(children).length - 1;

      if (scrolling === false) {
        if (index < count) {
          _this.handleChange(index + 1);
        }
      }
    });

    return _this;
  }

  Object(createClass["a" /* default */])(Carousel, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      var eventName = whatenvis.firefox ? 'DOMMouseScroll' : 'mousewheel';
      this.wheelListener = addEventListener_default()(document.body, eventName, this.handleWheel);
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      if (this.wheelListener) {
        this.wheelListener.remove();
        this.wheelListener = null;
      }

      if (this.rafHandle) {
        Object(requestAnimationFrame["a" /* cancelAnimationFrame */])(this.rafHandle);
        this.rafHandle = null;
      }
    }
  }, {
    key: "render",
    value: function render() {
      var _this$state4 = this.state,
          index = _this$state4.index,
          direction = _this$state4.direction,
          isEnable = _this$state4.isEnable;

      var _omit = external_omit_js_default()(this.props, ['onEnd']),
          children = _omit.children,
          className = _omit.className,
          disabled = _omit.disabled,
          showPoints = _omit.showPoints,
          showArrow = _omit.showArrow,
          props = Object(objectWithoutProperties["a" /* default */])(_omit, ["children", "className", "disabled", "showPoints", "showArrow"]);

      var childArray = external_react_default.a.Children.toArray(children);
      var count = childArray.length;
      var child = childArray.find(function (_, i) {
        return i === index;
      });
      return external_react_default.a.createElement(CarouselContext.Provider, {
        value: {
          isEnable: isEnable
        }
      }, external_react_default.a.createElement(HammerHoc, {
        onSwipe: this.handleSwipe,
        disabled: disabled
      }, external_react_default.a.createElement("div", Object(esm_extends["a" /* default */])({}, props, {
        className: external_classnames_default()(className, carousel_default.a.carousel)
      }), external_react_default.a.createElement(external_rc_animate_default.a, {
        component: "div",
        transitionAppear: false,
        onEnd: this.handleScrollEnd,
        transitionName: direction ? 'c-slide-up' : 'c-slide-down'
      }, external_react_default.a.createElement("div", {
        key: "".concat(index),
        className: carousel_default.a.paper
      }, external_react_default.a.createElement("div", {
        className: "c-scale"
      }, child))), showPoints ? external_react_default.a.createElement(components_Carousel_points, {
        size: "100%",
        index: index,
        onChange: this.handleChange,
        points: Array(count).fill(1)
      }) : null, external_react_default.a.createElement(TweenOneGroup, {
        component: "",
        enter: {
          opacity: 0,
          type: 'from',
          duration: 2000
        },
        leave: {
          opacity: 0,
          duration: 2000
        }
      }, showArrow && count - 1 > index ? external_react_default.a.createElement("div", {
        key: "arrow",
        className: carousel_default.a.arrowDown,
        onClick: this.handleSlider
      }, external_react_default.a.createElement("div", {
        className: carousel_default.a.arrowDownAnim
      }, external_react_default.a.createElement("em", null), external_react_default.a.createElement("em", null), external_react_default.a.createElement("em", null))) : null))));
    }
  }]);

  return Carousel;
}(external_react_default.a.Component);

Object(defineProperty["a" /* default */])(Carousel_Carousel, "defaultProps", {
  showArrow: true,
  showPoints: true
});

Object(defineProperty["a" /* default */])(Carousel_Carousel, "getDerivedStateFromProps", function (props, state) {
  if (external_whatitis_default.a.Number(props.index) && props.index >= 0 && state.index !== props.index) {
    return {
      index: props.index,
      direction: props.index > state.index ? 1 : 0,
      scrolling: false,
      isEnable: false
    };
  }

  return null;
});

/* harmony default export */ var components_Carousel = __webpack_exports__["b"] = (Carousel_Carousel);

/***/ }),

/***/ 14:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("jirs");


/***/ }),

/***/ "2crN":
/***/ (function(module, exports) {

module.exports = {
	"track": "_1ujYANvT",
	"block": "_1_K01DDo",
	"thumb": "_3m-xWWqN"
};

/***/ }),

/***/ "4Q3z":
/***/ (function(module, exports) {

module.exports = require("next/router");

/***/ }),

/***/ "4mXO":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("k1wZ");

/***/ }),

/***/ "9Jkg":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("fozc");

/***/ }),

/***/ "AT/M":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _assertThisInitialized; });
function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

/***/ }),

/***/ "BE5S":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return Icon; });
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("kOwS");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("qNsG");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("K2gz");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _svgIcon_less__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("flPq");
/* harmony import */ var _svgIcon_less__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_svgIcon_less__WEBPACK_IMPORTED_MODULE_4__);





function Icon(_ref) {
  var icon = _ref.icon,
      className = _ref.className,
      props = Object(_babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(_ref, ["icon", "className"]);

  return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("svg", Object(_babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])({
    "aria-hidden": "true"
  }, props, {
    className: classnames__WEBPACK_IMPORTED_MODULE_3___default()(_svgIcon_less__WEBPACK_IMPORTED_MODULE_4___default.a.svgIcon, className)
  }), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("use", {
    xlinkHref: "#".concat(icon.id)
  }));
}

/***/ }),

/***/ "BI0l":
/***/ (function(module, exports) {

module.exports = require("rc-util/lib/Dom/addEventListener");

/***/ }),

/***/ "BgYr":
/***/ (function(module, exports) {

module.exports = require("react-hammerjs");

/***/ }),

/***/ "Bhuq":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("/+oN");

/***/ }),

/***/ "C4g1":
/***/ (function(module, exports, __webpack_require__) {

/* eslint-disable */
var React = __webpack_require__("cDcd");
var SpriteSymbol = __webpack_require__("QAmA");
var sprite = __webpack_require__("TQFg");

var symbol = new SpriteSymbol({
  "id": "1NY7GLK5--sprite",
  "use": "1NY7GLK5--sprite-usage",
  "viewBox": "0 0 1000.637 1000.678",
  "content": "<symbol xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 1000.637 1000.678\" id=\"1NY7GLK5--sprite\"><path d=\"M193.098 555.603V799.28c0 18.313.803 29.992 2.417 35.047 1.61 5.053 4.978 9.193 10.107 12.414 5.126 3.224 13.328 4.834 24.609 4.834h6.812v8.13H80.159v-8.13h7.91c12.744 0 21.825-1.463 27.246-4.395 5.417-2.929 9.081-6.956 10.986-12.085 1.902-5.126 2.856-17.063 2.856-35.815V644.812c0-13.768-.659-22.374-1.978-25.817-1.318-3.44-3.773-6.373-7.361-8.789-3.591-2.418-7.728-3.626-12.415-3.626-7.471 0-16.555 2.345-27.246 7.031l-3.955-7.91 109.644-50.098zm286.963 155.126c0 29.738-4.175 57.496-12.524 83.276-4.981 15.82-11.683 28.784-20.105 38.892-8.425 10.107-17.983 18.128-28.674 24.06-10.694 5.934-22.34 8.899-34.937 8.899-14.358 0-27.322-3.663-38.892-10.986-11.573-7.323-21.829-17.798-30.762-31.421-6.448-9.96-12.085-23.216-16.919-39.771-6.3-22.412-9.448-45.556-9.448-69.434 0-32.372 4.539-62.107 13.623-89.209 7.471-22.412 18.821-39.585 34.058-51.525 15.233-11.938 31.345-17.908 48.34-17.908 17.283 0 33.433 5.898 48.45 17.688 15.014 11.794 26.038 27.651 33.069 47.571 9.811 27.394 14.721 57.349 14.721 89.868zm-67.676-.439c0-52.147-.295-82.542-.879-91.187-1.466-20.359-4.981-34.13-10.547-41.309-3.663-4.687-9.596-7.031-17.798-7.031-6.3 0-11.282 1.758-14.941 5.273-5.421 5.129-9.084 14.172-10.986 27.137-1.905 12.963-2.856 58.192-2.856 135.681 0 42.188 1.462 70.46 4.395 84.814 2.197 10.402 5.346 17.358 9.448 20.874 4.099 3.516 9.521 5.273 16.26 5.273 7.323 0 12.816-2.342 16.479-7.031 6.152-8.202 9.668-20.874 10.547-38.013zm292.676.439c0 29.738-4.174 57.496-12.523 83.276-4.982 15.82-11.684 28.784-20.105 38.892-8.426 10.107-17.983 18.128-28.674 24.06-10.695 5.934-22.34 8.899-34.938 8.899-14.357 0-27.321-3.663-38.891-10.986-11.574-7.323-21.829-17.798-30.762-31.421-6.448-9.96-12.086-23.216-16.92-39.771-6.299-22.412-9.447-45.556-9.447-69.434 0-32.372 4.538-62.107 13.623-89.209 7.471-22.412 18.82-39.585 34.057-51.525 15.234-11.938 31.346-17.908 48.34-17.908 17.283 0 33.434 5.898 48.45 17.688 15.014 11.794 26.038 27.651 33.069 47.571 9.811 27.394 14.721 57.349 14.721 89.868zm-67.676-.439c0-52.147-.295-82.542-.879-91.187-1.465-20.359-4.98-34.13-10.547-41.309-3.662-4.687-9.596-7.031-17.797-7.031-6.301 0-11.282 1.758-14.941 5.273-5.422 5.129-9.085 14.172-10.986 27.137-1.906 12.963-2.857 58.192-2.857 135.681 0 42.188 1.463 70.46 4.395 84.814 2.197 10.402 5.346 17.358 9.449 20.874 4.099 3.516 9.52 5.273 16.26 5.273 7.322 0 12.816-2.342 16.479-7.031 6.152-8.202 9.668-20.874 10.547-38.013zm292.676.439c0 29.738-4.174 57.496-12.523 83.276-4.982 15.82-11.684 28.784-20.105 38.892-8.426 10.107-17.983 18.128-28.674 24.06-10.695 5.934-22.34 8.899-34.938 8.899-14.357 0-27.321-3.663-38.891-10.986-11.574-7.323-21.829-17.798-30.762-31.421-6.448-9.96-12.086-23.216-16.92-39.771-6.299-22.412-9.447-45.556-9.447-69.434 0-32.372 4.538-62.107 13.623-89.209 7.471-22.412 18.82-39.585 34.057-51.525 15.234-11.938 31.346-17.908 48.34-17.908 17.283 0 33.434 5.898 48.45 17.688 15.014 11.794 26.038 27.651 33.069 47.571 9.811 27.394 14.721 57.349 14.721 89.868zm-67.676-.439c0-52.147-.295-82.542-.879-91.187-1.465-20.359-4.98-34.13-10.547-41.309-3.662-4.687-9.596-7.031-17.797-7.031-6.301 0-11.282 1.758-14.941 5.273-5.422 5.129-9.085 14.172-10.986 27.137-1.906 12.963-2.857 58.192-2.857 135.681 0 42.188 1.463 70.46 4.395 84.814 2.197 10.402 5.346 17.358 9.449 20.874 4.099 3.516 9.52 5.273 16.26 5.273 7.322 0 12.816-2.342 16.479-7.031 6.152-8.202 9.668-20.874 10.547-38.013zM438.193 148.277v80.64h-7.91c-4.69-18.602-9.888-31.97-15.601-40.101-5.713-8.129-13.551-14.611-23.511-19.445-5.569-2.637-15.309-3.955-29.224-3.955h-22.192V395.25c0 15.236.841 24.757 2.527 28.564 1.682 3.811 4.978 7.141 9.888 9.998 4.906 2.855 11.608 4.284 20.105 4.284h9.888v8.13H226.157v-8.13h9.888c8.642 0 15.601-1.538 20.874-4.614 3.808-2.05 6.812-5.565 9.009-10.547 1.61-3.516 2.417-12.744 2.417-27.686V165.416h-21.533c-20.071 0-34.645 4.25-43.726 12.744-12.744 11.865-20.802 28.784-24.17 50.757h-8.35v-80.64zm135.791 162.158v83.496c0 16.115.988 26.258 2.967 30.432 1.977 4.176 5.455 7.509 10.437 9.998 4.978 2.492 14.282 3.735 27.905 3.735v8.13h-152.49v-8.13c13.767 0 23.105-1.28 28.015-3.845 4.906-2.562 8.35-5.896 10.327-9.998 1.979-4.1 2.967-14.207 2.967-30.322V200.572c0-16.112-.988-26.258-2.967-30.432-1.977-4.176-5.458-7.505-10.437-9.998-4.981-2.489-14.282-3.735-27.905-3.735v-8.13H601.23c36.035 0 62.402 2.493 79.102 7.471 16.699 4.981 30.322 14.172 40.869 27.576 10.547 13.402 15.82 29.113 15.82 47.131 0 21.973-7.91 40.138-23.73 54.492-10.107 9.084-24.246 15.896-42.407 20.435l71.631 100.854c9.372 13.039 16.04 21.169 19.995 24.39 6.005 4.542 12.964 7.031 20.874 7.471v8.13h-93.823L593.54 310.435zm0-146.118v130.518h12.524c20.358 0 35.596-1.868 45.703-5.603 10.107-3.736 18.052-10.472 23.841-20.215 5.785-9.74 8.679-22.447 8.679-38.123 0-22.704-5.312-39.476-15.931-50.317-10.622-10.839-27.723-16.26-51.306-16.26z\" /></symbol>"
});
sprite.add(symbol);

var SvgSpriteIcon = function SvgSpriteIcon(props) {
  return React.createElement(
    'svg',
    Object.assign({
      viewBox: symbol.viewBox
    }, props),
    React.createElement(
      'use',
      {
        xlinkHref: '#' + symbol.id
      }
    )
  );
};

SvgSpriteIcon.viewBox = symbol.viewBox;
SvgSpriteIcon.id = symbol.id;
SvgSpriteIcon.content = symbol.content;
SvgSpriteIcon.url = symbol.url;
SvgSpriteIcon.toString = symbol.toString;

module.exports = SvgSpriteIcon;
module.exports.default = SvgSpriteIcon;


/***/ }),

/***/ "IMUT":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("kOwS");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("qNsG");
/* harmony import */ var _babel_runtime_corejs2_core_js_object_assign__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("UXZV");
/* harmony import */ var _babel_runtime_corejs2_core_js_object_assign__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_core_js_object_assign__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("0iUn");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("sLSF");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("MI3g");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("a7VT");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__("Tit0");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__("vYYK");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var omit_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__("LSCY");
/* harmony import */ var omit_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(omit_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var parallax_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__("W0Av");
/* harmony import */ var parallax_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(parallax_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _components_Carousel__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__("1+QS");












 //https://ken.artbees.net/wide-parallax-startup/

var Scene =
/*#__PURE__*/
function (_React$Component) {
  Object(_babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_7__[/* default */ "a"])(Scene, _React$Component);

  function Scene(props) {
    var _this;

    Object(_babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"])(this, Scene);

    _this = Object(_babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"])(this, Object(_babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_6__[/* default */ "a"])(Scene).call(this, props));
    _this.sceneRef = react__WEBPACK_IMPORTED_MODULE_9___default.a.createRef();
    return _this;
  }

  Object(_babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_4__[/* default */ "a"])(Scene, [{
    key: "componentDidUpdate",
    value: function componentDidUpdate() {
      var isEnable = this.context.isEnable;

      if (isEnable) {
        this.createParallax();
      } else {
        this.destroyParallax();
      }
    }
  }, {
    key: "componentDidMount",
    value: function componentDidMount() {
      var isEnable = this.context.isEnable;

      if (isEnable) {
        this.createParallax();
      }
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      this.destroyParallax();
    }
  }, {
    key: "createParallax",
    value: function createParallax() {
      var defaultOptions = {
        selector: '.paper'
      };
      var options = this.props.options;
      this.parallaxInstance = new parallax_js__WEBPACK_IMPORTED_MODULE_11___default.a(this.sceneRef.current, _babel_runtime_corejs2_core_js_object_assign__WEBPACK_IMPORTED_MODULE_2___default()(defaultOptions, options));
    }
  }, {
    key: "destroyParallax",
    value: function destroyParallax() {
      if (this.parallaxInstance) {
        this.parallaxInstance.destroy();
        this.parallaxInstance = null;
      }
    }
  }, {
    key: "render",
    value: function render() {
      var _omit = omit_js__WEBPACK_IMPORTED_MODULE_10___default()(this.props, ['options']),
          children = _omit.children,
          className = _omit.className,
          props = Object(_babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(_omit, ["children", "className"]);

      return react__WEBPACK_IMPORTED_MODULE_9___default.a.createElement("div", Object(_babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])({}, props, {
        ref: this.sceneRef,
        className: "".concat(className ? "".concat(className, " ") : '', "scene")
      }), children);
    }
  }]);

  return Scene;
}(react__WEBPACK_IMPORTED_MODULE_9___default.a.Component);

Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_8__[/* default */ "a"])(Scene, "contextType", _components_Carousel__WEBPACK_IMPORTED_MODULE_12__[/* CarouselContext */ "a"]);

/* harmony default export */ __webpack_exports__["a"] = (Scene);

/***/ }),

/***/ "Jo+v":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("Z6Kq");

/***/ }),

/***/ "K2gz":
/***/ (function(module, exports) {

module.exports = require("classnames");

/***/ }),

/***/ "K47E":
/***/ (function(module, exports) {

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

module.exports = _assertThisInitialized;

/***/ }),

/***/ "KI45":
/***/ (function(module, exports) {

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    default: obj
  };
}

module.exports = _interopRequireDefault;

/***/ }),

/***/ "LSCY":
/***/ (function(module, exports) {

module.exports = require("omit.js");

/***/ }),

/***/ "MI3g":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/symbol/iterator.js
var iterator = __webpack_require__("XVgq");
var iterator_default = /*#__PURE__*/__webpack_require__.n(iterator);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/symbol.js
var symbol = __webpack_require__("Z7t5");
var symbol_default = /*#__PURE__*/__webpack_require__.n(symbol);

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/typeof.js



function typeof_typeof2(obj) { if (typeof symbol_default.a === "function" && typeof iterator_default.a === "symbol") { typeof_typeof2 = function _typeof2(obj) { return typeof obj; }; } else { typeof_typeof2 = function _typeof2(obj) { return obj && typeof symbol_default.a === "function" && obj.constructor === symbol_default.a && obj !== symbol_default.a.prototype ? "symbol" : typeof obj; }; } return typeof_typeof2(obj); }

function typeof_typeof(obj) {
  if (typeof symbol_default.a === "function" && typeof_typeof2(iterator_default.a) === "symbol") {
    typeof_typeof = function _typeof(obj) {
      return typeof_typeof2(obj);
    };
  } else {
    typeof_typeof = function _typeof(obj) {
      return obj && typeof symbol_default.a === "function" && obj.constructor === symbol_default.a && obj !== symbol_default.a.prototype ? "symbol" : typeof_typeof2(obj);
    };
  }

  return typeof_typeof(obj);
}
// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/assertThisInitialized.js
var assertThisInitialized = __webpack_require__("AT/M");

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/possibleConstructorReturn.js
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _possibleConstructorReturn; });


function _possibleConstructorReturn(self, call) {
  if (call && (typeof_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return Object(assertThisInitialized["a" /* default */])(self);
}

/***/ }),

/***/ "N9n2":
/***/ (function(module, exports, __webpack_require__) {

var _Object$create = __webpack_require__("SqZg");

var setPrototypeOf = __webpack_require__("vjea");

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = _Object$create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) setPrototypeOf(subClass, superClass);
}

module.exports = _inherits;

/***/ }),

/***/ "Pnzm":
/***/ (function(module, exports) {

module.exports = {
	"carousel": "QIruQvWN",
	"paper": "IDE1NymA",
	"arrow-down": "_11U8PP3q",
	"arrowDown": "_11U8PP3q",
	"arrow-down-anim": "OiG04KV1",
	"arrowDownAnim": "OiG04KV1",
	"arrowDownAnimKF": "_2nZLV2q0",
	"arrowDownAnimKf": "_2nZLV2q0"
};

/***/ }),

/***/ "QAmA":
/***/ (function(module, exports) {

module.exports = require("svg-baker-runtime/symbol");

/***/ }),

/***/ "QncY":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("kOwS");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("qNsG");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("0iUn");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("sLSF");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("MI3g");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("a7VT");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("Tit0");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);









var Paper =
/*#__PURE__*/
function (_React$Component) {
  Object(_babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_6__[/* default */ "a"])(Paper, _React$Component);

  function Paper() {
    Object(_babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_2__[/* default */ "a"])(this, Paper);

    return Object(_babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__[/* default */ "a"])(this, Object(_babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"])(Paper).apply(this, arguments));
  }

  Object(_babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"])(Paper, [{
    key: "render",
    value: function render() {
      var _this$props = this.props,
          depth = _this$props.depth,
          children = _this$props.children,
          className = _this$props.className,
          props = Object(_babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(_this$props, ["depth", "children", "className"]);

      return react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", Object(_babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])({}, props, {
        className: "".concat(className ? "".concat(className, " ") : '', "paper"),
        "data-depth": depth
      }), children);
    }
  }]);

  return Paper;
}(react__WEBPACK_IMPORTED_MODULE_7___default.a.Component);

/* harmony default export */ __webpack_exports__["a"] = (Paper);

/***/ }),

/***/ "Qnt8":
/***/ (function(module, exports) {

module.exports = {
	"cslideDownIn": "_33bJsfF1",
	"cslideDownOut": "_26zD-TbW"
};

/***/ }),

/***/ "SC1p":
/***/ (function(module, exports) {

module.exports = {
	"cScaleIn": "yzEr1rWc",
	"cScaleOut": "_34mAihAf"
};

/***/ }),

/***/ "SqZg":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("o5io");

/***/ }),

/***/ "TQFg":
/***/ (function(module, exports) {

module.exports = require("svg-sprite-loader/runtime/sprite.build");

/***/ }),

/***/ "TRZx":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("Wk4r");

/***/ }),

/***/ "TUA0":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/define-property");

/***/ }),

/***/ "Te8+":
/***/ (function(module, exports) {

module.exports = {
	"cslideUpIn": "_1BDx8_C5",
	"cslideUpOut": "_1Ck_eq3l"
};

/***/ }),

/***/ "Tit0":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/create.js
var create = __webpack_require__("SqZg");
var create_default = /*#__PURE__*/__webpack_require__.n(create);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/set-prototype-of.js
var set_prototype_of = __webpack_require__("TRZx");
var set_prototype_of_default = /*#__PURE__*/__webpack_require__.n(set_prototype_of);

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/setPrototypeOf.js

function _setPrototypeOf(o, p) {
  _setPrototypeOf = set_prototype_of_default.a || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}
// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/inherits.js
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _inherits; });


function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = create_default()(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

/***/ }),

/***/ "UXZV":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("dGr4");

/***/ }),

/***/ "VNO/":
/***/ (function(module, exports) {

module.exports = require("rc-tween-one");

/***/ }),

/***/ "Vam4":
/***/ (function(module, exports) {

module.exports = require("rc-animate");

/***/ }),

/***/ "W0Av":
/***/ (function(module, exports) {

module.exports = require("parallax-js");

/***/ }),

/***/ "WaGi":
/***/ (function(module, exports, __webpack_require__) {

var _Object$defineProperty = __webpack_require__("hfKm");

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;

    _Object$defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

module.exports = _createClass;

/***/ }),

/***/ "Wk4r":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/set-prototype-of");

/***/ }),

/***/ "XVgq":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("gHn/");

/***/ }),

/***/ "YFqc":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("cTJO")


/***/ }),

/***/ "Z6Kq":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/get-own-property-descriptor");

/***/ }),

/***/ "Z7t5":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("vqFK");

/***/ }),

/***/ "ZDA2":
/***/ (function(module, exports, __webpack_require__) {

var _typeof = __webpack_require__("iZP3");

var assertThisInitialized = __webpack_require__("K47E");

function _possibleConstructorReturn(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return assertThisInitialized(self);
}

module.exports = _possibleConstructorReturn;

/***/ }),

/***/ "a7VT":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _getPrototypeOf; });
/* harmony import */ var _core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("Bhuq");
/* harmony import */ var _core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("TRZx");
/* harmony import */ var _core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_1__);


function _getPrototypeOf(o) {
  _getPrototypeOf = _core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_1___default.a ? _core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0___default.a : function _getPrototypeOf(o) {
    return o.__proto__ || _core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0___default()(o);
  };
  return _getPrototypeOf(o);
}

/***/ }),

/***/ "bzos":
/***/ (function(module, exports) {

module.exports = require("url");

/***/ }),

/***/ "cDcd":
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "cTJO":
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/* global __NEXT_DATA__ */

var _interopRequireDefault = __webpack_require__("KI45");

var _stringify = _interopRequireDefault(__webpack_require__("9Jkg"));

var _classCallCheck2 = _interopRequireDefault(__webpack_require__("/HRN"));

var _createClass2 = _interopRequireDefault(__webpack_require__("WaGi"));

var _possibleConstructorReturn2 = _interopRequireDefault(__webpack_require__("ZDA2"));

var _getPrototypeOf2 = _interopRequireDefault(__webpack_require__("/+P4"));

var _inherits2 = _interopRequireDefault(__webpack_require__("N9n2"));

var __importStar = void 0 && (void 0).__importStar || function (mod) {
  if (mod && mod.__esModule) return mod;
  var result = {};
  if (mod != null) for (var k in mod) {
    if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
  }
  result["default"] = mod;
  return result;
};

var __importDefault = void 0 && (void 0).__importDefault || function (mod) {
  return mod && mod.__esModule ? mod : {
    "default": mod
  };
};

Object.defineProperty(exports, "__esModule", {
  value: true
});

var url_1 = __webpack_require__("bzos");

var react_1 = __importStar(__webpack_require__("cDcd"));

var prop_types_1 = __importDefault(__webpack_require__("rf6O"));

var router_1 = __importStar(__webpack_require__("4Q3z"));

var utils_1 = __webpack_require__("p8BD");

function isLocal(href) {
  var url = url_1.parse(href, false, true);
  var origin = url_1.parse(utils_1.getLocationOrigin(), false, true);
  return !url.host || url.protocol === origin.protocol && url.host === origin.host;
}

function memoizedFormatUrl(formatFunc) {
  var lastHref = null;
  var lastAs = null;
  var lastResult = null;
  return function (href, as) {
    if (href === lastHref && as === lastAs) {
      return lastResult;
    }

    var result = formatFunc(href, as);
    lastHref = href;
    lastAs = as;
    lastResult = result;
    return result;
  };
}

function formatUrl(url) {
  return url && typeof url === 'object' ? utils_1.formatWithValidation(url) : url;
}

var Link =
/*#__PURE__*/
function (_react_1$Component) {
  (0, _inherits2.default)(Link, _react_1$Component);

  function Link() {
    var _this;

    (0, _classCallCheck2.default)(this, Link);
    _this = (0, _possibleConstructorReturn2.default)(this, (0, _getPrototypeOf2.default)(Link).apply(this, arguments)); // The function is memoized so that no extra lifecycles are needed
    // as per https://reactjs.org/blog/2018/06/07/you-probably-dont-need-derived-state.html

    _this.formatUrls = memoizedFormatUrl(function (href, asHref) {
      return {
        href: formatUrl(href),
        as: formatUrl(asHref, true)
      };
    });

    _this.linkClicked = function (e) {
      var _e$currentTarget = e.currentTarget,
          nodeName = _e$currentTarget.nodeName,
          target = _e$currentTarget.target;

      if (nodeName === 'A' && (target && target !== '_self' || e.metaKey || e.ctrlKey || e.shiftKey || e.nativeEvent && e.nativeEvent.which === 2)) {
        // ignore click for new tab / new window behavior
        return;
      }

      var _this$formatUrls = _this.formatUrls(_this.props.href, _this.props.as),
          href = _this$formatUrls.href,
          as = _this$formatUrls.as;

      if (!isLocal(href)) {
        // ignore click if it's outside our scope
        return;
      }

      var pathname = window.location.pathname;
      href = url_1.resolve(pathname, href);
      as = as ? url_1.resolve(pathname, as) : href;
      e.preventDefault(); //  avoid scroll for urls with anchor refs

      var scroll = _this.props.scroll;

      if (scroll == null) {
        scroll = as.indexOf('#') < 0;
      } // replace state instead of push if prop is present


      router_1.default[_this.props.replace ? 'replace' : 'push'](href, as, {
        shallow: _this.props.shallow
      }).then(function (success) {
        if (!success) return;

        if (scroll) {
          window.scrollTo(0, 0);
          document.body.focus();
        }
      }).catch(function (err) {
        if (_this.props.onError) _this.props.onError(err);
      });
    };

    return _this;
  }

  (0, _createClass2.default)(Link, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      this.prefetch();
    }
  }, {
    key: "componentDidUpdate",
    value: function componentDidUpdate(prevProps) {
      if ((0, _stringify.default)(this.props.href) !== (0, _stringify.default)(prevProps.href)) {
        this.prefetch();
      }
    }
  }, {
    key: "prefetch",
    value: function prefetch() {
      if (!this.props.prefetch) return;
      if (typeof window === 'undefined') return; // Prefetch the JSON page if asked (only in the client)

      var pathname = window.location.pathname;

      var _this$formatUrls2 = this.formatUrls(this.props.href, this.props.as),
          parsedHref = _this$formatUrls2.href;

      var href = url_1.resolve(pathname, parsedHref);
      router_1.default.prefetch(href);
    }
  }, {
    key: "render",
    value: function render() {
      var _this2 = this;

      var children = this.props.children;

      var _this$formatUrls3 = this.formatUrls(this.props.href, this.props.as),
          href = _this$formatUrls3.href,
          as = _this$formatUrls3.as; // Deprecated. Warning shown by propType check. If the childen provided is a string (<Link>example</Link>) we wrap it in an <a> tag


      if (typeof children === 'string') {
        children = react_1.default.createElement("a", null, children);
      } // This will return the first child, if multiple are provided it will throw an error


      var child = react_1.Children.only(children);
      var props = {
        onClick: function onClick(e) {
          if (child.props && typeof child.props.onClick === 'function') {
            child.props.onClick(e);
          }

          if (!e.defaultPrevented) {
            _this2.linkClicked(e);
          }
        }
      }; // If child is an <a> tag and doesn't have a href attribute, or if the 'passHref' property is
      // defined, we specify the current 'href', so that repetition is not needed by the user

      if (this.props.passHref || child.type === 'a' && !('href' in child.props)) {
        props.href = as || href;
      } // Add the ending slash to the paths. So, we can serve the
      // "<page>/index.html" directly.


      if (true) {
        if (props.href && typeof __NEXT_DATA__ !== 'undefined' && __NEXT_DATA__.nextExport) {
          props.href = router_1.Router._rewriteUrlForNextExport(props.href);
        }
      }

      return react_1.default.cloneElement(child, props);
    }
  }]);
  return Link;
}(react_1.Component);

if (false) { var exact, warn; }

exports.default = Link;

/***/ }),

/***/ "dGr4":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/assign");

/***/ }),

/***/ "dxtb":
/***/ (function(module, exports) {

module.exports = "/_next/static/images/banner-5-03cc9e14c5b942f28e7e5382a32d6355.jpg";

/***/ }),

/***/ "flPq":
/***/ (function(module, exports) {

module.exports = {
	"svg-icon": "_39UYRa5H",
	"svgIcon": "_39UYRa5H"
};

/***/ }),

/***/ "fozc":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/json/stringify");

/***/ }),

/***/ "gHn/":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/symbol/iterator");

/***/ }),

/***/ "hain":
/***/ (function(module, exports, __webpack_require__) {

/* eslint-disable */
var React = __webpack_require__("cDcd");
var SpriteSymbol = __webpack_require__("QAmA");
var sprite = __webpack_require__("TQFg");

var symbol = new SpriteSymbol({
  "id": "_O0qsoc3--sprite",
  "use": "_O0qsoc3--sprite-usage",
  "viewBox": "0 0 1000.637 1000.678",
  "content": "<symbol xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 1000.637 1000.678\" id=\"_O0qsoc3--sprite\"><path d=\"M296.098 523.078v243.677c0 18.313.803 29.993 2.417 35.046 1.61 5.055 4.978 9.194 10.107 12.415 5.126 3.224 13.328 4.834 24.609 4.834h6.812v8.13H183.159v-8.13h7.91c12.744 0 21.825-1.463 27.246-4.395 5.417-2.929 9.081-6.956 10.986-12.085 1.902-5.126 2.856-17.063 2.856-35.815V612.287c0-13.768-.659-22.374-1.978-25.818-1.318-3.439-3.773-6.371-7.361-8.789-3.591-2.416-7.728-3.625-12.415-3.625-7.471 0-16.555 2.345-27.246 7.031l-3.955-7.91 109.644-50.098zM560.869 827.18H385.527v-4.834c53.757-64.013 86.387-107.079 97.888-129.199 11.498-22.117 17.249-43.726 17.249-64.819 0-15.381-4.762-28.159-14.282-38.343-9.524-10.179-21.169-15.271-34.937-15.271-22.56 0-40.066 11.281-52.515 33.838l-8.13-2.856c7.91-28.125 19.919-48.924 36.035-62.402 16.112-13.476 34.717-20.215 55.811-20.215 15.085 0 28.856 3.516 41.309 10.547 12.448 7.031 22.191 16.665 29.223 28.895 7.031 12.232 10.547 23.695 10.547 34.387 0 19.483-5.42 39.259-16.26 59.326-14.797 27.102-47.097 64.895-96.899 113.379h64.379c15.82 0 26.11-.659 30.872-1.978 4.759-1.318 8.679-3.55 11.755-6.702 3.076-3.147 7.104-9.777 12.086-19.885h7.91zm185.229-304.102v243.677c0 18.313.804 29.993 2.418 35.046 1.609 5.055 4.978 9.194 10.107 12.415 5.125 3.224 13.327 4.834 24.609 4.834h6.811v8.13H633.158v-8.13h7.91c12.744 0 21.826-1.463 27.246-4.395 5.418-2.929 9.082-6.956 10.986-12.085 1.902-5.126 2.857-17.063 2.857-35.815V612.287c0-13.768-.66-22.374-1.979-25.818-1.318-3.439-3.772-6.371-7.36-8.789-3.591-2.416-7.728-3.625-12.415-3.625-7.471 0-16.555 2.345-27.246 7.031l-3.955-7.91 109.645-50.098zM433.427 115.751v80.64h-7.91c-4.69-18.602-9.888-31.97-15.601-40.101-5.713-8.129-13.551-14.611-23.511-19.445-5.569-2.637-15.309-3.955-29.224-3.955H334.99v229.834c0 15.236.841 24.757 2.527 28.564 1.682 3.811 4.978 7.141 9.888 9.998 4.906 2.855 11.608 4.284 20.105 4.284h9.888v8.13H221.391v-8.13h9.888c8.642 0 15.601-1.538 20.874-4.614 3.808-2.05 6.812-5.565 9.009-10.547 1.61-3.516 2.417-12.744 2.417-27.686V132.89h-21.533c-20.071 0-34.645 4.25-43.726 12.744-12.744 11.865-20.802 28.784-24.17 50.757h-8.35v-80.64zm326.733-6.811v105.029h-8.129c-9.816-28.709-24.537-50.537-44.166-65.479-19.631-14.941-41.088-22.412-64.379-22.412-22.269 0-40.797 6.263-55.592 18.786-14.797 12.525-25.268 29.993-31.42 52.405s-9.229 45.411-9.229 68.994c0 28.564 3.367 53.613 10.107 75.146 6.735 21.533 17.611 37.354 32.629 47.461 15.014 10.107 32.85 15.161 53.504 15.161 7.175 0 14.535-.77 22.082-2.307 7.543-1.539 15.271-3.771 23.182-6.702v-61.963c0-11.718-.807-19.298-2.418-22.741-1.613-3.44-4.943-6.555-9.997-9.339-5.054-2.781-11.172-4.175-18.347-4.175h-7.691v-8.13h144.801v8.13c-10.986.734-18.643 2.235-22.962 4.504-4.322 2.273-7.656 6.043-9.997 11.316-1.318 2.784-1.979 9.596-1.979 20.435v61.963c-19.043 8.497-38.857 14.907-59.436 19.226-20.582 4.319-41.934 6.482-64.051 6.482-28.271 0-51.745-3.846-70.422-11.535-18.677-7.691-35.156-17.799-49.438-30.322-14.282-12.525-25.454-26.622-33.508-42.298-10.255-20.215-15.381-42.847-15.381-67.896 0-44.824 15.745-82.689 47.242-113.599 31.492-30.906 71.115-46.362 118.871-46.362 14.795 0 28.125 1.174 39.99 3.516 6.445 1.174 16.882 4.504 31.312 9.998 14.427 5.493 22.962 8.24 25.599 8.24 4.099 0 7.91-1.5 11.426-4.504 3.516-3 6.735-8.679 9.668-17.029h8.129z\" /></symbol>"
});
sprite.add(symbol);

var SvgSpriteIcon = function SvgSpriteIcon(props) {
  return React.createElement(
    'svg',
    Object.assign({
      viewBox: symbol.viewBox
    }, props),
    React.createElement(
      'use',
      {
        xlinkHref: '#' + symbol.id
      }
    )
  );
};

SvgSpriteIcon.viewBox = symbol.viewBox;
SvgSpriteIcon.id = symbol.id;
SvgSpriteIcon.content = symbol.content;
SvgSpriteIcon.url = symbol.url;
SvgSpriteIcon.toString = symbol.toString;

module.exports = SvgSpriteIcon;
module.exports.default = SvgSpriteIcon;


/***/ }),

/***/ "hfKm":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("TUA0");

/***/ }),

/***/ "iZP3":
/***/ (function(module, exports, __webpack_require__) {

var _Symbol$iterator = __webpack_require__("XVgq");

var _Symbol = __webpack_require__("Z7t5");

function _typeof2(obj) { if (typeof _Symbol === "function" && typeof _Symbol$iterator === "symbol") { _typeof2 = function _typeof2(obj) { return typeof obj; }; } else { _typeof2 = function _typeof2(obj) { return obj && typeof _Symbol === "function" && obj.constructor === _Symbol && obj !== _Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof2(obj); }

function _typeof(obj) {
  if (typeof _Symbol === "function" && _typeof2(_Symbol$iterator) === "symbol") {
    module.exports = _typeof = function _typeof(obj) {
      return _typeof2(obj);
    };
  } else {
    module.exports = _typeof = function _typeof(obj) {
      return obj && typeof _Symbol === "function" && obj.constructor === _Symbol && obj !== _Symbol.prototype ? "symbol" : _typeof2(obj);
    };
  }

  return _typeof(obj);
}

module.exports = _typeof;

/***/ }),

/***/ "jirs":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("kOwS");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("qNsG");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("0iUn");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("sLSF");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("MI3g");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("a7VT");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("Tit0");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__("YFqc");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__("K2gz");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _components_SvgIcon__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__("BE5S");
/* harmony import */ var _components_Parallax__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__("IMUT");
/* harmony import */ var _components_Parallax_Paper__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__("QncY");
/* harmony import */ var _assets_images_app_banner_5_banner_5_jpg__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__("dxtb");
/* harmony import */ var _assets_images_app_banner_5_banner_5_jpg__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_assets_images_app_banner_5_banner_5_jpg__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _assets_images_app_banner_5_svg_1_svg_sprite__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__("hain");
/* harmony import */ var _assets_images_app_banner_5_svg_1_svg_sprite__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_assets_images_app_banner_5_svg_1_svg_sprite__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _assets_images_app_banner_5_svg_2_svg_sprite__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__("C4g1");
/* harmony import */ var _assets_images_app_banner_5_svg_2_svg_sprite__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_assets_images_app_banner_5_svg_2_svg_sprite__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _assets_images_app_banner_5_svg_3_svg_sprite__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__("k5Ji");
/* harmony import */ var _assets_images_app_banner_5_svg_3_svg_sprite__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_assets_images_app_banner_5_svg_3_svg_sprite__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _parallax_less__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__("za0J");
/* harmony import */ var _parallax_less__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(_parallax_less__WEBPACK_IMPORTED_MODULE_17__);


















var options = {
  // selector: '.paper',
  // relativeInput: true
  // clipRelativeInput: true,
  // scalarX: 10,
  // scalarY: 10,
  limitX: 30,
  limitY: 30 // frictionX: 0.1,
  // frictionY: 0.1

};

var WallPaper =
/*#__PURE__*/
function (_React$Component) {
  Object(_babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_6__[/* default */ "a"])(WallPaper, _React$Component);

  function WallPaper() {
    Object(_babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_2__[/* default */ "a"])(this, WallPaper);

    return Object(_babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__[/* default */ "a"])(this, Object(_babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"])(WallPaper).apply(this, arguments));
  }

  Object(_babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"])(WallPaper, [{
    key: "render",
    value: function render() {
      var _this$props = this.props,
          className = _this$props.className,
          props = Object(_babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(_this$props, ["className"]);

      return react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_components_Parallax__WEBPACK_IMPORTED_MODULE_11__[/* default */ "a"], Object(_babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])({}, props, {
        className: classnames__WEBPACK_IMPORTED_MODULE_9___default()(_parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.scene, className),
        options: options
      }), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_components_Parallax_Paper__WEBPACK_IMPORTED_MODULE_12__[/* default */ "a"], {
        depth: 0.2
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.paperBackground,
        style: {
          backgroundImage: "url(".concat(_assets_images_app_banner_5_banner_5_jpg__WEBPACK_IMPORTED_MODULE_13___default.a, ")")
        }
      })), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.leftContent
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_9___default()(_parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.topic, 'AppSiYuan')
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("h1", {
        className: classnames__WEBPACK_IMPORTED_MODULE_9___default()(_parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.topicTitle, 'AppSiYuan')
      }, "\u6B23\u52A8\u79D1\u6280 \xB7 \u667A\u80FD\u786C\u4EF6"), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("p", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.topicDesc
      }, "\u667A\u80FD\u7269\u8054\u7F51\u7684\u7269\u7406\u63A5\u89E6\u70B9\uFF0C\u662F\u7528\u6237\u611F\u77E5\u6B23\u52A8\u201C\u65E0\u5F62\u7684\u6280\u672F\u201D\u7684\u91CD\u8981\u5A92\u4ECB\u3002"), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.topicExtend
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.topicIcon
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_components_SvgIcon__WEBPACK_IMPORTED_MODULE_10__[/* default */ "a"], {
        icon: _assets_images_app_banner_5_svg_1_svg_sprite__WEBPACK_IMPORTED_MODULE_14___default.a
      }), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.topicLabel
      }, "\u667A\u80FD\u7F51\u5173")), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.topicIcon
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_components_SvgIcon__WEBPACK_IMPORTED_MODULE_10__[/* default */ "a"], {
        icon: _assets_images_app_banner_5_svg_2_svg_sprite__WEBPACK_IMPORTED_MODULE_15___default.a
      }), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.topicLabel
      }, "\u667A\u80FD\u7F51\u7531")), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.topicIcon
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_components_SvgIcon__WEBPACK_IMPORTED_MODULE_10__[/* default */ "a"], {
        icon: _assets_images_app_banner_5_svg_3_svg_sprite__WEBPACK_IMPORTED_MODULE_16___default.a
      }), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.topicLabel
      }, "\u524D\u7F6E\u670D\u52A1\u5668"))), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.topicAction
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(next_link__WEBPACK_IMPORTED_MODULE_8___default.a, {
        as: "/hardware",
        href: "/hardware"
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("a", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.topicButton
      }, "\u4E86\u89E3\u66F4\u591A"))))));
    }
  }]);

  return WallPaper;
}(react__WEBPACK_IMPORTED_MODULE_7___default.a.Component);

/* harmony default export */ __webpack_exports__["default"] = (WallPaper);

/***/ }),

/***/ "k1wZ":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/get-own-property-symbols");

/***/ }),

/***/ "k5Ji":
/***/ (function(module, exports, __webpack_require__) {

/* eslint-disable */
var React = __webpack_require__("cDcd");
var SpriteSymbol = __webpack_require__("QAmA");
var sprite = __webpack_require__("TQFg");

var symbol = new SpriteSymbol({
  "id": "2YQWHgSs--sprite",
  "use": "2YQWHgSs--sprite-usage",
  "viewBox": "0 0 1000.637 1000.678",
  "content": "<symbol xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 1000.637 1000.678\" id=\"2YQWHgSs--sprite\"><path d=\"M202.098 555.501v243.678c0 18.313.803 29.992 2.417 35.047 1.61 5.053 4.978 9.193 10.107 12.414 5.126 3.223 13.328 4.834 24.609 4.834h6.812v8.129H89.159v-8.129h7.91c12.744 0 21.825-1.463 27.246-4.395 5.417-2.93 9.081-6.957 10.986-12.086 1.902-5.125 2.856-17.063 2.856-35.814V644.71c0-13.768-.659-22.373-1.978-25.816-1.318-3.441-3.773-6.373-7.361-8.789-3.591-2.418-7.728-3.627-12.415-3.627-7.471 0-16.555 2.346-27.246 7.031l-3.955-7.91 109.644-50.098zm286.963 155.127c0 29.738-4.175 57.496-12.524 83.277-4.981 15.82-11.683 28.783-20.105 38.891-8.425 10.107-17.983 18.129-28.674 24.061-10.694 5.934-22.34 8.898-34.937 8.898-14.358 0-27.322-3.662-38.892-10.986-11.573-7.322-21.829-17.797-30.762-31.42-6.448-9.961-12.085-23.217-16.919-39.771-6.3-22.412-9.448-45.555-9.448-69.434 0-32.371 4.539-62.107 13.623-89.209 7.471-22.412 18.821-39.584 34.058-51.525 15.233-11.938 31.345-17.908 48.34-17.908 17.283 0 33.433 5.898 48.45 17.688 15.014 11.794 26.038 27.651 33.069 47.571 9.811 27.392 14.721 57.347 14.721 89.867zm-67.676-.44c0-52.146-.295-82.541-.879-91.186-1.466-20.359-4.981-34.131-10.547-41.309-3.663-4.688-9.596-7.031-17.798-7.031-6.3 0-11.282 1.758-14.941 5.273-5.421 5.129-9.084 14.172-10.986 27.137-1.905 12.963-2.856 58.191-2.856 135.68 0 42.188 1.462 70.461 4.395 84.814 2.197 10.402 5.346 17.359 9.448 20.875 4.099 3.516 9.521 5.273 16.26 5.273 7.323 0 12.816-2.342 16.479-7.031 6.152-8.203 9.668-20.875 10.547-38.014zm292.676.44c0 29.738-4.174 57.496-12.523 83.277-4.982 15.82-11.684 28.783-20.105 38.891-8.426 10.107-17.983 18.129-28.674 24.061-10.695 5.934-22.34 8.898-34.938 8.898-14.357 0-27.321-3.662-38.891-10.986-11.574-7.322-21.829-17.797-30.762-31.42-6.448-9.961-12.086-23.217-16.92-39.771-6.299-22.412-9.447-45.555-9.447-69.434 0-32.371 4.538-62.107 13.623-89.209 7.471-22.412 18.82-39.584 34.057-51.525 15.234-11.938 31.346-17.908 48.34-17.908 17.283 0 33.434 5.898 48.45 17.688 15.014 11.794 26.038 27.651 33.069 47.571 9.811 27.392 14.721 57.347 14.721 89.867zm-67.676-.44c0-52.146-.295-82.541-.879-91.186-1.465-20.359-4.98-34.131-10.547-41.309-3.662-4.688-9.596-7.031-17.797-7.031-6.301 0-11.282 1.758-14.941 5.273-5.422 5.129-9.085 14.172-10.986 27.137-1.906 12.963-2.857 58.191-2.857 135.68 0 42.188 1.463 70.461 4.395 84.814 2.197 10.402 5.346 17.359 9.449 20.875 4.099 3.516 9.52 5.273 16.26 5.273 7.322 0 12.816-2.342 16.479-7.031 6.152-8.203 9.668-20.875 10.547-38.014zm292.676.44c0 29.738-4.174 57.496-12.523 83.277-4.982 15.82-11.684 28.783-20.105 38.891-8.426 10.107-17.983 18.129-28.674 24.061-10.695 5.934-22.34 8.898-34.938 8.898-14.357 0-27.321-3.662-38.891-10.986-11.574-7.322-21.829-17.797-30.762-31.42-6.448-9.961-12.086-23.217-16.92-39.771-6.299-22.412-9.447-45.555-9.447-69.434 0-32.371 4.538-62.107 13.623-89.209 7.471-22.412 18.82-39.584 34.057-51.525 15.234-11.938 31.346-17.908 48.34-17.908 17.283 0 33.434 5.898 48.45 17.688 15.014 11.794 26.038 27.651 33.069 47.571 9.811 27.392 14.721 57.347 14.721 89.867zm-67.676-.44c0-52.146-.295-82.541-.879-91.186-1.465-20.359-4.98-34.131-10.547-41.309-3.662-4.688-9.596-7.031-17.797-7.031-6.301 0-11.282 1.758-14.941 5.273-5.422 5.129-9.085 14.172-10.986 27.137-1.906 12.963-2.857 58.191-2.857 135.68 0 42.188 1.463 70.461 4.395 84.814 2.197 10.402 5.346 17.359 9.449 20.875 4.099 3.516 9.52 5.273 16.26 5.273 7.322 0 12.816-2.342 16.479-7.031 6.152-8.203 9.668-20.875 10.547-38.014zM361.682 148.176v80.64h-7.91c-4.69-18.602-9.888-31.97-15.601-40.101-5.713-8.129-13.551-14.611-23.511-19.445-5.569-2.637-15.309-3.955-29.224-3.955h-22.192v229.834c0 15.236.841 24.757 2.527 28.564 1.682 3.811 4.978 7.141 9.888 9.998 4.906 2.855 11.608 4.284 20.105 4.284h9.888v8.13H149.646v-8.13h9.888c8.642 0 15.601-1.538 20.874-4.614 3.808-2.05 6.812-5.565 9.009-10.547 1.61-3.516 2.417-12.744 2.417-27.686V165.314H170.3c-20.071 0-34.645 4.25-43.726 12.744-12.744 11.865-20.802 28.784-24.17 50.757h-8.35v-80.64h267.628zm139.966 17.138v122.388h8.568c13.184 0 23.951-1.978 32.301-5.933s15.414-10.619 21.203-19.995c5.785-9.373 9.559-22.045 11.316-38.013h7.689v149.634h-7.689c-2.785-28.27-10.365-46.911-22.742-55.921-12.381-9.008-26.404-13.513-42.078-13.513h-8.568v91.187c0 15.236.841 24.757 2.526 28.564 1.683 3.811 4.978 7.141 9.888 9.998 4.906 2.855 11.535 4.284 19.885 4.284h9.889v8.13H388.049v-8.13h9.888c8.642 0 15.601-1.538 20.874-4.614 3.808-2.05 6.736-5.565 8.789-10.547 1.61-3.516 2.417-12.744 2.417-27.686V199.152c0-15.233-.807-24.754-2.417-28.564-1.614-3.808-4.872-7.141-9.778-9.998-4.91-2.856-11.536-4.285-19.885-4.285h-9.888v-8.13h251.367v85.474h-9.008c-2.054-20.067-7.289-34.937-15.711-44.604-8.426-9.668-20.62-16.479-36.584-20.435-8.789-2.197-25.049-3.296-48.779-3.296zm362.549-23.95l2.416 99.316h-9.008c-4.251-24.901-14.688-44.935-31.312-60.095-16.627-15.162-34.606-22.742-53.942-22.742-14.941 0-26.773 3.993-35.486 11.975-8.717 7.986-13.074 17.177-13.074 27.576 0 6.592 1.539 12.452 4.615 17.578 4.246 6.887 11.059 13.698 20.434 20.435 6.885 4.834 22.776 13.403 47.682 25.708 34.86 17.139 58.371 33.326 70.531 48.56 12.01 15.236 18.018 32.667 18.018 52.295 0 24.904-9.705 46.328-29.113 64.271-19.412 17.945-44.055 26.916-73.938 26.916-9.377 0-18.238-.954-26.588-2.856-8.35-1.905-18.824-5.493-31.42-10.767-7.031-2.929-12.82-4.395-17.359-4.395-3.811 0-7.838 1.466-12.084 4.395-4.251 2.932-7.691 7.396-10.328 13.403h-8.129v-112.5h8.129c6.445 31.641 18.859 55.776 37.244 72.399 18.381 16.628 38.195 24.939 59.436 24.939 16.404 0 29.479-4.467 39.222-13.403 9.74-8.934 14.612-19.336 14.612-31.201 0-7.031-1.868-13.843-5.604-20.435s-9.414-12.854-17.029-18.787c-7.617-5.932-21.094-13.657-40.43-23.181-27.102-13.328-46.582-24.682-58.447-34.058-11.865-9.373-20.983-19.848-27.355-31.421-6.372-11.57-9.559-24.314-9.559-38.232 0-23.73 8.714-43.945 26.148-60.645 17.43-16.699 39.402-25.049 65.918-25.049 9.668 0 19.04 1.174 28.125 3.516 6.883 1.758 15.271 5.02 25.158 9.778 9.888 4.762 16.809 7.141 20.764 7.141 3.809 0 6.813-1.171 9.01-3.516 2.197-2.341 4.246-7.982 6.152-16.919h6.591z\" /></symbol>"
});
sprite.add(symbol);

var SvgSpriteIcon = function SvgSpriteIcon(props) {
  return React.createElement(
    'svg',
    Object.assign({
      viewBox: symbol.viewBox
    }, props),
    React.createElement(
      'use',
      {
        xlinkHref: '#' + symbol.id
      }
    )
  );
};

SvgSpriteIcon.viewBox = symbol.viewBox;
SvgSpriteIcon.id = symbol.id;
SvgSpriteIcon.content = symbol.content;
SvgSpriteIcon.url = symbol.url;
SvgSpriteIcon.toString = symbol.toString;

module.exports = SvgSpriteIcon;
module.exports.default = SvgSpriteIcon;


/***/ }),

/***/ "kOwS":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _extends; });
/* harmony import */ var _core_js_object_assign__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("UXZV");
/* harmony import */ var _core_js_object_assign__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_assign__WEBPACK_IMPORTED_MODULE_0__);

function _extends() {
  _extends = _core_js_object_assign__WEBPACK_IMPORTED_MODULE_0___default.a || function (target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];

      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }

    return target;
  };

  return _extends.apply(this, arguments);
}

/***/ }),

/***/ "lOhm":
/***/ (function(module, exports) {

module.exports = require("whatitis");

/***/ }),

/***/ "o5io":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/create");

/***/ }),

/***/ "p8BD":
/***/ (function(module, exports) {

module.exports = require("next-server/dist/lib/utils");

/***/ }),

/***/ "pLtp":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("qJj/");

/***/ }),

/***/ "qJj/":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/keys");

/***/ }),

/***/ "qNsG":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/get-own-property-symbols.js
var get_own_property_symbols = __webpack_require__("4mXO");
var get_own_property_symbols_default = /*#__PURE__*/__webpack_require__.n(get_own_property_symbols);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/keys.js
var keys = __webpack_require__("pLtp");
var keys_default = /*#__PURE__*/__webpack_require__.n(keys);

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/objectWithoutPropertiesLoose.js

function _objectWithoutPropertiesLoose(source, excluded) {
  if (source == null) return {};
  var target = {};

  var sourceKeys = keys_default()(source);

  var key, i;

  for (i = 0; i < sourceKeys.length; i++) {
    key = sourceKeys[i];
    if (excluded.indexOf(key) >= 0) continue;
    target[key] = source[key];
  }

  return target;
}
// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/objectWithoutProperties.js
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _objectWithoutProperties; });


function _objectWithoutProperties(source, excluded) {
  if (source == null) return {};
  var target = _objectWithoutPropertiesLoose(source, excluded);
  var key, i;

  if (get_own_property_symbols_default.a) {
    var sourceSymbolKeys = get_own_property_symbols_default()(source);

    for (i = 0; i < sourceSymbolKeys.length; i++) {
      key = sourceSymbolKeys[i];
      if (excluded.indexOf(key) >= 0) continue;
      if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
      target[key] = source[key];
    }
  }

  return target;
}

/***/ }),

/***/ "rf6O":
/***/ (function(module, exports) {

module.exports = require("prop-types");

/***/ }),

/***/ "sLSF":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _createClass; });
/* harmony import */ var _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("hfKm");
/* harmony import */ var _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__);


function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;

    _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default()(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

/***/ }),

/***/ "ushU":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return requestAnimationFrame; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return cancelAnimationFrame; });
var suffix = 'AnimationFrame';
var vendors = ['', 'moz', 'webkit'];

var getAFFunc = function getAFFunc(name) {
  var func = null;
  return function () {
    if (func) {
      return func.apply(void 0, arguments);
    }

    var win = window;

    for (var i = 0, l = vendors.length; i < l; i++) {
      var prefix = vendors[i];
      var funcName = name + suffix;

      if (prefix) {
        funcName = prefix + funcName.charAt(0).toUpperCase() + funcName.slice(1);
      }

      func = win[funcName];

      if (func) {
        break;
      }
    }

    return func ? func.apply(void 0, arguments) : func;
  };
};

var requestAnimationFrame = getAFFunc('request');
var cancelFunc = getAFFunc('cancel');
var cancelRequestFunc = getAFFunc('cancelRequest');
var cancelAnimationFrame = function cancelAnimationFrame() {
  return cancelFunc.apply(void 0, arguments) || cancelRequestFunc.apply(void 0, arguments);
};

/***/ }),

/***/ "vYYK":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _defineProperty; });
/* harmony import */ var _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("hfKm");
/* harmony import */ var _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__);

function _defineProperty(obj, key, value) {
  if (key in obj) {
    _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default()(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}

/***/ }),

/***/ "vjea":
/***/ (function(module, exports, __webpack_require__) {

var _Object$setPrototypeOf = __webpack_require__("TRZx");

function _setPrototypeOf(o, p) {
  module.exports = _setPrototypeOf = _Object$setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

module.exports = _setPrototypeOf;

/***/ }),

/***/ "vqFK":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/symbol");

/***/ }),

/***/ "za0J":
/***/ (function(module, exports) {

module.exports = {
	"scene": "_1Zxh9h73",
	"paper-background": "_3DuBECud",
	"paperBackground": "_3DuBECud",
	"left-content": "_1LyUV2O_",
	"leftContent": "_1LyUV2O_",
	"center-content": "_242OCfn4",
	"centerContent": "_242OCfn4",
	"topic": "_1mi59G5i",
	"topic-title": "_1bqmkkVN",
	"topicTitle": "_1bqmkkVN",
	"topic-desc": "_2eLjJxyF",
	"topicDesc": "_2eLjJxyF",
	"topic-extend": "XGtqH0oX",
	"topicExtend": "XGtqH0oX",
	"topic-icon": "Fmyt4vOV",
	"topicIcon": "Fmyt4vOV",
	"topic-label": "_2WnbhL6a",
	"topicLabel": "_2WnbhL6a",
	"topic-action": "QHmQ3fB4",
	"topicAction": "QHmQ3fB4",
	"topic-button": "_1pq2TqNo",
	"topicButton": "_1pq2TqNo"
};

/***/ }),

/***/ "zrwo":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _objectSpread; });
/* harmony import */ var _core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("Jo+v");
/* harmony import */ var _core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("4mXO");
/* harmony import */ var _core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _core_js_object_keys__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("pLtp");
/* harmony import */ var _core_js_object_keys__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_keys__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _defineProperty__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("vYYK");




function _objectSpread(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i] != null ? arguments[i] : {};

    var ownKeys = _core_js_object_keys__WEBPACK_IMPORTED_MODULE_2___default()(source);

    if (typeof _core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1___default.a === 'function') {
      ownKeys = ownKeys.concat(_core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1___default()(source).filter(function (sym) {
        return _core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_0___default()(source, sym).enumerable;
      }));
    }

    ownKeys.forEach(function (key) {
      Object(_defineProperty__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"])(target, key, source[key]);
    });
  }

  return target;
}

/***/ })

/******/ });