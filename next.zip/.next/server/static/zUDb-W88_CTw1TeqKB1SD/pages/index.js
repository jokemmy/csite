module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../../../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 3);
/******/ })
/************************************************************************/
/******/ ({

/***/ "++HN":
/***/ (function(module, exports) {

module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA4AAAAQCAYAAAAmlE46AAADMUlEQVQYGQXBW2hbBQCA4f9cc2tO0maNaZtubbq262gpXStUWLGsKlgYahHmUDZ8GQpDfBIEn3yYDvTBG3PFDXyYSrU+yGSCeKHYsdauprglLY5eWa9Jc9KcnFzO6Tl+n+CaSRw3AnYTaGuIGIrxaO/Fe3dnXt3Z1hMnu1p+6h3q+kEMDyQ5EMEyQfQhuGaSQ0dDCrRirt9568bVm+8o5fUmX0nHFTWiT7fxIOlhoKf5rzNvXB6r5Nlz7A1EZC+ivx5I9d+4+vUn06lM01PWAWdWcpxV9nlyfpmTvSG+mvj7tD4/+Zkn5FL0bSJXyyVU+Z/zV94e/2Z2XeD6cAFzfJecpGKIkL97n5E3S5gXXuCVS9Pnxj83a4N17llRrhjoDyfPvffzMZ6IqEQW1jB3q6iAncwRbI6SupZi2P2PPwstfDC+8lyN4jaKj+emXjPWNp9tSURo8h9gVT2Ito19SqPm3S58iRAWDkHBoLtTxBKDKDFtUs6upscSccuvygqLRhTv+aPsrFiEWwMIHbUItkK8P8xeY5T0dJGL78dgaeaUqKrBAU0sMdRb4dvvapiZtWh9Jg5zeQq3Vik+zBKLK3zxURHTjTLctkNucbsgSkpRK2XKjPXroDaw/OkjjiXTaI02oViVjuMq8rVZbv+6SvtoLd1HcuybHuRAMJrO7q8NPj9sMfKyh4u3hvljapGIDPUBBavOz8LWECnhBD+ObiAEPPhitciO7PQauo/CzAJfvi7wYaSPqZlOuustmprXufl7jFQozOULXl7quM/avQJSbSAoFB5/fz07P3HJWD4gWM5ydPQ4juPBKZvIdp48jYh1dTgPlsisZJE6GtHaE1npyscTt3HzDYKUHijuQ363gjcWxsiUMAgTiCg4mSz6Vgm5PYHgC22FEyOnZbswi1su93jDcdRBgUO9iJHJI4ZCKLLI3r+b2CUHf2ccUZWxTLuhWt7rFAV02Rv3LElhP7JYRmvwIGFDQaeyuY0sQ7AtiKyWUII+tO6OeUmL5QTXXWZ/O83qnckThxu7Y4I3PxiKHWlRhMOQ4pM8VQJb3ki9Xq745vTSwS/Rvr7f6ht6+B/V01hosSSg4wAAAABJRU5ErkJggg=="

/***/ }),

/***/ "+d49":
/***/ (function(module, exports) {

module.exports = "/_next/static/images/banner-3-ca2e9bd06e17bc23aea1129fc099c59d.jpg";

/***/ }),

/***/ "/+P4":
/***/ (function(module, exports, __webpack_require__) {

var _Object$getPrototypeOf = __webpack_require__("Bhuq");

var _Object$setPrototypeOf = __webpack_require__("TRZx");

function _getPrototypeOf(o) {
  module.exports = _getPrototypeOf = _Object$setPrototypeOf ? _Object$getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || _Object$getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}

module.exports = _getPrototypeOf;

/***/ }),

/***/ "/+oN":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/get-prototype-of");

/***/ }),

/***/ "/HRN":
/***/ (function(module, exports) {

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

module.exports = _classCallCheck;

/***/ }),

/***/ "/nWe":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("kOwS");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("qNsG");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("0iUn");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("sLSF");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("MI3g");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("a7VT");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("Tit0");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__("YFqc");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__("K2gz");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _components_SvgIcon__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__("BE5S");
/* harmony import */ var _components_Parallax__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__("IMUT");
/* harmony import */ var _components_Parallax_Paper__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__("QncY");
/* harmony import */ var _assets_images_app_banner_1_banner_1_jpg__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__("tIKZ");
/* harmony import */ var _assets_images_app_banner_1_banner_1_jpg__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_assets_images_app_banner_1_banner_1_jpg__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _assets_images_app_banner_1_svg_1_svg_sprite__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__("jfTJ");
/* harmony import */ var _assets_images_app_banner_1_svg_1_svg_sprite__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_assets_images_app_banner_1_svg_1_svg_sprite__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _assets_images_app_banner_1_svg_2_svg_sprite__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__("RrwS");
/* harmony import */ var _assets_images_app_banner_1_svg_2_svg_sprite__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_assets_images_app_banner_1_svg_2_svg_sprite__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _assets_images_app_banner_1_svg_3_svg_sprite__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__("fFR6");
/* harmony import */ var _assets_images_app_banner_1_svg_3_svg_sprite__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_assets_images_app_banner_1_svg_3_svg_sprite__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _assets_images_app_banner_1_svg_4_svg_sprite__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__("UeOi");
/* harmony import */ var _assets_images_app_banner_1_svg_4_svg_sprite__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(_assets_images_app_banner_1_svg_4_svg_sprite__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var _parallax_less__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__("za0J");
/* harmony import */ var _parallax_less__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(_parallax_less__WEBPACK_IMPORTED_MODULE_18__);



















var options = {
  // selector: '.paper',
  // relativeInput: true
  // clipRelativeInput: true,
  // scalarX: 10,
  // scalarY: 10,
  limitX: 30,
  limitY: 30 // frictionX: 0.1,
  // frictionY: 0.1

};

var WallPaper =
/*#__PURE__*/
function (_React$Component) {
  Object(_babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_6__[/* default */ "a"])(WallPaper, _React$Component);

  function WallPaper() {
    Object(_babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_2__[/* default */ "a"])(this, WallPaper);

    return Object(_babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__[/* default */ "a"])(this, Object(_babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"])(WallPaper).apply(this, arguments));
  }

  Object(_babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"])(WallPaper, [{
    key: "render",
    value: function render() {
      var _this$props = this.props,
          className = _this$props.className,
          props = Object(_babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(_this$props, ["className"]);

      return react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_components_Parallax__WEBPACK_IMPORTED_MODULE_11__[/* default */ "a"], Object(_babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])({}, props, {
        className: classnames__WEBPACK_IMPORTED_MODULE_9___default()(_parallax_less__WEBPACK_IMPORTED_MODULE_18___default.a.scene, className),
        options: options
      }), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_components_Parallax_Paper__WEBPACK_IMPORTED_MODULE_12__[/* default */ "a"], {
        depth: 0.2
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_18___default.a.paperBackground,
        style: {
          backgroundImage: "url(".concat(_assets_images_app_banner_1_banner_1_jpg__WEBPACK_IMPORTED_MODULE_13___default.a, ")")
        }
      })), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_18___default.a.centerContent
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_9___default()(_parallax_less__WEBPACK_IMPORTED_MODULE_18___default.a.topic, 'AppSiYuan')
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("h1", {
        className: classnames__WEBPACK_IMPORTED_MODULE_9___default()(_parallax_less__WEBPACK_IMPORTED_MODULE_18___default.a.topicTitle, 'AppSiYuan')
      }, "\u667A\u6167\u65E0\u754C \u8D4B\u80FD\u65E0\u9650"), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("p", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_18___default.a.topicDesc
      }, "\u6253\u9020\u5168\u65B0\u7684\u667A\u6167\u80FD\u6E90\u8FD0\u7BA1\u4F53\u7CFB\uFF0C\u4E3A\u5BA2\u6237\u63D0\u4F9B\u5168\u65B9\u4F4D\u3001\u4E00\u4F53\u5316\u7684\u6574\u5408\u5F0F\u670D\u52A1\u3002"), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_18___default.a.topicExtend
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_18___default.a.topicIcon
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_components_SvgIcon__WEBPACK_IMPORTED_MODULE_10__[/* default */ "a"], {
        icon: _assets_images_app_banner_1_svg_1_svg_sprite__WEBPACK_IMPORTED_MODULE_14___default.a
      }), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_18___default.a.topicLabel
      }, "\u667A\u6167\u80FD\u6E90")), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_18___default.a.topicIcon
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_components_SvgIcon__WEBPACK_IMPORTED_MODULE_10__[/* default */ "a"], {
        icon: _assets_images_app_banner_1_svg_2_svg_sprite__WEBPACK_IMPORTED_MODULE_15___default.a
      }), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_18___default.a.topicLabel
      }, "\u667A\u6167\u56ED\u533A")), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_18___default.a.topicIcon
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_components_SvgIcon__WEBPACK_IMPORTED_MODULE_10__[/* default */ "a"], {
        icon: _assets_images_app_banner_1_svg_3_svg_sprite__WEBPACK_IMPORTED_MODULE_16___default.a
      }), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_18___default.a.topicLabel
      }, "\u667A\u6167\u6821\u56ED")), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_18___default.a.topicIcon
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_components_SvgIcon__WEBPACK_IMPORTED_MODULE_10__[/* default */ "a"], {
        icon: _assets_images_app_banner_1_svg_4_svg_sprite__WEBPACK_IMPORTED_MODULE_17___default.a
      }), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_18___default.a.topicLabel
      }, "\u667A\u6167\u5EFA\u7B51"))), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_18___default.a.topicAction
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(next_link__WEBPACK_IMPORTED_MODULE_8___default.a, {
        as: "/scene",
        href: "/scene"
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("a", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_18___default.a.topicButton
      }, "\u4E86\u89E3\u66F4\u591A"))))));
    }
  }]);

  return WallPaper;
}(react__WEBPACK_IMPORTED_MODULE_7___default.a.Component);

/* harmony default export */ __webpack_exports__["default"] = (WallPaper);

/***/ }),

/***/ "0EcU":
/***/ (function(module, exports) {

module.exports = {
	"banner": "_2H8Am4T8"
};

/***/ }),

/***/ "0iUn":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _classCallCheck; });
function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

/***/ }),

/***/ "1+QS":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/classCallCheck.js
var classCallCheck = __webpack_require__("0iUn");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/createClass.js
var createClass = __webpack_require__("sLSF");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/possibleConstructorReturn.js + 1 modules
var possibleConstructorReturn = __webpack_require__("MI3g");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/getPrototypeOf.js
var getPrototypeOf = __webpack_require__("a7VT");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/assertThisInitialized.js
var assertThisInitialized = __webpack_require__("AT/M");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/inherits.js + 1 modules
var inherits = __webpack_require__("Tit0");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/defineProperty.js
var defineProperty = __webpack_require__("vYYK");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/extends.js
var esm_extends = __webpack_require__("kOwS");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/objectWithoutProperties.js + 1 modules
var objectWithoutProperties = __webpack_require__("qNsG");

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__("cDcd");
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);

// EXTERNAL MODULE: external "whatitis"
var external_whatitis_ = __webpack_require__("lOhm");
var external_whatitis_default = /*#__PURE__*/__webpack_require__.n(external_whatitis_);

// EXTERNAL MODULE: external "omit.js"
var external_omit_js_ = __webpack_require__("LSCY");
var external_omit_js_default = /*#__PURE__*/__webpack_require__.n(external_omit_js_);

// EXTERNAL MODULE: external "rc-animate"
var external_rc_animate_ = __webpack_require__("Vam4");
var external_rc_animate_default = /*#__PURE__*/__webpack_require__.n(external_rc_animate_);

// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__("K2gz");
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);

// EXTERNAL MODULE: external "react-hammerjs"
var external_react_hammerjs_ = __webpack_require__("BgYr");
var external_react_hammerjs_default = /*#__PURE__*/__webpack_require__.n(external_react_hammerjs_);

// EXTERNAL MODULE: external "rc-tween-one"
var external_rc_tween_one_ = __webpack_require__("VNO/");
var external_rc_tween_one_default = /*#__PURE__*/__webpack_require__.n(external_rc_tween_one_);

// EXTERNAL MODULE: external "rc-util/lib/Dom/addEventListener"
var addEventListener_ = __webpack_require__("BI0l");
var addEventListener_default = /*#__PURE__*/__webpack_require__.n(addEventListener_);

// EXTERNAL MODULE: ./lib/requestAnimationFrame.js
var requestAnimationFrame = __webpack_require__("ushU");

// EXTERNAL MODULE: ./assets/motions/cScale.less
var cScale = __webpack_require__("SC1p");

// EXTERNAL MODULE: ./assets/motions/cSlideUp.less
var cSlideUp = __webpack_require__("Te8+");

// EXTERNAL MODULE: ./assets/motions/cSlideDown.less
var cSlideDown = __webpack_require__("Qnt8");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/objectSpread.js
var objectSpread = __webpack_require__("zrwo");

// EXTERNAL MODULE: ./components/Carousel/points.less
var Carousel_points = __webpack_require__("2crN");
var points_default = /*#__PURE__*/__webpack_require__.n(Carousel_points);

// CONCATENATED MODULE: ./components/Carousel/points.js












var points_Points =
/*#__PURE__*/
function (_React$Component) {
  Object(inherits["a" /* default */])(Points, _React$Component);

  function Points() {
    var _getPrototypeOf2;

    var _this;

    Object(classCallCheck["a" /* default */])(this, Points);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = Object(possibleConstructorReturn["a" /* default */])(this, (_getPrototypeOf2 = Object(getPrototypeOf["a" /* default */])(Points)).call.apply(_getPrototypeOf2, [this].concat(args)));

    Object(defineProperty["a" /* default */])(Object(assertThisInitialized["a" /* default */])(_this), "handleClick", function (i) {
      return function () {
        var _this$props = _this.props,
            onChange = _this$props.onChange,
            index = _this$props.index;

        if (index !== i) {
          onChange(i);
        }
      };
    });

    return _this;
  }

  Object(createClass["a" /* default */])(Points, [{
    key: "render",
    value: function render() {
      var _this2 = this;

      var _this$props2 = this.props,
          points = _this$props2.points,
          index = _this$props2.index,
          size = _this$props2.size;
      var sizeStyle = {
        height: "".concat(100 / points.length, "%")
      };

      var blockProps = function blockProps(i) {
        return {
          className: points_default.a.block,
          onClick: _this2.handleClick(i),
          style: sizeStyle
        };
      };

      return external_react_default.a.createElement("div", {
        className: points_default.a.track,
        style: {
          height: size
        }
      }, points.map(function (point, i) {
        return i === index ? external_react_default.a.createElement("div", Object(esm_extends["a" /* default */])({
          key: "point-".concat(i)
        }, blockProps(i))) : external_react_default.a.createElement("div", Object(esm_extends["a" /* default */])({
          key: "active-point-".concat(i)
        }, blockProps(i)));
      }), external_react_default.a.createElement("div", {
        className: points_default.a.thumb,
        style: Object(objectSpread["a" /* default */])({
          top: "".concat(index * 100 / points.length, "%")
        }, sizeStyle)
      }));
    }
  }]);

  return Points;
}(external_react_default.a.Component);

/* harmony default export */ var components_Carousel_points = (points_Points);
// EXTERNAL MODULE: ./components/Carousel/carousel.less
var carousel = __webpack_require__("Pnzm");
var carousel_default = /*#__PURE__*/__webpack_require__.n(carousel);

// CONCATENATED MODULE: ./components/Carousel/index.js
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CarouselContext; });























var TweenOneGroup = external_rc_tween_one_default.a.TweenOneGroup;
var CarouselContext = external_react_default.a.createContext({
  isEnable: true
});

function HammerHoc(_ref) {
  var disabled = _ref.disabled,
      children = _ref.children,
      props = Object(objectWithoutProperties["a" /* default */])(_ref, ["disabled", "children"]);

  return disabled ? children : external_react_default.a.createElement(external_react_hammerjs_default.a, Object(esm_extends["a" /* default */])({}, props, {
    direction: "DIRECTION_VERTICAL"
  }), children);
}

var Carousel_Carousel =
/*#__PURE__*/
function (_React$Component) {
  Object(inherits["a" /* default */])(Carousel, _React$Component);

  function Carousel() {
    var _getPrototypeOf2;

    var _this;

    Object(classCallCheck["a" /* default */])(this, Carousel);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = Object(possibleConstructorReturn["a" /* default */])(this, (_getPrototypeOf2 = Object(getPrototypeOf["a" /* default */])(Carousel)).call.apply(_getPrototypeOf2, [this].concat(args)));

    Object(defineProperty["a" /* default */])(Object(assertThisInitialized["a" /* default */])(_this), "state", {
      index: 0,
      scrolling: false,
      isEnable: true
    });

    Object(defineProperty["a" /* default */])(Object(assertThisInitialized["a" /* default */])(_this), "handleWheel", function (e) {
      // 正数页面向上,负数页面向下
      var delta = (whatenvis.firefox ? 3 : 1) * e.delta;
      var _this$props = _this.props,
          children = _this$props.children,
          disabled = _this$props.disabled;
      var _this$state = _this.state,
          index = _this$state.index,
          scrolling = _this$state.scrolling;
      var count = external_react_default.a.Children.toArray(children).length - 1;

      if (!disabled && scrolling === false) {
        if (delta > 0 && index > 0) {
          _this.handleChange(index - 1);
        } else if (delta < 0 && index < count) {
          _this.handleChange(index + 1);
        }
      }
    });

    Object(defineProperty["a" /* default */])(Object(assertThisInitialized["a" /* default */])(_this), "handleScrollEnd", function (_, exists) {
      if (exists) {
        var onEnd = _this.props.onEnd;
        _this.state.scrolling = false; // eslint-disable-line

        _this.setState({
          isEnable: true
        }, external_whatitis_default.a.Function(onEnd) ? onEnd : null);
      }
    });

    Object(defineProperty["a" /* default */])(Object(assertThisInitialized["a" /* default */])(_this), "handleChange", function (targetIndex) {
      var _this$props2 = _this.props,
          index = _this$props2.index,
          onChange = _this$props2.onChange;

      if (external_whatitis_default.a.Number(index) && index >= 0) {
        external_whatitis_default.a.Function(onChange) && onChange(targetIndex);
      } else {
        var _this$state2 = _this.state,
            _index = _this$state2.index,
            scrolling = _this$state2.scrolling;

        if (scrolling === false) {
          _this.state.scrolling = true; // eslint-disable-line

          _this.setState({
            isEnable: false
          }, function () {
            _this.rafHandle = Object(requestAnimationFrame["b" /* requestAnimationFrame */])(function () {
              _this.rafHandle = null;

              _this.setState({
                index: targetIndex,
                direction: targetIndex > _index ? 1 : 0
              });
            });
          });
        }
      }
    });

    Object(defineProperty["a" /* default */])(Object(assertThisInitialized["a" /* default */])(_this), "handleSwipe", function (event) {
      var index = _this.state.index;
      var children = _this.props.children;
      var count = external_react_default.a.Children.toArray(children).length;
      var offsetDirection = event.offsetDirection;
      event.preventDefault();

      if (offsetDirection === 8 && index < count - 1) {
        // 上
        _this.handleChange(index + 1);
      }

      if (offsetDirection === 16 && index > 0) {
        // 下
        _this.handleChange(index - 1);
      }
    });

    Object(defineProperty["a" /* default */])(Object(assertThisInitialized["a" /* default */])(_this), "handleSlider", function () {
      var children = _this.props.children;
      var _this$state3 = _this.state,
          index = _this$state3.index,
          scrolling = _this$state3.scrolling;
      var count = external_react_default.a.Children.toArray(children).length - 1;

      if (scrolling === false) {
        if (index < count) {
          _this.handleChange(index + 1);
        }
      }
    });

    return _this;
  }

  Object(createClass["a" /* default */])(Carousel, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      var eventName = whatenvis.firefox ? 'DOMMouseScroll' : 'mousewheel';
      this.wheelListener = addEventListener_default()(document.body, eventName, this.handleWheel);
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      if (this.wheelListener) {
        this.wheelListener.remove();
        this.wheelListener = null;
      }

      if (this.rafHandle) {
        Object(requestAnimationFrame["a" /* cancelAnimationFrame */])(this.rafHandle);
        this.rafHandle = null;
      }
    }
  }, {
    key: "render",
    value: function render() {
      var _this$state4 = this.state,
          index = _this$state4.index,
          direction = _this$state4.direction,
          isEnable = _this$state4.isEnable;

      var _omit = external_omit_js_default()(this.props, ['onEnd']),
          children = _omit.children,
          className = _omit.className,
          disabled = _omit.disabled,
          showPoints = _omit.showPoints,
          showArrow = _omit.showArrow,
          props = Object(objectWithoutProperties["a" /* default */])(_omit, ["children", "className", "disabled", "showPoints", "showArrow"]);

      var childArray = external_react_default.a.Children.toArray(children);
      var count = childArray.length;
      var child = childArray.find(function (_, i) {
        return i === index;
      });
      return external_react_default.a.createElement(CarouselContext.Provider, {
        value: {
          isEnable: isEnable
        }
      }, external_react_default.a.createElement(HammerHoc, {
        onSwipe: this.handleSwipe,
        disabled: disabled
      }, external_react_default.a.createElement("div", Object(esm_extends["a" /* default */])({}, props, {
        className: external_classnames_default()(className, carousel_default.a.carousel)
      }), external_react_default.a.createElement(external_rc_animate_default.a, {
        component: "div",
        transitionAppear: false,
        onEnd: this.handleScrollEnd,
        transitionName: direction ? 'c-slide-up' : 'c-slide-down'
      }, external_react_default.a.createElement("div", {
        key: "".concat(index),
        className: carousel_default.a.paper
      }, external_react_default.a.createElement("div", {
        className: "c-scale"
      }, child))), showPoints ? external_react_default.a.createElement(components_Carousel_points, {
        size: "100%",
        index: index,
        onChange: this.handleChange,
        points: Array(count).fill(1)
      }) : null, external_react_default.a.createElement(TweenOneGroup, {
        component: "",
        enter: {
          opacity: 0,
          type: 'from',
          duration: 2000
        },
        leave: {
          opacity: 0,
          duration: 2000
        }
      }, showArrow && count - 1 > index ? external_react_default.a.createElement("div", {
        key: "arrow",
        className: carousel_default.a.arrowDown,
        onClick: this.handleSlider
      }, external_react_default.a.createElement("div", {
        className: carousel_default.a.arrowDownAnim
      }, external_react_default.a.createElement("em", null), external_react_default.a.createElement("em", null), external_react_default.a.createElement("em", null))) : null))));
    }
  }]);

  return Carousel;
}(external_react_default.a.Component);

Object(defineProperty["a" /* default */])(Carousel_Carousel, "defaultProps", {
  showArrow: true,
  showPoints: true
});

Object(defineProperty["a" /* default */])(Carousel_Carousel, "getDerivedStateFromProps", function (props, state) {
  if (external_whatitis_default.a.Number(props.index) && props.index >= 0 && state.index !== props.index) {
    return {
      index: props.index,
      direction: props.index > state.index ? 1 : 0,
      scrolling: false,
      isEnable: false
    };
  }

  return null;
});

/* harmony default export */ var components_Carousel = __webpack_exports__["b"] = (Carousel_Carousel);

/***/ }),

/***/ "2bz7":
/***/ (function(module, exports, __webpack_require__) {

/* eslint-disable */
var React = __webpack_require__("cDcd");
var SpriteSymbol = __webpack_require__("QAmA");
var sprite = __webpack_require__("TQFg");

var symbol = new SpriteSymbol({
  "id": "1p4fRT6e--sprite",
  "use": "1p4fRT6e--sprite-usage",
  "viewBox": "0 0 1000.637 1000.678",
  "content": "<symbol xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 1000.637 1000.678\" id=\"1p4fRT6e--sprite\"><path d=\"M743.59 522.013H623.646a43.347 43.347 0 0 1-30.836-12.516l-75.146-70.819c-18.497-16.824-47.136-15.479-63.97 3.02a52.182 52.182 0 0 0-1.549 1.795l-48.17 61.18a44.787 44.787 0 0 1-35.171 17.34H256.567v-43.357h87.669a48.13 48.13 0 0 0 35.65-16.85l66.003-83.83c15.302-19.435 43.472-22.78 62.907-7.478a43.14 43.14 0 0 1 3.081 2.663l96.351 93.457a44.752 44.752 0 0 0 30.824 12.037h102.133z\" /><path d=\"M784.539 702.662H216.105c-29.277 0-52.996-23.719-52.996-52.987V264.288c0-29.259 23.718-52.986 52.996-52.986h568.434c29.27 0 52.988 23.728 52.988 52.986v385.387c0 29.268-23.718 52.987-52.988 52.987zM216.105 259.473c-2.567.23-4.602 2.257-4.823 4.815v385.387a5.303 5.303 0 0 0 5.301 5.301h567.956a5.304 5.304 0 0 0 4.824-5.301V264.288a5.322 5.322 0 0 0-4.824-4.815zm551.096 529.903H227.185c-13.31.016-24.1-10.764-24.108-24.065-.018-13.302 10.762-24.099 24.064-24.106h540.061c13.295.008 24.076 10.805 24.066 24.106-.01 13.283-10.78 24.054-24.067 24.065z\" /></symbol>"
});
sprite.add(symbol);

var SvgSpriteIcon = function SvgSpriteIcon(props) {
  return React.createElement(
    'svg',
    Object.assign({
      viewBox: symbol.viewBox
    }, props),
    React.createElement(
      'use',
      {
        xlinkHref: '#' + symbol.id
      }
    )
  );
};

SvgSpriteIcon.viewBox = symbol.viewBox;
SvgSpriteIcon.id = symbol.id;
SvgSpriteIcon.content = symbol.content;
SvgSpriteIcon.url = symbol.url;
SvgSpriteIcon.toString = symbol.toString;

module.exports = SvgSpriteIcon;
module.exports.default = SvgSpriteIcon;


/***/ }),

/***/ "2crN":
/***/ (function(module, exports) {

module.exports = {
	"track": "_1ujYANvT",
	"block": "_1_K01DDo",
	"thumb": "_3m-xWWqN"
};

/***/ }),

/***/ 3:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("RNiq");


/***/ }),

/***/ "4LTB":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("0iUn");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("sLSF");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("MI3g");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("a7VT");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("Tit0");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("K2gz");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _components_SvgIcon__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__("BE5S");
/* harmony import */ var _components_Parallax__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__("IMUT");
/* harmony import */ var _components_Parallax_Paper__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__("QncY");
/* harmony import */ var _assets_images_app_banner_2_banner_2_jpg__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__("hnuN");
/* harmony import */ var _assets_images_app_banner_2_banner_2_jpg__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_assets_images_app_banner_2_banner_2_jpg__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _assets_images_app_banner_2_svg_1_svg_sprite__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__("Wq/1");
/* harmony import */ var _assets_images_app_banner_2_svg_1_svg_sprite__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_assets_images_app_banner_2_svg_1_svg_sprite__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _assets_images_app_banner_2_svg_2_svg_sprite__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__("vF0m");
/* harmony import */ var _assets_images_app_banner_2_svg_2_svg_sprite__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_assets_images_app_banner_2_svg_2_svg_sprite__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _assets_images_app_banner_2_svg_3_svg_sprite__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__("dfL4");
/* harmony import */ var _assets_images_app_banner_2_svg_3_svg_sprite__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_assets_images_app_banner_2_svg_3_svg_sprite__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _assets_images_app_banner_2_svg_4_svg_sprite__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__("Qw6K");
/* harmony import */ var _assets_images_app_banner_2_svg_4_svg_sprite__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_assets_images_app_banner_2_svg_4_svg_sprite__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _assets_images_app_banner_2_svg_5_svg_sprite__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__("Zom5");
/* harmony import */ var _assets_images_app_banner_2_svg_5_svg_sprite__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_assets_images_app_banner_2_svg_5_svg_sprite__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _parallax_less__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__("za0J");
/* harmony import */ var _parallax_less__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_parallax_less__WEBPACK_IMPORTED_MODULE_16__);





 // import Link from 'next/link';












var options = {
  // selector: '.paper',
  // relativeInput: true
  // clipRelativeInput: true,
  // scalarX: 10,
  // scalarY: 10,
  limitX: 30,
  limitY: 30 // frictionX: 0.1,
  // frictionY: 0.1

};

var WallPaper =
/*#__PURE__*/
function (_React$Component) {
  Object(_babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_4__[/* default */ "a"])(WallPaper, _React$Component);

  function WallPaper() {
    Object(_babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(this, WallPaper);

    return Object(_babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__[/* default */ "a"])(this, Object(_babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"])(WallPaper).apply(this, arguments));
  }

  Object(_babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(WallPaper, [{
    key: "render",
    value: function render() {
      return react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement(_components_Parallax__WEBPACK_IMPORTED_MODULE_8__[/* default */ "a"], {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.scene,
        options: options
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement(_components_Parallax_Paper__WEBPACK_IMPORTED_MODULE_9__[/* default */ "a"], {
        depth: 0.2
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.paperBackground,
        style: {
          backgroundImage: "url(".concat(_assets_images_app_banner_2_banner_2_jpg__WEBPACK_IMPORTED_MODULE_10___default.a, ")")
        }
      })), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.leftContent
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_6___default()(_parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.topic, 'AppSiYuan')
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("h1", {
        className: classnames__WEBPACK_IMPORTED_MODULE_6___default()(_parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.topicTitle, 'AppSiYuan')
      }, "\u4E07\u7269\u611F\u77E5 \xB7 \u4E07\u7269\u4E92\u8054 \xB7 \u4E07\u7269\u667A\u80FD"), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("p", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.topicDesc
      }, "DD-IoT\u7269\u8054\u611F\u77E5\u5E73\u53F0\uFF0C\u90E8\u7F72\u5404\u7C7B\u4F20\u611F\u7F51\u667A\u80FD\u786C\u4EF6\u4EA7\u54C1\uFF0C\u53CA\u65F6\u3001\u51C6\u786E\u3001\u5FEB\u901F\u7684\u76D1\u6D4B\u4E00\u5207\u4EBA\u548C\u7269\u3002"), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.topicExtend
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.topicIcon
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement(_components_SvgIcon__WEBPACK_IMPORTED_MODULE_7__[/* default */ "a"], {
        icon: _assets_images_app_banner_2_svg_1_svg_sprite__WEBPACK_IMPORTED_MODULE_11___default.a
      }), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.topicLabel
      }, "\u9AD8\u5E76\u53D1")), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.topicIcon
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement(_components_SvgIcon__WEBPACK_IMPORTED_MODULE_7__[/* default */ "a"], {
        icon: _assets_images_app_banner_2_svg_2_svg_sprite__WEBPACK_IMPORTED_MODULE_12___default.a
      }), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.topicLabel
      }, "\u6D77\u91CF\u5B9E\u65F6\u6570\u636E\u5B58\u50A8")), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.topicIcon
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement(_components_SvgIcon__WEBPACK_IMPORTED_MODULE_7__[/* default */ "a"], {
        icon: _assets_images_app_banner_2_svg_3_svg_sprite__WEBPACK_IMPORTED_MODULE_13___default.a
      }), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.topicLabel
      }, "\u6570\u636E\u6EE4\u6CE2")), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.topicIcon
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement(_components_SvgIcon__WEBPACK_IMPORTED_MODULE_7__[/* default */ "a"], {
        icon: _assets_images_app_banner_2_svg_4_svg_sprite__WEBPACK_IMPORTED_MODULE_14___default.a
      }), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.topicLabel
      }, "\u53EF\u5B9A\u5236\u5316\u9A71\u52A8\u6A21\u578B")), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.topicIcon
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement(_components_SvgIcon__WEBPACK_IMPORTED_MODULE_7__[/* default */ "a"], {
        icon: _assets_images_app_banner_2_svg_5_svg_sprite__WEBPACK_IMPORTED_MODULE_15___default.a
      }), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.topicLabel
      }, "\u53EF\u7F16\u7A0B\u7CFB\u5217\u901A\u8BAF\u7F51\u5173"))))));
    }
  }]);

  return WallPaper;
}(react__WEBPACK_IMPORTED_MODULE_5___default.a.Component);

/* harmony default export */ __webpack_exports__["default"] = (WallPaper);

/***/ }),

/***/ "4Q3z":
/***/ (function(module, exports) {

module.exports = require("next/router");

/***/ }),

/***/ "4mXO":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("k1wZ");

/***/ }),

/***/ "5dF4":
/***/ (function(module, exports, __webpack_require__) {

/* eslint-disable */
var React = __webpack_require__("cDcd");
var SpriteSymbol = __webpack_require__("QAmA");
var sprite = __webpack_require__("TQFg");

var symbol = new SpriteSymbol({
  "id": "1JYjvWBU--sprite",
  "use": "1JYjvWBU--sprite-usage",
  "viewBox": "0 0 1000.637 1000.678",
  "content": "<symbol xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 1000.637 1000.678\" id=\"1JYjvWBU--sprite\"><path d=\"M479.222 579.314V310.756c0-12.22 9.812-22.143 21.921-22.143 12.112 0 21.919 9.923 21.919 22.143v180.709l74.697-75.45c8.548-8.648 22.44-8.648 30.987 0 8.563 8.635 8.563 22.668 0 31.304L523.062 554.086v165.321c21.784-2.438 33.034-4.541 44.473-8.388l2.179-.691c76.873-22.725 131.812-92.722 135.579-174.301 1.574-42.154-6.673-78.662-24.564-114.794-15.536-31.414-37.375-61.569-73.805-104.042-7.479-8.731-10.837-12.579-28.428-32.632-32.702-35.261-57.734-64.365-77.903-91.932-6.655 8.911-13.918 18.087-21.837 27.705-8.055 9.757-16.575 19.708-27.509 32.205-4.11 4.704-22.537 25.643-27.456 31.289l-1.342 1.467c-48.499 52.063-74.312 83.988-94.013 119.181-23.209 41.394-33.907 82.938-32.1 131.554 3.739 80.929 57.844 150.47 133.757 173.75 19.017 4.233 35.154 7.374 49.129 9.408v-78.549a22.035 22.035 0 0 1-5.097-3.849L367.208 528.817c-8.549-8.664-8.549-22.684 0-31.317a21.783 21.783 0 0 1 31.019 0zm41.232 179.253c-2.435 54.281-38.868 89.985-103.933 105.007-10.747 2.488-21.443-4.365-23.891-15.29-2.444-10.923 4.295-21.809 15.054-24.296 26.061-6.016 44.809-15.353 56.59-27.47 9.762-10.049 15.129-22.435 16.177-38.002-19.06-2.398-39.803-6.648-58.614-10.887-91.912-27.355-159.186-111.681-163.667-211.981-4.48-118.52 58.3-193.735 130.043-271.235 33.624-38.738 67.274-75.216 89.691-113.953 6.715-13.678 24.664-18.246 35.872-9.123 4.481 2.271 6.727 6.839 8.961 9.123 22.43 38.737 56.067 77.487 89.692 113.953 69.508 79.771 134.522 152.715 130.043 271.235-4.481 100.301-71.757 184.626-163.668 211.981-18.846 6.371-37.694 8.794-58.35 10.938z\" /></symbol>"
});
sprite.add(symbol);

var SvgSpriteIcon = function SvgSpriteIcon(props) {
  return React.createElement(
    'svg',
    Object.assign({
      viewBox: symbol.viewBox
    }, props),
    React.createElement(
      'use',
      {
        xlinkHref: '#' + symbol.id
      }
    )
  );
};

SvgSpriteIcon.viewBox = symbol.viewBox;
SvgSpriteIcon.id = symbol.id;
SvgSpriteIcon.content = symbol.content;
SvgSpriteIcon.url = symbol.url;
SvgSpriteIcon.toString = symbol.toString;

module.exports = SvgSpriteIcon;
module.exports.default = SvgSpriteIcon;


/***/ }),

/***/ "6RRd":
/***/ (function(module, exports) {

module.exports = require("object.pick");

/***/ }),

/***/ "9Jkg":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("fozc");

/***/ }),

/***/ "AT/M":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _assertThisInitialized; });
function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

/***/ }),

/***/ "BE5S":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return Icon; });
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("kOwS");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("qNsG");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("K2gz");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _svgIcon_less__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("flPq");
/* harmony import */ var _svgIcon_less__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_svgIcon_less__WEBPACK_IMPORTED_MODULE_4__);





function Icon(_ref) {
  var icon = _ref.icon,
      className = _ref.className,
      props = Object(_babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(_ref, ["icon", "className"]);

  return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("svg", Object(_babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])({
    "aria-hidden": "true"
  }, props, {
    className: classnames__WEBPACK_IMPORTED_MODULE_3___default()(_svgIcon_less__WEBPACK_IMPORTED_MODULE_4___default.a.svgIcon, className)
  }), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("use", {
    xlinkHref: "#".concat(icon.id)
  }));
}

/***/ }),

/***/ "BI0l":
/***/ (function(module, exports) {

module.exports = require("rc-util/lib/Dom/addEventListener");

/***/ }),

/***/ "BgYr":
/***/ (function(module, exports) {

module.exports = require("react-hammerjs");

/***/ }),

/***/ "Bhuq":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("/+oN");

/***/ }),

/***/ "C4g1":
/***/ (function(module, exports, __webpack_require__) {

/* eslint-disable */
var React = __webpack_require__("cDcd");
var SpriteSymbol = __webpack_require__("QAmA");
var sprite = __webpack_require__("TQFg");

var symbol = new SpriteSymbol({
  "id": "1NY7GLK5--sprite",
  "use": "1NY7GLK5--sprite-usage",
  "viewBox": "0 0 1000.637 1000.678",
  "content": "<symbol xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 1000.637 1000.678\" id=\"1NY7GLK5--sprite\"><path d=\"M193.098 555.603V799.28c0 18.313.803 29.992 2.417 35.047 1.61 5.053 4.978 9.193 10.107 12.414 5.126 3.224 13.328 4.834 24.609 4.834h6.812v8.13H80.159v-8.13h7.91c12.744 0 21.825-1.463 27.246-4.395 5.417-2.929 9.081-6.956 10.986-12.085 1.902-5.126 2.856-17.063 2.856-35.815V644.812c0-13.768-.659-22.374-1.978-25.817-1.318-3.44-3.773-6.373-7.361-8.789-3.591-2.418-7.728-3.626-12.415-3.626-7.471 0-16.555 2.345-27.246 7.031l-3.955-7.91 109.644-50.098zm286.963 155.126c0 29.738-4.175 57.496-12.524 83.276-4.981 15.82-11.683 28.784-20.105 38.892-8.425 10.107-17.983 18.128-28.674 24.06-10.694 5.934-22.34 8.899-34.937 8.899-14.358 0-27.322-3.663-38.892-10.986-11.573-7.323-21.829-17.798-30.762-31.421-6.448-9.96-12.085-23.216-16.919-39.771-6.3-22.412-9.448-45.556-9.448-69.434 0-32.372 4.539-62.107 13.623-89.209 7.471-22.412 18.821-39.585 34.058-51.525 15.233-11.938 31.345-17.908 48.34-17.908 17.283 0 33.433 5.898 48.45 17.688 15.014 11.794 26.038 27.651 33.069 47.571 9.811 27.394 14.721 57.349 14.721 89.868zm-67.676-.439c0-52.147-.295-82.542-.879-91.187-1.466-20.359-4.981-34.13-10.547-41.309-3.663-4.687-9.596-7.031-17.798-7.031-6.3 0-11.282 1.758-14.941 5.273-5.421 5.129-9.084 14.172-10.986 27.137-1.905 12.963-2.856 58.192-2.856 135.681 0 42.188 1.462 70.46 4.395 84.814 2.197 10.402 5.346 17.358 9.448 20.874 4.099 3.516 9.521 5.273 16.26 5.273 7.323 0 12.816-2.342 16.479-7.031 6.152-8.202 9.668-20.874 10.547-38.013zm292.676.439c0 29.738-4.174 57.496-12.523 83.276-4.982 15.82-11.684 28.784-20.105 38.892-8.426 10.107-17.983 18.128-28.674 24.06-10.695 5.934-22.34 8.899-34.938 8.899-14.357 0-27.321-3.663-38.891-10.986-11.574-7.323-21.829-17.798-30.762-31.421-6.448-9.96-12.086-23.216-16.92-39.771-6.299-22.412-9.447-45.556-9.447-69.434 0-32.372 4.538-62.107 13.623-89.209 7.471-22.412 18.82-39.585 34.057-51.525 15.234-11.938 31.346-17.908 48.34-17.908 17.283 0 33.434 5.898 48.45 17.688 15.014 11.794 26.038 27.651 33.069 47.571 9.811 27.394 14.721 57.349 14.721 89.868zm-67.676-.439c0-52.147-.295-82.542-.879-91.187-1.465-20.359-4.98-34.13-10.547-41.309-3.662-4.687-9.596-7.031-17.797-7.031-6.301 0-11.282 1.758-14.941 5.273-5.422 5.129-9.085 14.172-10.986 27.137-1.906 12.963-2.857 58.192-2.857 135.681 0 42.188 1.463 70.46 4.395 84.814 2.197 10.402 5.346 17.358 9.449 20.874 4.099 3.516 9.52 5.273 16.26 5.273 7.322 0 12.816-2.342 16.479-7.031 6.152-8.202 9.668-20.874 10.547-38.013zm292.676.439c0 29.738-4.174 57.496-12.523 83.276-4.982 15.82-11.684 28.784-20.105 38.892-8.426 10.107-17.983 18.128-28.674 24.06-10.695 5.934-22.34 8.899-34.938 8.899-14.357 0-27.321-3.663-38.891-10.986-11.574-7.323-21.829-17.798-30.762-31.421-6.448-9.96-12.086-23.216-16.92-39.771-6.299-22.412-9.447-45.556-9.447-69.434 0-32.372 4.538-62.107 13.623-89.209 7.471-22.412 18.82-39.585 34.057-51.525 15.234-11.938 31.346-17.908 48.34-17.908 17.283 0 33.434 5.898 48.45 17.688 15.014 11.794 26.038 27.651 33.069 47.571 9.811 27.394 14.721 57.349 14.721 89.868zm-67.676-.439c0-52.147-.295-82.542-.879-91.187-1.465-20.359-4.98-34.13-10.547-41.309-3.662-4.687-9.596-7.031-17.797-7.031-6.301 0-11.282 1.758-14.941 5.273-5.422 5.129-9.085 14.172-10.986 27.137-1.906 12.963-2.857 58.192-2.857 135.681 0 42.188 1.463 70.46 4.395 84.814 2.197 10.402 5.346 17.358 9.449 20.874 4.099 3.516 9.52 5.273 16.26 5.273 7.322 0 12.816-2.342 16.479-7.031 6.152-8.202 9.668-20.874 10.547-38.013zM438.193 148.277v80.64h-7.91c-4.69-18.602-9.888-31.97-15.601-40.101-5.713-8.129-13.551-14.611-23.511-19.445-5.569-2.637-15.309-3.955-29.224-3.955h-22.192V395.25c0 15.236.841 24.757 2.527 28.564 1.682 3.811 4.978 7.141 9.888 9.998 4.906 2.855 11.608 4.284 20.105 4.284h9.888v8.13H226.157v-8.13h9.888c8.642 0 15.601-1.538 20.874-4.614 3.808-2.05 6.812-5.565 9.009-10.547 1.61-3.516 2.417-12.744 2.417-27.686V165.416h-21.533c-20.071 0-34.645 4.25-43.726 12.744-12.744 11.865-20.802 28.784-24.17 50.757h-8.35v-80.64zm135.791 162.158v83.496c0 16.115.988 26.258 2.967 30.432 1.977 4.176 5.455 7.509 10.437 9.998 4.978 2.492 14.282 3.735 27.905 3.735v8.13h-152.49v-8.13c13.767 0 23.105-1.28 28.015-3.845 4.906-2.562 8.35-5.896 10.327-9.998 1.979-4.1 2.967-14.207 2.967-30.322V200.572c0-16.112-.988-26.258-2.967-30.432-1.977-4.176-5.458-7.505-10.437-9.998-4.981-2.489-14.282-3.735-27.905-3.735v-8.13H601.23c36.035 0 62.402 2.493 79.102 7.471 16.699 4.981 30.322 14.172 40.869 27.576 10.547 13.402 15.82 29.113 15.82 47.131 0 21.973-7.91 40.138-23.73 54.492-10.107 9.084-24.246 15.896-42.407 20.435l71.631 100.854c9.372 13.039 16.04 21.169 19.995 24.39 6.005 4.542 12.964 7.031 20.874 7.471v8.13h-93.823L593.54 310.435zm0-146.118v130.518h12.524c20.358 0 35.596-1.868 45.703-5.603 10.107-3.736 18.052-10.472 23.841-20.215 5.785-9.74 8.679-22.447 8.679-38.123 0-22.704-5.312-39.476-15.931-50.317-10.622-10.839-27.723-16.26-51.306-16.26z\" /></symbol>"
});
sprite.add(symbol);

var SvgSpriteIcon = function SvgSpriteIcon(props) {
  return React.createElement(
    'svg',
    Object.assign({
      viewBox: symbol.viewBox
    }, props),
    React.createElement(
      'use',
      {
        xlinkHref: '#' + symbol.id
      }
    )
  );
};

SvgSpriteIcon.viewBox = symbol.viewBox;
SvgSpriteIcon.id = symbol.id;
SvgSpriteIcon.content = symbol.content;
SvgSpriteIcon.url = symbol.url;
SvgSpriteIcon.toString = symbol.toString;

module.exports = SvgSpriteIcon;
module.exports.default = SvgSpriteIcon;


/***/ }),

/***/ "FwBY":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("kOwS");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("qNsG");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("K2gz");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_Themes__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("qRXU");
/* harmony import */ var _assets_images_icon_police_png__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("++HN");
/* harmony import */ var _assets_images_icon_police_png__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_assets_images_icon_police_png__WEBPACK_IMPORTED_MODULE_5__);








function Beian(_ref) {
  var className = _ref.className,
      props = Object(_babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(_ref, ["className"]);

  var _useContext = Object(react__WEBPACK_IMPORTED_MODULE_2__["useContext"])(_components_Themes__WEBPACK_IMPORTED_MODULE_4__[/* ThemeContext */ "a"]),
      env = _useContext.env;

  return env.pc ? react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("div", Object(_babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])({}, props, {
    className: classnames__WEBPACK_IMPORTED_MODULE_3___default()('footer-beian', className)
  }), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("a", {
    target: "_blank",
    href: "http://www.beian.miit.gov.cn"
  }, "\u82CFICP\u590719019187\u53F7-1"), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("span", {
    style: {
      width: 300,
      display: 'inline-block',
      paddingLeft: 8
    }
  }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("a", {
    target: "_blank",
    href: "http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=32021402001107"
  }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("img", {
    alt: "police",
    src: _assets_images_icon_police_png__WEBPACK_IMPORTED_MODULE_5___default.a,
    style: {
      marginRight: 3,
      width: 12,
      verticalAlign: 'text-bottom'
    }
  }), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("span", {
    style: {
      height: 20,
      lineHeight: '20px'
    }
  }, "\u82CF\u516C\u7F51\u5B89\u5907 32021402001107\u53F7")))) : null;
}

/* harmony default export */ __webpack_exports__["a"] = (Beian);

/***/ }),

/***/ "Fz14":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/regenerator/index.js
var regenerator = __webpack_require__("ln6h");
var regenerator_default = /*#__PURE__*/__webpack_require__.n(regenerator);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/asyncToGenerator.js
var asyncToGenerator = __webpack_require__("O40h");

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__("cDcd");
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/extends.js
var esm_extends = __webpack_require__("kOwS");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/objectWithoutProperties.js + 1 modules
var objectWithoutProperties = __webpack_require__("qNsG");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/classCallCheck.js
var classCallCheck = __webpack_require__("0iUn");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/createClass.js
var createClass = __webpack_require__("sLSF");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/possibleConstructorReturn.js + 1 modules
var possibleConstructorReturn = __webpack_require__("MI3g");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/getPrototypeOf.js
var getPrototypeOf = __webpack_require__("a7VT");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/inherits.js + 1 modules
var inherits = __webpack_require__("Tit0");

// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__("K2gz");
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);

// EXTERNAL MODULE: ./components/Carousel/index.js + 1 modules
var Carousel = __webpack_require__("1+QS");

// EXTERNAL MODULE: ./components/Banner/banner.less
var banner = __webpack_require__("0EcU");
var banner_default = /*#__PURE__*/__webpack_require__.n(banner);

// CONCATENATED MODULE: ./components/Banner/index.js












var Banner_Banner =
/*#__PURE__*/
function (_React$Component) {
  Object(inherits["a" /* default */])(Banner, _React$Component);

  function Banner() {
    Object(classCallCheck["a" /* default */])(this, Banner);

    return Object(possibleConstructorReturn["a" /* default */])(this, Object(getPrototypeOf["a" /* default */])(Banner).apply(this, arguments));
  }

  Object(createClass["a" /* default */])(Banner, [{
    key: "render",
    value: function render() {
      var _this$props = this.props,
          children = _this$props.children,
          className = _this$props.className,
          props = Object(objectWithoutProperties["a" /* default */])(_this$props, ["children", "className"]);

      return external_react_default.a.createElement(Carousel["b" /* default */], Object(esm_extends["a" /* default */])({}, props, {
        className: external_classnames_default()(banner_default.a.banner, className)
      }), children);
    }
  }]);

  return Banner;
}(external_react_default.a.Component);

/* harmony default export */ var components_Banner = (Banner_Banner);
// EXTERNAL MODULE: ./components/Footer/Beian.js
var Beian = __webpack_require__("FwBY");

// EXTERNAL MODULE: ./pages/app/Parallax1.js
var Parallax1 = __webpack_require__("/nWe");

// EXTERNAL MODULE: ./pages/app/Parallax2.js
var Parallax2 = __webpack_require__("4LTB");

// EXTERNAL MODULE: ./pages/app/Parallax3.js
var Parallax3 = __webpack_require__("auXZ");

// EXTERNAL MODULE: ./pages/app/Parallax4.js
var Parallax4 = __webpack_require__("bKMw");

// EXTERNAL MODULE: ./pages/app/Parallax5.js
var Parallax5 = __webpack_require__("jirs");

// EXTERNAL MODULE: ./pages/app/app.less
var app = __webpack_require__("UDI0");
var app_default = /*#__PURE__*/__webpack_require__.n(app);

// CONCATENATED MODULE: ./pages/app/index.js












function App() {
  return external_react_default.a.createElement(external_react_default.a.Fragment, null, external_react_default.a.createElement(components_Banner, null, external_react_default.a.createElement(Parallax1["default"], null), external_react_default.a.createElement(Parallax2["default"], null), external_react_default.a.createElement(Parallax3["default"], null), external_react_default.a.createElement(Parallax4["default"], null), external_react_default.a.createElement(Parallax5["default"], null)), external_react_default.a.createElement(Beian["a" /* default */], {
    className: app_default.a.beian
  }));
}

App.getInitialProps =
/*#__PURE__*/
function () {
  var _ref = Object(asyncToGenerator["a" /* default */])(
  /*#__PURE__*/
  regenerator_default.a.mark(function _callee(ctx_) {
    var layoutProps;
    return regenerator_default.a.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            layoutProps = {
              header: {
                transparent: true
              },
              footer: false,
              title: '江苏欣动信息科技'
            };
            return _context.abrupt("return", {
              layoutProps: layoutProps
            });

          case 2:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));

  return function (_x) {
    return _ref.apply(this, arguments);
  };
}();

/* harmony default export */ var pages_app = __webpack_exports__["default"] = (App);

/***/ }),

/***/ "IMUT":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("kOwS");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("qNsG");
/* harmony import */ var _babel_runtime_corejs2_core_js_object_assign__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("UXZV");
/* harmony import */ var _babel_runtime_corejs2_core_js_object_assign__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_core_js_object_assign__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("0iUn");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("sLSF");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("MI3g");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("a7VT");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__("Tit0");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__("vYYK");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var omit_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__("LSCY");
/* harmony import */ var omit_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(omit_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var parallax_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__("W0Av");
/* harmony import */ var parallax_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(parallax_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _components_Carousel__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__("1+QS");












 //https://ken.artbees.net/wide-parallax-startup/

var Scene =
/*#__PURE__*/
function (_React$Component) {
  Object(_babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_7__[/* default */ "a"])(Scene, _React$Component);

  function Scene(props) {
    var _this;

    Object(_babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"])(this, Scene);

    _this = Object(_babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"])(this, Object(_babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_6__[/* default */ "a"])(Scene).call(this, props));
    _this.sceneRef = react__WEBPACK_IMPORTED_MODULE_9___default.a.createRef();
    return _this;
  }

  Object(_babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_4__[/* default */ "a"])(Scene, [{
    key: "componentDidUpdate",
    value: function componentDidUpdate() {
      var isEnable = this.context.isEnable;

      if (isEnable) {
        this.createParallax();
      } else {
        this.destroyParallax();
      }
    }
  }, {
    key: "componentDidMount",
    value: function componentDidMount() {
      var isEnable = this.context.isEnable;

      if (isEnable) {
        this.createParallax();
      }
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      this.destroyParallax();
    }
  }, {
    key: "createParallax",
    value: function createParallax() {
      var defaultOptions = {
        selector: '.paper'
      };
      var options = this.props.options;
      this.parallaxInstance = new parallax_js__WEBPACK_IMPORTED_MODULE_11___default.a(this.sceneRef.current, _babel_runtime_corejs2_core_js_object_assign__WEBPACK_IMPORTED_MODULE_2___default()(defaultOptions, options));
    }
  }, {
    key: "destroyParallax",
    value: function destroyParallax() {
      if (this.parallaxInstance) {
        this.parallaxInstance.destroy();
        this.parallaxInstance = null;
      }
    }
  }, {
    key: "render",
    value: function render() {
      var _omit = omit_js__WEBPACK_IMPORTED_MODULE_10___default()(this.props, ['options']),
          children = _omit.children,
          className = _omit.className,
          props = Object(_babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(_omit, ["children", "className"]);

      return react__WEBPACK_IMPORTED_MODULE_9___default.a.createElement("div", Object(_babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])({}, props, {
        ref: this.sceneRef,
        className: "".concat(className ? "".concat(className, " ") : '', "scene")
      }), children);
    }
  }]);

  return Scene;
}(react__WEBPACK_IMPORTED_MODULE_9___default.a.Component);

Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_8__[/* default */ "a"])(Scene, "contextType", _components_Carousel__WEBPACK_IMPORTED_MODULE_12__[/* CarouselContext */ "a"]);

/* harmony default export */ __webpack_exports__["a"] = (Scene);

/***/ }),

/***/ "Jo+v":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("Z6Kq");

/***/ }),

/***/ "K2gz":
/***/ (function(module, exports) {

module.exports = require("classnames");

/***/ }),

/***/ "K47E":
/***/ (function(module, exports) {

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

module.exports = _assertThisInitialized;

/***/ }),

/***/ "KI45":
/***/ (function(module, exports) {

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    default: obj
  };
}

module.exports = _interopRequireDefault;

/***/ }),

/***/ "LSCY":
/***/ (function(module, exports) {

module.exports = require("omit.js");

/***/ }),

/***/ "MI3g":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/symbol/iterator.js
var iterator = __webpack_require__("XVgq");
var iterator_default = /*#__PURE__*/__webpack_require__.n(iterator);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/symbol.js
var symbol = __webpack_require__("Z7t5");
var symbol_default = /*#__PURE__*/__webpack_require__.n(symbol);

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/typeof.js



function typeof_typeof2(obj) { if (typeof symbol_default.a === "function" && typeof iterator_default.a === "symbol") { typeof_typeof2 = function _typeof2(obj) { return typeof obj; }; } else { typeof_typeof2 = function _typeof2(obj) { return obj && typeof symbol_default.a === "function" && obj.constructor === symbol_default.a && obj !== symbol_default.a.prototype ? "symbol" : typeof obj; }; } return typeof_typeof2(obj); }

function typeof_typeof(obj) {
  if (typeof symbol_default.a === "function" && typeof_typeof2(iterator_default.a) === "symbol") {
    typeof_typeof = function _typeof(obj) {
      return typeof_typeof2(obj);
    };
  } else {
    typeof_typeof = function _typeof(obj) {
      return obj && typeof symbol_default.a === "function" && obj.constructor === symbol_default.a && obj !== symbol_default.a.prototype ? "symbol" : typeof_typeof2(obj);
    };
  }

  return typeof_typeof(obj);
}
// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/assertThisInitialized.js
var assertThisInitialized = __webpack_require__("AT/M");

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/possibleConstructorReturn.js
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _possibleConstructorReturn; });


function _possibleConstructorReturn(self, call) {
  if (call && (typeof_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return Object(assertThisInitialized["a" /* default */])(self);
}

/***/ }),

/***/ "N9n2":
/***/ (function(module, exports, __webpack_require__) {

var _Object$create = __webpack_require__("SqZg");

var setPrototypeOf = __webpack_require__("vjea");

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = _Object$create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) setPrototypeOf(subClass, superClass);
}

module.exports = _inherits;

/***/ }),

/***/ "O40h":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _asyncToGenerator; });
/* harmony import */ var _core_js_promise__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("eVuF");
/* harmony import */ var _core_js_promise__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_promise__WEBPACK_IMPORTED_MODULE_0__);


function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
  try {
    var info = gen[key](arg);
    var value = info.value;
  } catch (error) {
    reject(error);
    return;
  }

  if (info.done) {
    resolve(value);
  } else {
    _core_js_promise__WEBPACK_IMPORTED_MODULE_0___default.a.resolve(value).then(_next, _throw);
  }
}

function _asyncToGenerator(fn) {
  return function () {
    var self = this,
        args = arguments;
    return new _core_js_promise__WEBPACK_IMPORTED_MODULE_0___default.a(function (resolve, reject) {
      var gen = fn.apply(self, args);

      function _next(value) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
      }

      function _throw(err) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
      }

      _next(undefined);
    });
  };
}

/***/ }),

/***/ "Pnzm":
/***/ (function(module, exports) {

module.exports = {
	"carousel": "QIruQvWN",
	"paper": "IDE1NymA",
	"arrow-down": "_11U8PP3q",
	"arrowDown": "_11U8PP3q",
	"arrow-down-anim": "OiG04KV1",
	"arrowDownAnim": "OiG04KV1",
	"arrowDownAnimKF": "_2nZLV2q0",
	"arrowDownAnimKf": "_2nZLV2q0"
};

/***/ }),

/***/ "QAmA":
/***/ (function(module, exports) {

module.exports = require("svg-baker-runtime/symbol");

/***/ }),

/***/ "QncY":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("kOwS");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("qNsG");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("0iUn");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("sLSF");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("MI3g");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("a7VT");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("Tit0");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);









var Paper =
/*#__PURE__*/
function (_React$Component) {
  Object(_babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_6__[/* default */ "a"])(Paper, _React$Component);

  function Paper() {
    Object(_babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_2__[/* default */ "a"])(this, Paper);

    return Object(_babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__[/* default */ "a"])(this, Object(_babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"])(Paper).apply(this, arguments));
  }

  Object(_babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"])(Paper, [{
    key: "render",
    value: function render() {
      var _this$props = this.props,
          depth = _this$props.depth,
          children = _this$props.children,
          className = _this$props.className,
          props = Object(_babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(_this$props, ["depth", "children", "className"]);

      return react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", Object(_babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])({}, props, {
        className: "".concat(className ? "".concat(className, " ") : '', "paper"),
        "data-depth": depth
      }), children);
    }
  }]);

  return Paper;
}(react__WEBPACK_IMPORTED_MODULE_7___default.a.Component);

/* harmony default export */ __webpack_exports__["a"] = (Paper);

/***/ }),

/***/ "Qnt8":
/***/ (function(module, exports) {

module.exports = {
	"cslideDownIn": "_33bJsfF1",
	"cslideDownOut": "_26zD-TbW"
};

/***/ }),

/***/ "Qw6K":
/***/ (function(module, exports, __webpack_require__) {

/* eslint-disable */
var React = __webpack_require__("cDcd");
var SpriteSymbol = __webpack_require__("QAmA");
var sprite = __webpack_require__("TQFg");

var symbol = new SpriteSymbol({
  "id": "3aI8Gi6J--sprite",
  "use": "3aI8Gi6J--sprite-usage",
  "viewBox": "0 0 1000.637 1000.678",
  "content": "<symbol xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 1000.637 1000.678\" id=\"3aI8Gi6J--sprite\"><path d=\"M830.643 273.016L539.15 110.535c-23.672-13.241-54.005-13.241-77.318 0L170.714 273.016c-23.673 13.242-38.473 38.113-38.473 64.993v324.962c0 26.886 14.8 51.348 38.473 64.596l291.119 162.481c11.843 6.416 25.151 10.026 38.473 10.026a79.134 79.134 0 0 0 38.474-10.026l291.117-162.481c23.685-13.248 38.473-38.112 38.473-64.596V338.009c.745-26.88-14.043-51.751-37.727-64.993zm-10.364 389.563c0 10.015-5.543 18.855-14.429 24.071L514.732 849.116c-8.511 4.828-19.97 4.828-28.482 0L195.126 686.65c-8.874-4.825-14.421-14.057-14.421-24.071V337.605c0-10.026 5.548-18.854 14.421-24.071L486.25 151.055c4.437-2.407 9.246-3.612 14.427-3.612 5.182 0 9.992 1.205 14.055 3.612l291.502 162.479c8.875 4.818 14.429 14.044 14.429 24.071v324.974zm-68.05-322.561L517.69 463.589c-2.212 1.2-4.437 2.399-6.661 4.003-6.648 2.412-14.427 2.412-21.076-.404-1.852-1.201-3.703-2.4-5.927-3.6l-227.121-123.57c-11.47-6.422-26.637-2.413-33.291 8.827-5.548 9.225-3.703 20.458 3.697 27.682 1.479 1.604 3.697 3.208 5.921 4.407l23.673 12.844 206.033 113.139c.384.391 1.118.391 1.491.796 6.661 5.216 10.724 13.235 10.724 21.659l1.107 253.155v2.411c0 .393 0 .796.372 1.2v1.2c0 .402.373.808.373 1.2 0 .403 0 .809.36 1.211 0 .404.384.795.384.795 0 .404.361.81.361 1.2 0 .417.373.417.373.808.372.405.372.81.734 1.605v.404c3.701 6.414 10.735 11.239 18.874 12.034h2.585c7.394 0 14.428-3.208 18.865-8.826 3.33-4.018 5.554-9.231 5.554-15.243v-16.051l.745-236.7c0-8.021 3.692-15.243 9.618-20.46.734-.402 1.84-.808 2.574-1.198l237.496-125.972c11.831-6.428 16.279-20.471 9.618-32.103-6.297-12.033-21.086-16.447-32.917-10.024z\" /></symbol>"
});
sprite.add(symbol);

var SvgSpriteIcon = function SvgSpriteIcon(props) {
  return React.createElement(
    'svg',
    Object.assign({
      viewBox: symbol.viewBox
    }, props),
    React.createElement(
      'use',
      {
        xlinkHref: '#' + symbol.id
      }
    )
  );
};

SvgSpriteIcon.viewBox = symbol.viewBox;
SvgSpriteIcon.id = symbol.id;
SvgSpriteIcon.content = symbol.content;
SvgSpriteIcon.url = symbol.url;
SvgSpriteIcon.toString = symbol.toString;

module.exports = SvgSpriteIcon;
module.exports.default = SvgSpriteIcon;


/***/ }),

/***/ "RNiq":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _app__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("Fz14");

/* harmony default export */ __webpack_exports__["default"] = (_app__WEBPACK_IMPORTED_MODULE_0__["default"]);

/***/ }),

/***/ "RrwS":
/***/ (function(module, exports, __webpack_require__) {

/* eslint-disable */
var React = __webpack_require__("cDcd");
var SpriteSymbol = __webpack_require__("QAmA");
var sprite = __webpack_require__("TQFg");

var symbol = new SpriteSymbol({
  "id": "3rdNLiSu--sprite",
  "use": "3rdNLiSu--sprite-usage",
  "viewBox": "0 0 1000.637 1000.678",
  "content": "<symbol xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 1000.637 1000.678\" id=\"3rdNLiSu--sprite\"><g fill=\"#fff\"><path d=\"M643.587 217.813h13.388c74.979 13.392 83.019 21.432 83.019 42.85v18.751h45.518v-93.726c0-10.725-2.668-29.476-16.056-50.894-21.433-32.143-58.92-48.198-107.118-48.198H536.466a24 24 0 0 0-24.1 24.099c0 69.63 48.198 93.729 131.221 107.118zm-80.341-85.687h99.091c34.807 0 56.226 8.03 69.617 26.78 2.681 8.026 5.358 13.389 5.358 18.737v16.069c-16.069-8.025-40.169-13.388-74.976-18.75l-10.725-2.668c-56.222-10.72-80.336-18.749-88.365-40.168zm-26.78 589.14c-13.389 16.068-18.751 18.75-32.14 18.75-10.71 0-13.388-2.682-29.448-18.75-18.75-21.419-34.82-32.13-64.281-32.13-29.448 0-42.836 10.711-64.268 32.13-10.71 16.068-16.069 18.75-26.78 18.75h-8.029v45.53h10.71c29.461 0 42.85-10.725 64.268-32.142 13.392-16.07 18.75-18.751 29.461-18.751 10.707 0 16.069 2.681 32.139 18.751 18.741 21.417 34.81 32.142 61.59 32.142 29.458 0 45.531-10.725 64.268-32.142 13.389-13.389 18.751-16.07 26.781-16.07h8.04v-45.518h-8.04c-29.462-2.68-45.517 8.031-64.271 29.45z\" /><path d=\"M863.185 314.223H686.437c-13.392 0-21.432 10.708-21.432 24.099v530.229H156.193V723.946L367.76 509.708h275.826v-45.531H359.718c-5.345 0-10.708 2.694-16.07 8.043L118.702 699.847c-5.349 5.359-5.349 10.708-5.349 16.069v176.748c0 13.389 10.711 21.418 24.099 21.418H865.85c13.39 0 21.433-10.711 21.433-21.418V335.641c-2.68-13.389-13.391-21.418-24.098-21.418zM707.854 865.884V434.729h131.217v431.155zm131.217-506.131v29.448H707.854v-29.448z\" /><path d=\"M608.777 590.048h-8.04c-26.781 0-42.851 10.707-61.591 32.14-13.389 16.068-18.75 18.736-29.458 18.736-10.711 0-13.392-2.668-29.461-18.736-18.737-21.433-34.81-32.14-64.268-32.14-29.461 0-42.85 10.707-64.268 32.14-13.392 16.068-18.75 18.736-29.461 18.736h-10.71v45.53h10.71c29.461 0 42.85-10.706 64.268-32.139 13.392-16.06 18.75-18.74 29.461-18.74 10.707 0 16.069 2.681 32.139 18.74 18.741 21.433 34.81 32.139 61.59 32.139 29.458 0 45.531-10.706 64.268-32.139 13.389-13.392 18.751-16.06 26.781-16.06h8.04z\" /></g></symbol>"
});
sprite.add(symbol);

var SvgSpriteIcon = function SvgSpriteIcon(props) {
  return React.createElement(
    'svg',
    Object.assign({
      viewBox: symbol.viewBox
    }, props),
    React.createElement(
      'use',
      {
        xlinkHref: '#' + symbol.id
      }
    )
  );
};

SvgSpriteIcon.viewBox = symbol.viewBox;
SvgSpriteIcon.id = symbol.id;
SvgSpriteIcon.content = symbol.content;
SvgSpriteIcon.url = symbol.url;
SvgSpriteIcon.toString = symbol.toString;

module.exports = SvgSpriteIcon;
module.exports.default = SvgSpriteIcon;


/***/ }),

/***/ "S3+N":
/***/ (function(module, exports, __webpack_require__) {

/* eslint-disable */
var React = __webpack_require__("cDcd");
var SpriteSymbol = __webpack_require__("QAmA");
var sprite = __webpack_require__("TQFg");

var symbol = new SpriteSymbol({
  "id": "1iJgNdIp--sprite",
  "use": "1iJgNdIp--sprite-usage",
  "viewBox": "0 0 1000.637 1000.678",
  "content": "<symbol xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 1000.637 1000.678\" id=\"1iJgNdIp--sprite\"><path d=\"M600.035 774.771l-86.167-86.167a1154.955 1154.955 0 0 1-72.125 43.009L269.049 558.919a964.174 964.174 0 0 1 42.475-72.66l-85.643-85.643c-7.946-7.945-7.951-20.832-.02-28.773l.019-.019 71.948-71.948c55.244-55.194 141.896-63.391 206.515-19.541 128.376-91.134 259.239-119.139 297.139-81.2 37.89 37.93 9.924 168.791-81.205 297.133 43.85 64.619 35.657 151.276-19.54 206.515l-71.949 71.947c-7.927 7.947-20.786 7.965-28.753.041zm-143.91-460.503c-31.787-31.797-83.335-31.796-115.127-.004l-57.556 57.556c-7.951 7.939-7.961 20.831-.026 28.788l.015.015 43.169 43.169zm302.211-71.946c-18.318-18.319-69.745-12.332-130.481 13.41l117.061 117.062c25.814-60.728 31.896-112.078 13.482-130.473zm-31.973 169.497L588.84 274.294a571.686 571.686 0 0 0-134.099 98.933 980.288 980.288 0 0 0-135.316 178.478l129.528 129.528A1068.426 1068.426 0 0 0 627.434 545.92c39.357-39.641 72.722-84.814 98.979-134.111zM686.384 659.65c31.803-31.782 31.798-83.328.007-115.117L556.866 674.057l43.159 43.158c7.956 7.956 20.838 7.956 28.783.012l.021-.021zM484.903 515.755c-31.792-31.792-31.792-83.342-.001-115.132 31.792-31.792 83.341-31.792 115.133 0 31.791 31.79 31.781 83.331-.001 115.132-31.786 31.745-83.29 31.739-115.071-.002zm86.355-86.355c-15.891-15.901-41.667-15.91-57.567-.01-15.9 15.891-15.901 41.665-.005 57.562 15.885 15.895 41.665 15.9 57.57.015l.006-.005c15.896-15.896 15.931-41.655.056-57.562zM182.817 817.899s-3.009-112.122 28.783-143.914c31.792-31.791 83.336-31.798 115.132-.001 31.792 31.792 31.791 83.341-.001 115.133-31.851 31.852-143.914 28.782-143.914 28.782zM297.95 702.768c-15.896-15.896-41.661-15.896-57.562.006-15.89 15.891-28.787 86.344-28.787 86.344s70.447-12.903 86.338-28.793c15.841-15.9 15.819-41.625-.051-57.495z\" fill=\"#fff\" /></symbol>"
});
sprite.add(symbol);

var SvgSpriteIcon = function SvgSpriteIcon(props) {
  return React.createElement(
    'svg',
    Object.assign({
      viewBox: symbol.viewBox
    }, props),
    React.createElement(
      'use',
      {
        xlinkHref: '#' + symbol.id
      }
    )
  );
};

SvgSpriteIcon.viewBox = symbol.viewBox;
SvgSpriteIcon.id = symbol.id;
SvgSpriteIcon.content = symbol.content;
SvgSpriteIcon.url = symbol.url;
SvgSpriteIcon.toString = symbol.toString;

module.exports = SvgSpriteIcon;
module.exports.default = SvgSpriteIcon;


/***/ }),

/***/ "SC1p":
/***/ (function(module, exports) {

module.exports = {
	"cScaleIn": "yzEr1rWc",
	"cScaleOut": "_34mAihAf"
};

/***/ }),

/***/ "SLvO":
/***/ (function(module, exports, __webpack_require__) {

/* eslint-disable */
var React = __webpack_require__("cDcd");
var SpriteSymbol = __webpack_require__("QAmA");
var sprite = __webpack_require__("TQFg");

var symbol = new SpriteSymbol({
  "id": "21uW6yUi--sprite",
  "use": "21uW6yUi--sprite-usage",
  "viewBox": "0 0 1000.637 1000.678",
  "content": "<symbol xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 1000.637 1000.678\" id=\"21uW6yUi--sprite\"><g fill=\"#fff\"><path d=\"M784.324 221.6c-119.518-13.541-209.432-45.867-267.232-96.125l-15.219-13.229-16.401 11.719c-90.606 64.696-180.215 97.469-266.305 97.469h-25.551v357.819c0 109.696 96.712 209.184 295.677 304.177l10.473 5.004 10.636-4.56C707.248 799.3 807.02 696.852 807.02 579.252V224.17zm-28.418 357.652c0 93.283-85.785 178.412-255.055 253.025C330.889 749.39 244.73 664.283 244.73 579.252V271.733c83.606-5.414 168.984-37.293 254.381-95.003 61.29 46.727 147.508 77.89 256.795 92.836z\" /><path d=\"M372.437 466.348c-9.354-10.573-25.501-11.577-36.081-2.224-10.599 9.354-11.583 25.508-2.23 36.093l97.264 110.08c10.091 11.372 24.12 17.207 38.292 17.207a51.312 51.312 0 0 0 39.653-18.756l157.862-193.88c8.906-10.943 7.245-27.036-3.706-35.96-10.938-8.9-27.03-7.265-35.949 3.698L469.7 576.414z\" /></g></symbol>"
});
sprite.add(symbol);

var SvgSpriteIcon = function SvgSpriteIcon(props) {
  return React.createElement(
    'svg',
    Object.assign({
      viewBox: symbol.viewBox
    }, props),
    React.createElement(
      'use',
      {
        xlinkHref: '#' + symbol.id
      }
    )
  );
};

SvgSpriteIcon.viewBox = symbol.viewBox;
SvgSpriteIcon.id = symbol.id;
SvgSpriteIcon.content = symbol.content;
SvgSpriteIcon.url = symbol.url;
SvgSpriteIcon.toString = symbol.toString;

module.exports = SvgSpriteIcon;
module.exports.default = SvgSpriteIcon;


/***/ }),

/***/ "SqZg":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("o5io");

/***/ }),

/***/ "TQFg":
/***/ (function(module, exports) {

module.exports = require("svg-sprite-loader/runtime/sprite.build");

/***/ }),

/***/ "TRZx":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("Wk4r");

/***/ }),

/***/ "TUA0":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/define-property");

/***/ }),

/***/ "Te8+":
/***/ (function(module, exports) {

module.exports = {
	"cslideUpIn": "_1BDx8_C5",
	"cslideUpOut": "_1Ck_eq3l"
};

/***/ }),

/***/ "Tit0":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/create.js
var create = __webpack_require__("SqZg");
var create_default = /*#__PURE__*/__webpack_require__.n(create);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/set-prototype-of.js
var set_prototype_of = __webpack_require__("TRZx");
var set_prototype_of_default = /*#__PURE__*/__webpack_require__.n(set_prototype_of);

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/setPrototypeOf.js

function _setPrototypeOf(o, p) {
  _setPrototypeOf = set_prototype_of_default.a || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}
// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/inherits.js
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _inherits; });


function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = create_default()(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

/***/ }),

/***/ "UDI0":
/***/ (function(module, exports) {

module.exports = {
	"beian": "_2OTteH9I"
};

/***/ }),

/***/ "UXZV":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("dGr4");

/***/ }),

/***/ "UeOi":
/***/ (function(module, exports, __webpack_require__) {

/* eslint-disable */
var React = __webpack_require__("cDcd");
var SpriteSymbol = __webpack_require__("QAmA");
var sprite = __webpack_require__("TQFg");

var symbol = new SpriteSymbol({
  "id": "2d_1CBT1--sprite",
  "use": "2d_1CBT1--sprite-usage",
  "viewBox": "0 0 1000.637 1000.678",
  "content": "<symbol xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 1000.637 1000.678\" id=\"2d_1CBT1--sprite\"><g fill=\"#fff\"><path d=\"M250.355 587.923h153.826c10.614 0 19.225-10.51 19.225-23.483 0-12.955-8.61-23.465-19.225-23.465H250.355c-10.621 0-19.224 10.51-19.224 23.465.001 12.973 8.603 23.483 19.224 23.483zm0-145.303h153.826c10.614 0 19.225-10.51 19.225-23.474 0-12.965-8.61-23.468-19.225-23.468H250.355c-10.621 0-19.224 10.503-19.224 23.468.001 12.964 8.603 23.474 19.224 23.474zm0-145.299h153.826c10.614 0 19.225-10.51 19.225-23.474 0-12.958-8.61-23.467-19.225-23.467H250.355c-10.621 0-19.224 10.509-19.224 23.467.001 12.964 8.603 23.474 19.224 23.474zM830.62 385.87l-192.294-76.915c-21.229 0-38.448 17.22-38.448 38.46v499.911c0 21.256 17.22 38.463 38.448 38.463H830.62c21.228 0 38.447-17.207 38.447-38.463V424.325c0-21.236-10.493-26.394-38.447-38.455zm-8.383 448.543H646.709V369.209l175.528 71.57z\" /><path d=\"M691.82 557.526h76.922c10.614 0 19.212-10.771 19.212-24.049 0-13.276-8.598-24.049-19.212-24.049H691.82c-10.614 0-19.226 10.772-19.226 24.049.001 13.278 8.612 24.049 19.226 24.049zM500.316 115.785H154.217c-21.237 0-38.456 17.213-38.456 38.455v692.191c0 21.256 17.219 38.463 38.456 38.463h346.099c21.242 0 38.461-17.207 38.461-38.463V154.24c0-21.242-17.218-38.455-38.461-38.455zM376.915 832.913H276.42V720.419h100.495zm108.05-1.5h-70.086V721.175c0-20.299-15.679-36.754-35.049-36.754H274.708c-19.358 0-35.043 16.455-35.043 36.754v110.238h-70.091V169.946h315.391zM691.82 701.851h76.922c10.614 0 19.212-10.77 19.212-24.066 0-13.279-8.598-24.049-19.212-24.049H691.82c-10.614 0-19.226 10.77-19.226 24.049.001 13.296 8.612 24.066 19.226 24.066z\" /></g></symbol>"
});
sprite.add(symbol);

var SvgSpriteIcon = function SvgSpriteIcon(props) {
  return React.createElement(
    'svg',
    Object.assign({
      viewBox: symbol.viewBox
    }, props),
    React.createElement(
      'use',
      {
        xlinkHref: '#' + symbol.id
      }
    )
  );
};

SvgSpriteIcon.viewBox = symbol.viewBox;
SvgSpriteIcon.id = symbol.id;
SvgSpriteIcon.content = symbol.content;
SvgSpriteIcon.url = symbol.url;
SvgSpriteIcon.toString = symbol.toString;

module.exports = SvgSpriteIcon;
module.exports.default = SvgSpriteIcon;


/***/ }),

/***/ "VNO/":
/***/ (function(module, exports) {

module.exports = require("rc-tween-one");

/***/ }),

/***/ "Vam4":
/***/ (function(module, exports) {

module.exports = require("rc-animate");

/***/ }),

/***/ "W0Av":
/***/ (function(module, exports) {

module.exports = require("parallax-js");

/***/ }),

/***/ "WaGi":
/***/ (function(module, exports, __webpack_require__) {

var _Object$defineProperty = __webpack_require__("hfKm");

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;

    _Object$defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

module.exports = _createClass;

/***/ }),

/***/ "Wk4r":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/set-prototype-of");

/***/ }),

/***/ "Wq/1":
/***/ (function(module, exports, __webpack_require__) {

/* eslint-disable */
var React = __webpack_require__("cDcd");
var SpriteSymbol = __webpack_require__("QAmA");
var sprite = __webpack_require__("TQFg");

var symbol = new SpriteSymbol({
  "id": "1GGCkgTz--sprite",
  "use": "1GGCkgTz--sprite-usage",
  "viewBox": "0 0 1000.637 1000.678",
  "content": "<symbol xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 1000.637 1000.678\" id=\"1GGCkgTz--sprite\"><path d=\"M500.317 179.837c-153.766 0-275.108 230.997-283.92 531.571v32.95h59.772V714.92c7.324-111.38 54.691-186.61 97.729-186.61 46.771 0 98.774 88.806 98.774 216.204h59.772c0-155.321-69.486-276.921-158.25-276.921-24.981.412-49.053 9.629-68.139 26.09 41.539-157.459 119.546-252.817 194.261-252.817 121.636 0 224.149 230.694 224.149 503.492h59.773c.002-316.589-125.072-564.521-283.921-564.521z\" /><path d=\"M186.51 759.771c0 33.704 26.758 61.029 59.773 61.029 33.009 0 59.773-27.325 59.773-61.029 0-33.702-26.764-61.028-59.773-61.028-33.014 0-59.773 27.326-59.773 61.028zm254.035 0c0 33.704 26.758 61.029 59.772 61.029 33.011 0 59.772-27.325 59.772-61.029 0-33.702-26.762-61.028-59.772-61.028-33.013 0-59.772 27.326-59.772 61.028zm254.035 0c-.02 33.704 26.725 61.049 59.734 61.069 33.02.021 59.793-27.298 59.813-61.001v-.068c0-33.702-26.766-61.028-59.775-61.028-33.008 0-59.772 27.326-59.772 61.028z\" /></symbol>"
});
sprite.add(symbol);

var SvgSpriteIcon = function SvgSpriteIcon(props) {
  return React.createElement(
    'svg',
    Object.assign({
      viewBox: symbol.viewBox
    }, props),
    React.createElement(
      'use',
      {
        xlinkHref: '#' + symbol.id
      }
    )
  );
};

SvgSpriteIcon.viewBox = symbol.viewBox;
SvgSpriteIcon.id = symbol.id;
SvgSpriteIcon.content = symbol.content;
SvgSpriteIcon.url = symbol.url;
SvgSpriteIcon.toString = symbol.toString;

module.exports = SvgSpriteIcon;
module.exports.default = SvgSpriteIcon;


/***/ }),

/***/ "XVgq":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("gHn/");

/***/ }),

/***/ "YFqc":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("cTJO")


/***/ }),

/***/ "Z4xq":
/***/ (function(module, exports, __webpack_require__) {

/* eslint-disable */
var React = __webpack_require__("cDcd");
var SpriteSymbol = __webpack_require__("QAmA");
var sprite = __webpack_require__("TQFg");

var symbol = new SpriteSymbol({
  "id": "XKKiZiT3--sprite",
  "use": "XKKiZiT3--sprite-usage",
  "viewBox": "0 0 1000.637 1000.678",
  "content": "<symbol xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 1000.637 1000.678\" id=\"XKKiZiT3--sprite\"><path d=\"M289.583 826.415h-26.51c-41.229 0-74.758-38.69-74.758-86.233V395.289c0-47.554 33.529-86.233 74.758-86.233h26.51c41.218 0 74.746 38.673 74.746 86.227v344.899c-.001 47.543-33.529 86.233-74.746 86.233zm-26.511-470.339c-17.247 0-31.261 17.575-31.261 39.189v344.917c0 21.598 14.014 39.194 31.261 39.194h26.51c17.222 0 31.248-17.597 31.248-39.194V395.289c0-21.62-14.037-39.195-31.248-39.195zm250.574 470.339h-26.465c-41.192 0-74.699-38.69-74.699-86.233V489.339c0-47.555 33.506-86.226 74.699-86.226h26.465c41.203 0 74.684 38.671 74.684 86.226v250.856c0 47.53-33.492 86.22-74.684 86.22zm-26.465-376.272c-17.223 0-31.225 17.576-31.225 39.196v250.856c0 21.595 14.002 39.195 31.225 39.195h26.465c17.221 0 31.232-17.601 31.232-39.195V489.339c0-21.621-14.012-39.196-31.232-39.196zM737.73 826.415h-26.451c-41.123 0-74.582-38.69-74.582-86.233V238.49c0-47.554 33.459-86.227 74.582-86.227h26.451c41.135 0 74.592 38.673 74.592 86.227v501.692c0 47.543-33.457 86.233-74.592 86.233zm-26.451-627.12c-17.188 0-31.178 17.575-31.178 39.195v501.692c0 21.598 13.99 39.194 31.178 39.194h26.451c17.188 0 31.178-17.597 31.178-39.194V238.49c0-21.62-13.979-39.195-31.178-39.195z\" /></symbol>"
});
sprite.add(symbol);

var SvgSpriteIcon = function SvgSpriteIcon(props) {
  return React.createElement(
    'svg',
    Object.assign({
      viewBox: symbol.viewBox
    }, props),
    React.createElement(
      'use',
      {
        xlinkHref: '#' + symbol.id
      }
    )
  );
};

SvgSpriteIcon.viewBox = symbol.viewBox;
SvgSpriteIcon.id = symbol.id;
SvgSpriteIcon.content = symbol.content;
SvgSpriteIcon.url = symbol.url;
SvgSpriteIcon.toString = symbol.toString;

module.exports = SvgSpriteIcon;
module.exports.default = SvgSpriteIcon;


/***/ }),

/***/ "Z6Kq":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/get-own-property-descriptor");

/***/ }),

/***/ "Z7t5":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("vqFK");

/***/ }),

/***/ "ZDA2":
/***/ (function(module, exports, __webpack_require__) {

var _typeof = __webpack_require__("iZP3");

var assertThisInitialized = __webpack_require__("K47E");

function _possibleConstructorReturn(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return assertThisInitialized(self);
}

module.exports = _possibleConstructorReturn;

/***/ }),

/***/ "Zom5":
/***/ (function(module, exports, __webpack_require__) {

/* eslint-disable */
var React = __webpack_require__("cDcd");
var SpriteSymbol = __webpack_require__("QAmA");
var sprite = __webpack_require__("TQFg");

var symbol = new SpriteSymbol({
  "id": "I-tRJLaQ--sprite",
  "use": "I-tRJLaQ--sprite-usage",
  "viewBox": "0 0 1000.637 1000.678",
  "content": "<symbol xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 1000.637 1000.678\" id=\"I-tRJLaQ--sprite\"><path d=\"M499.299 904.139c-22.194 0-46.421-10.097-64.604-28.266L121.769 566.957c-34.337-36.341-34.337-94.889 0-131.232L438.73 122.786c16.152-16.138 38.374-26.247 60.568-26.247 22.225 0 46.45 10.108 64.606 28.266l314.973 308.916c34.323 36.342 34.323 94.891 0 131.231l-319.009 312.94c-14.119 16.15-38.345 26.247-60.569 26.247zm1.016-759.889c-13.702 0-25.444 5.87-33.262 15.665L159.883 463.16c-17.612 21.535-17.612 52.837 0 74.358l307.17 303.258c7.832 9.781 19.56 15.651 33.262 15.651 13.703 0 25.432-5.87 33.264-15.651l307.169-301.311c17.611-21.508 17.611-52.823 0-74.343L533.579 159.916c-7.817-9.795-19.56-15.666-33.264-15.666zm0 507.517c-84.797 0-151.421-68.656-151.421-151.433 0-82.767 68.644-151.411 151.421-151.411 84.798 0 151.422 68.645 151.422 151.411 0 82.776-66.624 151.433-151.422 151.433zm0-250.635c-54.911 0-99.216 44.286-99.216 99.202 0 54.925 44.305 99.212 99.216 99.212 54.912 0 99.217-44.287 99.217-99.212 0-54.916-44.304-99.202-99.217-99.202z\" /></symbol>"
});
sprite.add(symbol);

var SvgSpriteIcon = function SvgSpriteIcon(props) {
  return React.createElement(
    'svg',
    Object.assign({
      viewBox: symbol.viewBox
    }, props),
    React.createElement(
      'use',
      {
        xlinkHref: '#' + symbol.id
      }
    )
  );
};

SvgSpriteIcon.viewBox = symbol.viewBox;
SvgSpriteIcon.id = symbol.id;
SvgSpriteIcon.content = symbol.content;
SvgSpriteIcon.url = symbol.url;
SvgSpriteIcon.toString = symbol.toString;

module.exports = SvgSpriteIcon;
module.exports.default = SvgSpriteIcon;


/***/ }),

/***/ "a7VT":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _getPrototypeOf; });
/* harmony import */ var _core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("Bhuq");
/* harmony import */ var _core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("TRZx");
/* harmony import */ var _core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_1__);


function _getPrototypeOf(o) {
  _getPrototypeOf = _core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_1___default.a ? _core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0___default.a : function _getPrototypeOf(o) {
    return o.__proto__ || _core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0___default()(o);
  };
  return _getPrototypeOf(o);
}

/***/ }),

/***/ "aC71":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/promise");

/***/ }),

/***/ "auXZ":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("kOwS");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("qNsG");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("0iUn");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("sLSF");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("MI3g");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("a7VT");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("Tit0");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__("K2gz");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _components_SvgIcon__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__("BE5S");
/* harmony import */ var _components_Parallax__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__("IMUT");
/* harmony import */ var _components_Parallax_Paper__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__("QncY");
/* harmony import */ var _assets_images_app_banner_3_banner_3_jpg__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__("+d49");
/* harmony import */ var _assets_images_app_banner_3_banner_3_jpg__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_assets_images_app_banner_3_banner_3_jpg__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _assets_images_app_banner_3_svg_1_svg_sprite__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__("2bz7");
/* harmony import */ var _assets_images_app_banner_3_svg_1_svg_sprite__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_assets_images_app_banner_3_svg_1_svg_sprite__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _assets_images_app_banner_3_svg_2_svg_sprite__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__("Z4xq");
/* harmony import */ var _assets_images_app_banner_3_svg_2_svg_sprite__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_assets_images_app_banner_3_svg_2_svg_sprite__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _assets_images_app_banner_3_svg_3_svg_sprite__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__("5dF4");
/* harmony import */ var _assets_images_app_banner_3_svg_3_svg_sprite__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_assets_images_app_banner_3_svg_3_svg_sprite__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _parallax_less__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__("za0J");
/* harmony import */ var _parallax_less__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_parallax_less__WEBPACK_IMPORTED_MODULE_16__);







 // import Link from 'next/link';










var options = {
  // selector: '.paper',
  // relativeInput: true
  // clipRelativeInput: true,
  // scalarX: 10,
  // scalarY: 10,
  limitX: 30,
  limitY: 30 // frictionX: 0.1,
  // frictionY: 0.1

};

var WallPaper =
/*#__PURE__*/
function (_React$Component) {
  Object(_babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_6__[/* default */ "a"])(WallPaper, _React$Component);

  function WallPaper() {
    Object(_babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_2__[/* default */ "a"])(this, WallPaper);

    return Object(_babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__[/* default */ "a"])(this, Object(_babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"])(WallPaper).apply(this, arguments));
  }

  Object(_babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"])(WallPaper, [{
    key: "render",
    value: function render() {
      var _this$props = this.props,
          className = _this$props.className,
          props = Object(_babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(_this$props, ["className"]);

      return react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_components_Parallax__WEBPACK_IMPORTED_MODULE_10__[/* default */ "a"], Object(_babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])({}, props, {
        className: classnames__WEBPACK_IMPORTED_MODULE_8___default()(_parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.scene, className),
        options: options
      }), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_components_Parallax_Paper__WEBPACK_IMPORTED_MODULE_11__[/* default */ "a"], {
        depth: 0.2
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.paperBackground,
        style: {
          backgroundImage: "url(".concat(_assets_images_app_banner_3_banner_3_jpg__WEBPACK_IMPORTED_MODULE_12___default.a, ")")
        }
      })), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.leftContent
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_8___default()(_parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.topic, 'AppSiYuan')
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("h1", {
        className: classnames__WEBPACK_IMPORTED_MODULE_8___default()(_parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.topicTitle, 'AppSiYuan')
      }, "\u6570\u636E\u4E2D\u5FC3"), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("p", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.topicDesc
      }, "\u5145\u5206\u5229\u7528\u4E91\u8BA1\u7B97\u548C\u5927\u6570\u636E\u6280\u672F\uFF0C\u9002\u914D\u5404\u4E2A\u884C\u4E1A\u9700\u6C42\uFF0C\u4E3A\u5BA2\u6237\u63D0\u4F9B\u6258\u7BA1\u4E91\u3001\u6DF7\u5408\u4E91\u7B49\u573A\u666F\u4E0B\u7684\u89E3\u51B3\u65B9\u6848\uFF0C\u5B9E\u73B0\u4E1A\u52A1\u5168\u9762\u4E91\u5316\uFF0C\u63A8\u8FDB\u884C\u4E1A\u6570\u5B57\u5316\u8F6C\u578B\u3002"), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.topicExtend
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.topicIcon
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_components_SvgIcon__WEBPACK_IMPORTED_MODULE_9__[/* default */ "a"], {
        icon: _assets_images_app_banner_3_svg_1_svg_sprite__WEBPACK_IMPORTED_MODULE_13___default.a
      }), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.topicLabel
      }, "\u6781\u81F4\u6027\u80FD")), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.topicIcon
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_components_SvgIcon__WEBPACK_IMPORTED_MODULE_9__[/* default */ "a"], {
        icon: _assets_images_app_banner_3_svg_2_svg_sprite__WEBPACK_IMPORTED_MODULE_14___default.a
      }), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.topicLabel
      }, "\u667A\u80FD\u5206\u6790")), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.topicIcon
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_components_SvgIcon__WEBPACK_IMPORTED_MODULE_9__[/* default */ "a"], {
        icon: _assets_images_app_banner_3_svg_3_svg_sprite__WEBPACK_IMPORTED_MODULE_15___default.a
      }), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_16___default.a.topicLabel
      }, "\u8282\u80FD\u73AF\u4FDD"))))));
    }
  }]);

  return WallPaper;
}(react__WEBPACK_IMPORTED_MODULE_7___default.a.Component);

/* harmony default export */ __webpack_exports__["default"] = (WallPaper);

/***/ }),

/***/ "bKMw":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("kOwS");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("qNsG");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("0iUn");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("sLSF");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("MI3g");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("a7VT");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("Tit0");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__("YFqc");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__("K2gz");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _components_SvgIcon__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__("BE5S");
/* harmony import */ var _components_Parallax__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__("IMUT");
/* harmony import */ var _components_Parallax_Paper__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__("QncY");
/* harmony import */ var _assets_images_app_banner_4_banner_4_jpg__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__("sNF/");
/* harmony import */ var _assets_images_app_banner_4_banner_4_jpg__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_assets_images_app_banner_4_banner_4_jpg__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _assets_images_app_banner_4_svg_1_svg_sprite__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__("p+Sj");
/* harmony import */ var _assets_images_app_banner_4_svg_1_svg_sprite__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_assets_images_app_banner_4_svg_1_svg_sprite__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _assets_images_app_banner_4_svg_2_svg_sprite__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__("SLvO");
/* harmony import */ var _assets_images_app_banner_4_svg_2_svg_sprite__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_assets_images_app_banner_4_svg_2_svg_sprite__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _assets_images_app_banner_4_svg_3_svg_sprite__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__("S3+N");
/* harmony import */ var _assets_images_app_banner_4_svg_3_svg_sprite__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_assets_images_app_banner_4_svg_3_svg_sprite__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _parallax_less__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__("za0J");
/* harmony import */ var _parallax_less__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(_parallax_less__WEBPACK_IMPORTED_MODULE_17__);


















var options = {
  // selector: '.paper',
  // relativeInput: true
  // clipRelativeInput: true,
  // scalarX: 10,
  // scalarY: 10,
  limitX: 30,
  limitY: 30 // frictionX: 0.1,
  // frictionY: 0.1

};

var WallPaper =
/*#__PURE__*/
function (_React$Component) {
  Object(_babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_6__[/* default */ "a"])(WallPaper, _React$Component);

  function WallPaper() {
    Object(_babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_2__[/* default */ "a"])(this, WallPaper);

    return Object(_babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__[/* default */ "a"])(this, Object(_babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"])(WallPaper).apply(this, arguments));
  }

  Object(_babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"])(WallPaper, [{
    key: "render",
    value: function render() {
      var _this$props = this.props,
          className = _this$props.className,
          props = Object(_babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(_this$props, ["className"]);

      return react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_components_Parallax__WEBPACK_IMPORTED_MODULE_11__[/* default */ "a"], Object(_babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])({}, props, {
        className: classnames__WEBPACK_IMPORTED_MODULE_9___default()(_parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.scene, className),
        options: options
      }), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_components_Parallax_Paper__WEBPACK_IMPORTED_MODULE_12__[/* default */ "a"], {
        depth: 0.2
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.paperBackground,
        style: {
          backgroundImage: "url(".concat(_assets_images_app_banner_4_banner_4_jpg__WEBPACK_IMPORTED_MODULE_13___default.a, ")")
        }
      })), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.leftContent
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_9___default()(_parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.topic, 'AppSiYuan')
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("h1", {
        className: classnames__WEBPACK_IMPORTED_MODULE_9___default()(_parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.topicTitle, 'AppSiYuan')
      }, "\u667A\u6167\u5E94\u7528"), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("p", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.topicDesc
      }, "\u56F4\u7ED5\u6838\u5FC3\u529F\u80FD\uFF0C\u5206\u7C7B\u6784\u5EFA\u529F\u80FD\u5E94\u7528\u4F53\u7CFB\uFF0C\u6D89\u53CA\u591A\u4E2A\u4E1A\u52A1\u9886\u57DF\uFF0C\u4E3A\u7528\u6237\u5E26\u6765\u7EDF\u4E00\u9AD8\u6548\u7684\u7BA1\u7406\u3002"), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.topicExtend
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.topicIcon
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_components_SvgIcon__WEBPACK_IMPORTED_MODULE_10__[/* default */ "a"], {
        icon: _assets_images_app_banner_4_svg_1_svg_sprite__WEBPACK_IMPORTED_MODULE_14___default.a
      }), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.topicLabel
      }, "\u516C\u4E91\u670D\u52A1")), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.topicIcon
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_components_SvgIcon__WEBPACK_IMPORTED_MODULE_10__[/* default */ "a"], {
        icon: _assets_images_app_banner_4_svg_2_svg_sprite__WEBPACK_IMPORTED_MODULE_15___default.a
      }), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.topicLabel
      }, "\u7B80\u5355\u5B89\u5168")), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.topicIcon
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_components_SvgIcon__WEBPACK_IMPORTED_MODULE_10__[/* default */ "a"], {
        icon: _assets_images_app_banner_4_svg_3_svg_sprite__WEBPACK_IMPORTED_MODULE_16___default.a
      }), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.topicLabel
      }, "\u7EDF\u4E00\u9AD8\u6548"))), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.topicAction
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(next_link__WEBPACK_IMPORTED_MODULE_8___default.a, {
        as: "/store",
        href: "/store"
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("a", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.topicButton
      }, "\u4E86\u89E3\u66F4\u591A"))))));
    }
  }]);

  return WallPaper;
}(react__WEBPACK_IMPORTED_MODULE_7___default.a.Component);

/* harmony default export */ __webpack_exports__["default"] = (WallPaper);

/***/ }),

/***/ "bPsq":
/***/ (function(module, exports) {

module.exports = require("less-vars-to-js");

/***/ }),

/***/ "bzos":
/***/ (function(module, exports) {

module.exports = require("url");

/***/ }),

/***/ "cDcd":
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "cTJO":
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/* global __NEXT_DATA__ */

var _interopRequireDefault = __webpack_require__("KI45");

var _stringify = _interopRequireDefault(__webpack_require__("9Jkg"));

var _classCallCheck2 = _interopRequireDefault(__webpack_require__("/HRN"));

var _createClass2 = _interopRequireDefault(__webpack_require__("WaGi"));

var _possibleConstructorReturn2 = _interopRequireDefault(__webpack_require__("ZDA2"));

var _getPrototypeOf2 = _interopRequireDefault(__webpack_require__("/+P4"));

var _inherits2 = _interopRequireDefault(__webpack_require__("N9n2"));

var __importStar = void 0 && (void 0).__importStar || function (mod) {
  if (mod && mod.__esModule) return mod;
  var result = {};
  if (mod != null) for (var k in mod) {
    if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
  }
  result["default"] = mod;
  return result;
};

var __importDefault = void 0 && (void 0).__importDefault || function (mod) {
  return mod && mod.__esModule ? mod : {
    "default": mod
  };
};

Object.defineProperty(exports, "__esModule", {
  value: true
});

var url_1 = __webpack_require__("bzos");

var react_1 = __importStar(__webpack_require__("cDcd"));

var prop_types_1 = __importDefault(__webpack_require__("rf6O"));

var router_1 = __importStar(__webpack_require__("4Q3z"));

var utils_1 = __webpack_require__("p8BD");

function isLocal(href) {
  var url = url_1.parse(href, false, true);
  var origin = url_1.parse(utils_1.getLocationOrigin(), false, true);
  return !url.host || url.protocol === origin.protocol && url.host === origin.host;
}

function memoizedFormatUrl(formatFunc) {
  var lastHref = null;
  var lastAs = null;
  var lastResult = null;
  return function (href, as) {
    if (href === lastHref && as === lastAs) {
      return lastResult;
    }

    var result = formatFunc(href, as);
    lastHref = href;
    lastAs = as;
    lastResult = result;
    return result;
  };
}

function formatUrl(url) {
  return url && typeof url === 'object' ? utils_1.formatWithValidation(url) : url;
}

var Link =
/*#__PURE__*/
function (_react_1$Component) {
  (0, _inherits2.default)(Link, _react_1$Component);

  function Link() {
    var _this;

    (0, _classCallCheck2.default)(this, Link);
    _this = (0, _possibleConstructorReturn2.default)(this, (0, _getPrototypeOf2.default)(Link).apply(this, arguments)); // The function is memoized so that no extra lifecycles are needed
    // as per https://reactjs.org/blog/2018/06/07/you-probably-dont-need-derived-state.html

    _this.formatUrls = memoizedFormatUrl(function (href, asHref) {
      return {
        href: formatUrl(href),
        as: formatUrl(asHref, true)
      };
    });

    _this.linkClicked = function (e) {
      var _e$currentTarget = e.currentTarget,
          nodeName = _e$currentTarget.nodeName,
          target = _e$currentTarget.target;

      if (nodeName === 'A' && (target && target !== '_self' || e.metaKey || e.ctrlKey || e.shiftKey || e.nativeEvent && e.nativeEvent.which === 2)) {
        // ignore click for new tab / new window behavior
        return;
      }

      var _this$formatUrls = _this.formatUrls(_this.props.href, _this.props.as),
          href = _this$formatUrls.href,
          as = _this$formatUrls.as;

      if (!isLocal(href)) {
        // ignore click if it's outside our scope
        return;
      }

      var pathname = window.location.pathname;
      href = url_1.resolve(pathname, href);
      as = as ? url_1.resolve(pathname, as) : href;
      e.preventDefault(); //  avoid scroll for urls with anchor refs

      var scroll = _this.props.scroll;

      if (scroll == null) {
        scroll = as.indexOf('#') < 0;
      } // replace state instead of push if prop is present


      router_1.default[_this.props.replace ? 'replace' : 'push'](href, as, {
        shallow: _this.props.shallow
      }).then(function (success) {
        if (!success) return;

        if (scroll) {
          window.scrollTo(0, 0);
          document.body.focus();
        }
      }).catch(function (err) {
        if (_this.props.onError) _this.props.onError(err);
      });
    };

    return _this;
  }

  (0, _createClass2.default)(Link, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      this.prefetch();
    }
  }, {
    key: "componentDidUpdate",
    value: function componentDidUpdate(prevProps) {
      if ((0, _stringify.default)(this.props.href) !== (0, _stringify.default)(prevProps.href)) {
        this.prefetch();
      }
    }
  }, {
    key: "prefetch",
    value: function prefetch() {
      if (!this.props.prefetch) return;
      if (typeof window === 'undefined') return; // Prefetch the JSON page if asked (only in the client)

      var pathname = window.location.pathname;

      var _this$formatUrls2 = this.formatUrls(this.props.href, this.props.as),
          parsedHref = _this$formatUrls2.href;

      var href = url_1.resolve(pathname, parsedHref);
      router_1.default.prefetch(href);
    }
  }, {
    key: "render",
    value: function render() {
      var _this2 = this;

      var children = this.props.children;

      var _this$formatUrls3 = this.formatUrls(this.props.href, this.props.as),
          href = _this$formatUrls3.href,
          as = _this$formatUrls3.as; // Deprecated. Warning shown by propType check. If the childen provided is a string (<Link>example</Link>) we wrap it in an <a> tag


      if (typeof children === 'string') {
        children = react_1.default.createElement("a", null, children);
      } // This will return the first child, if multiple are provided it will throw an error


      var child = react_1.Children.only(children);
      var props = {
        onClick: function onClick(e) {
          if (child.props && typeof child.props.onClick === 'function') {
            child.props.onClick(e);
          }

          if (!e.defaultPrevented) {
            _this2.linkClicked(e);
          }
        }
      }; // If child is an <a> tag and doesn't have a href attribute, or if the 'passHref' property is
      // defined, we specify the current 'href', so that repetition is not needed by the user

      if (this.props.passHref || child.type === 'a' && !('href' in child.props)) {
        props.href = as || href;
      } // Add the ending slash to the paths. So, we can serve the
      // "<page>/index.html" directly.


      if (true) {
        if (props.href && typeof __NEXT_DATA__ !== 'undefined' && __NEXT_DATA__.nextExport) {
          props.href = router_1.Router._rewriteUrlForNextExport(props.href);
        }
      }

      return react_1.default.cloneElement(child, props);
    }
  }]);
  return Link;
}(react_1.Component);

if (false) { var exact, warn; }

exports.default = Link;

/***/ }),

/***/ "cu1A":
/***/ (function(module, exports) {

module.exports = require("regenerator-runtime");

/***/ }),

/***/ "dGr4":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/assign");

/***/ }),

/***/ "dfL4":
/***/ (function(module, exports, __webpack_require__) {

/* eslint-disable */
var React = __webpack_require__("cDcd");
var SpriteSymbol = __webpack_require__("QAmA");
var sprite = __webpack_require__("TQFg");

var symbol = new SpriteSymbol({
  "id": "GQZgh5xn--sprite",
  "use": "GQZgh5xn--sprite-usage",
  "viewBox": "0 0 1000.637 1000.678",
  "content": "<symbol xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 1000.637 1000.678\" id=\"GQZgh5xn--sprite\"><path d=\"M843.592 475.709h57.23v297.108c.363 10.611-12.115 19.428-27.918 19.684-15.801.257-28.916-8.136-29.313-18.746V475.709zm-114.358 0h57.197V821.48c.393 10.61-12.121 19.415-27.92 19.683-15.801.246-28.916-8.137-29.277-18.746a3.767 3.767 0 0 1 0-.937zm-114.494 0h57.215v273.147c.377 10.608-12.121 19.414-27.902 19.671-15.803.256-28.932-8.137-29.313-18.748v-.923zm-114.426 0h57.211v175.287c.383 10.611-12.115 19.416-27.914 19.685-15.805.246-28.916-8.137-29.297-18.747v-.938zm-371.894-316.2c15.8 0 28.615 8.604 28.615 19.214v296.999H99.807V178.724c0-10.611 12.812-19.215 28.613-19.215zm228.868 194.536c15.801 0 28.614 8.604 28.614 19.214v102.45h-57.229V373.26c-.019-10.599 12.78-19.204 28.583-19.214l.032-.001zm-114.441-60.822c15.799-.01 28.614 8.594 28.614 19.193v163.293h-57.23V312.427c-.001-10.61 12.814-19.204 28.616-19.204zm228.87-12.048c15.799 0 28.613 8.604 28.613 19.215v175.298h-57.229V300.39c0-10.611 12.815-19.215 28.616-19.215z\" /></symbol>"
});
sprite.add(symbol);

var SvgSpriteIcon = function SvgSpriteIcon(props) {
  return React.createElement(
    'svg',
    Object.assign({
      viewBox: symbol.viewBox
    }, props),
    React.createElement(
      'use',
      {
        xlinkHref: '#' + symbol.id
      }
    )
  );
};

SvgSpriteIcon.viewBox = symbol.viewBox;
SvgSpriteIcon.id = symbol.id;
SvgSpriteIcon.content = symbol.content;
SvgSpriteIcon.url = symbol.url;
SvgSpriteIcon.toString = symbol.toString;

module.exports = SvgSpriteIcon;
module.exports.default = SvgSpriteIcon;


/***/ }),

/***/ "dxtb":
/***/ (function(module, exports) {

module.exports = "/_next/static/images/banner-5-03cc9e14c5b942f28e7e5382a32d6355.jpg";

/***/ }),

/***/ "eVuF":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("aC71");

/***/ }),

/***/ "fFR6":
/***/ (function(module, exports, __webpack_require__) {

/* eslint-disable */
var React = __webpack_require__("cDcd");
var SpriteSymbol = __webpack_require__("QAmA");
var sprite = __webpack_require__("TQFg");

var symbol = new SpriteSymbol({
  "id": "3nTrrqn---sprite",
  "use": "3nTrrqn---sprite-usage",
  "viewBox": "0 0 1000.637 1000.678",
  "content": "<symbol xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 1000.637 1000.678\" id=\"3nTrrqn---sprite\"><g fill=\"#fff\"><path d=\"M514.52 590.495c-11.045 5.683-21.696 5.683-32.741 0L116.063 394.75l366.11-196.139c11.045-5.688 21.697-5.688 32.738 0L886.549 394.35zm190.939 153.096c0 5.682-3.539 9.347-9.06 11.365l-136.107 42.648c-41.821 12.992-85.22 12.992-127.042 0l-125.453-41.023c-3.549-3.644-7.1-7.309-7.1-12.99V549.484l159.378 84.061c12.626 5.685 25.251 9.327 37.877 9.327 12.625 0 25.247-3.643 37.878-9.327l170.818-89.755zm231.583-375.236L534.641 155.56c-23.673-12.991-52.468-12.991-76.139 0L63.201 368.355c-10.65 5.688-16.176 15.024-16.176 26.394 0 11.376 5.526 22.339 16.176 25.587l37.872 22.333v199.8c-14.597 9.338-25.247 24.366-25.247 43.053 0 28.02 21.696 50.348 48.918 50.348s48.918-21.928 48.918-49.947c0-18.673-11.047-35.331-25.247-43.051V467.036l105.335 56.042V743.18c0 26.002 16.176 50.357 41.817 57.668l125.062 41.021c25.247 7.308 52.468 12.992 79.69 12.992 25.251 0 50.893-3.655 76.144-11.376l134.138-43.039c25.241-7.309 41.811-31.677 41.811-57.669V519.425l185.021-97.054c11.062-5.688 16.181-15.031 16.181-25.995-.401-12.996-5.922-23.96-16.572-28.021z\" /><path d=\"M264.401 422.371c-5.525 0-12.625-3.655-16.177-9.343-5.52-9.343-1.968-20.712 7.1-25.992l88.765-52.383c9.077-5.688 20.122-2.033 25.253 7.308 5.52 9.337 1.969 20.713-7.102 25.989l-88.765 52.387c-3.548-.001-5.525 2.034-9.074 2.034z\" /></g></symbol>"
});
sprite.add(symbol);

var SvgSpriteIcon = function SvgSpriteIcon(props) {
  return React.createElement(
    'svg',
    Object.assign({
      viewBox: symbol.viewBox
    }, props),
    React.createElement(
      'use',
      {
        xlinkHref: '#' + symbol.id
      }
    )
  );
};

SvgSpriteIcon.viewBox = symbol.viewBox;
SvgSpriteIcon.id = symbol.id;
SvgSpriteIcon.content = symbol.content;
SvgSpriteIcon.url = symbol.url;
SvgSpriteIcon.toString = symbol.toString;

module.exports = SvgSpriteIcon;
module.exports.default = SvgSpriteIcon;


/***/ }),

/***/ "flPq":
/***/ (function(module, exports) {

module.exports = {
	"svg-icon": "_39UYRa5H",
	"svgIcon": "_39UYRa5H"
};

/***/ }),

/***/ "fozc":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/json/stringify");

/***/ }),

/***/ "gHn/":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/symbol/iterator");

/***/ }),

/***/ "hain":
/***/ (function(module, exports, __webpack_require__) {

/* eslint-disable */
var React = __webpack_require__("cDcd");
var SpriteSymbol = __webpack_require__("QAmA");
var sprite = __webpack_require__("TQFg");

var symbol = new SpriteSymbol({
  "id": "_O0qsoc3--sprite",
  "use": "_O0qsoc3--sprite-usage",
  "viewBox": "0 0 1000.637 1000.678",
  "content": "<symbol xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 1000.637 1000.678\" id=\"_O0qsoc3--sprite\"><path d=\"M296.098 523.078v243.677c0 18.313.803 29.993 2.417 35.046 1.61 5.055 4.978 9.194 10.107 12.415 5.126 3.224 13.328 4.834 24.609 4.834h6.812v8.13H183.159v-8.13h7.91c12.744 0 21.825-1.463 27.246-4.395 5.417-2.929 9.081-6.956 10.986-12.085 1.902-5.126 2.856-17.063 2.856-35.815V612.287c0-13.768-.659-22.374-1.978-25.818-1.318-3.439-3.773-6.371-7.361-8.789-3.591-2.416-7.728-3.625-12.415-3.625-7.471 0-16.555 2.345-27.246 7.031l-3.955-7.91 109.644-50.098zM560.869 827.18H385.527v-4.834c53.757-64.013 86.387-107.079 97.888-129.199 11.498-22.117 17.249-43.726 17.249-64.819 0-15.381-4.762-28.159-14.282-38.343-9.524-10.179-21.169-15.271-34.937-15.271-22.56 0-40.066 11.281-52.515 33.838l-8.13-2.856c7.91-28.125 19.919-48.924 36.035-62.402 16.112-13.476 34.717-20.215 55.811-20.215 15.085 0 28.856 3.516 41.309 10.547 12.448 7.031 22.191 16.665 29.223 28.895 7.031 12.232 10.547 23.695 10.547 34.387 0 19.483-5.42 39.259-16.26 59.326-14.797 27.102-47.097 64.895-96.899 113.379h64.379c15.82 0 26.11-.659 30.872-1.978 4.759-1.318 8.679-3.55 11.755-6.702 3.076-3.147 7.104-9.777 12.086-19.885h7.91zm185.229-304.102v243.677c0 18.313.804 29.993 2.418 35.046 1.609 5.055 4.978 9.194 10.107 12.415 5.125 3.224 13.327 4.834 24.609 4.834h6.811v8.13H633.158v-8.13h7.91c12.744 0 21.826-1.463 27.246-4.395 5.418-2.929 9.082-6.956 10.986-12.085 1.902-5.126 2.857-17.063 2.857-35.815V612.287c0-13.768-.66-22.374-1.979-25.818-1.318-3.439-3.772-6.371-7.36-8.789-3.591-2.416-7.728-3.625-12.415-3.625-7.471 0-16.555 2.345-27.246 7.031l-3.955-7.91 109.645-50.098zM433.427 115.751v80.64h-7.91c-4.69-18.602-9.888-31.97-15.601-40.101-5.713-8.129-13.551-14.611-23.511-19.445-5.569-2.637-15.309-3.955-29.224-3.955H334.99v229.834c0 15.236.841 24.757 2.527 28.564 1.682 3.811 4.978 7.141 9.888 9.998 4.906 2.855 11.608 4.284 20.105 4.284h9.888v8.13H221.391v-8.13h9.888c8.642 0 15.601-1.538 20.874-4.614 3.808-2.05 6.812-5.565 9.009-10.547 1.61-3.516 2.417-12.744 2.417-27.686V132.89h-21.533c-20.071 0-34.645 4.25-43.726 12.744-12.744 11.865-20.802 28.784-24.17 50.757h-8.35v-80.64zm326.733-6.811v105.029h-8.129c-9.816-28.709-24.537-50.537-44.166-65.479-19.631-14.941-41.088-22.412-64.379-22.412-22.269 0-40.797 6.263-55.592 18.786-14.797 12.525-25.268 29.993-31.42 52.405s-9.229 45.411-9.229 68.994c0 28.564 3.367 53.613 10.107 75.146 6.735 21.533 17.611 37.354 32.629 47.461 15.014 10.107 32.85 15.161 53.504 15.161 7.175 0 14.535-.77 22.082-2.307 7.543-1.539 15.271-3.771 23.182-6.702v-61.963c0-11.718-.807-19.298-2.418-22.741-1.613-3.44-4.943-6.555-9.997-9.339-5.054-2.781-11.172-4.175-18.347-4.175h-7.691v-8.13h144.801v8.13c-10.986.734-18.643 2.235-22.962 4.504-4.322 2.273-7.656 6.043-9.997 11.316-1.318 2.784-1.979 9.596-1.979 20.435v61.963c-19.043 8.497-38.857 14.907-59.436 19.226-20.582 4.319-41.934 6.482-64.051 6.482-28.271 0-51.745-3.846-70.422-11.535-18.677-7.691-35.156-17.799-49.438-30.322-14.282-12.525-25.454-26.622-33.508-42.298-10.255-20.215-15.381-42.847-15.381-67.896 0-44.824 15.745-82.689 47.242-113.599 31.492-30.906 71.115-46.362 118.871-46.362 14.795 0 28.125 1.174 39.99 3.516 6.445 1.174 16.882 4.504 31.312 9.998 14.427 5.493 22.962 8.24 25.599 8.24 4.099 0 7.91-1.5 11.426-4.504 3.516-3 6.735-8.679 9.668-17.029h8.129z\" /></symbol>"
});
sprite.add(symbol);

var SvgSpriteIcon = function SvgSpriteIcon(props) {
  return React.createElement(
    'svg',
    Object.assign({
      viewBox: symbol.viewBox
    }, props),
    React.createElement(
      'use',
      {
        xlinkHref: '#' + symbol.id
      }
    )
  );
};

SvgSpriteIcon.viewBox = symbol.viewBox;
SvgSpriteIcon.id = symbol.id;
SvgSpriteIcon.content = symbol.content;
SvgSpriteIcon.url = symbol.url;
SvgSpriteIcon.toString = symbol.toString;

module.exports = SvgSpriteIcon;
module.exports.default = SvgSpriteIcon;


/***/ }),

/***/ "hfKm":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("TUA0");

/***/ }),

/***/ "hnuN":
/***/ (function(module, exports) {

module.exports = "/_next/static/images/banner-2-85379310c8a6bd96273b5d40e4088984.jpg";

/***/ }),

/***/ "iZP3":
/***/ (function(module, exports, __webpack_require__) {

var _Symbol$iterator = __webpack_require__("XVgq");

var _Symbol = __webpack_require__("Z7t5");

function _typeof2(obj) { if (typeof _Symbol === "function" && typeof _Symbol$iterator === "symbol") { _typeof2 = function _typeof2(obj) { return typeof obj; }; } else { _typeof2 = function _typeof2(obj) { return obj && typeof _Symbol === "function" && obj.constructor === _Symbol && obj !== _Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof2(obj); }

function _typeof(obj) {
  if (typeof _Symbol === "function" && _typeof2(_Symbol$iterator) === "symbol") {
    module.exports = _typeof = function _typeof(obj) {
      return _typeof2(obj);
    };
  } else {
    module.exports = _typeof = function _typeof(obj) {
      return obj && typeof _Symbol === "function" && obj.constructor === _Symbol && obj !== _Symbol.prototype ? "symbol" : _typeof2(obj);
    };
  }

  return _typeof(obj);
}

module.exports = _typeof;

/***/ }),

/***/ "jfTJ":
/***/ (function(module, exports, __webpack_require__) {

/* eslint-disable */
var React = __webpack_require__("cDcd");
var SpriteSymbol = __webpack_require__("QAmA");
var sprite = __webpack_require__("TQFg");

var symbol = new SpriteSymbol({
  "id": "2BWLqXP4--sprite",
  "use": "2BWLqXP4--sprite-usage",
  "viewBox": "0 0 1000.637 1000.678",
  "content": "<symbol xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 1000.637 1000.678\" id=\"2BWLqXP4--sprite\"><path d=\"M517.371 125.01c-9.408-8.956-24.697-8.956-34.105 0-12.355 11.73-302.786 289.813-302.786 452.894 0 167.868 143.479 304.48 319.838 304.48 176.36 0 319.838-136.612 319.838-304.48 0-163.081-290.429-441.164-302.785-452.894zm-17.053 711.375c-149.731 0-271.528-115.921-271.528-258.48 0-111.911 182.306-315.516 271.528-403.808 89.223 88.374 271.53 291.897 271.53 403.808 0 142.559-121.797 258.48-271.53 258.48zm185.311-270.446c-13.273-1.531-25.238 7.654-26.699 20.232-8.643 72.546-61.746 132.82-135.387 153.5-12.814 3.64-20.068 16.37-16.277 28.571 3.086 10.033 12.732 16.512 23.154 16.512 2.238 0 4.547-.307 6.867-.92 92.154-25.932 158.764-101.492 169.646-192.423 1.46-12.659-8.031-24.001-21.304-25.472z\" fill=\"#fff\" /></symbol>"
});
sprite.add(symbol);

var SvgSpriteIcon = function SvgSpriteIcon(props) {
  return React.createElement(
    'svg',
    Object.assign({
      viewBox: symbol.viewBox
    }, props),
    React.createElement(
      'use',
      {
        xlinkHref: '#' + symbol.id
      }
    )
  );
};

SvgSpriteIcon.viewBox = symbol.viewBox;
SvgSpriteIcon.id = symbol.id;
SvgSpriteIcon.content = symbol.content;
SvgSpriteIcon.url = symbol.url;
SvgSpriteIcon.toString = symbol.toString;

module.exports = SvgSpriteIcon;
module.exports.default = SvgSpriteIcon;


/***/ }),

/***/ "jirs":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("kOwS");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("qNsG");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("0iUn");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("sLSF");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("MI3g");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("a7VT");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("Tit0");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__("YFqc");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__("K2gz");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _components_SvgIcon__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__("BE5S");
/* harmony import */ var _components_Parallax__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__("IMUT");
/* harmony import */ var _components_Parallax_Paper__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__("QncY");
/* harmony import */ var _assets_images_app_banner_5_banner_5_jpg__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__("dxtb");
/* harmony import */ var _assets_images_app_banner_5_banner_5_jpg__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_assets_images_app_banner_5_banner_5_jpg__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _assets_images_app_banner_5_svg_1_svg_sprite__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__("hain");
/* harmony import */ var _assets_images_app_banner_5_svg_1_svg_sprite__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_assets_images_app_banner_5_svg_1_svg_sprite__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _assets_images_app_banner_5_svg_2_svg_sprite__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__("C4g1");
/* harmony import */ var _assets_images_app_banner_5_svg_2_svg_sprite__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_assets_images_app_banner_5_svg_2_svg_sprite__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _assets_images_app_banner_5_svg_3_svg_sprite__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__("k5Ji");
/* harmony import */ var _assets_images_app_banner_5_svg_3_svg_sprite__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_assets_images_app_banner_5_svg_3_svg_sprite__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _parallax_less__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__("za0J");
/* harmony import */ var _parallax_less__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(_parallax_less__WEBPACK_IMPORTED_MODULE_17__);


















var options = {
  // selector: '.paper',
  // relativeInput: true
  // clipRelativeInput: true,
  // scalarX: 10,
  // scalarY: 10,
  limitX: 30,
  limitY: 30 // frictionX: 0.1,
  // frictionY: 0.1

};

var WallPaper =
/*#__PURE__*/
function (_React$Component) {
  Object(_babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_6__[/* default */ "a"])(WallPaper, _React$Component);

  function WallPaper() {
    Object(_babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_2__[/* default */ "a"])(this, WallPaper);

    return Object(_babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__[/* default */ "a"])(this, Object(_babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"])(WallPaper).apply(this, arguments));
  }

  Object(_babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"])(WallPaper, [{
    key: "render",
    value: function render() {
      var _this$props = this.props,
          className = _this$props.className,
          props = Object(_babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(_this$props, ["className"]);

      return react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_components_Parallax__WEBPACK_IMPORTED_MODULE_11__[/* default */ "a"], Object(_babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])({}, props, {
        className: classnames__WEBPACK_IMPORTED_MODULE_9___default()(_parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.scene, className),
        options: options
      }), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_components_Parallax_Paper__WEBPACK_IMPORTED_MODULE_12__[/* default */ "a"], {
        depth: 0.2
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.paperBackground,
        style: {
          backgroundImage: "url(".concat(_assets_images_app_banner_5_banner_5_jpg__WEBPACK_IMPORTED_MODULE_13___default.a, ")")
        }
      })), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.leftContent
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_9___default()(_parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.topic, 'AppSiYuan')
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("h1", {
        className: classnames__WEBPACK_IMPORTED_MODULE_9___default()(_parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.topicTitle, 'AppSiYuan')
      }, "\u6B23\u52A8\u79D1\u6280 \xB7 \u667A\u80FD\u786C\u4EF6"), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("p", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.topicDesc
      }, "\u667A\u80FD\u7269\u8054\u7F51\u7684\u7269\u7406\u63A5\u89E6\u70B9\uFF0C\u662F\u7528\u6237\u611F\u77E5\u6B23\u52A8\u201C\u65E0\u5F62\u7684\u6280\u672F\u201D\u7684\u91CD\u8981\u5A92\u4ECB\u3002"), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.topicExtend
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.topicIcon
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_components_SvgIcon__WEBPACK_IMPORTED_MODULE_10__[/* default */ "a"], {
        icon: _assets_images_app_banner_5_svg_1_svg_sprite__WEBPACK_IMPORTED_MODULE_14___default.a
      }), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.topicLabel
      }, "\u667A\u80FD\u7F51\u5173")), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.topicIcon
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_components_SvgIcon__WEBPACK_IMPORTED_MODULE_10__[/* default */ "a"], {
        icon: _assets_images_app_banner_5_svg_2_svg_sprite__WEBPACK_IMPORTED_MODULE_15___default.a
      }), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.topicLabel
      }, "\u667A\u80FD\u7F51\u7531")), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.topicIcon
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_components_SvgIcon__WEBPACK_IMPORTED_MODULE_10__[/* default */ "a"], {
        icon: _assets_images_app_banner_5_svg_3_svg_sprite__WEBPACK_IMPORTED_MODULE_16___default.a
      }), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.topicLabel
      }, "\u524D\u7F6E\u670D\u52A1\u5668"))), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.topicAction
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(next_link__WEBPACK_IMPORTED_MODULE_8___default.a, {
        as: "/hardware",
        href: "/hardware"
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("a", {
        className: _parallax_less__WEBPACK_IMPORTED_MODULE_17___default.a.topicButton
      }, "\u4E86\u89E3\u66F4\u591A"))))));
    }
  }]);

  return WallPaper;
}(react__WEBPACK_IMPORTED_MODULE_7___default.a.Component);

/* harmony default export */ __webpack_exports__["default"] = (WallPaper);

/***/ }),

/***/ "k1wZ":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/get-own-property-symbols");

/***/ }),

/***/ "k5Ji":
/***/ (function(module, exports, __webpack_require__) {

/* eslint-disable */
var React = __webpack_require__("cDcd");
var SpriteSymbol = __webpack_require__("QAmA");
var sprite = __webpack_require__("TQFg");

var symbol = new SpriteSymbol({
  "id": "2YQWHgSs--sprite",
  "use": "2YQWHgSs--sprite-usage",
  "viewBox": "0 0 1000.637 1000.678",
  "content": "<symbol xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 1000.637 1000.678\" id=\"2YQWHgSs--sprite\"><path d=\"M202.098 555.501v243.678c0 18.313.803 29.992 2.417 35.047 1.61 5.053 4.978 9.193 10.107 12.414 5.126 3.223 13.328 4.834 24.609 4.834h6.812v8.129H89.159v-8.129h7.91c12.744 0 21.825-1.463 27.246-4.395 5.417-2.93 9.081-6.957 10.986-12.086 1.902-5.125 2.856-17.063 2.856-35.814V644.71c0-13.768-.659-22.373-1.978-25.816-1.318-3.441-3.773-6.373-7.361-8.789-3.591-2.418-7.728-3.627-12.415-3.627-7.471 0-16.555 2.346-27.246 7.031l-3.955-7.91 109.644-50.098zm286.963 155.127c0 29.738-4.175 57.496-12.524 83.277-4.981 15.82-11.683 28.783-20.105 38.891-8.425 10.107-17.983 18.129-28.674 24.061-10.694 5.934-22.34 8.898-34.937 8.898-14.358 0-27.322-3.662-38.892-10.986-11.573-7.322-21.829-17.797-30.762-31.42-6.448-9.961-12.085-23.217-16.919-39.771-6.3-22.412-9.448-45.555-9.448-69.434 0-32.371 4.539-62.107 13.623-89.209 7.471-22.412 18.821-39.584 34.058-51.525 15.233-11.938 31.345-17.908 48.34-17.908 17.283 0 33.433 5.898 48.45 17.688 15.014 11.794 26.038 27.651 33.069 47.571 9.811 27.392 14.721 57.347 14.721 89.867zm-67.676-.44c0-52.146-.295-82.541-.879-91.186-1.466-20.359-4.981-34.131-10.547-41.309-3.663-4.688-9.596-7.031-17.798-7.031-6.3 0-11.282 1.758-14.941 5.273-5.421 5.129-9.084 14.172-10.986 27.137-1.905 12.963-2.856 58.191-2.856 135.68 0 42.188 1.462 70.461 4.395 84.814 2.197 10.402 5.346 17.359 9.448 20.875 4.099 3.516 9.521 5.273 16.26 5.273 7.323 0 12.816-2.342 16.479-7.031 6.152-8.203 9.668-20.875 10.547-38.014zm292.676.44c0 29.738-4.174 57.496-12.523 83.277-4.982 15.82-11.684 28.783-20.105 38.891-8.426 10.107-17.983 18.129-28.674 24.061-10.695 5.934-22.34 8.898-34.938 8.898-14.357 0-27.321-3.662-38.891-10.986-11.574-7.322-21.829-17.797-30.762-31.42-6.448-9.961-12.086-23.217-16.92-39.771-6.299-22.412-9.447-45.555-9.447-69.434 0-32.371 4.538-62.107 13.623-89.209 7.471-22.412 18.82-39.584 34.057-51.525 15.234-11.938 31.346-17.908 48.34-17.908 17.283 0 33.434 5.898 48.45 17.688 15.014 11.794 26.038 27.651 33.069 47.571 9.811 27.392 14.721 57.347 14.721 89.867zm-67.676-.44c0-52.146-.295-82.541-.879-91.186-1.465-20.359-4.98-34.131-10.547-41.309-3.662-4.688-9.596-7.031-17.797-7.031-6.301 0-11.282 1.758-14.941 5.273-5.422 5.129-9.085 14.172-10.986 27.137-1.906 12.963-2.857 58.191-2.857 135.68 0 42.188 1.463 70.461 4.395 84.814 2.197 10.402 5.346 17.359 9.449 20.875 4.099 3.516 9.52 5.273 16.26 5.273 7.322 0 12.816-2.342 16.479-7.031 6.152-8.203 9.668-20.875 10.547-38.014zm292.676.44c0 29.738-4.174 57.496-12.523 83.277-4.982 15.82-11.684 28.783-20.105 38.891-8.426 10.107-17.983 18.129-28.674 24.061-10.695 5.934-22.34 8.898-34.938 8.898-14.357 0-27.321-3.662-38.891-10.986-11.574-7.322-21.829-17.797-30.762-31.42-6.448-9.961-12.086-23.217-16.92-39.771-6.299-22.412-9.447-45.555-9.447-69.434 0-32.371 4.538-62.107 13.623-89.209 7.471-22.412 18.82-39.584 34.057-51.525 15.234-11.938 31.346-17.908 48.34-17.908 17.283 0 33.434 5.898 48.45 17.688 15.014 11.794 26.038 27.651 33.069 47.571 9.811 27.392 14.721 57.347 14.721 89.867zm-67.676-.44c0-52.146-.295-82.541-.879-91.186-1.465-20.359-4.98-34.131-10.547-41.309-3.662-4.688-9.596-7.031-17.797-7.031-6.301 0-11.282 1.758-14.941 5.273-5.422 5.129-9.085 14.172-10.986 27.137-1.906 12.963-2.857 58.191-2.857 135.68 0 42.188 1.463 70.461 4.395 84.814 2.197 10.402 5.346 17.359 9.449 20.875 4.099 3.516 9.52 5.273 16.26 5.273 7.322 0 12.816-2.342 16.479-7.031 6.152-8.203 9.668-20.875 10.547-38.014zM361.682 148.176v80.64h-7.91c-4.69-18.602-9.888-31.97-15.601-40.101-5.713-8.129-13.551-14.611-23.511-19.445-5.569-2.637-15.309-3.955-29.224-3.955h-22.192v229.834c0 15.236.841 24.757 2.527 28.564 1.682 3.811 4.978 7.141 9.888 9.998 4.906 2.855 11.608 4.284 20.105 4.284h9.888v8.13H149.646v-8.13h9.888c8.642 0 15.601-1.538 20.874-4.614 3.808-2.05 6.812-5.565 9.009-10.547 1.61-3.516 2.417-12.744 2.417-27.686V165.314H170.3c-20.071 0-34.645 4.25-43.726 12.744-12.744 11.865-20.802 28.784-24.17 50.757h-8.35v-80.64h267.628zm139.966 17.138v122.388h8.568c13.184 0 23.951-1.978 32.301-5.933s15.414-10.619 21.203-19.995c5.785-9.373 9.559-22.045 11.316-38.013h7.689v149.634h-7.689c-2.785-28.27-10.365-46.911-22.742-55.921-12.381-9.008-26.404-13.513-42.078-13.513h-8.568v91.187c0 15.236.841 24.757 2.526 28.564 1.683 3.811 4.978 7.141 9.888 9.998 4.906 2.855 11.535 4.284 19.885 4.284h9.889v8.13H388.049v-8.13h9.888c8.642 0 15.601-1.538 20.874-4.614 3.808-2.05 6.736-5.565 8.789-10.547 1.61-3.516 2.417-12.744 2.417-27.686V199.152c0-15.233-.807-24.754-2.417-28.564-1.614-3.808-4.872-7.141-9.778-9.998-4.91-2.856-11.536-4.285-19.885-4.285h-9.888v-8.13h251.367v85.474h-9.008c-2.054-20.067-7.289-34.937-15.711-44.604-8.426-9.668-20.62-16.479-36.584-20.435-8.789-2.197-25.049-3.296-48.779-3.296zm362.549-23.95l2.416 99.316h-9.008c-4.251-24.901-14.688-44.935-31.312-60.095-16.627-15.162-34.606-22.742-53.942-22.742-14.941 0-26.773 3.993-35.486 11.975-8.717 7.986-13.074 17.177-13.074 27.576 0 6.592 1.539 12.452 4.615 17.578 4.246 6.887 11.059 13.698 20.434 20.435 6.885 4.834 22.776 13.403 47.682 25.708 34.86 17.139 58.371 33.326 70.531 48.56 12.01 15.236 18.018 32.667 18.018 52.295 0 24.904-9.705 46.328-29.113 64.271-19.412 17.945-44.055 26.916-73.938 26.916-9.377 0-18.238-.954-26.588-2.856-8.35-1.905-18.824-5.493-31.42-10.767-7.031-2.929-12.82-4.395-17.359-4.395-3.811 0-7.838 1.466-12.084 4.395-4.251 2.932-7.691 7.396-10.328 13.403h-8.129v-112.5h8.129c6.445 31.641 18.859 55.776 37.244 72.399 18.381 16.628 38.195 24.939 59.436 24.939 16.404 0 29.479-4.467 39.222-13.403 9.74-8.934 14.612-19.336 14.612-31.201 0-7.031-1.868-13.843-5.604-20.435s-9.414-12.854-17.029-18.787c-7.617-5.932-21.094-13.657-40.43-23.181-27.102-13.328-46.582-24.682-58.447-34.058-11.865-9.373-20.983-19.848-27.355-31.421-6.372-11.57-9.559-24.314-9.559-38.232 0-23.73 8.714-43.945 26.148-60.645 17.43-16.699 39.402-25.049 65.918-25.049 9.668 0 19.04 1.174 28.125 3.516 6.883 1.758 15.271 5.02 25.158 9.778 9.888 4.762 16.809 7.141 20.764 7.141 3.809 0 6.813-1.171 9.01-3.516 2.197-2.341 4.246-7.982 6.152-16.919h6.591z\" /></symbol>"
});
sprite.add(symbol);

var SvgSpriteIcon = function SvgSpriteIcon(props) {
  return React.createElement(
    'svg',
    Object.assign({
      viewBox: symbol.viewBox
    }, props),
    React.createElement(
      'use',
      {
        xlinkHref: '#' + symbol.id
      }
    )
  );
};

SvgSpriteIcon.viewBox = symbol.viewBox;
SvgSpriteIcon.id = symbol.id;
SvgSpriteIcon.content = symbol.content;
SvgSpriteIcon.url = symbol.url;
SvgSpriteIcon.toString = symbol.toString;

module.exports = SvgSpriteIcon;
module.exports.default = SvgSpriteIcon;


/***/ }),

/***/ "kJFy":
/***/ (function(module, exports) {

module.exports = require("flystore");

/***/ }),

/***/ "kOwS":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _extends; });
/* harmony import */ var _core_js_object_assign__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("UXZV");
/* harmony import */ var _core_js_object_assign__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_assign__WEBPACK_IMPORTED_MODULE_0__);

function _extends() {
  _extends = _core_js_object_assign__WEBPACK_IMPORTED_MODULE_0___default.a || function (target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];

      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }

    return target;
  };

  return _extends.apply(this, arguments);
}

/***/ }),

/***/ "lOhm":
/***/ (function(module, exports) {

module.exports = require("whatitis");

/***/ }),

/***/ "ln6h":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("cu1A");


/***/ }),

/***/ "o5io":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/create");

/***/ }),

/***/ "p+Sj":
/***/ (function(module, exports, __webpack_require__) {

/* eslint-disable */
var React = __webpack_require__("cDcd");
var SpriteSymbol = __webpack_require__("QAmA");
var sprite = __webpack_require__("TQFg");

var symbol = new SpriteSymbol({
  "id": "2CYjp8SS--sprite",
  "use": "2CYjp8SS--sprite-usage",
  "viewBox": "0 0 1000.637 1000.678",
  "content": "<symbol xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 1000.637 1000.678\" id=\"2CYjp8SS--sprite\"><g fill=\"#fff\"><path d=\"M414.745 756.688h-97.152c-45.385 0-88.122-17.683-120.225-49.786-32.11-32.114-49.792-74.845-49.792-120.23s17.683-88.116 49.792-120.225c32.103-32.109 74.839-49.793 120.225-49.793 13.438 0 24.288-10.851 24.288-24.287v-.301c0-58.367 22.77-113.324 64.058-154.536 41.29-41.21 96.164-64.058 154.536-64.058 35.067 0 68.618 8.046 99.583 23.907 29.601 15.181 55.786 37.27 75.675 63.982 8.042 10.78 23.221 12.979 34.002 4.935 10.78-8.047 12.974-23.229 4.933-34.002-24.371-32.638-56.32-59.659-92.443-78.177-37.428-19.129-79.471-29.222-121.749-29.222-36.053 0-71.044 7.056-103.984 21.021-31.8 13.436-60.418 32.713-84.932 57.233-24.52 24.514-43.796 53.13-57.228 84.932-11.005 25.954-17.687 53.207-20.042 81.214-49.561 5.235-95.481 27.092-131.231 62.766C121.77 473.354 99 528.299 99 586.671c0 58.373 22.77 113.317 64.059 154.526 41.218 41.297 96.168 64.066 154.535 64.066h97.152c13.437 0 24.288-10.852 24.288-24.288s-10.852-24.287-24.289-24.287z\" /><path d=\"M827.644 368.078H536.187c-26.79 0-48.576 21.786-48.576 48.575v388.611c0 26.791 21.786 48.576 48.576 48.576h291.457c26.791 0 48.576-21.785 48.576-48.576V416.653c0-26.79-21.785-48.575-48.576-48.575zm0 437.186H536.187V708.11h291.457zm0-145.729H536.187v-97.152h291.457zm0-145.728H536.187v-97.231.077h291.457v-.077z\" /><path d=\"M730.49 465.231c0 13.413 10.875 24.288 24.289 24.288 13.413 0 24.288-10.875 24.288-24.288 0-13.415-10.875-24.29-24.288-24.29-13.414 0-24.289 10.875-24.289 24.29zm0 145.728c0 13.412 10.875 24.288 24.289 24.288 13.413 0 24.288-10.876 24.288-24.288 0-13.413-10.875-24.288-24.288-24.288-13.414 0-24.289 10.875-24.289 24.288zm0 145.729c0 13.413 10.875 24.288 24.289 24.288 13.413 0 24.288-10.875 24.288-24.288 0-13.415-10.875-24.288-24.288-24.288-13.414-.001-24.289 10.872-24.289 24.288z\" /></g></symbol>"
});
sprite.add(symbol);

var SvgSpriteIcon = function SvgSpriteIcon(props) {
  return React.createElement(
    'svg',
    Object.assign({
      viewBox: symbol.viewBox
    }, props),
    React.createElement(
      'use',
      {
        xlinkHref: '#' + symbol.id
      }
    )
  );
};

SvgSpriteIcon.viewBox = symbol.viewBox;
SvgSpriteIcon.id = symbol.id;
SvgSpriteIcon.content = symbol.content;
SvgSpriteIcon.url = symbol.url;
SvgSpriteIcon.toString = symbol.toString;

module.exports = SvgSpriteIcon;
module.exports.default = SvgSpriteIcon;


/***/ }),

/***/ "p8BD":
/***/ (function(module, exports) {

module.exports = require("next-server/dist/lib/utils");

/***/ }),

/***/ "pLtp":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("qJj/");

/***/ }),

/***/ "qJj/":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/keys");

/***/ }),

/***/ "qNsG":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/get-own-property-symbols.js
var get_own_property_symbols = __webpack_require__("4mXO");
var get_own_property_symbols_default = /*#__PURE__*/__webpack_require__.n(get_own_property_symbols);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/keys.js
var keys = __webpack_require__("pLtp");
var keys_default = /*#__PURE__*/__webpack_require__.n(keys);

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/objectWithoutPropertiesLoose.js

function _objectWithoutPropertiesLoose(source, excluded) {
  if (source == null) return {};
  var target = {};

  var sourceKeys = keys_default()(source);

  var key, i;

  for (i = 0; i < sourceKeys.length; i++) {
    key = sourceKeys[i];
    if (excluded.indexOf(key) >= 0) continue;
    target[key] = source[key];
  }

  return target;
}
// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/objectWithoutProperties.js
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _objectWithoutProperties; });


function _objectWithoutProperties(source, excluded) {
  if (source == null) return {};
  var target = _objectWithoutPropertiesLoose(source, excluded);
  var key, i;

  if (get_own_property_symbols_default.a) {
    var sourceSymbolKeys = get_own_property_symbols_default()(source);

    for (i = 0; i < sourceSymbolKeys.length; i++) {
      key = sourceSymbolKeys[i];
      if (excluded.indexOf(key) >= 0) continue;
      if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
      target[key] = source[key];
    }
  }

  return target;
}

/***/ }),

/***/ "qRXU":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/keys.js
var keys = __webpack_require__("pLtp");
var keys_default = /*#__PURE__*/__webpack_require__.n(keys);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/extends.js
var esm_extends = __webpack_require__("kOwS");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/classCallCheck.js
var classCallCheck = __webpack_require__("0iUn");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/createClass.js
var createClass = __webpack_require__("sLSF");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/possibleConstructorReturn.js + 1 modules
var possibleConstructorReturn = __webpack_require__("MI3g");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/getPrototypeOf.js
var getPrototypeOf = __webpack_require__("a7VT");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/assertThisInitialized.js
var assertThisInitialized = __webpack_require__("AT/M");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/inherits.js + 1 modules
var inherits = __webpack_require__("Tit0");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/defineProperty.js
var defineProperty = __webpack_require__("vYYK");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/assign.js
var object_assign = __webpack_require__("UXZV");
var assign_default = /*#__PURE__*/__webpack_require__.n(object_assign);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/objectSpread.js
var objectSpread = __webpack_require__("zrwo");

// EXTERNAL MODULE: external "flystore"
var external_flystore_ = __webpack_require__("kJFy");
var external_flystore_default = /*#__PURE__*/__webpack_require__.n(external_flystore_);

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__("cDcd");
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);

// EXTERNAL MODULE: external "object.pick"
var external_object_pick_ = __webpack_require__("6RRd");
var external_object_pick_default = /*#__PURE__*/__webpack_require__.n(external_object_pick_);

// EXTERNAL MODULE: external "less-vars-to-js"
var external_less_vars_to_js_ = __webpack_require__("bPsq");
var external_less_vars_to_js_default = /*#__PURE__*/__webpack_require__.n(external_less_vars_to_js_);

// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__("4Q3z");
var router_default = /*#__PURE__*/__webpack_require__.n(router_);

// CONCATENATED MODULE: ./node_modules/raw-loader/dist/cjs.js!./assets/custom.less
/* harmony default export */ var custom = ("\n// https://github.com/ant-design/ant-design/blob/master/components/style/themes/default.less\n@import (reference) \"~antd/lib/style/themes/default.less\";\n@import (reference) \"~antd/lib/style/mixins/index.less\";\n@import (reference) \"./easings/index.less\";\n\n@gray-1: #ffffff;\n@gray-2: #fafafa;\n@gray-3: #f5f5f5;\n@gray-4: #e8e8e8;\n@gray-5: #d9d9d9;\n@gray-6: #bfbfbf;\n@gray-7: #8c8c8c;\n@gray-8: #595959;\n@gray-9: #262626;\n@gray-10: #000000;\n\n// 暗黑\n@dark-1: rgba(0, 0, 0, .05);\n@dark-2: rgba(0, 0, 0, .15);\n@dark-3: rgba(0, 0, 0, .25);\n@dark-4: rgba(0, 0, 0, .35);\n@dark-5: rgba(0, 0, 0, .45);\n@dark-6: rgba(0, 0, 0, .55);\n@dark-7: rgba(0, 0, 0, .65);\n@dark-8: rgba(0, 0, 0, .75);\n@dark-9: rgba(0, 0, 0, .85);\n@dark-10: rgba(0, 0, 0, 1);\n\n// 亮白\n@light-1: rgba(255, 255, 255, .05);\n@light-2: rgba(255, 255, 255, .15);\n@light-3: rgba(255, 255, 255, .25);\n@light-4: rgba(255, 255, 255, .35);\n@light-5: rgba(255, 255, 255, .45);\n@light-6: rgba(255, 255, 255, .55);\n@light-7: rgba(255, 255, 255, .65);\n@light-8: rgba(255, 255, 255, .75);\n@light-9: rgba(255, 255, 255, .85);\n@light-10: rgba(255, 255, 255, 1);\n\n\n@mask-color: #001529;\n@footer-color: @light-8;\n@footer-link-color: @light-6;\n@footer-link-hover-color: @light-10;\n@footer-background-color: @dark-10;\n@header-background-color: #001529;\n@anchor-background-color: @light-10;\n@anchor-color: #1890ff;\n\n\n@dark-menu-color: @light-7;\n@dark-menu-background-color: @header-background-color;\n\n\n@anim-speed-1: 200ms;\n@anim-speed-2: 375ms;\n@anim-speed-3: 500ms;\n@anim-speed-4: 800ms;\n@anim-speed-5: 1200ms;\n\n\n@page-width: 980px;\n@page-width-lg: 1440px;\n@max-width: 1920px; // 2560px\n@header-height: 64px;\n@header-phone-height: 48px;\n@anchor-height: 48px;\n\n\n// z-index\n@header-zIndex: 1100;\n@anchor-zIndex: @header-zIndex - 10;\n\n// shadow\n@shadow-down: 0 2px 8px rgba(0, 0, 0, 0.08);\n@shadow-down-dark: 0 2px 8px rgba(0, 0, 0, 0.2);\n@shadow-down-sm: 4px 6px 10px rgba(0, 0, 0, 0.1);\n@shadow-down-lg: 8px 12px 20px rgba(0, 0, 0, 0.3);\n\n\n@main-color: #fa8c16;\n@main-background-color: #001529;\n@main-light-background-color: #f1f3ff;\n\n// .function {\n//   .foo(@x) {\n//     return: @x * 2;\n//   }\n// }");
// CONCATENATED MODULE: ./node_modules/raw-loader/dist/cjs.js!./assets/easings/index.less
/* harmony default export */ var easings = ("//https://easings.net/\n//http://cubic-bezier.com/#.17,.67,.83,.67\n@linear         : cubic-bezier(0.250, 0.250, 0.750, 0.750);\n@ease           : cubic-bezier(0.250, 0.100, 0.250, 1.000);\n@ease-in        : cubic-bezier(0.420, 0.000, 1.000, 1.000);\n@ease-out       : cubic-bezier(0.000, 0.000, 0.580, 1.000);\n@ease-in-out    : cubic-bezier(0.420, 0.000, 0.580, 1.000);\n\n@easeInQuad     : cubic-bezier(0.550, 0.085, 0.680, 0.530);\n@easeInCubic    : cubic-bezier(0.550, 0.055, 0.675, 0.190);\n@easeInQuart    : cubic-bezier(0.895, 0.030, 0.685, 0.220);\n@easeInQuint    : cubic-bezier(0.755, 0.050, 0.855, 0.060);\n@easeInSine     : cubic-bezier(0.470, 0.000, 0.745, 0.715);\n@easeInExpo     : cubic-bezier(0.950, 0.050, 0.795, 0.035);\n@easeInCirc     : cubic-bezier(0.600, 0.040, 0.980, 0.335);\n@easeInBack     : cubic-bezier(0.600, -0.280, 0.735, 0.045);\n\n@easeOutQuad    : cubic-bezier(0.250, 0.460, 0.450, 0.940);\n@easeOutCubic   : cubic-bezier(0.215, 0.610, 0.355, 1.000);\n@easeOutQuart   : cubic-bezier(0.165, 0.840, 0.440, 1.000);\n@easeOutQuint   : cubic-bezier(0.230, 1.000, 0.320, 1.000);\n@easeOutSine    : cubic-bezier(0.390, 0.575, 0.565, 1.000);\n@easeOutExpo    : cubic-bezier(0.190, 1.000, 0.220, 1.000);\n@easeOutCirc    : cubic-bezier(0.075, 0.820, 0.165, 1.000);\n@easeOutBack    : cubic-bezier(0.175, 0.885, 0.320, 1.275);\n\n@easeInOutQuad  : cubic-bezier(0.455, 0.030, 0.515, 0.955);\n@easeInOutCubic : cubic-bezier(0.645, 0.045, 0.355, 1.000);\n@easeInOutQuart : cubic-bezier(0.770, 0.000, 0.175, 1.000);\n@easeInOutQuint : cubic-bezier(0.860, 0.000, 0.070, 1.000);\n@easeInOutSine  : cubic-bezier(0.445, 0.050, 0.550, 0.950);\n@easeInOutExpo  : cubic-bezier(1.000, 0.000, 0.000, 1.000);\n@easeInOutCirc  : cubic-bezier(0.785, 0.135, 0.150, 0.860);\n@easeInOutBack  : cubic-bezier(0.680, -0.550, 0.265, 1.550);\n");
// CONCATENATED MODULE: ./components/Themes/index.js
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return themeVariables; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return themeEasings; });
/* unused harmony export defaultThemeConfig */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return Themes_setTheme; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "e", function() { return withTheme; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ThemeContext; });


















var themeVariables = external_less_vars_to_js_default()(custom, {
  resolveVariables: true
});
var themeEasings = external_less_vars_to_js_default()(easings, {
  resolveVariables: true
});
var defaultThemeConfig = {
  footer: true,
  header: true
};
var storeTheme = external_flystore_default()('@theme-config');
storeTheme.set('config', Object(objectSpread["a" /* default */])({}, defaultThemeConfig));
storeTheme.set('change', {});
var Themes_setTheme = function setTheme(config, changeRoute) {
  var route = router_default.a.router.route;

  if (changeRoute && changeRoute !== route) {
    var themeConfig = storeTheme.get("change-".concat(changeRoute));
    storeTheme.set("change-".concat(changeRoute), assign_default()({}, themeConfig, config));
  } else {
    var _themeConfig = storeTheme.get("change-".concat(route));

    var newConfig = assign_default()({}, _themeConfig, config);

    storeTheme.set("change-".concat(route), newConfig);
    storeTheme.dispense('change', newConfig);
  }
};
function withTheme(Comp) {
  var _class, _temp;

  return Object(router_["withRouter"])((_temp = _class =
  /*#__PURE__*/
  function (_React$Component) {
    Object(inherits["a" /* default */])(WithTheme, _React$Component);

    function WithTheme() {
      var _getPrototypeOf2;

      var _this;

      Object(classCallCheck["a" /* default */])(this, WithTheme);

      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }

      _this = Object(possibleConstructorReturn["a" /* default */])(this, (_getPrototypeOf2 = Object(getPrototypeOf["a" /* default */])(WithTheme)).call.apply(_getPrototypeOf2, [this].concat(args)));

      Object(defineProperty["a" /* default */])(Object(assertThisInitialized["a" /* default */])(_this), "state", {
        themeConfig: storeTheme.get('config')
      });

      return _this;
    }

    Object(createClass["a" /* default */])(WithTheme, [{
      key: "componentDidMount",
      value: function componentDidMount() {
        var _this2 = this;

        var route = this.props.router.route;
        var changeConfig = storeTheme.get("change-".concat(route));

        if (changeConfig) {
          this.setState({
            themeConfig: assign_default()(storeTheme.get('config'), changeConfig)
          });
        }

        this.configHandle = storeTheme.watch('change', function (themeConfig) {
          _this2.setState({
            themeConfig: assign_default()(storeTheme.get('config'), themeConfig)
          });
        });
      }
    }, {
      key: "componentWillUnmount",
      value: function componentWillUnmount() {
        if (this.configHandle) {
          this.configHandle.clear();
          this.configHandle = null;
        }
      }
    }, {
      key: "render",
      value: function render() {
        return external_react_default.a.createElement(Comp, Object(esm_extends["a" /* default */])({}, this.props, {
          themeConfig: this.state.themeConfig
        }));
      }
    }]);

    return WithTheme;
  }(external_react_default.a.Component), Object(defineProperty["a" /* default */])(_class, "getDerivedStateFromProps", function (props) {
    var route = props.router.route;

    var newConfig = assign_default()({}, defaultThemeConfig, external_object_pick_default()(props, keys_default()(defaultThemeConfig)));

    var changeConfig = storeTheme.get("change-".concat(route));
    return {
      themeConfig: assign_default()(newConfig, changeConfig)
    };
  }), _temp));
}
var ThemeContext = external_react_default.a.createContext({
  env: {},
  themeConfig: Object(objectSpread["a" /* default */])({}, defaultThemeConfig),
  themeEasings: themeEasings,
  themeVariables: themeVariables,
  isLoaded: false,
  isMobile: false
});

/***/ }),

/***/ "rf6O":
/***/ (function(module, exports) {

module.exports = require("prop-types");

/***/ }),

/***/ "sLSF":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _createClass; });
/* harmony import */ var _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("hfKm");
/* harmony import */ var _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__);


function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;

    _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default()(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

/***/ }),

/***/ "sNF/":
/***/ (function(module, exports) {

module.exports = "/_next/static/images/banner-4-1c1aeb98ea269980a65581402e773d56.jpg";

/***/ }),

/***/ "tIKZ":
/***/ (function(module, exports) {

module.exports = "/_next/static/images/banner-1-d531cb542d847f7bc367a24c938d4c91.jpg";

/***/ }),

/***/ "ushU":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return requestAnimationFrame; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return cancelAnimationFrame; });
var suffix = 'AnimationFrame';
var vendors = ['', 'moz', 'webkit'];

var getAFFunc = function getAFFunc(name) {
  var func = null;
  return function () {
    if (func) {
      return func.apply(void 0, arguments);
    }

    var win = window;

    for (var i = 0, l = vendors.length; i < l; i++) {
      var prefix = vendors[i];
      var funcName = name + suffix;

      if (prefix) {
        funcName = prefix + funcName.charAt(0).toUpperCase() + funcName.slice(1);
      }

      func = win[funcName];

      if (func) {
        break;
      }
    }

    return func ? func.apply(void 0, arguments) : func;
  };
};

var requestAnimationFrame = getAFFunc('request');
var cancelFunc = getAFFunc('cancel');
var cancelRequestFunc = getAFFunc('cancelRequest');
var cancelAnimationFrame = function cancelAnimationFrame() {
  return cancelFunc.apply(void 0, arguments) || cancelRequestFunc.apply(void 0, arguments);
};

/***/ }),

/***/ "vF0m":
/***/ (function(module, exports, __webpack_require__) {

/* eslint-disable */
var React = __webpack_require__("cDcd");
var SpriteSymbol = __webpack_require__("QAmA");
var sprite = __webpack_require__("TQFg");

var symbol = new SpriteSymbol({
  "id": "2ggMRxLE--sprite",
  "use": "2ggMRxLE--sprite-usage",
  "viewBox": "0 0 1000.637 1000.678",
  "content": "<symbol xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 1000.637 1000.678\" id=\"2ggMRxLE--sprite\"><path d=\"M500.317 77.019c-234.747 0-423.326 188.565-423.326 423.313 0 234.749 188.579 423.328 423.326 423.328 234.749 0 423.328-188.579 423.328-423.328.001-234.748-188.579-423.313-423.328-423.313zm211.652 101.977v13.473c0 40.404-3.834 78.893-11.529 117.367-26.945 5.778-46.197 28.862-46.197 55.809 0 15.39 5.778 30.779 17.335 40.404-13.474 30.794-26.946 61.572-46.197 90.435-71.184-80.81-121.214-182.8-138.534-296.32 44.251-26.945 92.366-48.113 142.396-61.571 28.861 9.624 57.723 23.082 82.726 40.403zm-80.811 379.06c34.641 32.712 71.198 61.573 111.603 84.672-40.404 7.696-82.74 11.528-126.993 11.528-19.25 0-38.473-1.918-57.725-1.918 0-3.847 0-7.693-1.917-11.541 26.933-25.016 51.948-53.878 75.032-82.741zM500.317 115.492c21.168 0 42.336 1.932 63.504 5.778-26.945 11.541-53.893 23.084-80.822 36.558-1.933-13.474-1.933-26.946-1.933-40.404 5.78-1.932 13.474-1.932 19.251-1.932zm103.909 413.701c-21.167 28.862-44.266 53.879-69.268 78.895-9.624-7.695-21.168-11.557-34.641-11.557-25.016 0-46.184 15.403-53.878 38.502-76.962-19.252-150.076-48.114-215.496-88.518 17.306-65.421 46.169-127.008 82.726-180.871 3.862 0 7.695 1.917 13.474 1.917 32.711 0 57.726-25.016 57.726-57.726 0-7.695-1.917-15.39-3.847-23.085 23.098-23.085 46.183-42.335 71.183-61.572 21.167 115.451 75.059 219.359 152.021 304.015zM173.218 702.37c-34.64-57.726-55.808-123.145-57.726-194.344 23.086 19.251 46.169 38.489 71.185 53.879-7.694 42.336-13.459 86.586-13.459 130.854zm25.001-178.954c-28.861-19.236-53.863-40.405-78.893-63.489 19.252-173.176 153.938-311.71 325.184-338.656 0 21.168 1.93 40.404 3.862 61.572-32.725 23.1-63.504 48.1-92.366 75.046-9.611-5.778-19.251-7.695-28.863-7.695-32.71 0-57.726 25.002-57.726 57.726 0 13.473 5.778 25.001 13.474 36.558-38.489 53.876-67.351 113.518-84.672 178.938zm17.321 234.762c-1.932-21.168-3.848-42.335-3.848-65.418 0-36.572 3.848-73.131 11.542-107.758 69.268 40.392 144.313 71.186 223.205 88.505 0 1.917 0 1.917 1.933 3.847-67.351 44.269-144.313 73.13-227.068 86.589-3.834-1.93-3.834-3.847-5.764-5.765zm284.777 126.979c-94.281 0-178.953-34.626-246.29-90.421 80.81-15.391 153.924-46.183 219.345-90.45 7.694 5.779 17.336 7.694 26.945 7.694 19.253 0 34.641-9.61 46.185-23.083 23.083 1.93 46.182 3.862 69.266 3.862 61.575 0 121.229-7.71 178.955-21.169 13.472 5.763 26.933 13.459 40.404 17.307-65.435 117.381-190.496 196.26-334.81 196.26zm298.238-253.986c-53.862-26.93-103.895-63.502-146.228-105.824 21.167-32.71 38.486-67.351 53.877-101.977h5.765c32.724 0 57.724-25.016 57.724-57.726 0-23.099-13.458-42.336-32.696-51.961 7.696-34.627 11.544-69.268 11.544-105.825 82.74 71.198 134.687 175.092 134.687 292.473 0 38.475-5.778 73.115-15.391 107.757-21.167 9.611-44.252 17.306-69.282 23.083z\" /></symbol>"
});
sprite.add(symbol);

var SvgSpriteIcon = function SvgSpriteIcon(props) {
  return React.createElement(
    'svg',
    Object.assign({
      viewBox: symbol.viewBox
    }, props),
    React.createElement(
      'use',
      {
        xlinkHref: '#' + symbol.id
      }
    )
  );
};

SvgSpriteIcon.viewBox = symbol.viewBox;
SvgSpriteIcon.id = symbol.id;
SvgSpriteIcon.content = symbol.content;
SvgSpriteIcon.url = symbol.url;
SvgSpriteIcon.toString = symbol.toString;

module.exports = SvgSpriteIcon;
module.exports.default = SvgSpriteIcon;


/***/ }),

/***/ "vYYK":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _defineProperty; });
/* harmony import */ var _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("hfKm");
/* harmony import */ var _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__);

function _defineProperty(obj, key, value) {
  if (key in obj) {
    _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default()(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}

/***/ }),

/***/ "vjea":
/***/ (function(module, exports, __webpack_require__) {

var _Object$setPrototypeOf = __webpack_require__("TRZx");

function _setPrototypeOf(o, p) {
  module.exports = _setPrototypeOf = _Object$setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

module.exports = _setPrototypeOf;

/***/ }),

/***/ "vqFK":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/symbol");

/***/ }),

/***/ "za0J":
/***/ (function(module, exports) {

module.exports = {
	"scene": "_1Zxh9h73",
	"paper-background": "_3DuBECud",
	"paperBackground": "_3DuBECud",
	"left-content": "_1LyUV2O_",
	"leftContent": "_1LyUV2O_",
	"center-content": "_242OCfn4",
	"centerContent": "_242OCfn4",
	"topic": "_1mi59G5i",
	"topic-title": "_1bqmkkVN",
	"topicTitle": "_1bqmkkVN",
	"topic-desc": "_2eLjJxyF",
	"topicDesc": "_2eLjJxyF",
	"topic-extend": "XGtqH0oX",
	"topicExtend": "XGtqH0oX",
	"topic-icon": "Fmyt4vOV",
	"topicIcon": "Fmyt4vOV",
	"topic-label": "_2WnbhL6a",
	"topicLabel": "_2WnbhL6a",
	"topic-action": "QHmQ3fB4",
	"topicAction": "QHmQ3fB4",
	"topic-button": "_1pq2TqNo",
	"topicButton": "_1pq2TqNo"
};

/***/ }),

/***/ "zrwo":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _objectSpread; });
/* harmony import */ var _core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("Jo+v");
/* harmony import */ var _core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("4mXO");
/* harmony import */ var _core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _core_js_object_keys__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("pLtp");
/* harmony import */ var _core_js_object_keys__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_keys__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _defineProperty__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("vYYK");




function _objectSpread(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i] != null ? arguments[i] : {};

    var ownKeys = _core_js_object_keys__WEBPACK_IMPORTED_MODULE_2___default()(source);

    if (typeof _core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1___default.a === 'function') {
      ownKeys = ownKeys.concat(_core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1___default()(source).filter(function (sym) {
        return _core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_0___default()(source, sym).enumerable;
      }));
    }

    ownKeys.forEach(function (key) {
      Object(_defineProperty__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"])(target, key, source[key]);
    });
  }

  return target;
}

/***/ })

/******/ });