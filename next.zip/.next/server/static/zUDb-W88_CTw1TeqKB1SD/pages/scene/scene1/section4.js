module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../../../../../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 26);
/******/ })
/************************************************************************/
/******/ ({

/***/ "+ys9":
/***/ (function(module, exports) {

module.exports = require("rc-util/lib/Dom/css");

/***/ }),

/***/ "/+oN":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/get-prototype-of");

/***/ }),

/***/ "0iUn":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _classCallCheck; });
function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

/***/ }),

/***/ 26:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("kMzP");


/***/ }),

/***/ "4Q3z":
/***/ (function(module, exports) {

module.exports = require("next/router");

/***/ }),

/***/ "4mXO":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("k1wZ");

/***/ }),

/***/ "6RRd":
/***/ (function(module, exports) {

module.exports = require("object.pick");

/***/ }),

/***/ "AT/M":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _assertThisInitialized; });
function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

/***/ }),

/***/ "BI0l":
/***/ (function(module, exports) {

module.exports = require("rc-util/lib/Dom/addEventListener");

/***/ }),

/***/ "Bhuq":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("/+oN");

/***/ }),

/***/ "Jo+v":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("Z6Kq");

/***/ }),

/***/ "K2gz":
/***/ (function(module, exports) {

module.exports = require("classnames");

/***/ }),

/***/ "MI3g":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/symbol/iterator.js
var iterator = __webpack_require__("XVgq");
var iterator_default = /*#__PURE__*/__webpack_require__.n(iterator);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/symbol.js
var symbol = __webpack_require__("Z7t5");
var symbol_default = /*#__PURE__*/__webpack_require__.n(symbol);

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/typeof.js



function typeof_typeof2(obj) { if (typeof symbol_default.a === "function" && typeof iterator_default.a === "symbol") { typeof_typeof2 = function _typeof2(obj) { return typeof obj; }; } else { typeof_typeof2 = function _typeof2(obj) { return obj && typeof symbol_default.a === "function" && obj.constructor === symbol_default.a && obj !== symbol_default.a.prototype ? "symbol" : typeof obj; }; } return typeof_typeof2(obj); }

function typeof_typeof(obj) {
  if (typeof symbol_default.a === "function" && typeof_typeof2(iterator_default.a) === "symbol") {
    typeof_typeof = function _typeof(obj) {
      return typeof_typeof2(obj);
    };
  } else {
    typeof_typeof = function _typeof(obj) {
      return obj && typeof symbol_default.a === "function" && obj.constructor === symbol_default.a && obj !== symbol_default.a.prototype ? "symbol" : typeof_typeof2(obj);
    };
  }

  return typeof_typeof(obj);
}
// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/assertThisInitialized.js
var assertThisInitialized = __webpack_require__("AT/M");

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/possibleConstructorReturn.js
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _possibleConstructorReturn; });


function _possibleConstructorReturn(self, call) {
  if (call && (typeof_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return Object(assertThisInitialized["a" /* default */])(self);
}

/***/ }),

/***/ "SqZg":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("o5io");

/***/ }),

/***/ "TRZx":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("Wk4r");

/***/ }),

/***/ "TUA0":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/define-property");

/***/ }),

/***/ "Tit0":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/create.js
var create = __webpack_require__("SqZg");
var create_default = /*#__PURE__*/__webpack_require__.n(create);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/set-prototype-of.js
var set_prototype_of = __webpack_require__("TRZx");
var set_prototype_of_default = /*#__PURE__*/__webpack_require__.n(set_prototype_of);

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/setPrototypeOf.js

function _setPrototypeOf(o, p) {
  _setPrototypeOf = set_prototype_of_default.a || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}
// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/inherits.js
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _inherits; });


function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = create_default()(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

/***/ }),

/***/ "UXZV":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("dGr4");

/***/ }),

/***/ "WLOv":
/***/ (function(module, exports) {

module.exports = {
	"container": "ZNsC9-qr"
};

/***/ }),

/***/ "Wk4r":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/set-prototype-of");

/***/ }),

/***/ "XVgq":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("gHn/");

/***/ }),

/***/ "Z6Kq":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/get-own-property-descriptor");

/***/ }),

/***/ "Z7t5":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("vqFK");

/***/ }),

/***/ "a7VT":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _getPrototypeOf; });
/* harmony import */ var _core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("Bhuq");
/* harmony import */ var _core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("TRZx");
/* harmony import */ var _core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_1__);


function _getPrototypeOf(o) {
  _getPrototypeOf = _core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_1___default.a ? _core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0___default.a : function _getPrototypeOf(o) {
    return o.__proto__ || _core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0___default()(o);
  };
  return _getPrototypeOf(o);
}

/***/ }),

/***/ "bPsq":
/***/ (function(module, exports) {

module.exports = require("less-vars-to-js");

/***/ }),

/***/ "cDcd":
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "dDZb":
/***/ (function(module, exports) {

module.exports = {
	"wrap": "_3XqvdFoJ",
	"layer-title": "t0vLE4vS",
	"layerTitle": "t0vLE4vS",
	"layer-content": "_1AqLxy6g",
	"layerContent": "_1AqLxy6g",
	"layer-item": "MkdEHrd_",
	"layerItem": "MkdEHrd_",
	"flex-row": "_3ZI7kptF",
	"flexRow": "_3ZI7kptF",
	"flex-col": "_2TeO8c4I",
	"flexCol": "_2TeO8c4I",
	"layer-block": "_3h1xPIa5",
	"layerBlock": "_3h1xPIa5",
	"block-title": "_6bQfW_4O",
	"blockTitle": "_6bQfW_4O",
	"layer-third": "_2EXl80iN",
	"layerThird": "_2EXl80iN",
	"layer-col-6": "_3M3ed6jf",
	"layerCol6": "_3M3ed6jf",
	"layer-col-5": "_1Qmt8qOo",
	"layerCol5": "_1Qmt8qOo",
	"layer-col-4": "_1wM1x0oD",
	"layerCol4": "_1wM1x0oD",
	"layer-col-2": "_3Oxr4vMN",
	"layerCol2": "_3Oxr4vMN",
	"layer": "_3xcUBeDd"
};

/***/ }),

/***/ "dGr4":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/assign");

/***/ }),

/***/ "gHn/":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/symbol/iterator");

/***/ }),

/***/ "hfKm":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("TUA0");

/***/ }),

/***/ "k1wZ":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/get-own-property-symbols");

/***/ }),

/***/ "kJFy":
/***/ (function(module, exports) {

module.exports = require("flystore");

/***/ }),

/***/ "kMzP":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/classCallCheck.js
var classCallCheck = __webpack_require__("0iUn");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/createClass.js
var createClass = __webpack_require__("sLSF");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/possibleConstructorReturn.js + 1 modules
var possibleConstructorReturn = __webpack_require__("MI3g");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/getPrototypeOf.js
var getPrototypeOf = __webpack_require__("a7VT");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/inherits.js + 1 modules
var inherits = __webpack_require__("Tit0");

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__("cDcd");
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);

// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__("K2gz");
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/extends.js
var esm_extends = __webpack_require__("kOwS");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/keys.js
var keys = __webpack_require__("pLtp");
var keys_default = /*#__PURE__*/__webpack_require__.n(keys);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/objectWithoutProperties.js + 1 modules
var objectWithoutProperties = __webpack_require__("qNsG");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/assertThisInitialized.js
var assertThisInitialized = __webpack_require__("AT/M");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/defineProperty.js
var defineProperty = __webpack_require__("vYYK");

// EXTERNAL MODULE: external "object.pick"
var external_object_pick_ = __webpack_require__("6RRd");
var external_object_pick_default = /*#__PURE__*/__webpack_require__.n(external_object_pick_);

// EXTERNAL MODULE: external "rc-util/lib/Dom/css"
var css_ = __webpack_require__("+ys9");

// EXTERNAL MODULE: external "rc-util/lib/Dom/addEventListener"
var addEventListener_ = __webpack_require__("BI0l");
var addEventListener_default = /*#__PURE__*/__webpack_require__.n(addEventListener_);

// EXTERNAL MODULE: ./components/Themes/index.js + 2 modules
var Themes = __webpack_require__("qRXU");

// EXTERNAL MODULE: ./lib/requestAnimationFrame.js
var requestAnimationFrame = __webpack_require__("ushU");

// EXTERNAL MODULE: ./components/ResizeImage/resizeImage.less
var resizeImage = __webpack_require__("WLOv");
var resizeImage_default = /*#__PURE__*/__webpack_require__.n(resizeImage);

// CONCATENATED MODULE: ./components/ResizeImage/index.js


















var ResizeImage_ResizeImage =
/*#__PURE__*/
function (_React$Component) {
  Object(inherits["a" /* default */])(ResizeImage, _React$Component);

  Object(createClass["a" /* default */])(ResizeImage, null, [{
    key: "getDerivedStateFromProps",
    value: function getDerivedStateFromProps(props, state) {
      if (props.width && !state.width) {
        return {
          width: props.width
        };
      }

      return null;
    }
  }]);

  function ResizeImage(props) {
    var _this;

    Object(classCallCheck["a" /* default */])(this, ResizeImage);

    _this = Object(possibleConstructorReturn["a" /* default */])(this, Object(getPrototypeOf["a" /* default */])(ResizeImage).call(this, props));

    Object(defineProperty["a" /* default */])(Object(assertThisInitialized["a" /* default */])(_this), "handleResize", function () {
      Object(requestAnimationFrame["b" /* requestAnimationFrame */])(function () {
        if (_this.wrapRef.current) {
          var width = _this.state.width;
          var wrap = _this.wrapRef.current;
          var container = _this.containerRef.current;
          var currentWidth = Object(css_["get"])(wrap, 'width');
          var targetHeight = Object(css_["get"])(container, 'height');
          var scale = currentWidth / width;
          Object(css_["set"])(container, 'transform', "scale(".concat(scale, ")"));
          Object(css_["set"])(wrap, 'height', targetHeight * scale);
        }
      });
    });

    _this.wrapRef = external_react_default.a.createRef();
    _this.containerRef = external_react_default.a.createRef();
    _this.state = {
      width: null,
      height: null
    };
    return _this;
  }

  Object(createClass["a" /* default */])(ResizeImage, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      var width = this.state.width;
      var themeVariables = this.context.themeVariables; // eslint-disable-next-line

      this.state.width = width === null ? +themeVariables['@page-width'].replace(/px$/, '') - 24 * 2 : width;
      this.resizeHandler = addEventListener_default()(window, 'resize', this.handleResize);
      this.handleResize();
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      if (this.resizeHandler) {
        this.resizeHandler.remove();
        this.resizeHandler = null;
      }
    }
  }, {
    key: "render",
    value: function render() {
      var _this$state = this.state,
          width = _this$state.width,
          height = _this$state.height;
      var themeVariables = this.context.themeVariables;

      var _this$props = this.props,
          children = _this$props.children,
          props = Object(objectWithoutProperties["a" /* default */])(_this$props, ["children"]); // width 一定要设置默认


      var style = {
        // 最大宽度减 pandding
        width: width === null ? +themeVariables['@page-width'].replace(/px$/, '') - 24 * 2 : width,
        height: height
      };
      style = external_object_pick_default()(style, keys_default()(style).filter(function (key) {
        return style[key];
      }));
      return external_react_default.a.createElement("div", Object(esm_extends["a" /* default */])({}, props, {
        ref: this.wrapRef
      }), external_react_default.a.createElement("div", {
        style: style,
        className: resizeImage_default.a.container,
        ref: this.containerRef
      }, children));
    }
  }]);

  return ResizeImage;
}(external_react_default.a.Component);

Object(defineProperty["a" /* default */])(ResizeImage_ResizeImage, "contextType", Themes["a" /* ThemeContext */]);

/* harmony default export */ var components_ResizeImage = (ResizeImage_ResizeImage);
// EXTERNAL MODULE: ./pages/scene/scene1/section4.less
var section4 = __webpack_require__("dDZb");
var section4_default = /*#__PURE__*/__webpack_require__.n(section4);

// CONCATENATED MODULE: ./pages/scene/scene1/section4.js










var section4_Section =
/*#__PURE__*/
function (_React$Component) {
  Object(inherits["a" /* default */])(Section, _React$Component);

  function Section() {
    Object(classCallCheck["a" /* default */])(this, Section);

    return Object(possibleConstructorReturn["a" /* default */])(this, Object(getPrototypeOf["a" /* default */])(Section).apply(this, arguments));
  }

  Object(createClass["a" /* default */])(Section, [{
    key: "render",
    value: function render() {
      return external_react_default.a.createElement(components_ResizeImage, {
        className: section4_default.a.wrap
      }, external_react_default.a.createElement("div", {
        className: section4_default.a.layer
      }, external_react_default.a.createElement("div", {
        className: section4_default.a.layerTitle
      }, external_react_default.a.createElement("div", null, "\u7528\u6237\u573A\u666F")), external_react_default.a.createElement("div", {
        className: section4_default.a.layerContent
      }, external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol5)
      }, "\u8FDC\u7A0B\u63A7\u5236"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol5)
      }, "\u6D88\u9632\u5B89\u5168"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol5)
      }, "\u7BA1\u7F51\u68C0\u6D4B"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol5)
      }, "\u5145\u503C\u67E5\u8BE2"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol5)
      }, "..."))), external_react_default.a.createElement("div", {
        className: section4_default.a.layer
      }, external_react_default.a.createElement("div", {
        className: section4_default.a.layerTitle
      }, external_react_default.a.createElement("div", null, "\u5E94\u7528\u7CFB\u7EDF")), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerContent, section4_default.a.flexCol)
      }, external_react_default.a.createElement("div", {
        className: section4_default.a.layerBlock
      }, external_react_default.a.createElement("div", {
        className: section4_default.a.blockTitle
      }, "\u6807\u51C6\u5E94\u7528"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol5)
      }, "\u5EFA\u7B51\u80FD\u8017\u7BA1\u7406"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol5)
      }, "\u90E8\u95E8\u80FD\u8017\u7BA1\u7406"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol5)
      }, "\u8BBE\u65BD\u80FD\u8017\u7BA1\u7406"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol5)
      }, "\u7528\u80FD\u5E73\u8861\u68C0\u6D4B"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol5)
      }, "\u80FD\u8017\u6570\u636E\u4E0A\u62A5")), external_react_default.a.createElement("div", {
        className: section4_default.a.layerBlock
      }, external_react_default.a.createElement("div", {
        className: section4_default.a.blockTitle
      }, "\u6269\u5C55\u5E94\u7528"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol4)
      }, "\u5546\u4E1A\u7528\u80FD\u6536\u8D39"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol4)
      }, "\u7528\u80FD\u8D26\u76EE\u7BA1\u7406"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol4)
      }, "\u4E2D\u592E\u7A7A\u8C03\u76D1\u63A7"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol4)
      }, "\u5206\u4F53\u7A7A\u8C03\u76D1\u63A7"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol4)
      }, "\u591A\u8054\u673A\u7A7A\u8C03\u76D1\u63A7"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol4)
      }, "\u667A\u80FD\u7167\u660E\u76D1\u63A7"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol4)
      }, "\u4F9B\u6696\u8282\u80FD\u76D1\u63A7"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol4)
      }, "...")))), external_react_default.a.createElement("div", {
        className: section4_default.a.layer
      }, external_react_default.a.createElement("div", {
        className: section4_default.a.layerTitle
      }, external_react_default.a.createElement("div", null, "\u6570\u636E\u4E2D\u5FC3")), external_react_default.a.createElement("div", {
        className: section4_default.a.flexRow
      }, external_react_default.a.createElement("div", {
        className: section4_default.a.layerContent,
        style: {
          paddingRight: 0
        }
      }, external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol4)
      }, "\u8EAB\u4EFD\u8BA4\u8BC1"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol4)
      }, "\u8D22\u52A1\u7ED3\u7B97"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol4)
      }, "\u95E8\u6237\u96C6\u6210"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol4)
      }, "\u7CFB\u7EDF\u96C6\u6210"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol4)
      }, "\u7EC4\u7EC7\u67B6\u6784"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol4)
      }, "\u6570\u636E\u6316\u6398"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol4)
      }, "\u6570\u636E\u5BF9\u63A5"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol4)
      }, "...")), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerContent, section4_default.a.layerThird)
      }, external_react_default.a.createElement("div", {
        className: section4_default.a.blockTitle
      }, "\u7B2C\u4E09\u65B9\u5BF9\u63A5"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol2)
      }, "\u5206\u6790\u62A5\u8868"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol2)
      }, "\u6536\u8D39\u7ED3\u7B97"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol2)
      }, "\u8EAB\u4EFD\u8BA4\u8BC1"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol2)
      }, "...")))), external_react_default.a.createElement("div", {
        className: section4_default.a.layer
      }, external_react_default.a.createElement("div", {
        className: section4_default.a.layerTitle
      }, external_react_default.a.createElement("div", null, "\u667A\u80FD\u7269\u8054")), external_react_default.a.createElement("div", {
        className: section4_default.a.layerContent
      }, external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol5)
      }, "\u8BBE\u5907\u5BF9\u63A5"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol5)
      }, "\u6570\u636E\u6574\u7406"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol5)
      }, "\u6D77\u91CF\u5B58\u50A8"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol5)
      }, "\u9A71\u52A8\u5F00\u53D1"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol5)
      }, "\u8BBE\u5907\u76D1\u542C"))));
    }
  }]);

  return Section;
}(external_react_default.a.Component);

/* harmony default export */ var scene1_section4 = __webpack_exports__["default"] = (section4_Section);

/***/ }),

/***/ "kOwS":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _extends; });
/* harmony import */ var _core_js_object_assign__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("UXZV");
/* harmony import */ var _core_js_object_assign__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_assign__WEBPACK_IMPORTED_MODULE_0__);

function _extends() {
  _extends = _core_js_object_assign__WEBPACK_IMPORTED_MODULE_0___default.a || function (target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];

      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }

    return target;
  };

  return _extends.apply(this, arguments);
}

/***/ }),

/***/ "o5io":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/create");

/***/ }),

/***/ "pLtp":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("qJj/");

/***/ }),

/***/ "qJj/":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/keys");

/***/ }),

/***/ "qNsG":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/get-own-property-symbols.js
var get_own_property_symbols = __webpack_require__("4mXO");
var get_own_property_symbols_default = /*#__PURE__*/__webpack_require__.n(get_own_property_symbols);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/keys.js
var keys = __webpack_require__("pLtp");
var keys_default = /*#__PURE__*/__webpack_require__.n(keys);

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/objectWithoutPropertiesLoose.js

function _objectWithoutPropertiesLoose(source, excluded) {
  if (source == null) return {};
  var target = {};

  var sourceKeys = keys_default()(source);

  var key, i;

  for (i = 0; i < sourceKeys.length; i++) {
    key = sourceKeys[i];
    if (excluded.indexOf(key) >= 0) continue;
    target[key] = source[key];
  }

  return target;
}
// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/objectWithoutProperties.js
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _objectWithoutProperties; });


function _objectWithoutProperties(source, excluded) {
  if (source == null) return {};
  var target = _objectWithoutPropertiesLoose(source, excluded);
  var key, i;

  if (get_own_property_symbols_default.a) {
    var sourceSymbolKeys = get_own_property_symbols_default()(source);

    for (i = 0; i < sourceSymbolKeys.length; i++) {
      key = sourceSymbolKeys[i];
      if (excluded.indexOf(key) >= 0) continue;
      if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
      target[key] = source[key];
    }
  }

  return target;
}

/***/ }),

/***/ "qRXU":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/keys.js
var keys = __webpack_require__("pLtp");
var keys_default = /*#__PURE__*/__webpack_require__.n(keys);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/extends.js
var esm_extends = __webpack_require__("kOwS");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/classCallCheck.js
var classCallCheck = __webpack_require__("0iUn");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/createClass.js
var createClass = __webpack_require__("sLSF");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/possibleConstructorReturn.js + 1 modules
var possibleConstructorReturn = __webpack_require__("MI3g");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/getPrototypeOf.js
var getPrototypeOf = __webpack_require__("a7VT");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/assertThisInitialized.js
var assertThisInitialized = __webpack_require__("AT/M");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/inherits.js + 1 modules
var inherits = __webpack_require__("Tit0");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/defineProperty.js
var defineProperty = __webpack_require__("vYYK");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/assign.js
var object_assign = __webpack_require__("UXZV");
var assign_default = /*#__PURE__*/__webpack_require__.n(object_assign);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/objectSpread.js
var objectSpread = __webpack_require__("zrwo");

// EXTERNAL MODULE: external "flystore"
var external_flystore_ = __webpack_require__("kJFy");
var external_flystore_default = /*#__PURE__*/__webpack_require__.n(external_flystore_);

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__("cDcd");
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);

// EXTERNAL MODULE: external "object.pick"
var external_object_pick_ = __webpack_require__("6RRd");
var external_object_pick_default = /*#__PURE__*/__webpack_require__.n(external_object_pick_);

// EXTERNAL MODULE: external "less-vars-to-js"
var external_less_vars_to_js_ = __webpack_require__("bPsq");
var external_less_vars_to_js_default = /*#__PURE__*/__webpack_require__.n(external_less_vars_to_js_);

// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__("4Q3z");
var router_default = /*#__PURE__*/__webpack_require__.n(router_);

// CONCATENATED MODULE: ./node_modules/raw-loader/dist/cjs.js!./assets/custom.less
/* harmony default export */ var custom = ("\n// https://github.com/ant-design/ant-design/blob/master/components/style/themes/default.less\n@import (reference) \"~antd/lib/style/themes/default.less\";\n@import (reference) \"~antd/lib/style/mixins/index.less\";\n@import (reference) \"./easings/index.less\";\n\n@gray-1: #ffffff;\n@gray-2: #fafafa;\n@gray-3: #f5f5f5;\n@gray-4: #e8e8e8;\n@gray-5: #d9d9d9;\n@gray-6: #bfbfbf;\n@gray-7: #8c8c8c;\n@gray-8: #595959;\n@gray-9: #262626;\n@gray-10: #000000;\n\n// 暗黑\n@dark-1: rgba(0, 0, 0, .05);\n@dark-2: rgba(0, 0, 0, .15);\n@dark-3: rgba(0, 0, 0, .25);\n@dark-4: rgba(0, 0, 0, .35);\n@dark-5: rgba(0, 0, 0, .45);\n@dark-6: rgba(0, 0, 0, .55);\n@dark-7: rgba(0, 0, 0, .65);\n@dark-8: rgba(0, 0, 0, .75);\n@dark-9: rgba(0, 0, 0, .85);\n@dark-10: rgba(0, 0, 0, 1);\n\n// 亮白\n@light-1: rgba(255, 255, 255, .05);\n@light-2: rgba(255, 255, 255, .15);\n@light-3: rgba(255, 255, 255, .25);\n@light-4: rgba(255, 255, 255, .35);\n@light-5: rgba(255, 255, 255, .45);\n@light-6: rgba(255, 255, 255, .55);\n@light-7: rgba(255, 255, 255, .65);\n@light-8: rgba(255, 255, 255, .75);\n@light-9: rgba(255, 255, 255, .85);\n@light-10: rgba(255, 255, 255, 1);\n\n\n@mask-color: #001529;\n@footer-color: @light-8;\n@footer-link-color: @light-6;\n@footer-link-hover-color: @light-10;\n@footer-background-color: @dark-10;\n@header-background-color: #001529;\n@anchor-background-color: @light-10;\n@anchor-color: #1890ff;\n\n\n@dark-menu-color: @light-7;\n@dark-menu-background-color: @header-background-color;\n\n\n@anim-speed-1: 200ms;\n@anim-speed-2: 375ms;\n@anim-speed-3: 500ms;\n@anim-speed-4: 800ms;\n@anim-speed-5: 1200ms;\n\n\n@page-width: 980px;\n@page-width-lg: 1440px;\n@max-width: 1920px; // 2560px\n@header-height: 64px;\n@header-phone-height: 48px;\n@anchor-height: 48px;\n\n\n// z-index\n@header-zIndex: 1100;\n@anchor-zIndex: @header-zIndex - 10;\n\n// shadow\n@shadow-down: 0 2px 8px rgba(0, 0, 0, 0.08);\n@shadow-down-dark: 0 2px 8px rgba(0, 0, 0, 0.2);\n@shadow-down-sm: 4px 6px 10px rgba(0, 0, 0, 0.1);\n@shadow-down-lg: 8px 12px 20px rgba(0, 0, 0, 0.3);\n\n\n@main-color: #fa8c16;\n@main-background-color: #001529;\n@main-light-background-color: #f1f3ff;\n\n// .function {\n//   .foo(@x) {\n//     return: @x * 2;\n//   }\n// }");
// CONCATENATED MODULE: ./node_modules/raw-loader/dist/cjs.js!./assets/easings/index.less
/* harmony default export */ var easings = ("//https://easings.net/\n//http://cubic-bezier.com/#.17,.67,.83,.67\n@linear         : cubic-bezier(0.250, 0.250, 0.750, 0.750);\n@ease           : cubic-bezier(0.250, 0.100, 0.250, 1.000);\n@ease-in        : cubic-bezier(0.420, 0.000, 1.000, 1.000);\n@ease-out       : cubic-bezier(0.000, 0.000, 0.580, 1.000);\n@ease-in-out    : cubic-bezier(0.420, 0.000, 0.580, 1.000);\n\n@easeInQuad     : cubic-bezier(0.550, 0.085, 0.680, 0.530);\n@easeInCubic    : cubic-bezier(0.550, 0.055, 0.675, 0.190);\n@easeInQuart    : cubic-bezier(0.895, 0.030, 0.685, 0.220);\n@easeInQuint    : cubic-bezier(0.755, 0.050, 0.855, 0.060);\n@easeInSine     : cubic-bezier(0.470, 0.000, 0.745, 0.715);\n@easeInExpo     : cubic-bezier(0.950, 0.050, 0.795, 0.035);\n@easeInCirc     : cubic-bezier(0.600, 0.040, 0.980, 0.335);\n@easeInBack     : cubic-bezier(0.600, -0.280, 0.735, 0.045);\n\n@easeOutQuad    : cubic-bezier(0.250, 0.460, 0.450, 0.940);\n@easeOutCubic   : cubic-bezier(0.215, 0.610, 0.355, 1.000);\n@easeOutQuart   : cubic-bezier(0.165, 0.840, 0.440, 1.000);\n@easeOutQuint   : cubic-bezier(0.230, 1.000, 0.320, 1.000);\n@easeOutSine    : cubic-bezier(0.390, 0.575, 0.565, 1.000);\n@easeOutExpo    : cubic-bezier(0.190, 1.000, 0.220, 1.000);\n@easeOutCirc    : cubic-bezier(0.075, 0.820, 0.165, 1.000);\n@easeOutBack    : cubic-bezier(0.175, 0.885, 0.320, 1.275);\n\n@easeInOutQuad  : cubic-bezier(0.455, 0.030, 0.515, 0.955);\n@easeInOutCubic : cubic-bezier(0.645, 0.045, 0.355, 1.000);\n@easeInOutQuart : cubic-bezier(0.770, 0.000, 0.175, 1.000);\n@easeInOutQuint : cubic-bezier(0.860, 0.000, 0.070, 1.000);\n@easeInOutSine  : cubic-bezier(0.445, 0.050, 0.550, 0.950);\n@easeInOutExpo  : cubic-bezier(1.000, 0.000, 0.000, 1.000);\n@easeInOutCirc  : cubic-bezier(0.785, 0.135, 0.150, 0.860);\n@easeInOutBack  : cubic-bezier(0.680, -0.550, 0.265, 1.550);\n");
// CONCATENATED MODULE: ./components/Themes/index.js
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return themeVariables; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return themeEasings; });
/* unused harmony export defaultThemeConfig */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return Themes_setTheme; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "e", function() { return withTheme; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ThemeContext; });


















var themeVariables = external_less_vars_to_js_default()(custom, {
  resolveVariables: true
});
var themeEasings = external_less_vars_to_js_default()(easings, {
  resolveVariables: true
});
var defaultThemeConfig = {
  footer: true,
  header: true
};
var storeTheme = external_flystore_default()('@theme-config');
storeTheme.set('config', Object(objectSpread["a" /* default */])({}, defaultThemeConfig));
storeTheme.set('change', {});
var Themes_setTheme = function setTheme(config, changeRoute) {
  var route = router_default.a.router.route;

  if (changeRoute && changeRoute !== route) {
    var themeConfig = storeTheme.get("change-".concat(changeRoute));
    storeTheme.set("change-".concat(changeRoute), assign_default()({}, themeConfig, config));
  } else {
    var _themeConfig = storeTheme.get("change-".concat(route));

    var newConfig = assign_default()({}, _themeConfig, config);

    storeTheme.set("change-".concat(route), newConfig);
    storeTheme.dispense('change', newConfig);
  }
};
function withTheme(Comp) {
  var _class, _temp;

  return Object(router_["withRouter"])((_temp = _class =
  /*#__PURE__*/
  function (_React$Component) {
    Object(inherits["a" /* default */])(WithTheme, _React$Component);

    function WithTheme() {
      var _getPrototypeOf2;

      var _this;

      Object(classCallCheck["a" /* default */])(this, WithTheme);

      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }

      _this = Object(possibleConstructorReturn["a" /* default */])(this, (_getPrototypeOf2 = Object(getPrototypeOf["a" /* default */])(WithTheme)).call.apply(_getPrototypeOf2, [this].concat(args)));

      Object(defineProperty["a" /* default */])(Object(assertThisInitialized["a" /* default */])(_this), "state", {
        themeConfig: storeTheme.get('config')
      });

      return _this;
    }

    Object(createClass["a" /* default */])(WithTheme, [{
      key: "componentDidMount",
      value: function componentDidMount() {
        var _this2 = this;

        var route = this.props.router.route;
        var changeConfig = storeTheme.get("change-".concat(route));

        if (changeConfig) {
          this.setState({
            themeConfig: assign_default()(storeTheme.get('config'), changeConfig)
          });
        }

        this.configHandle = storeTheme.watch('change', function (themeConfig) {
          _this2.setState({
            themeConfig: assign_default()(storeTheme.get('config'), themeConfig)
          });
        });
      }
    }, {
      key: "componentWillUnmount",
      value: function componentWillUnmount() {
        if (this.configHandle) {
          this.configHandle.clear();
          this.configHandle = null;
        }
      }
    }, {
      key: "render",
      value: function render() {
        return external_react_default.a.createElement(Comp, Object(esm_extends["a" /* default */])({}, this.props, {
          themeConfig: this.state.themeConfig
        }));
      }
    }]);

    return WithTheme;
  }(external_react_default.a.Component), Object(defineProperty["a" /* default */])(_class, "getDerivedStateFromProps", function (props) {
    var route = props.router.route;

    var newConfig = assign_default()({}, defaultThemeConfig, external_object_pick_default()(props, keys_default()(defaultThemeConfig)));

    var changeConfig = storeTheme.get("change-".concat(route));
    return {
      themeConfig: assign_default()(newConfig, changeConfig)
    };
  }), _temp));
}
var ThemeContext = external_react_default.a.createContext({
  env: {},
  themeConfig: Object(objectSpread["a" /* default */])({}, defaultThemeConfig),
  themeEasings: themeEasings,
  themeVariables: themeVariables,
  isLoaded: false,
  isMobile: false
});

/***/ }),

/***/ "sLSF":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _createClass; });
/* harmony import */ var _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("hfKm");
/* harmony import */ var _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__);


function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;

    _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default()(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

/***/ }),

/***/ "ushU":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return requestAnimationFrame; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return cancelAnimationFrame; });
var suffix = 'AnimationFrame';
var vendors = ['', 'moz', 'webkit'];

var getAFFunc = function getAFFunc(name) {
  var func = null;
  return function () {
    if (func) {
      return func.apply(void 0, arguments);
    }

    var win = window;

    for (var i = 0, l = vendors.length; i < l; i++) {
      var prefix = vendors[i];
      var funcName = name + suffix;

      if (prefix) {
        funcName = prefix + funcName.charAt(0).toUpperCase() + funcName.slice(1);
      }

      func = win[funcName];

      if (func) {
        break;
      }
    }

    return func ? func.apply(void 0, arguments) : func;
  };
};

var requestAnimationFrame = getAFFunc('request');
var cancelFunc = getAFFunc('cancel');
var cancelRequestFunc = getAFFunc('cancelRequest');
var cancelAnimationFrame = function cancelAnimationFrame() {
  return cancelFunc.apply(void 0, arguments) || cancelRequestFunc.apply(void 0, arguments);
};

/***/ }),

/***/ "vYYK":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _defineProperty; });
/* harmony import */ var _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("hfKm");
/* harmony import */ var _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__);

function _defineProperty(obj, key, value) {
  if (key in obj) {
    _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default()(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}

/***/ }),

/***/ "vqFK":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/symbol");

/***/ }),

/***/ "zrwo":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _objectSpread; });
/* harmony import */ var _core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("Jo+v");
/* harmony import */ var _core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("4mXO");
/* harmony import */ var _core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _core_js_object_keys__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("pLtp");
/* harmony import */ var _core_js_object_keys__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_keys__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _defineProperty__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("vYYK");




function _objectSpread(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i] != null ? arguments[i] : {};

    var ownKeys = _core_js_object_keys__WEBPACK_IMPORTED_MODULE_2___default()(source);

    if (typeof _core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1___default.a === 'function') {
      ownKeys = ownKeys.concat(_core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1___default()(source).filter(function (sym) {
        return _core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_0___default()(source, sym).enumerable;
      }));
    }

    ownKeys.forEach(function (key) {
      Object(_defineProperty__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"])(target, key, source[key]);
    });
  }

  return target;
}

/***/ })

/******/ });