module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../../../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 16);
/******/ })
/************************************************************************/
/******/ ({

/***/ "+ys9":
/***/ (function(module, exports) {

module.exports = require("rc-util/lib/Dom/css");

/***/ }),

/***/ "/+oN":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/get-prototype-of");

/***/ }),

/***/ "0iUn":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _classCallCheck; });
function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

/***/ }),

/***/ 16:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("KMZ8");


/***/ }),

/***/ "4Q3z":
/***/ (function(module, exports) {

module.exports = require("next/router");

/***/ }),

/***/ "4mXO":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("k1wZ");

/***/ }),

/***/ "5kjc":
/***/ (function(module, exports) {

module.exports = "/_next/static/images/banner-2-8da8e4b9d03ca5c3159b0163966e4067.jpg";

/***/ }),

/***/ "6RRd":
/***/ (function(module, exports) {

module.exports = require("object.pick");

/***/ }),

/***/ "AT/M":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _assertThisInitialized; });
function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

/***/ }),

/***/ "BE5S":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return Icon; });
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("kOwS");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("qNsG");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("K2gz");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _svgIcon_less__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("flPq");
/* harmony import */ var _svgIcon_less__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_svgIcon_less__WEBPACK_IMPORTED_MODULE_4__);





function Icon(_ref) {
  var icon = _ref.icon,
      className = _ref.className,
      props = Object(_babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(_ref, ["icon", "className"]);

  return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("svg", Object(_babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])({
    "aria-hidden": "true"
  }, props, {
    className: classnames__WEBPACK_IMPORTED_MODULE_3___default()(_svgIcon_less__WEBPACK_IMPORTED_MODULE_4___default.a.svgIcon, className)
  }), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("use", {
    xlinkHref: "#".concat(icon.id)
  }));
}

/***/ }),

/***/ "BI0l":
/***/ (function(module, exports) {

module.exports = require("rc-util/lib/Dom/addEventListener");

/***/ }),

/***/ "Bhuq":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("/+oN");

/***/ }),

/***/ "CK/I":
/***/ (function(module, exports) {



/***/ }),

/***/ "Ggtc":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("0iUn");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("sLSF");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("MI3g");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("a7VT");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("Tit0");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _section3_less__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("f4fG");
/* harmony import */ var _section3_less__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_section3_less__WEBPACK_IMPORTED_MODULE_6__);







var adv = [{
  key: '1',
  title: '为能源计量提供数据基础',
  content: ''
}, {
  key: '2',
  title: '为节能减排提供管控平台',
  content: ''
}, {
  key: '3',
  title: '为节能控制提供有效手段',
  content: ''
}, {
  key: '4',
  title: '为用能决策提供科学依据',
  content: ''
}, {
  key: '5',
  title: '为科学管理提供技术支撑',
  content: ''
}, {
  key: '6',
  title: '为统计分析提供科学方法',
  content: ''
}];

var Section =
/*#__PURE__*/
function (_React$Component) {
  Object(_babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_4__[/* default */ "a"])(Section, _React$Component);

  function Section() {
    Object(_babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(this, Section);

    return Object(_babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__[/* default */ "a"])(this, Object(_babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"])(Section).apply(this, arguments));
  }

  Object(_babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(Section, [{
    key: "render",
    value: function render() {
      return react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: _section3_less__WEBPACK_IMPORTED_MODULE_6___default.a.wrap
      }, adv.map(function (_ref) {
        var key = _ref.key,
            title = _ref.title,
            content = _ref.content;
        return react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
          key: key
        }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
          className: _section3_less__WEBPACK_IMPORTED_MODULE_6___default.a.blockTitle
        }, title), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
          className: _section3_less__WEBPACK_IMPORTED_MODULE_6___default.a.blockContent
        }, content));
      }));
    }
  }]);

  return Section;
}(react__WEBPACK_IMPORTED_MODULE_5___default.a.Component);

/* harmony default export */ __webpack_exports__["default"] = (Section);

/***/ }),

/***/ "J3/a":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/get-iterator");

/***/ }),

/***/ "Jo+v":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("Z6Kq");

/***/ }),

/***/ "K2gz":
/***/ (function(module, exports) {

module.exports = require("classnames");

/***/ }),

/***/ "KMZ8":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("pLtp");
/* harmony import */ var _babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("ln6h");
/* harmony import */ var _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("O40h");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("doui");
/* harmony import */ var _babel_runtime_corejs2_core_js_object_entries__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("LR/J");
/* harmony import */ var _babel_runtime_corejs2_core_js_object_entries__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_core_js_object_entries__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_objectSpread__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("zrwo");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("0iUn");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__("sLSF");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__("MI3g");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__("a7VT");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__("AT/M");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__("Tit0");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__("vYYK");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__("K2gz");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__("4Q3z");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__("+ys9");
/* harmony import */ var rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _components_Themes__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__("qRXU");
/* harmony import */ var _lib_requestAnimationFrame__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__("ushU");
/* harmony import */ var _assets_images_scene_banner_1_jpg__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__("hks1");
/* harmony import */ var _assets_images_scene_banner_1_jpg__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(_assets_images_scene_banner_1_jpg__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var _assets_images_scene_banner_2_jpg__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__("5kjc");
/* harmony import */ var _assets_images_scene_banner_2_jpg__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(_assets_images_scene_banner_2_jpg__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var _assets_images_scene_banner_3_jpg__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__("lCau");
/* harmony import */ var _assets_images_scene_banner_3_jpg__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(_assets_images_scene_banner_3_jpg__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var _assets_images_scene_banner_4_jpg__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__("l1Fa");
/* harmony import */ var _assets_images_scene_banner_4_jpg__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(_assets_images_scene_banner_4_jpg__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var _scene1__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__("WiSE");
/* harmony import */ var _scene2__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__("qEgx");
/* harmony import */ var _scene3__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__("n/KK");
/* harmony import */ var _scene4__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__("xExG");
/* harmony import */ var _scene_less__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__("nV/z");
/* harmony import */ var _scene_less__WEBPACK_IMPORTED_MODULE_27___default = /*#__PURE__*/__webpack_require__.n(_scene_less__WEBPACK_IMPORTED_MODULE_27__);














var _class, _class2, _temp;
















var images = [_assets_images_scene_banner_1_jpg__WEBPACK_IMPORTED_MODULE_19___default.a, _assets_images_scene_banner_2_jpg__WEBPACK_IMPORTED_MODULE_20___default.a, _assets_images_scene_banner_3_jpg__WEBPACK_IMPORTED_MODULE_21___default.a, _assets_images_scene_banner_4_jpg__WEBPACK_IMPORTED_MODULE_22___default.a];
var scenes = [{
  as: '/scene/1',
  url: '/scene?id=1',
  name: '智慧能源'
}, {
  as: '/scene/2',
  url: '/scene?id=2',
  name: '智慧校园'
}, {
  as: '/scene/3',
  url: '/scene?id=3',
  name: '智慧建筑'
}, {
  as: '/scene/4',
  url: '/scene?id=4',
  name: '智慧园区'
}];

var Scene = Object(next_router__WEBPACK_IMPORTED_MODULE_15__["withRouter"])(_class = (_temp = _class2 =
/*#__PURE__*/
function (_React$Component) {
  Object(_babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_11__[/* default */ "a"])(Scene, _React$Component);

  function Scene(props) {
    var _this;

    Object(_babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_6__[/* default */ "a"])(this, Scene);

    _this = Object(_babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_8__[/* default */ "a"])(this, Object(_babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_9__[/* default */ "a"])(Scene).call(this, props));

    Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_12__[/* default */ "a"])(Object(_babel_runtime_corejs2_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_10__[/* default */ "a"])(_this), "handleClick", function (_ref) {
      var index = _ref.index,
          title = _ref.title,
          image = _ref.image,
          className = _ref.className;
      return function (_ref2) {
        var currentTarget = _ref2.currentTarget;
        var selected = _this.state.selected;

        if (!selected.animIn && !selected.animating) {
          _this.state.selected = {
            // eslint-disable-line
            index: index,
            title: title,
            image: image,
            className: className,
            dom: currentTarget
          };

          _this.forceUpdate(function () {
            next_router__WEBPACK_IMPORTED_MODULE_15___default.a.push("/scene?id=".concat(index), "/scene/".concat(index), {
              shallow: true
            });
          });
        }
      };
    });

    Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_12__[/* default */ "a"])(Object(_babel_runtime_corejs2_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_10__[/* default */ "a"])(_this), "handleImageLoad", function () {
      var selected = _this.state.selected;
      var position = selected.dom.getBoundingClientRect();

      var fixedStyle = _this.getBlockStyle(position);

      var viewSize = {
        width: Object(rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_16__["get"])(_this.viewRef.current, 'width'),
        height: Object(rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_16__["get"])(_this.viewRef.current, 'height')
      };

      var imageSize = _this.getImageSize(viewSize);

      var fixedImageStyle = Object(_babel_runtime_corejs2_helpers_esm_objectSpread__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"])({}, _this.getImageStyle(imageSize, position, 0.75));

      var fixedLastStyle = {
        transition: _this.getTransition(true),
        transform: 'translateX(0) translateY(0) translateZ(0)',
        height: '100vh',
        width: '100vw'
      };
      var fixedImageLastStyle = {
        transition: _this.getImageTransition(true),
        transform: _this.getImageCoverTransform(imageSize, viewSize)
      };
      _this.state.selected = Object(_babel_runtime_corejs2_helpers_esm_objectSpread__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"])({}, selected, {
        animating: true,
        animIn: true
      }); // eslint-disable-line

      _this.forceUpdate(function () {
        Object(rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_16__["set"])(_this.pageRef.current, fixedStyle);
        Object(rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_16__["set"])(_this.pageImageRef.current, fixedImageStyle); // 火狐延迟一帧

        Object(_lib_requestAnimationFrame__WEBPACK_IMPORTED_MODULE_18__[/* requestAnimationFrame */ "b"])(function () {
          Object(_lib_requestAnimationFrame__WEBPACK_IMPORTED_MODULE_18__[/* requestAnimationFrame */ "b"])(function () {
            Object(rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_16__["set"])(_this.pageRef.current, fixedLastStyle);
            Object(rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_16__["set"])(_this.pageImageRef.current, fixedImageLastStyle);
          });
        });
      });
    });

    Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_12__[/* default */ "a"])(Object(_babel_runtime_corejs2_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_10__[/* default */ "a"])(_this), "handleBack", function () {
      var selected = _this.state.selected;

      if (selected.animIn && !selected.animating) {
        var position = selected.dom.getBoundingClientRect();
        var viewSize = {
          width: Object(rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_16__["get"])(_this.viewRef.current, 'width'),
          height: Object(rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_16__["get"])(_this.viewRef.current, 'height')
        };

        var imageSize = _this.getImageSize(viewSize);

        var fixedStyle = {
          width: '100vw',
          height: '100vh',
          transform: "translateX(0) translateY(0) translateZ(0)"
        };

        var fixedImageStyle = Object(_babel_runtime_corejs2_helpers_esm_objectSpread__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"])({}, _this.getImageStyle(imageSize, viewSize));

        var fixedLastStyle = {
          width: "".concat(position.width, "px"),
          height: "".concat(position.height, "px"),
          transition: _this.getTransition(false),
          transform: "translateX(".concat(position.left, "px) translateY(").concat(position.top, "px) translateZ(0)")
        };
        var fixedImageLastStyle = {
          transition: _this.getImageTransition(false),
          transform: _this.getImageCoverTransform(imageSize, position, 0.75)
        };
        _this.state.selected = Object(_babel_runtime_corejs2_helpers_esm_objectSpread__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"])({}, selected, {
          animating: true,
          animIn: false
        }); // eslint-disable-line

        _this.forceUpdate(function () {
          Object(rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_16__["set"])(_this.pageRef.current, fixedStyle);
          Object(rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_16__["set"])(_this.pageImageRef.current, fixedImageStyle);
          Object(_lib_requestAnimationFrame__WEBPACK_IMPORTED_MODULE_18__[/* requestAnimationFrame */ "b"])(function () {
            Object(_lib_requestAnimationFrame__WEBPACK_IMPORTED_MODULE_18__[/* requestAnimationFrame */ "b"])(function () {
              Object(rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_16__["set"])(_this.pageRef.current, fixedLastStyle);
              Object(rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_16__["set"])(_this.pageImageRef.current, fixedImageLastStyle);
            });
          });
        });
      }
    });

    Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_12__[/* default */ "a"])(Object(_babel_runtime_corejs2_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_10__[/* default */ "a"])(_this), "handleTransitionEnd", function (animIn) {
      return function (e) {
        var selected = _this.state.selected;
        var isTransform = e.nativeEvent.propertyName === 'transform';
        var isOpacity = e.nativeEvent.propertyName === 'opacity';

        if (e.target === e.currentTarget) {
          e.preventDefault();
          e.stopPropagation();
        }

        if (isOpacity && e.target === e.currentTarget) {
          _this.state.selected = {}; // eslint-disable-line

          Object(_lib_requestAnimationFrame__WEBPACK_IMPORTED_MODULE_18__[/* requestAnimationFrame */ "b"])(function () {
            _this.pageRef.current.removeAttribute('style');

            _this.pageImageRef.current.removeAttribute('style');

            _this.forceUpdate();
          });
        } else if (selected.animating && e.target === e.currentTarget) {
          if (isTransform) {
            if (animIn) {
              _this.state.selected = Object(_babel_runtime_corejs2_helpers_esm_objectSpread__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"])({}, selected, {
                animating: false
              }); // eslint-disable-line

              _this.setState({
                index: selected.index
              }, function () {
                Object(_lib_requestAnimationFrame__WEBPACK_IMPORTED_MODULE_18__[/* requestAnimationFrame */ "b"])(function () {
                  _this.pageRef.current.setAttribute('style', 'height:100vh;width:100vw;');
                });
              });
            } else {
              _this.setState({
                index: 0,
                toBack: false
              }, function () {
                Object(_lib_requestAnimationFrame__WEBPACK_IMPORTED_MODULE_18__[/* requestAnimationFrame */ "b"])(function () {
                  Object(rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_16__["set"])(_this.pageRef.current, {
                    opacity: 0.001
                  });
                });
              });
            }
          }
        }
      };
    });

    Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_12__[/* default */ "a"])(Object(_babel_runtime_corejs2_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_10__[/* default */ "a"])(_this), "getTransition", function (isIn) {
      var _this$context = _this.context,
          themeVariables = _this$context.themeVariables,
          themeEasings = _this$context.themeEasings;
      var animSpeed = themeVariables['@anim-speed-3'].replace('ms', '');
      var ease = isIn ? themeEasings['@easeOutExpo'] : themeEasings['@easeOutCirc'];
      return _babel_runtime_corejs2_core_js_object_entries__WEBPACK_IMPORTED_MODULE_4___default()({
        width: {
          ease: ease,
          duration: animSpeed
        },
        height: {
          ease: ease,
          duration: animSpeed
        },
        transform: {
          ease: ease,
          duration: animSpeed
        },
        opacity: {
          ease: '',
          duration: animSpeed / 4
        }
      }).map(function (_ref3) {
        var _ref4 = Object(_babel_runtime_corejs2_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"])(_ref3, 2),
            property = _ref4[0],
            _ref4$ = _ref4[1],
            ease = _ref4$.ease,
            duration = _ref4$.duration;

        return "".concat(property, " ").concat(duration, "ms ").concat(ease);
      }).join(',');
    });

    Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_12__[/* default */ "a"])(Object(_babel_runtime_corejs2_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_10__[/* default */ "a"])(_this), "getImageTransition", function (isIn) {
      var _this$context2 = _this.context,
          themeVariables = _this$context2.themeVariables,
          themeEasings = _this$context2.themeEasings;
      var animSpeed = themeVariables['@anim-speed-3'].replace('ms', '');
      return _babel_runtime_corejs2_core_js_object_entries__WEBPACK_IMPORTED_MODULE_4___default()({
        transform: {
          ease: isIn ? themeEasings['@easeOutCirc'] : themeEasings['@easeOutExpo'],
          duration: animSpeed
        }
      }).map(function (_ref5) {
        var _ref6 = Object(_babel_runtime_corejs2_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"])(_ref5, 2),
            property = _ref6[0],
            _ref6$ = _ref6[1],
            ease = _ref6$.ease,
            duration = _ref6$.duration;

        return "".concat(property, " ").concat(duration, "ms ").concat(ease);
      }).join(',');
    });

    Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_12__[/* default */ "a"])(Object(_babel_runtime_corejs2_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_10__[/* default */ "a"])(_this), "getBlockStyle", function (position) {
      return {
        width: "".concat(position.width, "px"),
        height: "".concat(position.height, "px"),
        transform: "translateX(".concat(position.left, "px) translateY(").concat(position.top, "px) translateZ(0)")
      };
    });

    Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_12__[/* default */ "a"])(Object(_babel_runtime_corejs2_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_10__[/* default */ "a"])(_this), "getImageSize", function (cover) {
      var image = _this.pageImageRef.current;

      var _ref7 = cover || Object(rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_16__["getClientSize"])(),
          width = _ref7.width,
          height = _ref7.height;

      var imageRatio = image.width / image.height;
      var targetRatio = width / height;
      return {
        width: imageRatio > targetRatio ? imageRatio * height : width,
        height: imageRatio > targetRatio ? height : width / imageRatio
      };
    });

    Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_12__[/* default */ "a"])(Object(_babel_runtime_corejs2_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_10__[/* default */ "a"])(_this), "getImageStyle", function (coverSize, target, percent) {
      return Object(_babel_runtime_corejs2_helpers_esm_objectSpread__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"])({}, coverSize, {
        transform: _this.getImageCoverTransform(coverSize, target, percent)
      });
    });

    Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_12__[/* default */ "a"])(Object(_babel_runtime_corejs2_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_10__[/* default */ "a"])(_this), "getImageCoverTransform", function (image, target) {
      var percent = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 0.5;
      var imageRatio = image.width / image.height;
      var targetRatio = target.width / target.height;

      if (imageRatio > targetRatio) {
        var _scale = target.height / image.height;

        var imageWidth = image.width * _scale;
        var w = (imageWidth - target.width) * -percent;
        return "translateX(".concat(w, "px) translateY(0) translateZ(0) scale(").concat(Math.ceil(_scale * 1000) / 1000, ")");
      }

      var scale = target.width / image.width;
      var imageHeight = image.height * scale;
      var h = (imageHeight - target.height) * -percent;
      return "translateX(0) translateY(".concat(h, "px) translateZ(0) scale(").concat(Math.ceil(scale * 1000) / 1000, ")");
    });

    var router = _this.props.router;

    var _index = ~~router.query.id;

    _this.state = {
      toBack: false,
      toFront: false,
      index: _index || 0,
      animating: false,
      selected: {}
    };
    _this.viewRef = react__WEBPACK_IMPORTED_MODULE_13___default.a.createRef();
    _this.pageRef = react__WEBPACK_IMPORTED_MODULE_13___default.a.createRef();
    _this.pageFontRef = react__WEBPACK_IMPORTED_MODULE_13___default.a.createRef();
    _this.pageImageRef = react__WEBPACK_IMPORTED_MODULE_13___default.a.createRef();
    _this.sceneRef = react__WEBPACK_IMPORTED_MODULE_13___default.a.createRef();
    return _this;
  }

  Object(_babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_7__[/* default */ "a"])(Scene, [{
    key: "componentDidUpdate",
    value: function componentDidUpdate(prevProps_, prevState) {
      var _this$state = this.state,
          toBack = _this$state.toBack,
          toFront = _this$state.toFront,
          selected = _this$state.selected;

      if (!prevState.toBack && toBack) {
        this.setState({
          toBack: false,
          selected: Object(_babel_runtime_corejs2_helpers_esm_objectSpread__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"])({}, selected, {
            dom: this.sceneRef.current
          })
        }, this.handleBack);
      }

      if (!prevState.toFront && toFront) {
        this.setState({
          toFront: false,
          selected: Object(_babel_runtime_corejs2_helpers_esm_objectSpread__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"])({}, selected, {
            dom: this.sceneRef.current
          })
        });
      }
    }
  }, {
    key: "render",
    value: function render() {
      var _classnames,
          _this2 = this,
          _classnames3;

      var _this$state2 = this.state,
          index = _this$state2.index,
          selected = _this$state2.selected;
      return react__WEBPACK_IMPORTED_MODULE_13___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_13___default.a.Fragment, null, react__WEBPACK_IMPORTED_MODULE_13___default.a.createElement("section", {
        ref: this.viewRef,
        className: classnames__WEBPACK_IMPORTED_MODULE_14___default()(_scene_less__WEBPACK_IMPORTED_MODULE_27___default.a.view, _scene_less__WEBPACK_IMPORTED_MODULE_27___default.a.sceneBanner)
      }, react__WEBPACK_IMPORTED_MODULE_13___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_14___default()(_scene_less__WEBPACK_IMPORTED_MODULE_27___default.a.solutions, (_classnames = {}, Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_12__[/* default */ "a"])(_classnames, _scene_less__WEBPACK_IMPORTED_MODULE_27___default.a.solutionHover, !selected.animating && !selected.animIn), Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_12__[/* default */ "a"])(_classnames, _scene_less__WEBPACK_IMPORTED_MODULE_27___default.a.unVisibility, selected.animIn && !selected.animating), Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_12__[/* default */ "a"])(_classnames, 'no-events', selected.animating || selected.animIn), _classnames))
      }, scenes.map(function (_ref8, index) {
        var name = _ref8.name;
        return react__WEBPACK_IMPORTED_MODULE_13___default.a.createElement("div", {
          key: name,
          ref: index + 1 === selected.index ? _this2.sceneRef : null,
          onClick: _this2.handleClick({
            title: name,
            index: index + 1,
            image: images[index],
            className: _scene_less__WEBPACK_IMPORTED_MODULE_27___default.a["sceneBanner".concat(index + 1)]
          }),
          className: classnames__WEBPACK_IMPORTED_MODULE_14___default()(_scene_less__WEBPACK_IMPORTED_MODULE_27___default.a.solutionBlock, _scene_less__WEBPACK_IMPORTED_MODULE_27___default.a["sceneBanner".concat(index + 1)], Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_12__[/* default */ "a"])({}, _scene_less__WEBPACK_IMPORTED_MODULE_27___default.a.unVisibility, selected.animIn ? selected.index === index + 1 && (selected.animating || selected.animIn) : selected.index === index + 1 && _this2.state.index !== 0))
        }, react__WEBPACK_IMPORTED_MODULE_13___default.a.createElement("h2", {
          className: _scene_less__WEBPACK_IMPORTED_MODULE_27___default.a.solutionBlockTitle
        }, name));
      }))), react__WEBPACK_IMPORTED_MODULE_13___default.a.createElement("div", {
        ref: this.pageRef,
        onTransitionEnd: this.handleTransitionEnd(selected.animIn),
        className: classnames__WEBPACK_IMPORTED_MODULE_14___default()(_scene_less__WEBPACK_IMPORTED_MODULE_27___default.a.solutionBlockContainer, {
          'no-events': selected.animating
        })
      }, react__WEBPACK_IMPORTED_MODULE_13___default.a.createElement("img", {
        alt: "",
        src: selected.image,
        ref: this.pageImageRef,
        onLoad: !selected.animIn ? this.handleImageLoad : null,
        style: selected.animIn && !selected.animating ? {
          display: 'none'
        } : {},
        className: _scene_less__WEBPACK_IMPORTED_MODULE_27___default.a.solutionBlockContainerImage
      }), react__WEBPACK_IMPORTED_MODULE_13___default.a.createElement("h2", {
        ref: this.pageFontRef,
        className: classnames__WEBPACK_IMPORTED_MODULE_14___default()(_scene_less__WEBPACK_IMPORTED_MODULE_27___default.a.solutionBlockTitle, (_classnames3 = {}, Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_12__[/* default */ "a"])(_classnames3, _scene_less__WEBPACK_IMPORTED_MODULE_27___default.a.hidden, selected.animIn && !selected.animating), Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_12__[/* default */ "a"])(_classnames3, _scene_less__WEBPACK_IMPORTED_MODULE_27___default.a.transparent, selected.animIn && selected.animating), _classnames3))
      }, selected.title)), !selected.animating && selected.animIn ? index === 1 ? react__WEBPACK_IMPORTED_MODULE_13___default.a.createElement(_scene1__WEBPACK_IMPORTED_MODULE_23__["default"], {
        key: "1",
        router: this.props.router,
        bannerImage: selected.image
      }) : index === 2 ? react__WEBPACK_IMPORTED_MODULE_13___default.a.createElement(_scene2__WEBPACK_IMPORTED_MODULE_24__["default"], {
        key: "2",
        router: this.props.router,
        bannerImage: selected.image
      }) : index === 3 ? react__WEBPACK_IMPORTED_MODULE_13___default.a.createElement(_scene3__WEBPACK_IMPORTED_MODULE_25__["default"], {
        key: "3",
        router: this.props.router,
        bannerImage: selected.image
      }) : react__WEBPACK_IMPORTED_MODULE_13___default.a.createElement(_scene4__WEBPACK_IMPORTED_MODULE_26__["default"], {
        key: "4",
        router: this.props.router,
        bannerImage: selected.image
      }) : null);
    }
  }]);

  return Scene;
}(react__WEBPACK_IMPORTED_MODULE_13___default.a.Component), Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_12__[/* default */ "a"])(_class2, "contextType", _components_Themes__WEBPACK_IMPORTED_MODULE_17__[/* ThemeContext */ "a"]), Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_12__[/* default */ "a"])(_class2, "getInitialProps",
/*#__PURE__*/
function () {
  var _ref9 = Object(_babel_runtime_corejs2_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_2__[/* default */ "a"])(
  /*#__PURE__*/
  _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_1___default.a.mark(function _callee(ctx_) {
    var layoutProps;
    return _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_1___default.a.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            layoutProps = {
              header: {
                transparent: true
              },
              footer: false,
              pageProps: {
                scrollClass: {
                  '>=0': 'page-header-hold',
                  '>=100vh-64': 'page-header-dark banner-menu-fixed'
                }
              },
              title: '解决方案'
            };
            return _context.abrupt("return", {
              layoutProps: layoutProps
            });

          case 2:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));

  return function (_x) {
    return _ref9.apply(this, arguments);
  };
}()), Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_12__[/* default */ "a"])(_class2, "getDerivedStateFromProps", function (props, state) {
  // 参数 category: >=1&<=6
  var router = props.router;
  var index = ~~router.query.id;

  if (index > 0 && index <= scenes.length) {
    if (state.index === 0 && _babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_0___default()(state.selected).length) {
      return null;
    } else if (state.index === 0) {
      return {
        toFront: true,
        selected: {
          index: index,
          title: scenes[index - 1].name,
          image: images[index - 1],
          className: _scene_less__WEBPACK_IMPORTED_MODULE_27___default.a["sceneBanner".concat(index)],
          dom: null
        }
      };
    }

    return {
      index: index,
      selected: {
        index: index,
        title: scenes[index - 1].name,
        image: images[index - 1],
        className: _scene_less__WEBPACK_IMPORTED_MODULE_27___default.a["sceneBanner".concat(index)],
        animIn: true,
        animating: false,
        dom: null
      }
    };
  } else if (state.index !== index && index === 0) {
    return !state.toBack ? {
      toBack: true
    } : null;
  } else if (router.query.category) {
    next_router__WEBPACK_IMPORTED_MODULE_15___default.a.replace('/scene', '/scene', {
      shallow: true
    });
  }

  return null;
}), _temp)) || _class;

/* harmony default export */ __webpack_exports__["default"] = (Scene);

/***/ }),

/***/ "LR/J":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("SWa5");

/***/ }),

/***/ "MI3g":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/symbol/iterator.js
var iterator = __webpack_require__("XVgq");
var iterator_default = /*#__PURE__*/__webpack_require__.n(iterator);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/symbol.js
var symbol = __webpack_require__("Z7t5");
var symbol_default = /*#__PURE__*/__webpack_require__.n(symbol);

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/typeof.js



function typeof_typeof2(obj) { if (typeof symbol_default.a === "function" && typeof iterator_default.a === "symbol") { typeof_typeof2 = function _typeof2(obj) { return typeof obj; }; } else { typeof_typeof2 = function _typeof2(obj) { return obj && typeof symbol_default.a === "function" && obj.constructor === symbol_default.a && obj !== symbol_default.a.prototype ? "symbol" : typeof obj; }; } return typeof_typeof2(obj); }

function typeof_typeof(obj) {
  if (typeof symbol_default.a === "function" && typeof_typeof2(iterator_default.a) === "symbol") {
    typeof_typeof = function _typeof(obj) {
      return typeof_typeof2(obj);
    };
  } else {
    typeof_typeof = function _typeof(obj) {
      return obj && typeof symbol_default.a === "function" && obj.constructor === symbol_default.a && obj !== symbol_default.a.prototype ? "symbol" : typeof_typeof2(obj);
    };
  }

  return typeof_typeof(obj);
}
// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/assertThisInitialized.js
var assertThisInitialized = __webpack_require__("AT/M");

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/possibleConstructorReturn.js
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _possibleConstructorReturn; });


function _possibleConstructorReturn(self, call) {
  if (call && (typeof_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return Object(assertThisInitialized["a" /* default */])(self);
}

/***/ }),

/***/ "MpZq":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("0iUn");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("sLSF");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("MI3g");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("a7VT");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("Tit0");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _section2_less__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("ZksH");
/* harmony import */ var _section2_less__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_section2_less__WEBPACK_IMPORTED_MODULE_6__);







var tableData = [{
  key: '1',
  col1: '驱动力',
  col2: '外部驱动力（政策和措施）',
  col3: '内部驱动力（机制和标准）'
}, {
  key: '2',
  col1: '目标',
  col2: '节能降耗',
  col3: '整体提高建筑和设施设备的能效、运行效率和使用寿命'
}, {
  key: '3',
  col1: '工作重点',
  col2: '能耗检测、水电管理',
  col3: '运行管理'
}, {
  key: '4',
  col1: '管理对象',
  col2: '各类能耗计量器具',
  col3: '各类基础设施和用能设备'
}, {
  key: '5',
  col1: '参与者',
  col2: '能源管理部门孤军奋战',
  col3: '能源管理部门和物业、安防、基建房产等工作相融合，转型升级，跨界发展'
}];

var Section =
/*#__PURE__*/
function (_React$Component) {
  Object(_babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_4__[/* default */ "a"])(Section, _React$Component);

  function Section() {
    Object(_babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(this, Section);

    return Object(_babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__[/* default */ "a"])(this, Object(_babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"])(Section).apply(this, arguments));
  }

  Object(_babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(Section, [{
    key: "render",
    value: function render() {
      return react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("table", {
        className: _section2_less__WEBPACK_IMPORTED_MODULE_6___default.a.table
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("thead", null, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("tr", {
        className: _section2_less__WEBPACK_IMPORTED_MODULE_6___default.a.tableHead
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("th", null), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("th", null, "\u80FD\u6E90\u7BA1\u7406 1.0"), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("th", null, "\u667A\u6167\u80FD\u6E90 2.0"))), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("tbody", null, tableData.map(function (data) {
        return react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("tr", {
          key: data.key
        }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("td", {
          className: _section2_less__WEBPACK_IMPORTED_MODULE_6___default.a.col1
        }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("span", {
          className: _section2_less__WEBPACK_IMPORTED_MODULE_6___default.a.chspan
        }, data.col1)), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("td", {
          className: _section2_less__WEBPACK_IMPORTED_MODULE_6___default.a.col2
        }, data.col2), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("td", {
          className: _section2_less__WEBPACK_IMPORTED_MODULE_6___default.a.col3
        }, data.col3));
      })));
    }
  }]);

  return Section;
}(react__WEBPACK_IMPORTED_MODULE_5___default.a.Component);

/* harmony default export */ __webpack_exports__["default"] = (Section);

/***/ }),

/***/ "Myvi":
/***/ (function(module, exports) {

module.exports = {
	"block": "_5hoKY83q",
	"block-banner": "_2M2PeaAF",
	"blockBanner": "_2M2PeaAF",
	"block-banner-mask": "pKloFejA",
	"blockBannerMask": "pKloFejA",
	"block-banner-image": "_2GIiRKka",
	"blockBannerImage": "_2GIiRKka",
	"block-banner-content": "_3_MrNw_9",
	"blockBannerContent": "_3_MrNw_9",
	"block-content": "_2PY1wS06",
	"blockContent": "_2PY1wS06",
	"dictum": "_3DGtQqP1",
	"dictum-text": "_1AOrjP_C",
	"dictumText": "_1AOrjP_C",
	"dictum-quote": "_3KfqH_m2",
	"dictumQuote": "_3KfqH_m2",
	"dictum-point": "v2ZXvUOd",
	"dictumPoint": "v2ZXvUOd",
	"platform": "KGkWtCuM"
};

/***/ }),

/***/ "O40h":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _asyncToGenerator; });
/* harmony import */ var _core_js_promise__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("eVuF");
/* harmony import */ var _core_js_promise__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_promise__WEBPACK_IMPORTED_MODULE_0__);


function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
  try {
    var info = gen[key](arg);
    var value = info.value;
  } catch (error) {
    reject(error);
    return;
  }

  if (info.done) {
    resolve(value);
  } else {
    _core_js_promise__WEBPACK_IMPORTED_MODULE_0___default.a.resolve(value).then(_next, _throw);
  }
}

function _asyncToGenerator(fn) {
  return function () {
    var self = this,
        args = arguments;
    return new _core_js_promise__WEBPACK_IMPORTED_MODULE_0___default.a(function (resolve, reject) {
      var gen = fn.apply(self, args);

      function _next(value) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
      }

      function _throw(err) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
      }

      _next(undefined);
    });
  };
}

/***/ }),

/***/ "QAmA":
/***/ (function(module, exports) {

module.exports = require("svg-baker-runtime/symbol");

/***/ }),

/***/ "R2Q7":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/array/is-array");

/***/ }),

/***/ "R92e":
/***/ (function(module, exports, __webpack_require__) {

/* eslint-disable */
var React = __webpack_require__("cDcd");
var SpriteSymbol = __webpack_require__("QAmA");
var sprite = __webpack_require__("TQFg");

var symbol = new SpriteSymbol({
  "id": "39F5vPyr--sprite",
  "use": "39F5vPyr--sprite-usage",
  "viewBox": "0 0 1195 1024",
  "content": "<symbol class=\"icon\" viewBox=\"0 0 1195 1024\" xmlns=\"http://www.w3.org/2000/svg\" id=\"39F5vPyr--sprite\"><defs><style></style></defs><path d=\"M1125.4 972.815H651.636V631.106c0-139.404 12.083-248.772 36.25-328.108 24.165-79.336 49.296-132.298 115.05-195.766C868.69 43.763 914.313 24.718 1010.828 0l67.428 145.03c-67.428 25.767-108.507 37.26-171.865 102.994-63.358 65.735-68.03 129.316-68.03 183.965h287.04v540.826zm-651.636 0H0V631.106c0-139.404 12.083-248.772 36.249-328.108 24.166-79.336 49.296-132.298 115.05-195.766C217.054 43.763 262.676 24.718 359.192 0l67.428 145.03c-67.428 25.767-108.507 37.26-171.865 102.994-63.358 65.735-68.031 129.316-68.031 183.965h287.04v540.826z\" /></symbol>"
});
sprite.add(symbol);

var SvgSpriteIcon = function SvgSpriteIcon(props) {
  return React.createElement(
    'svg',
    Object.assign({
      viewBox: symbol.viewBox
    }, props),
    React.createElement(
      'use',
      {
        xlinkHref: '#' + symbol.id
      }
    )
  );
};

SvgSpriteIcon.viewBox = symbol.viewBox;
SvgSpriteIcon.id = symbol.id;
SvgSpriteIcon.content = symbol.content;
SvgSpriteIcon.url = symbol.url;
SvgSpriteIcon.toString = symbol.toString;

module.exports = SvgSpriteIcon;
module.exports.default = SvgSpriteIcon;


/***/ }),

/***/ "SWa5":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/entries");

/***/ }),

/***/ "SqZg":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("o5io");

/***/ }),

/***/ "TNI3":
/***/ (function(module, exports) {



/***/ }),

/***/ "TQFg":
/***/ (function(module, exports) {

module.exports = require("svg-sprite-loader/runtime/sprite.build");

/***/ }),

/***/ "TRZx":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("Wk4r");

/***/ }),

/***/ "TUA0":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/define-property");

/***/ }),

/***/ "Tit0":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/create.js
var create = __webpack_require__("SqZg");
var create_default = /*#__PURE__*/__webpack_require__.n(create);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/set-prototype-of.js
var set_prototype_of = __webpack_require__("TRZx");
var set_prototype_of_default = /*#__PURE__*/__webpack_require__.n(set_prototype_of);

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/setPrototypeOf.js

function _setPrototypeOf(o, p) {
  _setPrototypeOf = set_prototype_of_default.a || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}
// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/inherits.js
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _inherits; });


function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = create_default()(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

/***/ }),

/***/ "UXZV":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("dGr4");

/***/ }),

/***/ "VNO/":
/***/ (function(module, exports) {

module.exports = require("rc-tween-one");

/***/ }),

/***/ "WLOv":
/***/ (function(module, exports) {

module.exports = {
	"container": "ZNsC9-qr"
};

/***/ }),

/***/ "WiSE":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("kOwS");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("qNsG");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("0iUn");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("sLSF");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("MI3g");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("a7VT");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("Tit0");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__("K2gz");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var rc_tween_one__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__("VNO/");
/* harmony import */ var rc_tween_one__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(rc_tween_one__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _components_SvgIcon__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__("BE5S");
/* harmony import */ var _components_Themes__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__("qRXU");
/* harmony import */ var _assets_images_scene_quote_svg_sprite__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__("R92e");
/* harmony import */ var _assets_images_scene_quote_svg_sprite__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_assets_images_scene_quote_svg_sprite__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _section2__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__("MpZq");
/* harmony import */ var _section3__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__("Ggtc");
/* harmony import */ var _section4__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__("kMzP");
/* harmony import */ var _scene1_less__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__("Myvi");
/* harmony import */ var _scene1_less__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_scene1_less__WEBPACK_IMPORTED_MODULE_16__);


















var SectionBlock =
/*#__PURE__*/
function (_React$Component) {
  Object(_babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_6__[/* default */ "a"])(SectionBlock, _React$Component);

  function SectionBlock() {
    Object(_babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_2__[/* default */ "a"])(this, SectionBlock);

    return Object(_babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__[/* default */ "a"])(this, Object(_babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"])(SectionBlock).apply(this, arguments));
  }

  Object(_babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"])(SectionBlock, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      Object(_components_Themes__WEBPACK_IMPORTED_MODULE_11__[/* setTheme */ "b"])({
        footer: true
      }, this.props.router.route);
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      Object(_components_Themes__WEBPACK_IMPORTED_MODULE_11__[/* setTheme */ "b"])({
        footer: false
      }, this.props.router.route);
    }
  }, {
    key: "render",
    value: function render() {
      var _this$props = this.props,
          className = _this$props.className,
          bannerImage = _this$props.bannerImage,
          props = Object(_babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(_this$props, ["className", "bannerImage"]);

      return react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", Object(_babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])({}, props, {
        className: classnames__WEBPACK_IMPORTED_MODULE_8___default()(_scene1_less__WEBPACK_IMPORTED_MODULE_16___default.a.block, className)
      }), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("section", {
        className: _scene1_less__WEBPACK_IMPORTED_MODULE_16___default.a.blockBanner,
        style: {
          backgroundImage: "url(".concat(bannerImage, ")")
        }
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(rc_tween_one__WEBPACK_IMPORTED_MODULE_9___default.a, {
        className: _scene1_less__WEBPACK_IMPORTED_MODULE_16___default.a.blockBannerMask,
        animation: {
          opacity: 0.001,
          type: 'from',
          duration: 1000,
          ease: 'easeOutExpo'
        }
      }), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_8___default()('page-content', _scene1_less__WEBPACK_IMPORTED_MODULE_16___default.a.blockBannerContent)
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("h1", {
        className: "SceneZcoolGaoDuanHei"
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("i", null, "\u667A\u6167\u80FD\u6E90"), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("span", {
        className: "SceneZcoolXiaoWeiTi"
      }, "\u89E3\u51B3\u65B9\u6848")))), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("section", {
        className: _scene1_less__WEBPACK_IMPORTED_MODULE_16___default.a.blockContent
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "page-content"
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("blockquote", {
        className: _scene1_less__WEBPACK_IMPORTED_MODULE_16___default.a.dictum
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("span", {
        className: _scene1_less__WEBPACK_IMPORTED_MODULE_16___default.a.dictumText
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_components_SvgIcon__WEBPACK_IMPORTED_MODULE_10__[/* default */ "a"], {
        className: _scene1_less__WEBPACK_IMPORTED_MODULE_16___default.a.dictumQuote,
        icon: _assets_images_scene_quote_svg_sprite__WEBPACK_IMPORTED_MODULE_12___default.a
      }), "\u6570\u636E\u8BA1\u7B97", react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("span", {
        className: classnames__WEBPACK_IMPORTED_MODULE_8___default()('SceneSiYuan', _scene1_less__WEBPACK_IMPORTED_MODULE_16___default.a.dictumPoint)
      }, "\u4E25\u8C28"), "\uFF0C\u4F7F\u7528\u65B9\u4FBF", react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("span", {
        className: classnames__WEBPACK_IMPORTED_MODULE_8___default()('SceneSiYuan', _scene1_less__WEBPACK_IMPORTED_MODULE_16___default.a.dictumPoint)
      }, "\u7B80\u5355"), "\uFF0C\u662F\u6211\u4EEC\u4EA7\u54C1\u7684\u8BBE\u8BA1\u5B97\u65E8")), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("p", {
        className: "page-poem"
      }, "\u6C5F\u82CF\u6B23\u52A8\u4FE1\u606F\u79D1\u6280", react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("br", null), "\u4E3A\u4E0D\u540C\u7684\u5BA2\u6237\u63D0\u4F9B\u5B9A\u5236\u5316\u7684\u89E3\u51B3\u65B9\u6848", react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("br", null), "\u5305\u62EC\u8BE5\u89E3\u51B3\u65B9\u6848\u9488\u5BF9\u5BA2\u6237\u7684\u6210\u672C\u548C\u6548\u679C\u987E\u8651", react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("br", null), "\u63D0\u4F9B\u4E0D\u540C\u7684\u5B9E\u65BD\u65B9\u6848\u3002"), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("p", {
        className: "page-poem"
      }, "\u6211\u4EEC\u901A\u8FC7", react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("br", null), "\u5BF9\u56ED\u533A\u3001\u9AD8\u7B49\u9662\u6821\u3001\u5546\u4E1A\u5EFA\u7B51\u3001\u653F\u5E9C\u673A\u5173\u3001\u5927\u578B\u516C\u5171\u5EFA\u7B51\u7B49\u8BBE\u65BD", react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("br", null), "\u7528\u6237\u7684\u7528\u80FD\u4E60\u60EF\u548C\u7528\u80FD\u60C5\u51B5\u8FDB\u884C\u5206\u6790", react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("br", null), "\u63D0\u4F9B\u5168\u9762\u7684\u80FD\u6E90\u7BA1\u7406", react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("br", null), "\u5B9E\u73B0\u80FD\u6E90\u5229\u7528\u6700\u4F18"))), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("section", {
        className: _scene1_less__WEBPACK_IMPORTED_MODULE_16___default.a.blockContent
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "page-content"
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("h2", null, "\u67B6\u6784\u5347\u7EA7"), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_section2__WEBPACK_IMPORTED_MODULE_13__["default"], null))), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("section", {
        className: _scene1_less__WEBPACK_IMPORTED_MODULE_16___default.a.blockContent
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "page-content"
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _scene1_less__WEBPACK_IMPORTED_MODULE_16___default.a.sectionContent
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("h2", null, "\u4F18\u52BF"), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_section3__WEBPACK_IMPORTED_MODULE_14__["default"], null)))), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("section", {
        className: _scene1_less__WEBPACK_IMPORTED_MODULE_16___default.a.blockContent
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "page-content"
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("h2", null, "\u5E73\u53F0\u67B6\u6784"), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_section4__WEBPACK_IMPORTED_MODULE_15__["default"], null))), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("section", {
        className: _scene1_less__WEBPACK_IMPORTED_MODULE_16___default.a.blockContent
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "page-content"
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("h2", null, "\u6280\u672F\u67B6\u6784"))), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("section", {
        className: _scene1_less__WEBPACK_IMPORTED_MODULE_16___default.a.blockContent
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "page-content"
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("h2", null, "\u6280\u672F\u7279\u70B9"), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _scene1_less__WEBPACK_IMPORTED_MODULE_16___default.a.characteristic
      }))));
    }
  }]);

  return SectionBlock;
}(react__WEBPACK_IMPORTED_MODULE_7___default.a.Component);

/* harmony default export */ __webpack_exports__["default"] = (SectionBlock);

/***/ }),

/***/ "Wk4r":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/set-prototype-of");

/***/ }),

/***/ "XVgq":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("gHn/");

/***/ }),

/***/ "XXOK":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("J3/a");

/***/ }),

/***/ "Z6Kq":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/get-own-property-descriptor");

/***/ }),

/***/ "Z7t5":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("vqFK");

/***/ }),

/***/ "ZksH":
/***/ (function(module, exports) {

module.exports = {
	"table": "_1X-ukBPC",
	"table-head": "_16-0o8_C",
	"tableHead": "_16-0o8_C",
	"col1": "_2cVZNO1J",
	"chspan": "_1Onf7mff",
	"col2": "QPkA2Rty",
	"col3": "_1rOKZtdu"
};

/***/ }),

/***/ "a7VT":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _getPrototypeOf; });
/* harmony import */ var _core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("Bhuq");
/* harmony import */ var _core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("TRZx");
/* harmony import */ var _core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_1__);


function _getPrototypeOf(o) {
  _getPrototypeOf = _core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_1___default.a ? _core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0___default.a : function _getPrototypeOf(o) {
    return o.__proto__ || _core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0___default()(o);
  };
  return _getPrototypeOf(o);
}

/***/ }),

/***/ "aC71":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/promise");

/***/ }),

/***/ "bPsq":
/***/ (function(module, exports) {

module.exports = require("less-vars-to-js");

/***/ }),

/***/ "cDcd":
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "cu1A":
/***/ (function(module, exports) {

module.exports = require("regenerator-runtime");

/***/ }),

/***/ "dDZb":
/***/ (function(module, exports) {

module.exports = {
	"wrap": "_3XqvdFoJ",
	"layer-title": "t0vLE4vS",
	"layerTitle": "t0vLE4vS",
	"layer-content": "_1AqLxy6g",
	"layerContent": "_1AqLxy6g",
	"layer-item": "MkdEHrd_",
	"layerItem": "MkdEHrd_",
	"flex-row": "_3ZI7kptF",
	"flexRow": "_3ZI7kptF",
	"flex-col": "_2TeO8c4I",
	"flexCol": "_2TeO8c4I",
	"layer-block": "_3h1xPIa5",
	"layerBlock": "_3h1xPIa5",
	"block-title": "_6bQfW_4O",
	"blockTitle": "_6bQfW_4O",
	"layer-third": "_2EXl80iN",
	"layerThird": "_2EXl80iN",
	"layer-col-6": "_3M3ed6jf",
	"layerCol6": "_3M3ed6jf",
	"layer-col-5": "_1Qmt8qOo",
	"layerCol5": "_1Qmt8qOo",
	"layer-col-4": "_1wM1x0oD",
	"layerCol4": "_1wM1x0oD",
	"layer-col-2": "_3Oxr4vMN",
	"layerCol2": "_3Oxr4vMN",
	"layer": "_3xcUBeDd"
};

/***/ }),

/***/ "dGr4":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/assign");

/***/ }),

/***/ "doui":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/array/is-array.js
var is_array = __webpack_require__("p0XB");
var is_array_default = /*#__PURE__*/__webpack_require__.n(is_array);

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/arrayWithHoles.js

function _arrayWithHoles(arr) {
  if (is_array_default()(arr)) return arr;
}
// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/get-iterator.js
var get_iterator = __webpack_require__("XXOK");
var get_iterator_default = /*#__PURE__*/__webpack_require__.n(get_iterator);

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/iterableToArrayLimit.js

function _iterableToArrayLimit(arr, i) {
  var _arr = [];
  var _n = true;
  var _d = false;
  var _e = undefined;

  try {
    for (var _i = get_iterator_default()(arr), _s; !(_n = (_s = _i.next()).done); _n = true) {
      _arr.push(_s.value);

      if (i && _arr.length === i) break;
    }
  } catch (err) {
    _d = true;
    _e = err;
  } finally {
    try {
      if (!_n && _i["return"] != null) _i["return"]();
    } finally {
      if (_d) throw _e;
    }
  }

  return _arr;
}
// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/nonIterableRest.js
function _nonIterableRest() {
  throw new TypeError("Invalid attempt to destructure non-iterable instance");
}
// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/slicedToArray.js
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _slicedToArray; });



function _slicedToArray(arr, i) {
  return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _nonIterableRest();
}

/***/ }),

/***/ "eVuF":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("aC71");

/***/ }),

/***/ "f4fG":
/***/ (function(module, exports) {

module.exports = {
	"wrap": "Ic_X-Z67",
	"block-title": "_1Rdd_k9t",
	"blockTitle": "_1Rdd_k9t",
	"block-content": "_2ax8_fc6",
	"blockContent": "_2ax8_fc6"
};

/***/ }),

/***/ "flPq":
/***/ (function(module, exports) {

module.exports = {
	"svg-icon": "_39UYRa5H",
	"svgIcon": "_39UYRa5H"
};

/***/ }),

/***/ "gHn/":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/symbol/iterator");

/***/ }),

/***/ "hfKm":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("TUA0");

/***/ }),

/***/ "hks1":
/***/ (function(module, exports) {

module.exports = "/_next/static/images/banner-1-d07c5a236da807adc23eddf3595ada7c.jpg";

/***/ }),

/***/ "k1wZ":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/get-own-property-symbols");

/***/ }),

/***/ "kJFy":
/***/ (function(module, exports) {

module.exports = require("flystore");

/***/ }),

/***/ "kMzP":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/classCallCheck.js
var classCallCheck = __webpack_require__("0iUn");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/createClass.js
var createClass = __webpack_require__("sLSF");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/possibleConstructorReturn.js + 1 modules
var possibleConstructorReturn = __webpack_require__("MI3g");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/getPrototypeOf.js
var getPrototypeOf = __webpack_require__("a7VT");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/inherits.js + 1 modules
var inherits = __webpack_require__("Tit0");

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__("cDcd");
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);

// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__("K2gz");
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/extends.js
var esm_extends = __webpack_require__("kOwS");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/keys.js
var keys = __webpack_require__("pLtp");
var keys_default = /*#__PURE__*/__webpack_require__.n(keys);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/objectWithoutProperties.js + 1 modules
var objectWithoutProperties = __webpack_require__("qNsG");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/assertThisInitialized.js
var assertThisInitialized = __webpack_require__("AT/M");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/defineProperty.js
var defineProperty = __webpack_require__("vYYK");

// EXTERNAL MODULE: external "object.pick"
var external_object_pick_ = __webpack_require__("6RRd");
var external_object_pick_default = /*#__PURE__*/__webpack_require__.n(external_object_pick_);

// EXTERNAL MODULE: external "rc-util/lib/Dom/css"
var css_ = __webpack_require__("+ys9");

// EXTERNAL MODULE: external "rc-util/lib/Dom/addEventListener"
var addEventListener_ = __webpack_require__("BI0l");
var addEventListener_default = /*#__PURE__*/__webpack_require__.n(addEventListener_);

// EXTERNAL MODULE: ./components/Themes/index.js + 2 modules
var Themes = __webpack_require__("qRXU");

// EXTERNAL MODULE: ./lib/requestAnimationFrame.js
var requestAnimationFrame = __webpack_require__("ushU");

// EXTERNAL MODULE: ./components/ResizeImage/resizeImage.less
var resizeImage = __webpack_require__("WLOv");
var resizeImage_default = /*#__PURE__*/__webpack_require__.n(resizeImage);

// CONCATENATED MODULE: ./components/ResizeImage/index.js


















var ResizeImage_ResizeImage =
/*#__PURE__*/
function (_React$Component) {
  Object(inherits["a" /* default */])(ResizeImage, _React$Component);

  Object(createClass["a" /* default */])(ResizeImage, null, [{
    key: "getDerivedStateFromProps",
    value: function getDerivedStateFromProps(props, state) {
      if (props.width && !state.width) {
        return {
          width: props.width
        };
      }

      return null;
    }
  }]);

  function ResizeImage(props) {
    var _this;

    Object(classCallCheck["a" /* default */])(this, ResizeImage);

    _this = Object(possibleConstructorReturn["a" /* default */])(this, Object(getPrototypeOf["a" /* default */])(ResizeImage).call(this, props));

    Object(defineProperty["a" /* default */])(Object(assertThisInitialized["a" /* default */])(_this), "handleResize", function () {
      Object(requestAnimationFrame["b" /* requestAnimationFrame */])(function () {
        if (_this.wrapRef.current) {
          var width = _this.state.width;
          var wrap = _this.wrapRef.current;
          var container = _this.containerRef.current;
          var currentWidth = Object(css_["get"])(wrap, 'width');
          var targetHeight = Object(css_["get"])(container, 'height');
          var scale = currentWidth / width;
          Object(css_["set"])(container, 'transform', "scale(".concat(scale, ")"));
          Object(css_["set"])(wrap, 'height', targetHeight * scale);
        }
      });
    });

    _this.wrapRef = external_react_default.a.createRef();
    _this.containerRef = external_react_default.a.createRef();
    _this.state = {
      width: null,
      height: null
    };
    return _this;
  }

  Object(createClass["a" /* default */])(ResizeImage, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      var width = this.state.width;
      var themeVariables = this.context.themeVariables; // eslint-disable-next-line

      this.state.width = width === null ? +themeVariables['@page-width'].replace(/px$/, '') - 24 * 2 : width;
      this.resizeHandler = addEventListener_default()(window, 'resize', this.handleResize);
      this.handleResize();
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      if (this.resizeHandler) {
        this.resizeHandler.remove();
        this.resizeHandler = null;
      }
    }
  }, {
    key: "render",
    value: function render() {
      var _this$state = this.state,
          width = _this$state.width,
          height = _this$state.height;
      var themeVariables = this.context.themeVariables;

      var _this$props = this.props,
          children = _this$props.children,
          props = Object(objectWithoutProperties["a" /* default */])(_this$props, ["children"]); // width 一定要设置默认


      var style = {
        // 最大宽度减 pandding
        width: width === null ? +themeVariables['@page-width'].replace(/px$/, '') - 24 * 2 : width,
        height: height
      };
      style = external_object_pick_default()(style, keys_default()(style).filter(function (key) {
        return style[key];
      }));
      return external_react_default.a.createElement("div", Object(esm_extends["a" /* default */])({}, props, {
        ref: this.wrapRef
      }), external_react_default.a.createElement("div", {
        style: style,
        className: resizeImage_default.a.container,
        ref: this.containerRef
      }, children));
    }
  }]);

  return ResizeImage;
}(external_react_default.a.Component);

Object(defineProperty["a" /* default */])(ResizeImage_ResizeImage, "contextType", Themes["a" /* ThemeContext */]);

/* harmony default export */ var components_ResizeImage = (ResizeImage_ResizeImage);
// EXTERNAL MODULE: ./pages/scene/scene1/section4.less
var section4 = __webpack_require__("dDZb");
var section4_default = /*#__PURE__*/__webpack_require__.n(section4);

// CONCATENATED MODULE: ./pages/scene/scene1/section4.js










var section4_Section =
/*#__PURE__*/
function (_React$Component) {
  Object(inherits["a" /* default */])(Section, _React$Component);

  function Section() {
    Object(classCallCheck["a" /* default */])(this, Section);

    return Object(possibleConstructorReturn["a" /* default */])(this, Object(getPrototypeOf["a" /* default */])(Section).apply(this, arguments));
  }

  Object(createClass["a" /* default */])(Section, [{
    key: "render",
    value: function render() {
      return external_react_default.a.createElement(components_ResizeImage, {
        className: section4_default.a.wrap
      }, external_react_default.a.createElement("div", {
        className: section4_default.a.layer
      }, external_react_default.a.createElement("div", {
        className: section4_default.a.layerTitle
      }, external_react_default.a.createElement("div", null, "\u7528\u6237\u573A\u666F")), external_react_default.a.createElement("div", {
        className: section4_default.a.layerContent
      }, external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol5)
      }, "\u8FDC\u7A0B\u63A7\u5236"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol5)
      }, "\u6D88\u9632\u5B89\u5168"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol5)
      }, "\u7BA1\u7F51\u68C0\u6D4B"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol5)
      }, "\u5145\u503C\u67E5\u8BE2"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol5)
      }, "..."))), external_react_default.a.createElement("div", {
        className: section4_default.a.layer
      }, external_react_default.a.createElement("div", {
        className: section4_default.a.layerTitle
      }, external_react_default.a.createElement("div", null, "\u5E94\u7528\u7CFB\u7EDF")), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerContent, section4_default.a.flexCol)
      }, external_react_default.a.createElement("div", {
        className: section4_default.a.layerBlock
      }, external_react_default.a.createElement("div", {
        className: section4_default.a.blockTitle
      }, "\u6807\u51C6\u5E94\u7528"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol5)
      }, "\u5EFA\u7B51\u80FD\u8017\u7BA1\u7406"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol5)
      }, "\u90E8\u95E8\u80FD\u8017\u7BA1\u7406"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol5)
      }, "\u8BBE\u65BD\u80FD\u8017\u7BA1\u7406"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol5)
      }, "\u7528\u80FD\u5E73\u8861\u68C0\u6D4B"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol5)
      }, "\u80FD\u8017\u6570\u636E\u4E0A\u62A5")), external_react_default.a.createElement("div", {
        className: section4_default.a.layerBlock
      }, external_react_default.a.createElement("div", {
        className: section4_default.a.blockTitle
      }, "\u6269\u5C55\u5E94\u7528"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol4)
      }, "\u5546\u4E1A\u7528\u80FD\u6536\u8D39"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol4)
      }, "\u7528\u80FD\u8D26\u76EE\u7BA1\u7406"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol4)
      }, "\u4E2D\u592E\u7A7A\u8C03\u76D1\u63A7"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol4)
      }, "\u5206\u4F53\u7A7A\u8C03\u76D1\u63A7"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol4)
      }, "\u591A\u8054\u673A\u7A7A\u8C03\u76D1\u63A7"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol4)
      }, "\u667A\u80FD\u7167\u660E\u76D1\u63A7"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol4)
      }, "\u4F9B\u6696\u8282\u80FD\u76D1\u63A7"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol4)
      }, "...")))), external_react_default.a.createElement("div", {
        className: section4_default.a.layer
      }, external_react_default.a.createElement("div", {
        className: section4_default.a.layerTitle
      }, external_react_default.a.createElement("div", null, "\u6570\u636E\u4E2D\u5FC3")), external_react_default.a.createElement("div", {
        className: section4_default.a.flexRow
      }, external_react_default.a.createElement("div", {
        className: section4_default.a.layerContent,
        style: {
          paddingRight: 0
        }
      }, external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol4)
      }, "\u8EAB\u4EFD\u8BA4\u8BC1"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol4)
      }, "\u8D22\u52A1\u7ED3\u7B97"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol4)
      }, "\u95E8\u6237\u96C6\u6210"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol4)
      }, "\u7CFB\u7EDF\u96C6\u6210"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol4)
      }, "\u7EC4\u7EC7\u67B6\u6784"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol4)
      }, "\u6570\u636E\u6316\u6398"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol4)
      }, "\u6570\u636E\u5BF9\u63A5"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol4)
      }, "...")), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerContent, section4_default.a.layerThird)
      }, external_react_default.a.createElement("div", {
        className: section4_default.a.blockTitle
      }, "\u7B2C\u4E09\u65B9\u5BF9\u63A5"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol2)
      }, "\u5206\u6790\u62A5\u8868"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol2)
      }, "\u6536\u8D39\u7ED3\u7B97"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol2)
      }, "\u8EAB\u4EFD\u8BA4\u8BC1"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol2)
      }, "...")))), external_react_default.a.createElement("div", {
        className: section4_default.a.layer
      }, external_react_default.a.createElement("div", {
        className: section4_default.a.layerTitle
      }, external_react_default.a.createElement("div", null, "\u667A\u80FD\u7269\u8054")), external_react_default.a.createElement("div", {
        className: section4_default.a.layerContent
      }, external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol5)
      }, "\u8BBE\u5907\u5BF9\u63A5"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol5)
      }, "\u6570\u636E\u6574\u7406"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol5)
      }, "\u6D77\u91CF\u5B58\u50A8"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol5)
      }, "\u9A71\u52A8\u5F00\u53D1"), external_react_default.a.createElement("div", {
        className: external_classnames_default()(section4_default.a.layerItem, section4_default.a.layerCol5)
      }, "\u8BBE\u5907\u76D1\u542C"))));
    }
  }]);

  return Section;
}(external_react_default.a.Component);

/* harmony default export */ var scene1_section4 = __webpack_exports__["default"] = (section4_Section);

/***/ }),

/***/ "kOwS":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _extends; });
/* harmony import */ var _core_js_object_assign__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("UXZV");
/* harmony import */ var _core_js_object_assign__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_assign__WEBPACK_IMPORTED_MODULE_0__);

function _extends() {
  _extends = _core_js_object_assign__WEBPACK_IMPORTED_MODULE_0___default.a || function (target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];

      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }

    return target;
  };

  return _extends.apply(this, arguments);
}

/***/ }),

/***/ "krCD":
/***/ (function(module, exports) {



/***/ }),

/***/ "l1Fa":
/***/ (function(module, exports) {

module.exports = "/_next/static/images/banner-4-23ae96cf7e703a84ffb7c38b4e492f7b.jpg";

/***/ }),

/***/ "lCau":
/***/ (function(module, exports) {

module.exports = "/_next/static/images/banner-3-3bfa1b1497c48af86b68f1e85c942e74.jpg";

/***/ }),

/***/ "ln6h":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("cu1A");


/***/ }),

/***/ "n/KK":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("kOwS");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("qNsG");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("K2gz");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _scene3_less__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("TNI3");
/* harmony import */ var _scene3_less__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_scene3_less__WEBPACK_IMPORTED_MODULE_4__);



 // import back from '@assets/images/scene/back.svg?sprite';
// import zhinengfenxi from '@assets/images/scene/zhinengfenxi.svg?sprite';
// import SvgIcon from '@components/SvgIcon';



function SectionBlock(_ref) {
  var className = _ref.className,
      bannerImage = _ref.bannerImage,
      props = Object(_babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(_ref, ["className", "bannerImage"]);

  return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("section", Object(_babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])({}, props, {
    className: classnames__WEBPACK_IMPORTED_MODULE_3___default()(_scene3_less__WEBPACK_IMPORTED_MODULE_4___default.a.block, className)
  }), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("div", {
    className: _scene3_less__WEBPACK_IMPORTED_MODULE_4___default.a.blockContent
  }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("div", {
    className: "page-content"
  })));
}

/* harmony default export */ __webpack_exports__["default"] = (SectionBlock);

/***/ }),

/***/ "nV/z":
/***/ (function(module, exports) {

module.exports = {
	"view": "VbQvtPs7",
	"scene-banner": "_3n-kG2Eb",
	"sceneBanner": "_3n-kG2Eb",
	"scene-banner-1": "LbuqteRN",
	"sceneBanner1": "LbuqteRN",
	"scene-banner-2": "_1JCp-fIh",
	"sceneBanner2": "_1JCp-fIh",
	"scene-banner-3": "_1-A6NK2a",
	"sceneBanner3": "_1-A6NK2a",
	"scene-banner-4": "_28TGj6Kr",
	"sceneBanner4": "_28TGj6Kr",
	"scene-banner-5": "MCA8Thmq",
	"sceneBanner5": "MCA8Thmq",
	"solutions": "_3KEkI8J3",
	"solution-block": "_1jRhLK7Q",
	"solutionBlock": "_1jRhLK7Q",
	"un-visibility": "_2RDX-ZM6",
	"unVisibility": "_2RDX-ZM6",
	"solution-hover": "_3e4cKruw",
	"solutionHover": "_3e4cKruw",
	"solution-block-container": "_3zkm0BLj",
	"solutionBlockContainer": "_3zkm0BLj",
	"solution-block-container-image": "_2eHbzm_d",
	"solutionBlockContainerImage": "_2eHbzm_d",
	"solution-block-container-banner": "_2Ug_X9mm",
	"solutionBlockContainerBanner": "_2Ug_X9mm",
	"solution-block-title": "fS2EgBtp",
	"solutionBlockTitle": "fS2EgBtp",
	"transparent": "_3ElDWqLY",
	"hidden": "_2eEuj_g_",
	"animating": "_2IAzsR2y"
};

/***/ }),

/***/ "o5io":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/create");

/***/ }),

/***/ "p0XB":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("R2Q7");

/***/ }),

/***/ "pLtp":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("qJj/");

/***/ }),

/***/ "qEgx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("kOwS");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("qNsG");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("K2gz");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _scene2_less__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("krCD");
/* harmony import */ var _scene2_less__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_scene2_less__WEBPACK_IMPORTED_MODULE_4__);



 // import back from '@assets/images/scene/back.svg?sprite';
// import zhinengfenxi from '@assets/images/scene/zhinengfenxi.svg?sprite';
// import SvgIcon from '@components/SvgIcon';



function SectionBlock(_ref) {
  var className = _ref.className,
      bannerImage = _ref.bannerImage,
      props = Object(_babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(_ref, ["className", "bannerImage"]);

  return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("section", Object(_babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])({}, props, {
    className: classnames__WEBPACK_IMPORTED_MODULE_3___default()(_scene2_less__WEBPACK_IMPORTED_MODULE_4___default.a.block, className)
  }), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("div", {
    className: _scene2_less__WEBPACK_IMPORTED_MODULE_4___default.a.blockContent
  }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("div", {
    className: "page-content"
  })));
}

/* harmony default export */ __webpack_exports__["default"] = (SectionBlock);

/***/ }),

/***/ "qJj/":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/keys");

/***/ }),

/***/ "qNsG":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/get-own-property-symbols.js
var get_own_property_symbols = __webpack_require__("4mXO");
var get_own_property_symbols_default = /*#__PURE__*/__webpack_require__.n(get_own_property_symbols);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/keys.js
var keys = __webpack_require__("pLtp");
var keys_default = /*#__PURE__*/__webpack_require__.n(keys);

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/objectWithoutPropertiesLoose.js

function _objectWithoutPropertiesLoose(source, excluded) {
  if (source == null) return {};
  var target = {};

  var sourceKeys = keys_default()(source);

  var key, i;

  for (i = 0; i < sourceKeys.length; i++) {
    key = sourceKeys[i];
    if (excluded.indexOf(key) >= 0) continue;
    target[key] = source[key];
  }

  return target;
}
// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/objectWithoutProperties.js
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _objectWithoutProperties; });


function _objectWithoutProperties(source, excluded) {
  if (source == null) return {};
  var target = _objectWithoutPropertiesLoose(source, excluded);
  var key, i;

  if (get_own_property_symbols_default.a) {
    var sourceSymbolKeys = get_own_property_symbols_default()(source);

    for (i = 0; i < sourceSymbolKeys.length; i++) {
      key = sourceSymbolKeys[i];
      if (excluded.indexOf(key) >= 0) continue;
      if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
      target[key] = source[key];
    }
  }

  return target;
}

/***/ }),

/***/ "qRXU":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/keys.js
var keys = __webpack_require__("pLtp");
var keys_default = /*#__PURE__*/__webpack_require__.n(keys);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/extends.js
var esm_extends = __webpack_require__("kOwS");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/classCallCheck.js
var classCallCheck = __webpack_require__("0iUn");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/createClass.js
var createClass = __webpack_require__("sLSF");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/possibleConstructorReturn.js + 1 modules
var possibleConstructorReturn = __webpack_require__("MI3g");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/getPrototypeOf.js
var getPrototypeOf = __webpack_require__("a7VT");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/assertThisInitialized.js
var assertThisInitialized = __webpack_require__("AT/M");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/inherits.js + 1 modules
var inherits = __webpack_require__("Tit0");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/defineProperty.js
var defineProperty = __webpack_require__("vYYK");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/assign.js
var object_assign = __webpack_require__("UXZV");
var assign_default = /*#__PURE__*/__webpack_require__.n(object_assign);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/objectSpread.js
var objectSpread = __webpack_require__("zrwo");

// EXTERNAL MODULE: external "flystore"
var external_flystore_ = __webpack_require__("kJFy");
var external_flystore_default = /*#__PURE__*/__webpack_require__.n(external_flystore_);

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__("cDcd");
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);

// EXTERNAL MODULE: external "object.pick"
var external_object_pick_ = __webpack_require__("6RRd");
var external_object_pick_default = /*#__PURE__*/__webpack_require__.n(external_object_pick_);

// EXTERNAL MODULE: external "less-vars-to-js"
var external_less_vars_to_js_ = __webpack_require__("bPsq");
var external_less_vars_to_js_default = /*#__PURE__*/__webpack_require__.n(external_less_vars_to_js_);

// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__("4Q3z");
var router_default = /*#__PURE__*/__webpack_require__.n(router_);

// CONCATENATED MODULE: ./node_modules/raw-loader/dist/cjs.js!./assets/custom.less
/* harmony default export */ var custom = ("\n// https://github.com/ant-design/ant-design/blob/master/components/style/themes/default.less\n@import (reference) \"~antd/lib/style/themes/default.less\";\n@import (reference) \"~antd/lib/style/mixins/index.less\";\n@import (reference) \"./easings/index.less\";\n\n@gray-1: #ffffff;\n@gray-2: #fafafa;\n@gray-3: #f5f5f5;\n@gray-4: #e8e8e8;\n@gray-5: #d9d9d9;\n@gray-6: #bfbfbf;\n@gray-7: #8c8c8c;\n@gray-8: #595959;\n@gray-9: #262626;\n@gray-10: #000000;\n\n// 暗黑\n@dark-1: rgba(0, 0, 0, .05);\n@dark-2: rgba(0, 0, 0, .15);\n@dark-3: rgba(0, 0, 0, .25);\n@dark-4: rgba(0, 0, 0, .35);\n@dark-5: rgba(0, 0, 0, .45);\n@dark-6: rgba(0, 0, 0, .55);\n@dark-7: rgba(0, 0, 0, .65);\n@dark-8: rgba(0, 0, 0, .75);\n@dark-9: rgba(0, 0, 0, .85);\n@dark-10: rgba(0, 0, 0, 1);\n\n// 亮白\n@light-1: rgba(255, 255, 255, .05);\n@light-2: rgba(255, 255, 255, .15);\n@light-3: rgba(255, 255, 255, .25);\n@light-4: rgba(255, 255, 255, .35);\n@light-5: rgba(255, 255, 255, .45);\n@light-6: rgba(255, 255, 255, .55);\n@light-7: rgba(255, 255, 255, .65);\n@light-8: rgba(255, 255, 255, .75);\n@light-9: rgba(255, 255, 255, .85);\n@light-10: rgba(255, 255, 255, 1);\n\n\n@mask-color: #001529;\n@footer-color: @light-8;\n@footer-link-color: @light-6;\n@footer-link-hover-color: @light-10;\n@footer-background-color: @dark-10;\n@header-background-color: #001529;\n@anchor-background-color: @light-10;\n@anchor-color: #1890ff;\n\n\n@dark-menu-color: @light-7;\n@dark-menu-background-color: @header-background-color;\n\n\n@anim-speed-1: 200ms;\n@anim-speed-2: 375ms;\n@anim-speed-3: 500ms;\n@anim-speed-4: 800ms;\n@anim-speed-5: 1200ms;\n\n\n@page-width: 980px;\n@page-width-lg: 1440px;\n@max-width: 1920px; // 2560px\n@header-height: 64px;\n@header-phone-height: 48px;\n@anchor-height: 48px;\n\n\n// z-index\n@header-zIndex: 1100;\n@anchor-zIndex: @header-zIndex - 10;\n\n// shadow\n@shadow-down: 0 2px 8px rgba(0, 0, 0, 0.08);\n@shadow-down-dark: 0 2px 8px rgba(0, 0, 0, 0.2);\n@shadow-down-sm: 4px 6px 10px rgba(0, 0, 0, 0.1);\n@shadow-down-lg: 8px 12px 20px rgba(0, 0, 0, 0.3);\n\n\n@main-color: #fa8c16;\n@main-background-color: #001529;\n@main-light-background-color: #f1f3ff;\n\n// .function {\n//   .foo(@x) {\n//     return: @x * 2;\n//   }\n// }");
// CONCATENATED MODULE: ./node_modules/raw-loader/dist/cjs.js!./assets/easings/index.less
/* harmony default export */ var easings = ("//https://easings.net/\n//http://cubic-bezier.com/#.17,.67,.83,.67\n@linear         : cubic-bezier(0.250, 0.250, 0.750, 0.750);\n@ease           : cubic-bezier(0.250, 0.100, 0.250, 1.000);\n@ease-in        : cubic-bezier(0.420, 0.000, 1.000, 1.000);\n@ease-out       : cubic-bezier(0.000, 0.000, 0.580, 1.000);\n@ease-in-out    : cubic-bezier(0.420, 0.000, 0.580, 1.000);\n\n@easeInQuad     : cubic-bezier(0.550, 0.085, 0.680, 0.530);\n@easeInCubic    : cubic-bezier(0.550, 0.055, 0.675, 0.190);\n@easeInQuart    : cubic-bezier(0.895, 0.030, 0.685, 0.220);\n@easeInQuint    : cubic-bezier(0.755, 0.050, 0.855, 0.060);\n@easeInSine     : cubic-bezier(0.470, 0.000, 0.745, 0.715);\n@easeInExpo     : cubic-bezier(0.950, 0.050, 0.795, 0.035);\n@easeInCirc     : cubic-bezier(0.600, 0.040, 0.980, 0.335);\n@easeInBack     : cubic-bezier(0.600, -0.280, 0.735, 0.045);\n\n@easeOutQuad    : cubic-bezier(0.250, 0.460, 0.450, 0.940);\n@easeOutCubic   : cubic-bezier(0.215, 0.610, 0.355, 1.000);\n@easeOutQuart   : cubic-bezier(0.165, 0.840, 0.440, 1.000);\n@easeOutQuint   : cubic-bezier(0.230, 1.000, 0.320, 1.000);\n@easeOutSine    : cubic-bezier(0.390, 0.575, 0.565, 1.000);\n@easeOutExpo    : cubic-bezier(0.190, 1.000, 0.220, 1.000);\n@easeOutCirc    : cubic-bezier(0.075, 0.820, 0.165, 1.000);\n@easeOutBack    : cubic-bezier(0.175, 0.885, 0.320, 1.275);\n\n@easeInOutQuad  : cubic-bezier(0.455, 0.030, 0.515, 0.955);\n@easeInOutCubic : cubic-bezier(0.645, 0.045, 0.355, 1.000);\n@easeInOutQuart : cubic-bezier(0.770, 0.000, 0.175, 1.000);\n@easeInOutQuint : cubic-bezier(0.860, 0.000, 0.070, 1.000);\n@easeInOutSine  : cubic-bezier(0.445, 0.050, 0.550, 0.950);\n@easeInOutExpo  : cubic-bezier(1.000, 0.000, 0.000, 1.000);\n@easeInOutCirc  : cubic-bezier(0.785, 0.135, 0.150, 0.860);\n@easeInOutBack  : cubic-bezier(0.680, -0.550, 0.265, 1.550);\n");
// CONCATENATED MODULE: ./components/Themes/index.js
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return themeVariables; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return themeEasings; });
/* unused harmony export defaultThemeConfig */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return Themes_setTheme; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "e", function() { return withTheme; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ThemeContext; });


















var themeVariables = external_less_vars_to_js_default()(custom, {
  resolveVariables: true
});
var themeEasings = external_less_vars_to_js_default()(easings, {
  resolveVariables: true
});
var defaultThemeConfig = {
  footer: true,
  header: true
};
var storeTheme = external_flystore_default()('@theme-config');
storeTheme.set('config', Object(objectSpread["a" /* default */])({}, defaultThemeConfig));
storeTheme.set('change', {});
var Themes_setTheme = function setTheme(config, changeRoute) {
  var route = router_default.a.router.route;

  if (changeRoute && changeRoute !== route) {
    var themeConfig = storeTheme.get("change-".concat(changeRoute));
    storeTheme.set("change-".concat(changeRoute), assign_default()({}, themeConfig, config));
  } else {
    var _themeConfig = storeTheme.get("change-".concat(route));

    var newConfig = assign_default()({}, _themeConfig, config);

    storeTheme.set("change-".concat(route), newConfig);
    storeTheme.dispense('change', newConfig);
  }
};
function withTheme(Comp) {
  var _class, _temp;

  return Object(router_["withRouter"])((_temp = _class =
  /*#__PURE__*/
  function (_React$Component) {
    Object(inherits["a" /* default */])(WithTheme, _React$Component);

    function WithTheme() {
      var _getPrototypeOf2;

      var _this;

      Object(classCallCheck["a" /* default */])(this, WithTheme);

      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }

      _this = Object(possibleConstructorReturn["a" /* default */])(this, (_getPrototypeOf2 = Object(getPrototypeOf["a" /* default */])(WithTheme)).call.apply(_getPrototypeOf2, [this].concat(args)));

      Object(defineProperty["a" /* default */])(Object(assertThisInitialized["a" /* default */])(_this), "state", {
        themeConfig: storeTheme.get('config')
      });

      return _this;
    }

    Object(createClass["a" /* default */])(WithTheme, [{
      key: "componentDidMount",
      value: function componentDidMount() {
        var _this2 = this;

        var route = this.props.router.route;
        var changeConfig = storeTheme.get("change-".concat(route));

        if (changeConfig) {
          this.setState({
            themeConfig: assign_default()(storeTheme.get('config'), changeConfig)
          });
        }

        this.configHandle = storeTheme.watch('change', function (themeConfig) {
          _this2.setState({
            themeConfig: assign_default()(storeTheme.get('config'), themeConfig)
          });
        });
      }
    }, {
      key: "componentWillUnmount",
      value: function componentWillUnmount() {
        if (this.configHandle) {
          this.configHandle.clear();
          this.configHandle = null;
        }
      }
    }, {
      key: "render",
      value: function render() {
        return external_react_default.a.createElement(Comp, Object(esm_extends["a" /* default */])({}, this.props, {
          themeConfig: this.state.themeConfig
        }));
      }
    }]);

    return WithTheme;
  }(external_react_default.a.Component), Object(defineProperty["a" /* default */])(_class, "getDerivedStateFromProps", function (props) {
    var route = props.router.route;

    var newConfig = assign_default()({}, defaultThemeConfig, external_object_pick_default()(props, keys_default()(defaultThemeConfig)));

    var changeConfig = storeTheme.get("change-".concat(route));
    return {
      themeConfig: assign_default()(newConfig, changeConfig)
    };
  }), _temp));
}
var ThemeContext = external_react_default.a.createContext({
  env: {},
  themeConfig: Object(objectSpread["a" /* default */])({}, defaultThemeConfig),
  themeEasings: themeEasings,
  themeVariables: themeVariables,
  isLoaded: false,
  isMobile: false
});

/***/ }),

/***/ "sLSF":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _createClass; });
/* harmony import */ var _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("hfKm");
/* harmony import */ var _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__);


function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;

    _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default()(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

/***/ }),

/***/ "ushU":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return requestAnimationFrame; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return cancelAnimationFrame; });
var suffix = 'AnimationFrame';
var vendors = ['', 'moz', 'webkit'];

var getAFFunc = function getAFFunc(name) {
  var func = null;
  return function () {
    if (func) {
      return func.apply(void 0, arguments);
    }

    var win = window;

    for (var i = 0, l = vendors.length; i < l; i++) {
      var prefix = vendors[i];
      var funcName = name + suffix;

      if (prefix) {
        funcName = prefix + funcName.charAt(0).toUpperCase() + funcName.slice(1);
      }

      func = win[funcName];

      if (func) {
        break;
      }
    }

    return func ? func.apply(void 0, arguments) : func;
  };
};

var requestAnimationFrame = getAFFunc('request');
var cancelFunc = getAFFunc('cancel');
var cancelRequestFunc = getAFFunc('cancelRequest');
var cancelAnimationFrame = function cancelAnimationFrame() {
  return cancelFunc.apply(void 0, arguments) || cancelRequestFunc.apply(void 0, arguments);
};

/***/ }),

/***/ "vYYK":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _defineProperty; });
/* harmony import */ var _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("hfKm");
/* harmony import */ var _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__);

function _defineProperty(obj, key, value) {
  if (key in obj) {
    _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default()(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}

/***/ }),

/***/ "vqFK":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/symbol");

/***/ }),

/***/ "xExG":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("kOwS");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("qNsG");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("K2gz");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _scene4_less__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("CK/I");
/* harmony import */ var _scene4_less__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_scene4_less__WEBPACK_IMPORTED_MODULE_4__);



 // import back from '@assets/images/scene/back.svg?sprite';
// import zhinengfenxi from '@assets/images/scene/zhinengfenxi.svg?sprite';
// import SvgIcon from '@components/SvgIcon';



function SectionBlock(_ref) {
  var className = _ref.className,
      bannerImage = _ref.bannerImage,
      props = Object(_babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(_ref, ["className", "bannerImage"]);

  return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("section", Object(_babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])({}, props, {
    className: classnames__WEBPACK_IMPORTED_MODULE_3___default()(_scene4_less__WEBPACK_IMPORTED_MODULE_4___default.a.block, className)
  }), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("div", {
    className: _scene4_less__WEBPACK_IMPORTED_MODULE_4___default.a.blockContent
  }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("div", {
    className: "page-content"
  })));
}

/* harmony default export */ __webpack_exports__["default"] = (SectionBlock);

/***/ }),

/***/ "zrwo":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _objectSpread; });
/* harmony import */ var _core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("Jo+v");
/* harmony import */ var _core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("4mXO");
/* harmony import */ var _core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _core_js_object_keys__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("pLtp");
/* harmony import */ var _core_js_object_keys__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_keys__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _defineProperty__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("vYYK");




function _objectSpread(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i] != null ? arguments[i] : {};

    var ownKeys = _core_js_object_keys__WEBPACK_IMPORTED_MODULE_2___default()(source);

    if (typeof _core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1___default.a === 'function') {
      ownKeys = ownKeys.concat(_core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1___default()(source).filter(function (sym) {
        return _core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_0___default()(source, sym).enumerable;
      }));
    }

    ownKeys.forEach(function (key) {
      Object(_defineProperty__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"])(target, key, source[key]);
    });
  }

  return target;
}

/***/ })

/******/ });