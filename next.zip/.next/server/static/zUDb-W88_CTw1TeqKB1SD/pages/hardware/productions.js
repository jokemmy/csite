module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../../../../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 22);
/******/ })
/************************************************************************/
/******/ ({

/***/ "/8XS":
/***/ (function(module, exports) {

module.exports = "/_next/static/images/TG121-N-485-fe3722511fdc4ce58df93a0ade04344a.png";

/***/ }),

/***/ 22:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("No+n");


/***/ }),

/***/ "9qb6":
/***/ (function(module, exports) {

module.exports = "<div>\r\n  <h2>\r\n    敏捷网关TG120系列\r\n  </h2>\r\n  <p>适用于各类IP设备、非IP设备的数据采集、处理、存储、加密、传输等。</p>\r\n  <ul>\r\n    <li>\r\n    使用了统一的DD-IoT 物联网协议\r\n    </li>\r\n    <li>\r\n    提供多种数据远程传输通道\r\n    </li>\r\n    <li>\r\n    多样化的数据采集接口\r\n    </li>\r\n    <li>\r\n    设备驱动可编程，支持各种设备通讯协议\r\n    </li>\r\n  </ul>\r\n</div>\r\n"

/***/ }),

/***/ "EYMO":
/***/ (function(module, exports) {

module.exports = "/_next/static/images/TDV100-WN-55a202354621e1ebade39e2da15b9d90.png";

/***/ }),

/***/ "HDZ4":
/***/ (function(module, exports) {

module.exports = "/_next/static/images/TR1000-DatUP-0a004fe31fc8be21ce7d494ce547f2c8.png";

/***/ }),

/***/ "MAnk":
/***/ (function(module, exports) {

module.exports = "<div>\r\n  <h2>\r\n    智能网由TR1000系列\r\n  </h2>\r\n  <p>适用于各类需要统一数据格式上报的场合。</p>\r\n  <ul>\r\n    <li>\r\n    支持BACNet、ModbusTCP、OPC格式数据转换\r\n    </li>\r\n    <li>\r\n    统一数据上报格式\r\n    </li>\r\n    <li>\r\n    提供网关及其连接设备远程状态诊断\r\n    </li>\r\n  </ul>\r\n</div>"

/***/ }),

/***/ "MC3a":
/***/ (function(module, exports) {

module.exports = "<div>\r\n  <h2>\r\n    敏捷网关TG100系列\r\n  </h2>\r\n  <p>适用于各类非IP设备的数据采集、处理、存储、加密、传输等。</p>\r\n  <ul>\r\n    <li>\r\n    使用了统一的DD-IoT 物联网协议\r\n    </li>\r\n    <li>\r\n    多样化的数据采集接口\r\n    </li>\r\n    <li>\r\n    设备驱动可配置，支持多种设备通讯协议\r\n    </li>\r\n  </ul>\r\n</div>"

/***/ }),

/***/ "No+n":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "categorys", function() { return categorys; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "productions", function() { return productions; });
var categorys = [{
  as: '/hardware/1',
  url: '/hardware?category=1',
  name: '智能网关类',
  products: 'TG121系列/TG120系列/TG100系列',
  description: '欣动智能网关是将客户通用需求与行业个性化需求有机融合的革命性产品，具有现场/远程可配置、可编程功能，提供可靠的物联网软硬件平台和统一开放的MQTT IoT通讯协议，简化物联网网关的定制和部署，协助加速物联网应用的开发和创新。'
}, {
  as: '/hardware/2',
  url: '/hardware?category=2',
  name: '智能网由类',
  products: 'TR1000系列/TR1000-DatUP',
  description: '欣动TR1000系列智能网由是将不同行业标准网络接口协议，转换为MQTT物联网接口协议的创新型产品。支持BACnet/IP、OPC和Modbus/TCP等协议，并能在持续更新与系列化发展中，支持更多传统产业如智能楼宇、工业自控等，向智能化物联网方向升级。'
}, {
  as: '/hardware/3',
  url: '/hardware?category=3',
  name: '前置服务类',
  products: 'TFS1000-BEMS/TFS1000-GBMS',
  description: '欣动TFS1000系列前置服务器是集数据采集、应用扩展和服务发布为一体的专用设备，提供特定功能的现场轻量级服务，如智能设备监测服务、单体建筑能源管理服务和单体绿色建筑运营管理服务等。'
}, {
  as: '/hardware/4',
  url: '/hardware?category=4',
  name: '终端设备类',
  products: 'TC100-R8/TDV100-WN',
  description: '欣动终端设备类是将客户通用需求与客户个性化需求、行业性需求有机融合的革命性产品。其中智能控制器使用微处理器和专用控制算法，实现智能控制；信息发布终端提供综合、全面的信息发布解决方案。'
}, {
  as: '/hardware/5',
  url: '/hardware?category=5',
  name: '接口转换类',
  products: 'TCONV-MR4',
  description: '欣动接口转换类产品可以将不同接口设备组网，实现设备间的互操作。基于多种通信口和各种协议，形成不同种类的接口转换器。'
}, {
  as: '/hardware/6',
  url: '/hardware?category=6',
  name: '集成机柜类',
  products: 'GR10-TG网关柜/GR10-TR网由柜',
  description: '欣动GR10系列集成机柜类，作为支持能源管理解决方案的重要组件，所有部件工厂预制、预装、预调试，打包运输，现场仅需简单安装，实现业务快速上线。所有设备一体化集成在一个机柜，相对于传统建设模式至少节省50%安装空间。'
}];
var productions = [// 智能网关
[{
  name: 'TG121-N-485',
  image: __webpack_require__("/8XS"),
  html: __webpack_require__("T2Y/")
}, {
  name: 'TG120-N-485',
  image: __webpack_require__("O8vT"),
  html: __webpack_require__("9qb6")
}, {
  soldOut: true,
  name: 'TG100-N-485',
  image: __webpack_require__("qmBw"),
  html: __webpack_require__("MC3a")
}], // 只能网由类
[{
  name: 'TR1000-Base',
  image: __webpack_require__("w9w0"),
  html: __webpack_require__("MAnk")
}, {
  name: 'TR1000-DatUP',
  image: __webpack_require__("HDZ4"),
  html: __webpack_require__("dIfZ")
}], // 前置服务
[{
  name: 'TFS1000-BEMS',
  image: __webpack_require__("vd60"),
  html: __webpack_require__("sO2e")
}, {
  name: 'TFS1000-GBMS',
  image: __webpack_require__("s3X4"),
  html: __webpack_require__("OsBW")
}], // 中断设备
[{
  name: 'TC100-R8',
  image: __webpack_require__("X8t4"),
  html: __webpack_require__("x3F3")
}, {
  name: 'TDV1000-WN',
  image: __webpack_require__("EYMO"),
  html: __webpack_require__("fyDi")
}], // 接口转换
[{
  name: 'TCONV-MR4',
  image: __webpack_require__("kaF8"),
  html: __webpack_require__("a2x+")
}], // 集成机柜
[{
  name: 'GR10-TG',
  image: __webpack_require__("YLb4"),
  html: __webpack_require__("e8Iw")
}, {
  name: 'GR10-TR',
  image: __webpack_require__("hlvG"),
  html: __webpack_require__("hYnc")
}]];

/***/ }),

/***/ "O8vT":
/***/ (function(module, exports) {

module.exports = "/_next/static/images/TG120-N-485-ac58423080658c8e1bd977548241960d.png";

/***/ }),

/***/ "OsBW":
/***/ (function(module, exports) {

module.exports = "<div>\r\n  <h2>\r\n    绿建监测服务器TFS1000-GBMS\r\n  </h2>\r\n  <p>适用于各类绿色建筑的能效评估服务</p>\r\n  <ul>\r\n    <li>\r\n    各类能源、资源分类、分项计量\r\n    </li>\r\n    <li>\r\n    能源可视化动态监测、损耗分析、能耗预警\r\n    </li>\r\n    <li>\r\n    能效对标、能效公示、能效评估\r\n    </li>\r\n    <li>\r\n    节能诊断分析、能效评估报告、节能改进建议\r\n    </li>\r\n  </ul>\r\n</div>"

/***/ }),

/***/ "T2Y/":
/***/ (function(module, exports) {

module.exports = "<div>\r\n  <h2>\r\n    智能网关TG121系列\r\n  </h2>\r\n  <p>提供全方位软硬件解决方案、建构模块与SDK ，以连接各种无线/有线装置，简化物联网部署；强化DD-IoT 应用开发，方便数据通信与设备管理，加速物联网创新。</p>\r\n  <ul>\r\n    <li>\r\n    使用了统一的DD-IoT 物联网协议\r\n    </li>\r\n    <li>\r\n    提供多种数据远程传输通道\r\n    </li>\r\n    <li>\r\n    多样化的数据采集接口\r\n    </li>\r\n    <li>\r\n    设备驱动可编程，支持各种设备通讯协议\r\n    </li>\r\n    <li>\r\n    可扩展数据存储容量\r\n    </li>\r\n  </ul>\r\n</div>"

/***/ }),

/***/ "X8t4":
/***/ (function(module, exports) {

module.exports = "/_next/static/images/TC100-R8-e2ab4ad6675894a834b25726a72b2ff8.png";

/***/ }),

/***/ "YLb4":
/***/ (function(module, exports) {

module.exports = "/_next/static/images/GR10-TG-c41c335af0de3e41958e6b90fc5833ae.png";

/***/ }),

/***/ "a2x+":
/***/ (function(module, exports) {

module.exports = "<div>\r\n  <h2>\r\n    MRus/485转换器-协议透传 TCONV-MR4\r\n  </h2>\r\n  <p>适用于需要MBus接口转成RS-485的接口的场合。</p>\r\n  <ul>\r\n    <li>\r\n     成熟的嵌入式软硬件平台，便于系统功能的扩展\r\n    </li>\r\n    <li>\r\n     通过电磁兼容性整体设计，满足低噪音、低电磁干扰的环保要求\r\n    </li>\r\n    <li>\r\n     适应恶劣电网、温度、湿度和粉尘能力，产品可靠性高\r\n    </li>\r\n  </ul>\r\n</div>"

/***/ }),

/***/ "dIfZ":
/***/ (function(module, exports) {

module.exports = "<div>\r\n  <h2>\r\n    智能TR1000-DatUP\r\n  </h2>\r\n  <p>适用于大型公建能源数据上报</p>\r\n  <ul>\r\n    <li>\r\n    标准的数据上报格式，可根据需要自定义数据格式\r\n    </li>\r\n    <li>\r\n    数据远程数据传输通道，具备跨网段数据转发功能\r\n    </li>\r\n    <li>\r\n    在无以太网情况下，可根据需要加装4G传输模块\r\n    </li>\r\n  </ul>\r\n</div>"

/***/ }),

/***/ "e8Iw":
/***/ (function(module, exports) {

module.exports = "<div>\n  <h2>\n    GR10-TG网关柜\n  </h2>\n  <p>含柜体、电源，适用于各类网关的现场安装</p>\n  <ul>\n    <li>\n     具有抗振动、抗冲击、耐腐蚀、防尘、防水、防辐射等性能，以便保证柜内设备稳定可靠地工作。\n    </li>\n    <li>\n     良好的使用性和安全防护设施，便于操作、安装和维修。\n    </li>\n    <li>\n     柜体大小、柜内设备及数量可定制\n    </li>\n  </ul>\n</div>"

/***/ }),

/***/ "fyDi":
/***/ (function(module, exports) {

module.exports = "<div>\r\n  <h2>\r\n    信息发布终端-配合电视监控屏实现终端信息发布 TDV100-WN\r\n  </h2>\r\n  <p>适用于使用显示设备发布各类信息的场合。</p>\r\n  <ul>\r\n    <li>\r\n     提供多种信息发布传输通道\r\n    </li>\r\n    <li>\r\n     支持后台设备管理，远程管理显示终端\r\n    </li>\r\n    <li>\r\n     提供显示终端远程状态信息\r\n    </li>\r\n  </ul>\r\n</div>"

/***/ }),

/***/ "hYnc":
/***/ (function(module, exports) {

module.exports = "<div>\n  <h2>\n    GR10-TR网由柜\n  </h2>\n  <p>含柜体、电源，适用于各类网由的现场安装</p>\n  <ul>\n    <li>\n     具有抗振动、抗冲击、耐腐蚀、防尘、防水、防辐射等性能，以便保证柜内设备稳定可靠地工作。\n    </li>\n    <li>\n     良好的使用性和安全防护设施，便于操作、安装和维修。\n    </li>\n    <li>\n     柜体大小、柜内设备及数量可定制。\n    </li>\n  </ul>\n</div>"

/***/ }),

/***/ "hlvG":
/***/ (function(module, exports) {

module.exports = "/_next/static/images/GR10-TR-1a4194ab83354c630b78526a0a10be8d.png";

/***/ }),

/***/ "kaF8":
/***/ (function(module, exports) {

module.exports = "/_next/static/images/TCONV-MR4-2ba85548e5a86c6e9127eaf0f35a2d5f.png";

/***/ }),

/***/ "qmBw":
/***/ (function(module, exports) {

module.exports = "/_next/static/images/TG100-N-485-5d4ed183fca046315a36e9c6266dff47.png";

/***/ }),

/***/ "s3X4":
/***/ (function(module, exports) {

module.exports = "/_next/static/images/TFS1000-GBMS-0881a7ed4278168be42c788b1d5aa9a9.png";

/***/ }),

/***/ "sO2e":
/***/ (function(module, exports) {

module.exports = "<div>\r\n  <h2>\r\n    建筑能源服务器TFS1000-BEMS\r\n  </h2>\r\n  <p>适用于各类建筑的能源服务。</p>\r\n  <ul>\r\n    <li>\r\n    各类能源、资源分类、分项计量\r\n    </li>\r\n    <li>\r\n    能源可视化动态监测\r\n    </li>\r\n    <li>\r\n    能效公示、评估\r\n    </li>\r\n  </ul>\r\n</div>"

/***/ }),

/***/ "vd60":
/***/ (function(module, exports) {

module.exports = "/_next/static/images/TFS1000-BEMS-0881a7ed4278168be42c788b1d5aa9a9.png";

/***/ }),

/***/ "w9w0":
/***/ (function(module, exports) {

module.exports = "/_next/static/images/TR1000-Base-0a004fe31fc8be21ce7d494ce547f2c8.png";

/***/ }),

/***/ "x3F3":
/***/ (function(module, exports) {

module.exports = "<div>\r\n  <h2>\r\n    智能控制器-八路继电器输出型TC100-R8\r\n  </h2>\r\n  <p>适用于工业自动化系统，负荷控制；各类使用时间策略控制的工业场合。配合智能网关及后台监控系统，可以实现多种控制模式：</p>\r\n  <ul>\r\n    <li>\r\n     远程手动控制模式\r\n    </li>\r\n    <li>\r\n     延时控制模式\r\n    </li>\r\n    <li>\r\n     循环控制模式\r\n    </li>\r\n    <li>\r\n     全自动策略控制模式\r\n    </li>\r\n  </ul>\r\n</div>"

/***/ })

/******/ });