module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../../../../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 7);
/******/ })
/************************************************************************/
/******/ ({

/***/ "/+P4":
/***/ (function(module, exports, __webpack_require__) {

var _Object$getPrototypeOf = __webpack_require__("Bhuq");

var _Object$setPrototypeOf = __webpack_require__("TRZx");

function _getPrototypeOf(o) {
  module.exports = _getPrototypeOf = _Object$setPrototypeOf ? _Object$getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || _Object$getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}

module.exports = _getPrototypeOf;

/***/ }),

/***/ "/+oN":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/get-prototype-of");

/***/ }),

/***/ "/8XS":
/***/ (function(module, exports) {

module.exports = "/_next/static/images/TG121-N-485-fe3722511fdc4ce58df93a0ade04344a.png";

/***/ }),

/***/ "/HRN":
/***/ (function(module, exports) {

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

module.exports = _classCallCheck;

/***/ }),

/***/ "0iUn":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _classCallCheck; });
function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

/***/ }),

/***/ "4Q3z":
/***/ (function(module, exports) {

module.exports = require("next/router");

/***/ }),

/***/ "4mXO":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("k1wZ");

/***/ }),

/***/ "6RRd":
/***/ (function(module, exports) {

module.exports = require("object.pick");

/***/ }),

/***/ 7:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("LjJ6");


/***/ }),

/***/ "9Jkg":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("fozc");

/***/ }),

/***/ "9qb6":
/***/ (function(module, exports) {

module.exports = "<div>\r\n  <h2>\r\n    敏捷网关TG120系列\r\n  </h2>\r\n  <p>适用于各类IP设备、非IP设备的数据采集、处理、存储、加密、传输等。</p>\r\n  <ul>\r\n    <li>\r\n    使用了统一的DD-IoT 物联网协议\r\n    </li>\r\n    <li>\r\n    提供多种数据远程传输通道\r\n    </li>\r\n    <li>\r\n    多样化的数据采集接口\r\n    </li>\r\n    <li>\r\n    设备驱动可编程，支持各种设备通讯协议\r\n    </li>\r\n  </ul>\r\n</div>\r\n"

/***/ }),

/***/ "AT/M":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _assertThisInitialized; });
function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

/***/ }),

/***/ "Bhuq":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("/+oN");

/***/ }),

/***/ "EYMO":
/***/ (function(module, exports) {

module.exports = "/_next/static/images/TDV100-WN-55a202354621e1ebade39e2da15b9d90.png";

/***/ }),

/***/ "HDZ4":
/***/ (function(module, exports) {

module.exports = "/_next/static/images/TR1000-DatUP-0a004fe31fc8be21ce7d494ce547f2c8.png";

/***/ }),

/***/ "Jo+v":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("Z6Kq");

/***/ }),

/***/ "K2gz":
/***/ (function(module, exports) {

module.exports = require("classnames");

/***/ }),

/***/ "K47E":
/***/ (function(module, exports) {

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

module.exports = _assertThisInitialized;

/***/ }),

/***/ "KI45":
/***/ (function(module, exports) {

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    default: obj
  };
}

module.exports = _interopRequireDefault;

/***/ }),

/***/ "LSCY":
/***/ (function(module, exports) {

module.exports = require("omit.js");

/***/ }),

/***/ "LjJ6":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("kOwS");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("qNsG");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("0iUn");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("sLSF");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("MI3g");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("a7VT");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("Tit0");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__("vYYK");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var omit_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__("LSCY");
/* harmony import */ var omit_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(omit_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__("K2gz");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _components_Themes__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__("qRXU");
/* harmony import */ var _productions__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__("No+n");
/* harmony import */ var _production__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__("SdlT");
/* harmony import */ var _category_less__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__("Sa3P");
/* harmony import */ var _category_less__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_category_less__WEBPACK_IMPORTED_MODULE_14__);










 // import { set, getClientSize } from 'rc-util/lib/Dom/css';

 // import { requestAnimationFrame } from '@lib/requestAnimationFrame';




var Banner = _production__WEBPACK_IMPORTED_MODULE_13__["default"].Banner;

var SectionBlock =
/*#__PURE__*/
function (_React$Component) {
  Object(_babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_6__[/* default */ "a"])(SectionBlock, _React$Component);

  function SectionBlock(props) {
    var _this;

    Object(_babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_2__[/* default */ "a"])(this, SectionBlock);

    _this = Object(_babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__[/* default */ "a"])(this, Object(_babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"])(SectionBlock).call(this, props)); // this.state = {
    //   animating: false,
    //   animOver: false
    // };
    // this.bannerRef = React.createRef();
    // this.contentRef = React.createRef();

    _this.fakeBannerRef = react__WEBPACK_IMPORTED_MODULE_8___default.a.createRef();
    return _this;
  }

  Object(_babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"])(SectionBlock, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      var _this2 = this;

      Object(_components_Themes__WEBPACK_IMPORTED_MODULE_11__[/* setTheme */ "b"])({
        footer: true
      }, this.props.router.route);

      SectionBlock.getBannerPosition = function () {
        return _this2.fakeBannerRef.current.getBoundingClientRect();
      }; // this.animationStart();

    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      Object(_components_Themes__WEBPACK_IMPORTED_MODULE_11__[/* setTheme */ "b"])({
        footer: false
      }, this.props.router.route);
    } // handleTransitionEnd = ({ target, currentTarget }) => {
    //   if ( target === currentTarget ) {
    //     this.state.animating = false; // eslint-disable-line
    //     this.state.animOver = true; // eslint-disable-line
    //     this.forceUpdate(() => {
    //       const dom = this.fakeBannerRef.current;
    //       SectionBlock.getBannerPosition = () => {
    //         return dom.getBoundingClientRect();
    //       };
    //     });
    //   }
    // };
    // animationStart = () => {
    //   const clientSize = getClientSize();
    //   const { transition, ...imageSize } = this.getImageStyle();
    //   this.state.animating = true; // eslint-disable-line
    //   set( this.bannerRef.current, {
    //     ...imageSize,
    //     transform: this.getImageCoverTransform( imageSize,  { width: clientSize.width, height: 350 })
    //   });
    //   this.forceUpdate(() => {
    //     set( this.contentRef.current, {
    //       transform: 'translateY(350px)'
    //     });
    //     requestAnimationFrame(() => {
    //       requestAnimationFrame(() => {
    //         const position = { width: getClientSize().width, height: 350 };
    //         if ( this.bannerRef.current ) {
    //           set( this.bannerRef.current, {
    //             transition,
    //             transform: this.getImageCoverTransform( imageSize, position )
    //           });
    //         }
    //       });
    //     });
    //   });
    // };
    // getImageStyle = () => {
    //   const { themeVariables, themeEasings } = this.context;
    //   const image = this.bannerRef.current;
    //   const { width, height } = getClientSize();
    //   const imageRatio = image.width / image.height;
    //   const targetRatio = width / height;
    //   return {
    //     width: imageRatio > targetRatio ? imageRatio * height : width,
    //     height: imageRatio > targetRatio ? height : width / imageRatio,
    //     transition: `transform ${themeVariables['@anim-speed-2']} ${themeEasings['@easeOutQuad']}`
    //   };
    // };
    // getImageCoverTransform = ( image, target, percent = 0.5 ) => {
    //   const imageRatio = image.width / image.height;
    //   const targetRatio = target.width / target.height;
    //   if ( imageRatio > targetRatio ) {
    //     const scale = target.height / image.height;
    //     const imageWidth = image.width * scale;
    //     const w = ( imageWidth - target.width ) * -percent;
    //     return `translateX(${w}px) translateY(0) translateZ(0) scale(${scale})`;
    //   }
    //   const scale = target.width / image.width;
    //   const imageHeight = image.height * scale;
    //   const h = ( imageHeight - target.height ) * -percent;
    //   return `translateX(0) translateY(${h}px) translateZ(0) scale(${scale})`;
    // };

  }, {
    key: "render",
    value: function render() {
      // const { animating, animOver } = this.state;
      var _this$props = this.props,
          className = _this$props.className,
          index = _this$props.index,
          bannerImage = _this$props.bannerImage,
          category = _this$props.category,
          props = Object(_babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(_this$props, ["className", "index", "bannerImage", "category"]);

      return react__WEBPACK_IMPORTED_MODULE_8___default.a.createElement("section", Object(_babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])({}, omit_js__WEBPACK_IMPORTED_MODULE_9___default()(props, ['router']), {
        className: classnames__WEBPACK_IMPORTED_MODULE_10___default()(_category_less__WEBPACK_IMPORTED_MODULE_14___default.a.block, className, {// [styles.blockAnimating]: !animOver,
          // [styles.blockOh]: !animOver
        })
      }), react__WEBPACK_IMPORTED_MODULE_8___default.a.createElement("div", {
        ref: this.fakeBannerRef,
        className: _category_less__WEBPACK_IMPORTED_MODULE_14___default.a.blockBanner,
        style: {
          backgroundImage: "url(".concat(bannerImage, ")")
        }
      }, react__WEBPACK_IMPORTED_MODULE_8___default.a.createElement(Banner, {
        category: category
      })), react__WEBPACK_IMPORTED_MODULE_8___default.a.createElement("div", {
        ref: this.contentRef,
        className: _category_less__WEBPACK_IMPORTED_MODULE_14___default.a.blockContent
      }, react__WEBPACK_IMPORTED_MODULE_8___default.a.createElement(_production__WEBPACK_IMPORTED_MODULE_13__["default"], {
        productions: _productions__WEBPACK_IMPORTED_MODULE_12__["productions"][index - 1]
      })));
    }
  }]);

  return SectionBlock;
}(react__WEBPACK_IMPORTED_MODULE_8___default.a.Component);

Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_7__[/* default */ "a"])(SectionBlock, "contextType", _components_Themes__WEBPACK_IMPORTED_MODULE_11__[/* ThemeContext */ "a"]);

/* harmony default export */ __webpack_exports__["default"] = (SectionBlock);

/***/ }),

/***/ "MAnk":
/***/ (function(module, exports) {

module.exports = "<div>\r\n  <h2>\r\n    智能网由TR1000系列\r\n  </h2>\r\n  <p>适用于各类需要统一数据格式上报的场合。</p>\r\n  <ul>\r\n    <li>\r\n    支持BACNet、ModbusTCP、OPC格式数据转换\r\n    </li>\r\n    <li>\r\n    统一数据上报格式\r\n    </li>\r\n    <li>\r\n    提供网关及其连接设备远程状态诊断\r\n    </li>\r\n  </ul>\r\n</div>"

/***/ }),

/***/ "MC3a":
/***/ (function(module, exports) {

module.exports = "<div>\r\n  <h2>\r\n    敏捷网关TG100系列\r\n  </h2>\r\n  <p>适用于各类非IP设备的数据采集、处理、存储、加密、传输等。</p>\r\n  <ul>\r\n    <li>\r\n    使用了统一的DD-IoT 物联网协议\r\n    </li>\r\n    <li>\r\n    多样化的数据采集接口\r\n    </li>\r\n    <li>\r\n    设备驱动可配置，支持多种设备通讯协议\r\n    </li>\r\n  </ul>\r\n</div>"

/***/ }),

/***/ "MI3g":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/symbol/iterator.js
var iterator = __webpack_require__("XVgq");
var iterator_default = /*#__PURE__*/__webpack_require__.n(iterator);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/symbol.js
var symbol = __webpack_require__("Z7t5");
var symbol_default = /*#__PURE__*/__webpack_require__.n(symbol);

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/typeof.js



function typeof_typeof2(obj) { if (typeof symbol_default.a === "function" && typeof iterator_default.a === "symbol") { typeof_typeof2 = function _typeof2(obj) { return typeof obj; }; } else { typeof_typeof2 = function _typeof2(obj) { return obj && typeof symbol_default.a === "function" && obj.constructor === symbol_default.a && obj !== symbol_default.a.prototype ? "symbol" : typeof obj; }; } return typeof_typeof2(obj); }

function typeof_typeof(obj) {
  if (typeof symbol_default.a === "function" && typeof_typeof2(iterator_default.a) === "symbol") {
    typeof_typeof = function _typeof(obj) {
      return typeof_typeof2(obj);
    };
  } else {
    typeof_typeof = function _typeof(obj) {
      return obj && typeof symbol_default.a === "function" && obj.constructor === symbol_default.a && obj !== symbol_default.a.prototype ? "symbol" : typeof_typeof2(obj);
    };
  }

  return typeof_typeof(obj);
}
// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/assertThisInitialized.js
var assertThisInitialized = __webpack_require__("AT/M");

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/possibleConstructorReturn.js
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _possibleConstructorReturn; });


function _possibleConstructorReturn(self, call) {
  if (call && (typeof_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return Object(assertThisInitialized["a" /* default */])(self);
}

/***/ }),

/***/ "N9n2":
/***/ (function(module, exports, __webpack_require__) {

var _Object$create = __webpack_require__("SqZg");

var setPrototypeOf = __webpack_require__("vjea");

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = _Object$create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) setPrototypeOf(subClass, superClass);
}

module.exports = _inherits;

/***/ }),

/***/ "No+n":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "categorys", function() { return categorys; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "productions", function() { return productions; });
var categorys = [{
  as: '/hardware/1',
  url: '/hardware?category=1',
  name: '智能网关类',
  products: 'TG121系列/TG120系列/TG100系列',
  description: '欣动智能网关是将客户通用需求与行业个性化需求有机融合的革命性产品，具有现场/远程可配置、可编程功能，提供可靠的物联网软硬件平台和统一开放的MQTT IoT通讯协议，简化物联网网关的定制和部署，协助加速物联网应用的开发和创新。'
}, {
  as: '/hardware/2',
  url: '/hardware?category=2',
  name: '智能网由类',
  products: 'TR1000系列/TR1000-DatUP',
  description: '欣动TR1000系列智能网由是将不同行业标准网络接口协议，转换为MQTT物联网接口协议的创新型产品。支持BACnet/IP、OPC和Modbus/TCP等协议，并能在持续更新与系列化发展中，支持更多传统产业如智能楼宇、工业自控等，向智能化物联网方向升级。'
}, {
  as: '/hardware/3',
  url: '/hardware?category=3',
  name: '前置服务类',
  products: 'TFS1000-BEMS/TFS1000-GBMS',
  description: '欣动TFS1000系列前置服务器是集数据采集、应用扩展和服务发布为一体的专用设备，提供特定功能的现场轻量级服务，如智能设备监测服务、单体建筑能源管理服务和单体绿色建筑运营管理服务等。'
}, {
  as: '/hardware/4',
  url: '/hardware?category=4',
  name: '终端设备类',
  products: 'TC100-R8/TDV100-WN',
  description: '欣动终端设备类是将客户通用需求与客户个性化需求、行业性需求有机融合的革命性产品。其中智能控制器使用微处理器和专用控制算法，实现智能控制；信息发布终端提供综合、全面的信息发布解决方案。'
}, {
  as: '/hardware/5',
  url: '/hardware?category=5',
  name: '接口转换类',
  products: 'TCONV-MR4',
  description: '欣动接口转换类产品可以将不同接口设备组网，实现设备间的互操作。基于多种通信口和各种协议，形成不同种类的接口转换器。'
}, {
  as: '/hardware/6',
  url: '/hardware?category=6',
  name: '集成机柜类',
  products: 'GR10-TG网关柜/GR10-TR网由柜',
  description: '欣动GR10系列集成机柜类，作为支持能源管理解决方案的重要组件，所有部件工厂预制、预装、预调试，打包运输，现场仅需简单安装，实现业务快速上线。所有设备一体化集成在一个机柜，相对于传统建设模式至少节省50%安装空间。'
}];
var productions = [// 智能网关
[{
  name: 'TG121-N-485',
  image: __webpack_require__("/8XS"),
  html: __webpack_require__("T2Y/")
}, {
  name: 'TG120-N-485',
  image: __webpack_require__("O8vT"),
  html: __webpack_require__("9qb6")
}, {
  soldOut: true,
  name: 'TG100-N-485',
  image: __webpack_require__("qmBw"),
  html: __webpack_require__("MC3a")
}], // 只能网由类
[{
  name: 'TR1000-Base',
  image: __webpack_require__("w9w0"),
  html: __webpack_require__("MAnk")
}, {
  name: 'TR1000-DatUP',
  image: __webpack_require__("HDZ4"),
  html: __webpack_require__("dIfZ")
}], // 前置服务
[{
  name: 'TFS1000-BEMS',
  image: __webpack_require__("vd60"),
  html: __webpack_require__("sO2e")
}, {
  name: 'TFS1000-GBMS',
  image: __webpack_require__("s3X4"),
  html: __webpack_require__("OsBW")
}], // 中断设备
[{
  name: 'TC100-R8',
  image: __webpack_require__("X8t4"),
  html: __webpack_require__("x3F3")
}, {
  name: 'TDV1000-WN',
  image: __webpack_require__("EYMO"),
  html: __webpack_require__("fyDi")
}], // 接口转换
[{
  name: 'TCONV-MR4',
  image: __webpack_require__("kaF8"),
  html: __webpack_require__("a2x+")
}], // 集成机柜
[{
  name: 'GR10-TG',
  image: __webpack_require__("YLb4"),
  html: __webpack_require__("e8Iw")
}, {
  name: 'GR10-TR',
  image: __webpack_require__("hlvG"),
  html: __webpack_require__("hYnc")
}]];

/***/ }),

/***/ "O8vT":
/***/ (function(module, exports) {

module.exports = "/_next/static/images/TG120-N-485-ac58423080658c8e1bd977548241960d.png";

/***/ }),

/***/ "OaG5":
/***/ (function(module, exports) {

module.exports = {
	"container": "xT0TZHns",
	"pro": "_2RRLFwcq",
	"pro-image": "_17sibiBV",
	"proImage": "_17sibiBV",
	"pro-info": "_3lznK7ro",
	"proInfo": "_3lznK7ro",
	"pro-info-content": "_323PXJDV",
	"proInfoContent": "_323PXJDV",
	"pro-info-sold-out": "W_JpTQFO",
	"proInfoSoldOut": "W_JpTQFO",
	"sold-out": "_1iswXWJa",
	"soldOut": "_1iswXWJa",
	"banner-container": "_2ESG1PyM",
	"bannerContainer": "_2ESG1PyM",
	"banner": "PEpqQqnw",
	"banner-menu": "sTZ73VCZ",
	"bannerMenu": "sTZ73VCZ",
	"link": "-SLBkbIt",
	"selected": "GlgkF1yP"
};

/***/ }),

/***/ "OsBW":
/***/ (function(module, exports) {

module.exports = "<div>\r\n  <h2>\r\n    绿建监测服务器TFS1000-GBMS\r\n  </h2>\r\n  <p>适用于各类绿色建筑的能效评估服务</p>\r\n  <ul>\r\n    <li>\r\n    各类能源、资源分类、分项计量\r\n    </li>\r\n    <li>\r\n    能源可视化动态监测、损耗分析、能耗预警\r\n    </li>\r\n    <li>\r\n    能效对标、能效公示、能效评估\r\n    </li>\r\n    <li>\r\n    节能诊断分析、能效评估报告、节能改进建议\r\n    </li>\r\n  </ul>\r\n</div>"

/***/ }),

/***/ "Sa3P":
/***/ (function(module, exports) {

module.exports = {
	"block": "_2-FNjH0g",
	"block-banner": "_2LBSK6aW",
	"blockBanner": "_2LBSK6aW",
	"block-animating": "_31mMt0ld",
	"blockAnimating": "_31mMt0ld",
	"block-banner-image": "_2nrZmGXq",
	"blockBannerImage": "_2nrZmGXq",
	"block-content": "MTsLtJt6",
	"blockContent": "MTsLtJt6"
};

/***/ }),

/***/ "SdlT":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("kOwS");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("vYYK");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("qNsG");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("0iUn");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("sLSF");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("MI3g");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("a7VT");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__("Tit0");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__("YFqc");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__("K2gz");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var rc_tween_one__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__("VNO/");
/* harmony import */ var rc_tween_one__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(rc_tween_one__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var rc_queue_anim__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__("Ufq7");
/* harmony import */ var rc_queue_anim__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(rc_queue_anim__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _productions__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__("No+n");
/* harmony import */ var _production_less__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__("OaG5");
/* harmony import */ var _production_less__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_production_less__WEBPACK_IMPORTED_MODULE_14__);
















var Production =
/*#__PURE__*/
function (_React$Component) {
  Object(_babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_7__[/* default */ "a"])(Production, _React$Component);

  function Production() {
    Object(_babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"])(this, Production);

    return Object(_babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"])(this, Object(_babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_6__[/* default */ "a"])(Production).apply(this, arguments));
  }

  Object(_babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_4__[/* default */ "a"])(Production, [{
    key: "render",
    value: function render() {
      var _this$props = this.props,
          productions = _this$props.productions,
          className = _this$props.className,
          props = Object(_babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_2__[/* default */ "a"])(_this$props, ["productions", "className"]);

      return react__WEBPACK_IMPORTED_MODULE_8___default.a.createElement(rc_queue_anim__WEBPACK_IMPORTED_MODULE_12___default.a, Object(_babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])({}, props, {
        delay: 300,
        duration: 600,
        animConfig: {
          opacity: [1, 0]
        },
        className: classnames__WEBPACK_IMPORTED_MODULE_10___default()(_production_less__WEBPACK_IMPORTED_MODULE_14___default.a.container, className)
      }), productions.map(function (_ref, index) {
        var name = _ref.name,
            image = _ref.image,
            html = _ref.html,
            soldOut = _ref.soldOut;
        var soldOutTag = "<div class=".concat(_production_less__WEBPACK_IMPORTED_MODULE_14___default.a.proInfoSoldOut, ">\u505C\u4EA7</div>");
        return react__WEBPACK_IMPORTED_MODULE_8___default.a.createElement("section", {
          key: "pro-".concat(index),
          className: classnames__WEBPACK_IMPORTED_MODULE_10___default()(_production_less__WEBPACK_IMPORTED_MODULE_14___default.a.pro, Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])({}, _production_less__WEBPACK_IMPORTED_MODULE_14___default.a.soldOut, soldOut))
        }, react__WEBPACK_IMPORTED_MODULE_8___default.a.createElement("div", {
          className: _production_less__WEBPACK_IMPORTED_MODULE_14___default.a.proInfo
        }, react__WEBPACK_IMPORTED_MODULE_8___default.a.createElement("div", {
          className: _production_less__WEBPACK_IMPORTED_MODULE_14___default.a.proInfoContent,
          dangerouslySetInnerHTML: {
            __html: (soldOut ? soldOutTag : '') + html
          }
        })), react__WEBPACK_IMPORTED_MODULE_8___default.a.createElement("figure", {
          className: _production_less__WEBPACK_IMPORTED_MODULE_14___default.a.proImage
        }, react__WEBPACK_IMPORTED_MODULE_8___default.a.createElement("img", {
          alt: name,
          src: image,
          width: "100%"
        })));
      }));
    }
  }]);

  return Production;
}(react__WEBPACK_IMPORTED_MODULE_8___default.a.Component);

function Banner(_ref2) {
  var category = _ref2.category;
  return react__WEBPACK_IMPORTED_MODULE_8___default.a.createElement(rc_tween_one__WEBPACK_IMPORTED_MODULE_11___default.a, {
    className: _production_less__WEBPACK_IMPORTED_MODULE_14___default.a.bannerContainer,
    animation: {
      opacity: 0,
      type: 'from'
    }
  }, react__WEBPACK_IMPORTED_MODULE_8___default.a.createElement("div", {
    className: _production_less__WEBPACK_IMPORTED_MODULE_14___default.a.banner
  }, react__WEBPACK_IMPORTED_MODULE_8___default.a.createElement(rc_tween_one__WEBPACK_IMPORTED_MODULE_11___default.a, {
    component: "h1",
    animation: {
      x: 100,
      type: 'from'
    }
  }, category.name), react__WEBPACK_IMPORTED_MODULE_8___default.a.createElement(rc_tween_one__WEBPACK_IMPORTED_MODULE_11___default.a, {
    component: "p",
    animation: {
      x: -80,
      type: 'from'
    }
  }, category.description)), react__WEBPACK_IMPORTED_MODULE_8___default.a.createElement("div", {
    className: _production_less__WEBPACK_IMPORTED_MODULE_14___default.a.bannerMenu
  }, _productions__WEBPACK_IMPORTED_MODULE_13__["categorys"].map(function (_ref3) {
    var name = _ref3.name,
        url = _ref3.url,
        as = _ref3.as;
    return react__WEBPACK_IMPORTED_MODULE_8___default.a.createElement(next_link__WEBPACK_IMPORTED_MODULE_9___default.a, {
      key: name,
      as: as,
      href: url
    }, react__WEBPACK_IMPORTED_MODULE_8___default.a.createElement("a", {
      className: classnames__WEBPACK_IMPORTED_MODULE_10___default()(_production_less__WEBPACK_IMPORTED_MODULE_14___default.a.link, Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])({}, _production_less__WEBPACK_IMPORTED_MODULE_14___default.a.selected, category.name === name))
    }, name));
  })));
}

Production.Banner = Banner;
/* harmony default export */ __webpack_exports__["default"] = (Production);

/***/ }),

/***/ "SqZg":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("o5io");

/***/ }),

/***/ "T2Y/":
/***/ (function(module, exports) {

module.exports = "<div>\r\n  <h2>\r\n    智能网关TG121系列\r\n  </h2>\r\n  <p>提供全方位软硬件解决方案、建构模块与SDK ，以连接各种无线/有线装置，简化物联网部署；强化DD-IoT 应用开发，方便数据通信与设备管理，加速物联网创新。</p>\r\n  <ul>\r\n    <li>\r\n    使用了统一的DD-IoT 物联网协议\r\n    </li>\r\n    <li>\r\n    提供多种数据远程传输通道\r\n    </li>\r\n    <li>\r\n    多样化的数据采集接口\r\n    </li>\r\n    <li>\r\n    设备驱动可编程，支持各种设备通讯协议\r\n    </li>\r\n    <li>\r\n    可扩展数据存储容量\r\n    </li>\r\n  </ul>\r\n</div>"

/***/ }),

/***/ "TRZx":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("Wk4r");

/***/ }),

/***/ "TUA0":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/define-property");

/***/ }),

/***/ "Tit0":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/create.js
var create = __webpack_require__("SqZg");
var create_default = /*#__PURE__*/__webpack_require__.n(create);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/set-prototype-of.js
var set_prototype_of = __webpack_require__("TRZx");
var set_prototype_of_default = /*#__PURE__*/__webpack_require__.n(set_prototype_of);

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/setPrototypeOf.js

function _setPrototypeOf(o, p) {
  _setPrototypeOf = set_prototype_of_default.a || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}
// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/inherits.js
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _inherits; });


function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = create_default()(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

/***/ }),

/***/ "UXZV":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("dGr4");

/***/ }),

/***/ "Ufq7":
/***/ (function(module, exports) {

module.exports = require("rc-queue-anim");

/***/ }),

/***/ "VNO/":
/***/ (function(module, exports) {

module.exports = require("rc-tween-one");

/***/ }),

/***/ "WaGi":
/***/ (function(module, exports, __webpack_require__) {

var _Object$defineProperty = __webpack_require__("hfKm");

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;

    _Object$defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

module.exports = _createClass;

/***/ }),

/***/ "Wk4r":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/set-prototype-of");

/***/ }),

/***/ "X8t4":
/***/ (function(module, exports) {

module.exports = "/_next/static/images/TC100-R8-e2ab4ad6675894a834b25726a72b2ff8.png";

/***/ }),

/***/ "XVgq":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("gHn/");

/***/ }),

/***/ "YFqc":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("cTJO")


/***/ }),

/***/ "YLb4":
/***/ (function(module, exports) {

module.exports = "/_next/static/images/GR10-TG-c41c335af0de3e41958e6b90fc5833ae.png";

/***/ }),

/***/ "Z6Kq":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/get-own-property-descriptor");

/***/ }),

/***/ "Z7t5":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("vqFK");

/***/ }),

/***/ "ZDA2":
/***/ (function(module, exports, __webpack_require__) {

var _typeof = __webpack_require__("iZP3");

var assertThisInitialized = __webpack_require__("K47E");

function _possibleConstructorReturn(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return assertThisInitialized(self);
}

module.exports = _possibleConstructorReturn;

/***/ }),

/***/ "a2x+":
/***/ (function(module, exports) {

module.exports = "<div>\r\n  <h2>\r\n    MRus/485转换器-协议透传 TCONV-MR4\r\n  </h2>\r\n  <p>适用于需要MBus接口转成RS-485的接口的场合。</p>\r\n  <ul>\r\n    <li>\r\n     成熟的嵌入式软硬件平台，便于系统功能的扩展\r\n    </li>\r\n    <li>\r\n     通过电磁兼容性整体设计，满足低噪音、低电磁干扰的环保要求\r\n    </li>\r\n    <li>\r\n     适应恶劣电网、温度、湿度和粉尘能力，产品可靠性高\r\n    </li>\r\n  </ul>\r\n</div>"

/***/ }),

/***/ "a7VT":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _getPrototypeOf; });
/* harmony import */ var _core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("Bhuq");
/* harmony import */ var _core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("TRZx");
/* harmony import */ var _core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_1__);


function _getPrototypeOf(o) {
  _getPrototypeOf = _core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_1___default.a ? _core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0___default.a : function _getPrototypeOf(o) {
    return o.__proto__ || _core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0___default()(o);
  };
  return _getPrototypeOf(o);
}

/***/ }),

/***/ "bPsq":
/***/ (function(module, exports) {

module.exports = require("less-vars-to-js");

/***/ }),

/***/ "bzos":
/***/ (function(module, exports) {

module.exports = require("url");

/***/ }),

/***/ "cDcd":
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "cTJO":
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/* global __NEXT_DATA__ */

var _interopRequireDefault = __webpack_require__("KI45");

var _stringify = _interopRequireDefault(__webpack_require__("9Jkg"));

var _classCallCheck2 = _interopRequireDefault(__webpack_require__("/HRN"));

var _createClass2 = _interopRequireDefault(__webpack_require__("WaGi"));

var _possibleConstructorReturn2 = _interopRequireDefault(__webpack_require__("ZDA2"));

var _getPrototypeOf2 = _interopRequireDefault(__webpack_require__("/+P4"));

var _inherits2 = _interopRequireDefault(__webpack_require__("N9n2"));

var __importStar = void 0 && (void 0).__importStar || function (mod) {
  if (mod && mod.__esModule) return mod;
  var result = {};
  if (mod != null) for (var k in mod) {
    if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
  }
  result["default"] = mod;
  return result;
};

var __importDefault = void 0 && (void 0).__importDefault || function (mod) {
  return mod && mod.__esModule ? mod : {
    "default": mod
  };
};

Object.defineProperty(exports, "__esModule", {
  value: true
});

var url_1 = __webpack_require__("bzos");

var react_1 = __importStar(__webpack_require__("cDcd"));

var prop_types_1 = __importDefault(__webpack_require__("rf6O"));

var router_1 = __importStar(__webpack_require__("4Q3z"));

var utils_1 = __webpack_require__("p8BD");

function isLocal(href) {
  var url = url_1.parse(href, false, true);
  var origin = url_1.parse(utils_1.getLocationOrigin(), false, true);
  return !url.host || url.protocol === origin.protocol && url.host === origin.host;
}

function memoizedFormatUrl(formatFunc) {
  var lastHref = null;
  var lastAs = null;
  var lastResult = null;
  return function (href, as) {
    if (href === lastHref && as === lastAs) {
      return lastResult;
    }

    var result = formatFunc(href, as);
    lastHref = href;
    lastAs = as;
    lastResult = result;
    return result;
  };
}

function formatUrl(url) {
  return url && typeof url === 'object' ? utils_1.formatWithValidation(url) : url;
}

var Link =
/*#__PURE__*/
function (_react_1$Component) {
  (0, _inherits2.default)(Link, _react_1$Component);

  function Link() {
    var _this;

    (0, _classCallCheck2.default)(this, Link);
    _this = (0, _possibleConstructorReturn2.default)(this, (0, _getPrototypeOf2.default)(Link).apply(this, arguments)); // The function is memoized so that no extra lifecycles are needed
    // as per https://reactjs.org/blog/2018/06/07/you-probably-dont-need-derived-state.html

    _this.formatUrls = memoizedFormatUrl(function (href, asHref) {
      return {
        href: formatUrl(href),
        as: formatUrl(asHref, true)
      };
    });

    _this.linkClicked = function (e) {
      var _e$currentTarget = e.currentTarget,
          nodeName = _e$currentTarget.nodeName,
          target = _e$currentTarget.target;

      if (nodeName === 'A' && (target && target !== '_self' || e.metaKey || e.ctrlKey || e.shiftKey || e.nativeEvent && e.nativeEvent.which === 2)) {
        // ignore click for new tab / new window behavior
        return;
      }

      var _this$formatUrls = _this.formatUrls(_this.props.href, _this.props.as),
          href = _this$formatUrls.href,
          as = _this$formatUrls.as;

      if (!isLocal(href)) {
        // ignore click if it's outside our scope
        return;
      }

      var pathname = window.location.pathname;
      href = url_1.resolve(pathname, href);
      as = as ? url_1.resolve(pathname, as) : href;
      e.preventDefault(); //  avoid scroll for urls with anchor refs

      var scroll = _this.props.scroll;

      if (scroll == null) {
        scroll = as.indexOf('#') < 0;
      } // replace state instead of push if prop is present


      router_1.default[_this.props.replace ? 'replace' : 'push'](href, as, {
        shallow: _this.props.shallow
      }).then(function (success) {
        if (!success) return;

        if (scroll) {
          window.scrollTo(0, 0);
          document.body.focus();
        }
      }).catch(function (err) {
        if (_this.props.onError) _this.props.onError(err);
      });
    };

    return _this;
  }

  (0, _createClass2.default)(Link, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      this.prefetch();
    }
  }, {
    key: "componentDidUpdate",
    value: function componentDidUpdate(prevProps) {
      if ((0, _stringify.default)(this.props.href) !== (0, _stringify.default)(prevProps.href)) {
        this.prefetch();
      }
    }
  }, {
    key: "prefetch",
    value: function prefetch() {
      if (!this.props.prefetch) return;
      if (typeof window === 'undefined') return; // Prefetch the JSON page if asked (only in the client)

      var pathname = window.location.pathname;

      var _this$formatUrls2 = this.formatUrls(this.props.href, this.props.as),
          parsedHref = _this$formatUrls2.href;

      var href = url_1.resolve(pathname, parsedHref);
      router_1.default.prefetch(href);
    }
  }, {
    key: "render",
    value: function render() {
      var _this2 = this;

      var children = this.props.children;

      var _this$formatUrls3 = this.formatUrls(this.props.href, this.props.as),
          href = _this$formatUrls3.href,
          as = _this$formatUrls3.as; // Deprecated. Warning shown by propType check. If the childen provided is a string (<Link>example</Link>) we wrap it in an <a> tag


      if (typeof children === 'string') {
        children = react_1.default.createElement("a", null, children);
      } // This will return the first child, if multiple are provided it will throw an error


      var child = react_1.Children.only(children);
      var props = {
        onClick: function onClick(e) {
          if (child.props && typeof child.props.onClick === 'function') {
            child.props.onClick(e);
          }

          if (!e.defaultPrevented) {
            _this2.linkClicked(e);
          }
        }
      }; // If child is an <a> tag and doesn't have a href attribute, or if the 'passHref' property is
      // defined, we specify the current 'href', so that repetition is not needed by the user

      if (this.props.passHref || child.type === 'a' && !('href' in child.props)) {
        props.href = as || href;
      } // Add the ending slash to the paths. So, we can serve the
      // "<page>/index.html" directly.


      if (true) {
        if (props.href && typeof __NEXT_DATA__ !== 'undefined' && __NEXT_DATA__.nextExport) {
          props.href = router_1.Router._rewriteUrlForNextExport(props.href);
        }
      }

      return react_1.default.cloneElement(child, props);
    }
  }]);
  return Link;
}(react_1.Component);

if (false) { var exact, warn; }

exports.default = Link;

/***/ }),

/***/ "dGr4":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/assign");

/***/ }),

/***/ "dIfZ":
/***/ (function(module, exports) {

module.exports = "<div>\r\n  <h2>\r\n    智能TR1000-DatUP\r\n  </h2>\r\n  <p>适用于大型公建能源数据上报</p>\r\n  <ul>\r\n    <li>\r\n    标准的数据上报格式，可根据需要自定义数据格式\r\n    </li>\r\n    <li>\r\n    数据远程数据传输通道，具备跨网段数据转发功能\r\n    </li>\r\n    <li>\r\n    在无以太网情况下，可根据需要加装4G传输模块\r\n    </li>\r\n  </ul>\r\n</div>"

/***/ }),

/***/ "e8Iw":
/***/ (function(module, exports) {

module.exports = "<div>\n  <h2>\n    GR10-TG网关柜\n  </h2>\n  <p>含柜体、电源，适用于各类网关的现场安装</p>\n  <ul>\n    <li>\n     具有抗振动、抗冲击、耐腐蚀、防尘、防水、防辐射等性能，以便保证柜内设备稳定可靠地工作。\n    </li>\n    <li>\n     良好的使用性和安全防护设施，便于操作、安装和维修。\n    </li>\n    <li>\n     柜体大小、柜内设备及数量可定制\n    </li>\n  </ul>\n</div>"

/***/ }),

/***/ "fozc":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/json/stringify");

/***/ }),

/***/ "fyDi":
/***/ (function(module, exports) {

module.exports = "<div>\r\n  <h2>\r\n    信息发布终端-配合电视监控屏实现终端信息发布 TDV100-WN\r\n  </h2>\r\n  <p>适用于使用显示设备发布各类信息的场合。</p>\r\n  <ul>\r\n    <li>\r\n     提供多种信息发布传输通道\r\n    </li>\r\n    <li>\r\n     支持后台设备管理，远程管理显示终端\r\n    </li>\r\n    <li>\r\n     提供显示终端远程状态信息\r\n    </li>\r\n  </ul>\r\n</div>"

/***/ }),

/***/ "gHn/":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/symbol/iterator");

/***/ }),

/***/ "hYnc":
/***/ (function(module, exports) {

module.exports = "<div>\n  <h2>\n    GR10-TR网由柜\n  </h2>\n  <p>含柜体、电源，适用于各类网由的现场安装</p>\n  <ul>\n    <li>\n     具有抗振动、抗冲击、耐腐蚀、防尘、防水、防辐射等性能，以便保证柜内设备稳定可靠地工作。\n    </li>\n    <li>\n     良好的使用性和安全防护设施，便于操作、安装和维修。\n    </li>\n    <li>\n     柜体大小、柜内设备及数量可定制。\n    </li>\n  </ul>\n</div>"

/***/ }),

/***/ "hfKm":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("TUA0");

/***/ }),

/***/ "hlvG":
/***/ (function(module, exports) {

module.exports = "/_next/static/images/GR10-TR-1a4194ab83354c630b78526a0a10be8d.png";

/***/ }),

/***/ "iZP3":
/***/ (function(module, exports, __webpack_require__) {

var _Symbol$iterator = __webpack_require__("XVgq");

var _Symbol = __webpack_require__("Z7t5");

function _typeof2(obj) { if (typeof _Symbol === "function" && typeof _Symbol$iterator === "symbol") { _typeof2 = function _typeof2(obj) { return typeof obj; }; } else { _typeof2 = function _typeof2(obj) { return obj && typeof _Symbol === "function" && obj.constructor === _Symbol && obj !== _Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof2(obj); }

function _typeof(obj) {
  if (typeof _Symbol === "function" && _typeof2(_Symbol$iterator) === "symbol") {
    module.exports = _typeof = function _typeof(obj) {
      return _typeof2(obj);
    };
  } else {
    module.exports = _typeof = function _typeof(obj) {
      return obj && typeof _Symbol === "function" && obj.constructor === _Symbol && obj !== _Symbol.prototype ? "symbol" : _typeof2(obj);
    };
  }

  return _typeof(obj);
}

module.exports = _typeof;

/***/ }),

/***/ "k1wZ":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/get-own-property-symbols");

/***/ }),

/***/ "kJFy":
/***/ (function(module, exports) {

module.exports = require("flystore");

/***/ }),

/***/ "kOwS":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _extends; });
/* harmony import */ var _core_js_object_assign__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("UXZV");
/* harmony import */ var _core_js_object_assign__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_assign__WEBPACK_IMPORTED_MODULE_0__);

function _extends() {
  _extends = _core_js_object_assign__WEBPACK_IMPORTED_MODULE_0___default.a || function (target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];

      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }

    return target;
  };

  return _extends.apply(this, arguments);
}

/***/ }),

/***/ "kaF8":
/***/ (function(module, exports) {

module.exports = "/_next/static/images/TCONV-MR4-2ba85548e5a86c6e9127eaf0f35a2d5f.png";

/***/ }),

/***/ "o5io":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/create");

/***/ }),

/***/ "p8BD":
/***/ (function(module, exports) {

module.exports = require("next-server/dist/lib/utils");

/***/ }),

/***/ "pLtp":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("qJj/");

/***/ }),

/***/ "qJj/":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/keys");

/***/ }),

/***/ "qNsG":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/get-own-property-symbols.js
var get_own_property_symbols = __webpack_require__("4mXO");
var get_own_property_symbols_default = /*#__PURE__*/__webpack_require__.n(get_own_property_symbols);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/keys.js
var keys = __webpack_require__("pLtp");
var keys_default = /*#__PURE__*/__webpack_require__.n(keys);

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/objectWithoutPropertiesLoose.js

function _objectWithoutPropertiesLoose(source, excluded) {
  if (source == null) return {};
  var target = {};

  var sourceKeys = keys_default()(source);

  var key, i;

  for (i = 0; i < sourceKeys.length; i++) {
    key = sourceKeys[i];
    if (excluded.indexOf(key) >= 0) continue;
    target[key] = source[key];
  }

  return target;
}
// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/objectWithoutProperties.js
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _objectWithoutProperties; });


function _objectWithoutProperties(source, excluded) {
  if (source == null) return {};
  var target = _objectWithoutPropertiesLoose(source, excluded);
  var key, i;

  if (get_own_property_symbols_default.a) {
    var sourceSymbolKeys = get_own_property_symbols_default()(source);

    for (i = 0; i < sourceSymbolKeys.length; i++) {
      key = sourceSymbolKeys[i];
      if (excluded.indexOf(key) >= 0) continue;
      if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
      target[key] = source[key];
    }
  }

  return target;
}

/***/ }),

/***/ "qRXU":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/keys.js
var keys = __webpack_require__("pLtp");
var keys_default = /*#__PURE__*/__webpack_require__.n(keys);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/extends.js
var esm_extends = __webpack_require__("kOwS");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/classCallCheck.js
var classCallCheck = __webpack_require__("0iUn");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/createClass.js
var createClass = __webpack_require__("sLSF");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/possibleConstructorReturn.js + 1 modules
var possibleConstructorReturn = __webpack_require__("MI3g");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/getPrototypeOf.js
var getPrototypeOf = __webpack_require__("a7VT");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/assertThisInitialized.js
var assertThisInitialized = __webpack_require__("AT/M");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/inherits.js + 1 modules
var inherits = __webpack_require__("Tit0");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/defineProperty.js
var defineProperty = __webpack_require__("vYYK");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/assign.js
var object_assign = __webpack_require__("UXZV");
var assign_default = /*#__PURE__*/__webpack_require__.n(object_assign);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/objectSpread.js
var objectSpread = __webpack_require__("zrwo");

// EXTERNAL MODULE: external "flystore"
var external_flystore_ = __webpack_require__("kJFy");
var external_flystore_default = /*#__PURE__*/__webpack_require__.n(external_flystore_);

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__("cDcd");
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);

// EXTERNAL MODULE: external "object.pick"
var external_object_pick_ = __webpack_require__("6RRd");
var external_object_pick_default = /*#__PURE__*/__webpack_require__.n(external_object_pick_);

// EXTERNAL MODULE: external "less-vars-to-js"
var external_less_vars_to_js_ = __webpack_require__("bPsq");
var external_less_vars_to_js_default = /*#__PURE__*/__webpack_require__.n(external_less_vars_to_js_);

// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__("4Q3z");
var router_default = /*#__PURE__*/__webpack_require__.n(router_);

// CONCATENATED MODULE: ./node_modules/raw-loader/dist/cjs.js!./assets/custom.less
/* harmony default export */ var custom = ("\n// https://github.com/ant-design/ant-design/blob/master/components/style/themes/default.less\n@import (reference) \"~antd/lib/style/themes/default.less\";\n@import (reference) \"~antd/lib/style/mixins/index.less\";\n@import (reference) \"./easings/index.less\";\n\n@gray-1: #ffffff;\n@gray-2: #fafafa;\n@gray-3: #f5f5f5;\n@gray-4: #e8e8e8;\n@gray-5: #d9d9d9;\n@gray-6: #bfbfbf;\n@gray-7: #8c8c8c;\n@gray-8: #595959;\n@gray-9: #262626;\n@gray-10: #000000;\n\n// 暗黑\n@dark-1: rgba(0, 0, 0, .05);\n@dark-2: rgba(0, 0, 0, .15);\n@dark-3: rgba(0, 0, 0, .25);\n@dark-4: rgba(0, 0, 0, .35);\n@dark-5: rgba(0, 0, 0, .45);\n@dark-6: rgba(0, 0, 0, .55);\n@dark-7: rgba(0, 0, 0, .65);\n@dark-8: rgba(0, 0, 0, .75);\n@dark-9: rgba(0, 0, 0, .85);\n@dark-10: rgba(0, 0, 0, 1);\n\n// 亮白\n@light-1: rgba(255, 255, 255, .05);\n@light-2: rgba(255, 255, 255, .15);\n@light-3: rgba(255, 255, 255, .25);\n@light-4: rgba(255, 255, 255, .35);\n@light-5: rgba(255, 255, 255, .45);\n@light-6: rgba(255, 255, 255, .55);\n@light-7: rgba(255, 255, 255, .65);\n@light-8: rgba(255, 255, 255, .75);\n@light-9: rgba(255, 255, 255, .85);\n@light-10: rgba(255, 255, 255, 1);\n\n\n@mask-color: #001529;\n@footer-color: @light-8;\n@footer-link-color: @light-6;\n@footer-link-hover-color: @light-10;\n@footer-background-color: @dark-10;\n@header-background-color: #001529;\n@anchor-background-color: @light-10;\n@anchor-color: #1890ff;\n\n\n@dark-menu-color: @light-7;\n@dark-menu-background-color: @header-background-color;\n\n\n@anim-speed-1: 200ms;\n@anim-speed-2: 375ms;\n@anim-speed-3: 500ms;\n@anim-speed-4: 800ms;\n@anim-speed-5: 1200ms;\n\n\n@page-width: 980px;\n@page-width-lg: 1440px;\n@max-width: 1920px; // 2560px\n@header-height: 64px;\n@header-phone-height: 48px;\n@anchor-height: 48px;\n\n\n// z-index\n@header-zIndex: 1100;\n@anchor-zIndex: @header-zIndex - 10;\n\n// shadow\n@shadow-down: 0 2px 8px rgba(0, 0, 0, 0.08);\n@shadow-down-dark: 0 2px 8px rgba(0, 0, 0, 0.2);\n@shadow-down-sm: 4px 6px 10px rgba(0, 0, 0, 0.1);\n@shadow-down-lg: 8px 12px 20px rgba(0, 0, 0, 0.3);\n\n\n@main-color: #fa8c16;\n@main-background-color: #001529;\n@main-light-background-color: #f1f3ff;\n\n// .function {\n//   .foo(@x) {\n//     return: @x * 2;\n//   }\n// }");
// CONCATENATED MODULE: ./node_modules/raw-loader/dist/cjs.js!./assets/easings/index.less
/* harmony default export */ var easings = ("//https://easings.net/\n//http://cubic-bezier.com/#.17,.67,.83,.67\n@linear         : cubic-bezier(0.250, 0.250, 0.750, 0.750);\n@ease           : cubic-bezier(0.250, 0.100, 0.250, 1.000);\n@ease-in        : cubic-bezier(0.420, 0.000, 1.000, 1.000);\n@ease-out       : cubic-bezier(0.000, 0.000, 0.580, 1.000);\n@ease-in-out    : cubic-bezier(0.420, 0.000, 0.580, 1.000);\n\n@easeInQuad     : cubic-bezier(0.550, 0.085, 0.680, 0.530);\n@easeInCubic    : cubic-bezier(0.550, 0.055, 0.675, 0.190);\n@easeInQuart    : cubic-bezier(0.895, 0.030, 0.685, 0.220);\n@easeInQuint    : cubic-bezier(0.755, 0.050, 0.855, 0.060);\n@easeInSine     : cubic-bezier(0.470, 0.000, 0.745, 0.715);\n@easeInExpo     : cubic-bezier(0.950, 0.050, 0.795, 0.035);\n@easeInCirc     : cubic-bezier(0.600, 0.040, 0.980, 0.335);\n@easeInBack     : cubic-bezier(0.600, -0.280, 0.735, 0.045);\n\n@easeOutQuad    : cubic-bezier(0.250, 0.460, 0.450, 0.940);\n@easeOutCubic   : cubic-bezier(0.215, 0.610, 0.355, 1.000);\n@easeOutQuart   : cubic-bezier(0.165, 0.840, 0.440, 1.000);\n@easeOutQuint   : cubic-bezier(0.230, 1.000, 0.320, 1.000);\n@easeOutSine    : cubic-bezier(0.390, 0.575, 0.565, 1.000);\n@easeOutExpo    : cubic-bezier(0.190, 1.000, 0.220, 1.000);\n@easeOutCirc    : cubic-bezier(0.075, 0.820, 0.165, 1.000);\n@easeOutBack    : cubic-bezier(0.175, 0.885, 0.320, 1.275);\n\n@easeInOutQuad  : cubic-bezier(0.455, 0.030, 0.515, 0.955);\n@easeInOutCubic : cubic-bezier(0.645, 0.045, 0.355, 1.000);\n@easeInOutQuart : cubic-bezier(0.770, 0.000, 0.175, 1.000);\n@easeInOutQuint : cubic-bezier(0.860, 0.000, 0.070, 1.000);\n@easeInOutSine  : cubic-bezier(0.445, 0.050, 0.550, 0.950);\n@easeInOutExpo  : cubic-bezier(1.000, 0.000, 0.000, 1.000);\n@easeInOutCirc  : cubic-bezier(0.785, 0.135, 0.150, 0.860);\n@easeInOutBack  : cubic-bezier(0.680, -0.550, 0.265, 1.550);\n");
// CONCATENATED MODULE: ./components/Themes/index.js
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return themeVariables; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return themeEasings; });
/* unused harmony export defaultThemeConfig */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return Themes_setTheme; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "e", function() { return withTheme; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ThemeContext; });


















var themeVariables = external_less_vars_to_js_default()(custom, {
  resolveVariables: true
});
var themeEasings = external_less_vars_to_js_default()(easings, {
  resolveVariables: true
});
var defaultThemeConfig = {
  footer: true,
  header: true
};
var storeTheme = external_flystore_default()('@theme-config');
storeTheme.set('config', Object(objectSpread["a" /* default */])({}, defaultThemeConfig));
storeTheme.set('change', {});
var Themes_setTheme = function setTheme(config, changeRoute) {
  var route = router_default.a.router.route;

  if (changeRoute && changeRoute !== route) {
    var themeConfig = storeTheme.get("change-".concat(changeRoute));
    storeTheme.set("change-".concat(changeRoute), assign_default()({}, themeConfig, config));
  } else {
    var _themeConfig = storeTheme.get("change-".concat(route));

    var newConfig = assign_default()({}, _themeConfig, config);

    storeTheme.set("change-".concat(route), newConfig);
    storeTheme.dispense('change', newConfig);
  }
};
function withTheme(Comp) {
  var _class, _temp;

  return Object(router_["withRouter"])((_temp = _class =
  /*#__PURE__*/
  function (_React$Component) {
    Object(inherits["a" /* default */])(WithTheme, _React$Component);

    function WithTheme() {
      var _getPrototypeOf2;

      var _this;

      Object(classCallCheck["a" /* default */])(this, WithTheme);

      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }

      _this = Object(possibleConstructorReturn["a" /* default */])(this, (_getPrototypeOf2 = Object(getPrototypeOf["a" /* default */])(WithTheme)).call.apply(_getPrototypeOf2, [this].concat(args)));

      Object(defineProperty["a" /* default */])(Object(assertThisInitialized["a" /* default */])(_this), "state", {
        themeConfig: storeTheme.get('config')
      });

      return _this;
    }

    Object(createClass["a" /* default */])(WithTheme, [{
      key: "componentDidMount",
      value: function componentDidMount() {
        var _this2 = this;

        var route = this.props.router.route;
        var changeConfig = storeTheme.get("change-".concat(route));

        if (changeConfig) {
          this.setState({
            themeConfig: assign_default()(storeTheme.get('config'), changeConfig)
          });
        }

        this.configHandle = storeTheme.watch('change', function (themeConfig) {
          _this2.setState({
            themeConfig: assign_default()(storeTheme.get('config'), themeConfig)
          });
        });
      }
    }, {
      key: "componentWillUnmount",
      value: function componentWillUnmount() {
        if (this.configHandle) {
          this.configHandle.clear();
          this.configHandle = null;
        }
      }
    }, {
      key: "render",
      value: function render() {
        return external_react_default.a.createElement(Comp, Object(esm_extends["a" /* default */])({}, this.props, {
          themeConfig: this.state.themeConfig
        }));
      }
    }]);

    return WithTheme;
  }(external_react_default.a.Component), Object(defineProperty["a" /* default */])(_class, "getDerivedStateFromProps", function (props) {
    var route = props.router.route;

    var newConfig = assign_default()({}, defaultThemeConfig, external_object_pick_default()(props, keys_default()(defaultThemeConfig)));

    var changeConfig = storeTheme.get("change-".concat(route));
    return {
      themeConfig: assign_default()(newConfig, changeConfig)
    };
  }), _temp));
}
var ThemeContext = external_react_default.a.createContext({
  env: {},
  themeConfig: Object(objectSpread["a" /* default */])({}, defaultThemeConfig),
  themeEasings: themeEasings,
  themeVariables: themeVariables,
  isLoaded: false,
  isMobile: false
});

/***/ }),

/***/ "qmBw":
/***/ (function(module, exports) {

module.exports = "/_next/static/images/TG100-N-485-5d4ed183fca046315a36e9c6266dff47.png";

/***/ }),

/***/ "rf6O":
/***/ (function(module, exports) {

module.exports = require("prop-types");

/***/ }),

/***/ "s3X4":
/***/ (function(module, exports) {

module.exports = "/_next/static/images/TFS1000-GBMS-0881a7ed4278168be42c788b1d5aa9a9.png";

/***/ }),

/***/ "sLSF":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _createClass; });
/* harmony import */ var _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("hfKm");
/* harmony import */ var _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__);


function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;

    _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default()(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

/***/ }),

/***/ "sO2e":
/***/ (function(module, exports) {

module.exports = "<div>\r\n  <h2>\r\n    建筑能源服务器TFS1000-BEMS\r\n  </h2>\r\n  <p>适用于各类建筑的能源服务。</p>\r\n  <ul>\r\n    <li>\r\n    各类能源、资源分类、分项计量\r\n    </li>\r\n    <li>\r\n    能源可视化动态监测\r\n    </li>\r\n    <li>\r\n    能效公示、评估\r\n    </li>\r\n  </ul>\r\n</div>"

/***/ }),

/***/ "vYYK":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _defineProperty; });
/* harmony import */ var _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("hfKm");
/* harmony import */ var _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__);

function _defineProperty(obj, key, value) {
  if (key in obj) {
    _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default()(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}

/***/ }),

/***/ "vd60":
/***/ (function(module, exports) {

module.exports = "/_next/static/images/TFS1000-BEMS-0881a7ed4278168be42c788b1d5aa9a9.png";

/***/ }),

/***/ "vjea":
/***/ (function(module, exports, __webpack_require__) {

var _Object$setPrototypeOf = __webpack_require__("TRZx");

function _setPrototypeOf(o, p) {
  module.exports = _setPrototypeOf = _Object$setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

module.exports = _setPrototypeOf;

/***/ }),

/***/ "vqFK":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/symbol");

/***/ }),

/***/ "w9w0":
/***/ (function(module, exports) {

module.exports = "/_next/static/images/TR1000-Base-0a004fe31fc8be21ce7d494ce547f2c8.png";

/***/ }),

/***/ "x3F3":
/***/ (function(module, exports) {

module.exports = "<div>\r\n  <h2>\r\n    智能控制器-八路继电器输出型TC100-R8\r\n  </h2>\r\n  <p>适用于工业自动化系统，负荷控制；各类使用时间策略控制的工业场合。配合智能网关及后台监控系统，可以实现多种控制模式：</p>\r\n  <ul>\r\n    <li>\r\n     远程手动控制模式\r\n    </li>\r\n    <li>\r\n     延时控制模式\r\n    </li>\r\n    <li>\r\n     循环控制模式\r\n    </li>\r\n    <li>\r\n     全自动策略控制模式\r\n    </li>\r\n  </ul>\r\n</div>"

/***/ }),

/***/ "zrwo":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _objectSpread; });
/* harmony import */ var _core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("Jo+v");
/* harmony import */ var _core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("4mXO");
/* harmony import */ var _core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _core_js_object_keys__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("pLtp");
/* harmony import */ var _core_js_object_keys__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_keys__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _defineProperty__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("vYYK");




function _objectSpread(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i] != null ? arguments[i] : {};

    var ownKeys = _core_js_object_keys__WEBPACK_IMPORTED_MODULE_2___default()(source);

    if (typeof _core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1___default.a === 'function') {
      ownKeys = ownKeys.concat(_core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1___default()(source).filter(function (sym) {
        return _core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_0___default()(source, sym).enumerable;
      }));
    }

    ownKeys.forEach(function (key) {
      Object(_defineProperty__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"])(target, key, source[key]);
    });
  }

  return target;
}

/***/ })

/******/ });