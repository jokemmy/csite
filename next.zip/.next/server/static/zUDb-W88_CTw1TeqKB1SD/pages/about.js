module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../../../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 5);
/******/ })
/************************************************************************/
/******/ ({

/***/ "/+oN":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/get-prototype-of");

/***/ }),

/***/ "0iUn":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _classCallCheck; });
function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

/***/ }),

/***/ "4Q3z":
/***/ (function(module, exports) {

module.exports = require("next/router");

/***/ }),

/***/ "4mXO":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("k1wZ");

/***/ }),

/***/ 5:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("7E5O");


/***/ }),

/***/ "6RRd":
/***/ (function(module, exports) {

module.exports = require("object.pick");

/***/ }),

/***/ "7E5O":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/regenerator/index.js
var regenerator = __webpack_require__("ln6h");
var regenerator_default = /*#__PURE__*/__webpack_require__.n(regenerator);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/asyncToGenerator.js
var asyncToGenerator = __webpack_require__("O40h");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/classCallCheck.js
var classCallCheck = __webpack_require__("0iUn");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/createClass.js
var createClass = __webpack_require__("sLSF");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/possibleConstructorReturn.js + 1 modules
var possibleConstructorReturn = __webpack_require__("MI3g");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/getPrototypeOf.js
var getPrototypeOf = __webpack_require__("a7VT");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/inherits.js + 1 modules
var inherits = __webpack_require__("Tit0");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/defineProperty.js
var defineProperty = __webpack_require__("vYYK");

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__("cDcd");
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);

// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__("K2gz");
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/extends.js
var esm_extends = __webpack_require__("kOwS");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/assign.js
var object_assign = __webpack_require__("UXZV");
var assign_default = /*#__PURE__*/__webpack_require__.n(object_assign);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/objectWithoutProperties.js + 1 modules
var objectWithoutProperties = __webpack_require__("qNsG");

// EXTERNAL MODULE: external "uuid/v1"
var v1_ = __webpack_require__("CUYq");
var v1_default = /*#__PURE__*/__webpack_require__.n(v1_);

// EXTERNAL MODULE: external "rc-scroll-anim"
var external_rc_scroll_anim_ = __webpack_require__("XQhW");

// EXTERNAL MODULE: ./components/ParallaxBackground/parallaxBackground.less
var parallaxBackground = __webpack_require__("cBsA");
var parallaxBackground_default = /*#__PURE__*/__webpack_require__.n(parallaxBackground);

// CONCATENATED MODULE: ./components/ParallaxBackground/index.js















var ParallaxBackground_ParallaxBackground =
/*#__PURE__*/
function (_React$Component) {
  Object(inherits["a" /* default */])(ParallaxBackground, _React$Component);

  function ParallaxBackground() {
    Object(classCallCheck["a" /* default */])(this, ParallaxBackground);

    return Object(possibleConstructorReturn["a" /* default */])(this, Object(getPrototypeOf["a" /* default */])(ParallaxBackground).apply(this, arguments));
  }

  Object(createClass["a" /* default */])(ParallaxBackground, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      this.uid = v1_default()();
      this.forceUpdate();
    }
  }, {
    key: "render",
    value: function render() {
      var _this$props = this.props,
          children = _this$props.children,
          className = _this$props.className,
          range = _this$props.range,
          image = _this$props.image,
          imageClass = _this$props.imageClass,
          style = _this$props.style,
          props = Object(objectWithoutProperties["a" /* default */])(_this$props, ["children", "className", "range", "image", "imageClass", "style"]);

      var imageStyle = !imageClass && image ? {
        backgroundImage: "url(".concat(image, ")")
      } : {};
      var distance = (range[1] - range[0]) / 2;
      return external_react_default.a.createElement("div", Object(esm_extends["a" /* default */])({}, props, {
        style: assign_default()({
          height: '100vh'
        }, style || {}),
        className: external_classnames_default()(className, parallaxBackground_default.a.container)
      }), external_react_default.a.createElement(external_rc_scroll_anim_["Parallax"], {
        animation: {
          y: distance
        },
        className: parallaxBackground_default.a.parallax,
        style: {
          position: 'absolute',
          top: 0,
          left: 0,
          height: '100%',
          zIndex: -1,
          marginTop: -distance
        }
      }, this.uid ? external_react_default.a.createElement(external_rc_scroll_anim_["Parallax"], {
        style: imageStyle,
        location: this.uid,
        animation: {
          y: distance
        },
        className: imageClass
      }) : null), children, external_react_default.a.createElement("div", {
        id: this.uid,
        style: {
          position: 'absolute',
          bottom: 0,
          left: 0,
          height: 0
        }
      }));
    }
  }]);

  return ParallaxBackground;
}(external_react_default.a.Component);

Object(defineProperty["a" /* default */])(ParallaxBackground_ParallaxBackground, "defaultProps", {
  range: [-88, 88]
});

/* harmony default export */ var components_ParallaxBackground = (ParallaxBackground_ParallaxBackground);
// EXTERNAL MODULE: ./components/SvgIcon/index.js
var SvgIcon = __webpack_require__("BE5S");

// EXTERNAL MODULE: external "typed.js"
var external_typed_js_ = __webpack_require__("kqMJ");
var external_typed_js_default = /*#__PURE__*/__webpack_require__.n(external_typed_js_);

// EXTERNAL MODULE: ./components/Typed/typed.less
var typed = __webpack_require__("NvCX");
var typed_default = /*#__PURE__*/__webpack_require__.n(typed);

// CONCATENATED MODULE: ./components/Typed/index.js












var Typed_TypedReact =
/*#__PURE__*/
function (_React$Component) {
  Object(inherits["a" /* default */])(TypedReact, _React$Component);

  function TypedReact(props) {
    var _this;

    Object(classCallCheck["a" /* default */])(this, TypedReact);

    _this = Object(possibleConstructorReturn["a" /* default */])(this, Object(getPrototypeOf["a" /* default */])(TypedReact).call(this, props));
    _this.typedRef = external_react_default.a.createRef();
    return _this;
  }

  Object(createClass["a" /* default */])(TypedReact, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      // If you want to pass more options as props, simply add
      // your desired props to this destructuring assignment.
      var strings = this.props.strings; // You can pass other options here, such as typing speed, back speed, etc.

      var options = {
        strings: strings,
        typeSpeed: 50,
        backSpeed: 50,
        backDelay: 3000,
        loop: true
      }; // this.el refers to the <span> in the render() method

      this.typed = new external_typed_js_default.a(this.typedRef.current, options);
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      // Make sure to destroy Typed instance on unmounting
      // to prevent memory leaks
      if (this.typed) {
        this.typed.destroy();
        this.typed = null;
      }
    }
  }, {
    key: "render",
    value: function render() {
      var _this$props = this.props,
          className = _this$props.className,
          props = Object(objectWithoutProperties["a" /* default */])(_this$props, ["className"]);

      return external_react_default.a.createElement("span", Object(esm_extends["a" /* default */])({}, props, {
        className: external_classnames_default()(className, typed_default.a.whiteSpace)
      }), external_react_default.a.createElement("span", {
        ref: this.typedRef
      }));
    }
  }]);

  return TypedReact;
}(external_react_default.a.Component);

/* harmony default export */ var Typed = (Typed_TypedReact);
// EXTERNAL MODULE: ./components/Themes/index.js + 2 modules
var Themes = __webpack_require__("qRXU");

// EXTERNAL MODULE: ./assets/images/about/core-1.svg?sprite
var core_1sprite = __webpack_require__("9Sqk");
var core_1sprite_default = /*#__PURE__*/__webpack_require__.n(core_1sprite);

// EXTERNAL MODULE: ./assets/images/about/core-2.svg?sprite
var core_2sprite = __webpack_require__("acqn");
var core_2sprite_default = /*#__PURE__*/__webpack_require__.n(core_2sprite);

// EXTERNAL MODULE: ./assets/images/about/core-3.svg?sprite
var core_3sprite = __webpack_require__("t+JW");
var core_3sprite_default = /*#__PURE__*/__webpack_require__.n(core_3sprite);

// EXTERNAL MODULE: ./assets/images/about/platform-1.svg?sprite
var platform_1sprite = __webpack_require__("GJh8");
var platform_1sprite_default = /*#__PURE__*/__webpack_require__.n(platform_1sprite);

// EXTERNAL MODULE: ./assets/images/about/platform-2.svg?sprite
var platform_2sprite = __webpack_require__("Hw11");
var platform_2sprite_default = /*#__PURE__*/__webpack_require__.n(platform_2sprite);

// EXTERNAL MODULE: ./assets/images/about/platform-3.svg?sprite
var platform_3sprite = __webpack_require__("aStJ");
var platform_3sprite_default = /*#__PURE__*/__webpack_require__.n(platform_3sprite);

// EXTERNAL MODULE: ./pages/about/about.less
var about = __webpack_require__("hzsg");
var about_default = /*#__PURE__*/__webpack_require__.n(about);

// CONCATENATED MODULE: ./pages/about/index.js



















 // import Topology from './topology';



var about_About =
/*#__PURE__*/
function (_React$Component) {
  Object(inherits["a" /* default */])(About, _React$Component);

  function About() {
    Object(classCallCheck["a" /* default */])(this, About);

    return Object(possibleConstructorReturn["a" /* default */])(this, Object(getPrototypeOf["a" /* default */])(About).apply(this, arguments));
  }

  Object(createClass["a" /* default */])(About, [{
    key: "render",
    value: function render() {
      var themeVariables = this.context.themeVariables;
      return external_react_default.a.createElement(external_react_default.a.Fragment, null, external_react_default.a.createElement("div", {
        className: external_classnames_default()(about_default.a.aboutBlock, about_default.a.aboutBanner)
      }, external_react_default.a.createElement(components_ParallaxBackground, {
        className: about_default.a.aboutBlockImage,
        imageClass: about_default.a.aboutBanner1
      }), external_react_default.a.createElement("div", {
        className: about_default.a.aboutBannerContent
      }, external_react_default.a.createElement(Typed, {
        className: about_default.a.aboutBannerTitle,
        strings: ['我们是“智慧能源的践行者”', '数据计算严谨，\n使用方便简单，\n是我们产品的设计宗旨', '我们是一家良心企业']
      }))), external_react_default.a.createElement("section", {
        className: about_default.a.aboutBlock,
        style: {
          backgroundColor: themeVariables['@gray-3']
        }
      }, external_react_default.a.createElement("div", {
        className: "page-content"
      }, external_react_default.a.createElement("h2", {
        className: about_default.a.aboutBlockTitle
      }, "\u6211\u4EEC\u505A\u4EC0\u4E48"), external_react_default.a.createElement("p", null, "\u6C5F\u82CF\u6B23\u52A8\u4FE1\u606F\u79D1\u6280\u6709\u9650\u516C\u53F8\u662F\u56FD\u5185\u9886\u5148\u7684\u667A\u6167\u80FD\u6E90\u96C6\u6210\u670D\u52A1\u63D0\u4F9B\u5546\uFF0C \u4E13\u6CE8\u4E8E\u7269\u8054\u7F51\u6280\u672F\u548C\u667A\u6167\u89E3\u51B3\u65B9\u6848\u5F00\u53D1\u3001\u5B9E\u65BD\u53CA\u8FD0\u8425\uFF0C\u81F4\u529B\u4E8E\u4E3A\u5BA2\u6237\u63D0\u4F9B\u667A\u6167\u80FD\u6E90\u89E3\u51B3\u65B9\u6848\u3002"), external_react_default.a.createElement("p", null, "\u6B23\u52A8\u79D1\u6280\u4E3A\u9AD8\u7B49\u9662\u6821\u3001\u653F\u5E9C\u673A\u5173\u3001\u4F01\u4E8B\u4E1A\u5355\u4F4D\u3001\u5927\u578B\u516C\u5171\u5EFA\u7B51\u7B49\u9886\u57DF\u63D0\u4F9B\u80FD\u6E90\u76D1\u7BA1\u5E73\u53F0\uFF08EMMS\uFF09\u7684\u8BBE\u8BA1\u4E0E\u5F00\u53D1\u670D\u52A1\u3001 \u73B0\u573A\u5B9E\u65BD\u670D\u52A1\u53CA\u7BA1\u7406\u54A8\u8BE2\u670D\u52A1\u3002\u516C\u53F8\u540C\u65F6\u62E5\u6709\u7ECF\u9A8C\u4E30\u5BCC\u7684\u9879\u76EE\u5B9E\u65BD\u8FD0\u8425\u56E2\u961F\u548C\u54A8\u8BE2\u670D\u52A1\u4E13\u5BB6\u56E2\u961F\uFF0C \u5728\u56FD\u5185\u9AD8\u6821\u53CA\u5546\u4E1A\u884C\u4E1A\u5E94\u7528\u5904\u4E8E\u5E02\u573A\u9886\u5148\u5730\u4F4D\u3002"))), external_react_default.a.createElement("section", {
        className: external_classnames_default()(about_default.a.aboutBlock, about_default.a.aboutBannerBlock)
      }, external_react_default.a.createElement(components_ParallaxBackground, {
        className: about_default.a.aboutBlockImage,
        imageClass: about_default.a.aboutBanner3
      }), external_react_default.a.createElement("div", {
        className: "page-content"
      }, external_react_default.a.createElement("h2", {
        className: about_default.a.aboutBlockTitle
      }, "\u4E09\u5927\u652F\u6491\u5E73\u53F0"), external_react_default.a.createElement("p", null, "\u4EE5\u6B23\u52A8\u79D1\u6280\u81EA\u4E3B\u7814\u53D1\u7684DD-IoT\u5E73\u53F0\u4E3A\u6838\u5FC3\uFF0C\u91C7\u7528\u5E94\u7528\u652F\u6491\u5E73\u53F0\u3001\u6570\u636E\u4E2D\u5FC3\u5E73\u53F0\u3001\u7269\u8054\u611F\u77E5\u5E73\u53F0\u6784\u5EFA\u8D77\u4E09\u7EA7\u5E73\u53F0\uFF0C \u5229\u7528\u4EBA\u5DE5\u667A\u80FD+\u7269\u8054\u7F51+\u5927\u6570\u636E+\u4E91\u8BA1\u7B97\u6280\u672F\uFF0C\u91C7\u7528\u524D\u7AEF\u786C\u4EF6\u8BBE\u5907+\u540E\u7AEF\u5927\u6570\u636E\u5E73\u53F0\u6A21\u5F0F\uFF0C\u5C06\u4EBA\u4E0E\u57FA\u7840\u8BBE\u65BD\u3001 \u670D\u52A1\u7BA1\u7406\u5EFA\u7ACB\u7D27\u5BC6\u8054\u7CFB\uFF0C\u6253\u901A\u5404\u7EA7\u3001\u5404\u884C\u4E1A\u667A\u6167\u5E94\u7528\u5E73\u53F0\uFF0C\u5F62\u6210\u7CFB\u7EDF\u5316\u7684\u89E3\u51B3\u65B9\u6848\u3002"), external_react_default.a.createElement("div", {
        className: about_default.a.aboutBlockPlatform3,
        style: {
          color: '#fff'
        }
      }, external_react_default.a.createElement("div", null, external_react_default.a.createElement("div", {
        className: about_default.a.icon
      }, external_react_default.a.createElement(SvgIcon["a" /* default */], {
        icon: platform_3sprite_default.a
      })), external_react_default.a.createElement("div", null, "\u7269\u8054\u611F\u77E5\u5E73\u53F0")), external_react_default.a.createElement("div", null, external_react_default.a.createElement("div", {
        className: about_default.a.icon
      }, external_react_default.a.createElement(SvgIcon["a" /* default */], {
        icon: platform_2sprite_default.a
      })), external_react_default.a.createElement("div", null, "\u6570\u636E\u4E2D\u5FC3\u5E73\u53F0")), external_react_default.a.createElement("div", null, external_react_default.a.createElement("div", {
        className: about_default.a.icon
      }, external_react_default.a.createElement(SvgIcon["a" /* default */], {
        icon: platform_1sprite_default.a
      })), external_react_default.a.createElement("div", null, "\u5E94\u7528\u652F\u6491\u5E73\u53F0"))))), external_react_default.a.createElement("section", {
        className: about_default.a.aboutBlock,
        style: {
          backgroundColor: themeVariables['@gray-3']
        }
      }, external_react_default.a.createElement("div", {
        className: "page-content"
      }, external_react_default.a.createElement("h2", {
        className: about_default.a.aboutBlockTitle
      }, "\u6838\u5FC3\u4E1A\u52A1"), external_react_default.a.createElement("p", null, "\u4E13\u4E1A\u7684\u7CFB\u7EDF\u96C6\u6210\u670D\u52A1\u56E2\u961F\uFF0C\u53EF\u4E3A\u5BA2\u6237\u63D0\u4F9B\u5168\u65B9\u4F4D\u3001\u5168\u8FC7\u7A0B\u3001\u4E00\u4F53\u5316\u7684\u80FD\u6E90\u7BA1\u7406\u7CFB\u7EDF\u89E3\u51B3\u65B9\u6848\u3002 \u4E3A\u5BA2\u6237\u63D0\u4F9B\u4E13\u4E1A\u7684\u6280\u672F\u652F\u6301\u548C\u7CFB\u7EDF\u6258\u7BA1\uFF0C\u786E\u4FDD\u7CFB\u7EDF\u6B63\u5E38\u8FD0\u884C\uFF0C\u4E3A\u8282\u80FD\u8BCA\u65AD\u3001\u8282\u80FD\u5BA1\u8BA1\u63D0\u4F9B\u4F18\u8D28\u7684\u6570\u636E\u57FA\u7840\u3002 \u4EE5\u6570\u636E\u4E3A\u8F7D\u4F53\uFF0C\u4EE5\u9488\u5BF9\u8BBE\u5907\u7CFB\u7EDF\u7684\u8BCA\u65AD\u3001\u8C03\u8BD5\u3001\u6539\u9020\u3001\u4F18\u5316\u548C\u9488\u5BF9\u7BA1\u7406\u8005\u7684\u6C47\u62A5\u3001\u57F9\u8BAD\u3001\u7BA1\u7406\u652F\u6301\u4E3A\u4E3B\u8981\u624B\u6BB5\uFF0C \u5E2E\u52A9\u5BA2\u6237\u89E3\u51B3\u80FD\u8017\u53CA\u54C1\u8D28\u7684\u76F8\u5173\u95EE\u9898\uFF0C\u540C\u65F6\u5EFA\u7ACB\u957F\u6548\u7684\u9884\u9632\u673A\u5236\uFF0C\u5B9E\u73B0\u957F\u671F\u7EFF\u8272\u8FD0\u8425\u3002"), external_react_default.a.createElement("div", {
        className: about_default.a.aboutBlockCore3
      }, external_react_default.a.createElement("div", null, external_react_default.a.createElement("div", {
        className: about_default.a.icon
      }, external_react_default.a.createElement(SvgIcon["a" /* default */], {
        icon: core_1sprite_default.a
      })), external_react_default.a.createElement("div", null, "\u73B0\u573A\u7CFB\u7EDF\u96C6\u6210")), external_react_default.a.createElement("div", null, external_react_default.a.createElement("div", {
        className: about_default.a.icon
      }, external_react_default.a.createElement(SvgIcon["a" /* default */], {
        icon: core_2sprite_default.a
      })), external_react_default.a.createElement("div", null, "\u5B9E\u65F6\u6570\u636E\u6258\u7BA1")), external_react_default.a.createElement("div", null, external_react_default.a.createElement("div", {
        className: about_default.a.icon
      }, external_react_default.a.createElement(SvgIcon["a" /* default */], {
        icon: core_3sprite_default.a
      })), external_react_default.a.createElement("div", null, "\u8FDC\u7A0B\u7EFF\u8272\u8FD0\u8425"))))), external_react_default.a.createElement("section", {
        className: external_classnames_default()(about_default.a.aboutBlock, about_default.a.aboutBannerBlock)
      }, external_react_default.a.createElement(components_ParallaxBackground, {
        className: about_default.a.aboutBlockImage,
        imageClass: about_default.a.aboutBanner2
      }), external_react_default.a.createElement("div", {
        className: "page-content"
      }, external_react_default.a.createElement("h2", {
        className: about_default.a.aboutBlockTitle
      }, "\u6838\u5FC3\u80FD\u529B\u4E0E\u4F18\u52BF"), external_react_default.a.createElement("p", null, "\u786E\u4FDD\u80FD\u6E90\u4F7F\u7528\u5B89\u5168\uFF1B\u63D0\u4F9B\u9AD8\u7A33\u5B9A\u6027\u7684\u4EA7\u54C1\u548C\u89E3\u51B3\u65B9\u6848\uFF1B\u63D0\u4F9B\u7B80\u6D01\u65B9\u4FBF\u7684\u89E3\u51B3\u65B9\u6848\uFF0C\u5E2E\u52A9\u5BA2\u6237\u5B9E\u73B0\u6700\u4F73\u7684\u80FD\u6548\u7BA1\u7406\u548C\u8FC7\u7A0B\u6548\u7387\uFF1B\u878D\u5408\u4FE1\u606F\u6280\u672F\u548C\u8FD0\u8425\u6280\u672F\uFF0C\u5E2E\u52A9\u5BA2\u6237\u5B9E\u73B0\u66F4\u597D\u7684\u7684\u5546\u4E1A\u7ED3\u679C\uFF1B\u4EE5\u80FD\u6E90\u4E3A\u5207\u5165\uFF0C\u5B9E\u73B0\u8D44\u6E90\u7684\u53EF\u6301\u7EED\uFF1B"), external_react_default.a.createElement("ul", {
        className: about_default.a.aboutBlockAdvantage
      }, external_react_default.a.createElement("li", null, external_react_default.a.createElement("div", {
        className: about_default.a.ad1
      }), external_react_default.a.createElement("div", null, "\u66F4\u5B89\u5168")), external_react_default.a.createElement("li", null, external_react_default.a.createElement("div", {
        className: about_default.a.ad2
      }), external_react_default.a.createElement("div", null, "\u66F4\u53EF\u9760")), external_react_default.a.createElement("li", null, external_react_default.a.createElement("div", {
        className: about_default.a.ad3
      }), external_react_default.a.createElement("div", null, "\u66F4\u9AD8\u6548")), external_react_default.a.createElement("li", null, external_react_default.a.createElement("div", {
        className: about_default.a.ad4
      }), external_react_default.a.createElement("div", null, "\u66F4\u4E92\u8054")), external_react_default.a.createElement("li", null, external_react_default.a.createElement("div", {
        className: about_default.a.ad5
      }), external_react_default.a.createElement("div", null, "\u66F4\u6301\u7EED"))))));
    }
  }]);

  return About;
}(external_react_default.a.Component);

Object(defineProperty["a" /* default */])(about_About, "contextType", Themes["a" /* ThemeContext */]);

Object(defineProperty["a" /* default */])(about_About, "getInitialProps",
/*#__PURE__*/
function () {
  var _ref = Object(asyncToGenerator["a" /* default */])(
  /*#__PURE__*/
  regenerator_default.a.mark(function _callee(ctx_) {
    var layoutProps;
    return regenerator_default.a.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            layoutProps = {
              title: '欣动价值',
              // anchor: {
              //   anchors: [ '我们做的是什么', '核心能力与优势' ]
              // },
              header: {
                transparent: true // mode: 'light'

              },
              footer: {
                transparent: true,
                overlay: true,
                mode: 'light'
              },
              pageProps: {
                scrollClass: {
                  '>=0': 'page-header-hold',
                  '>=600': 'page-header-light page-header-logo-color'
                }
              }
            };
            return _context.abrupt("return", {
              layoutProps: layoutProps
            });

          case 2:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));

  return function (_x) {
    return _ref.apply(this, arguments);
  };
}());

/* harmony default export */ var pages_about = __webpack_exports__["default"] = (about_About);

/***/ }),

/***/ "9Sqk":
/***/ (function(module, exports, __webpack_require__) {

/* eslint-disable */
var React = __webpack_require__("cDcd");
var SpriteSymbol = __webpack_require__("QAmA");
var sprite = __webpack_require__("TQFg");

var symbol = new SpriteSymbol({
  "id": "5nnBh5Ux--sprite",
  "use": "5nnBh5Ux--sprite-usage",
  "viewBox": "0 0 1000.637 1000.678",
  "content": "<symbol xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 1000.637 1000.678\" id=\"5nnBh5Ux--sprite\"><path d=\"M799.131 746.27C762.384 621.654 652.173 532.917 522.59 523.61V388.993h89.063c12.297 0 22.266-9.969 22.266-22.266v-89.064c0-12.296-9.969-22.266-22.266-22.266H388.995c-12.297 0-22.266 9.97-22.266 22.266v89.064c0 12.296 9.969 22.266 22.266 22.266h89.063V523.61c-129.594 9.307-239.837 98.032-276.584 222.659-24.049 5.196-39.324 28.887-34.139 52.925 5.197 24.049 28.887 39.324 52.926 34.139 20.504-4.436 35.149-22.57 35.139-43.554 0-11.47-4.458-21.82-11.579-29.702 30.801-106.307 123.952-182.629 234.238-191.913v183.28c-13.242 7.697-22.267 21.896-22.267 38.356 0 24.593 19.94 44.532 44.533 44.532 24.591 0 44.532-19.939 44.532-44.532 0-16.438-9.024-30.637-22.267-38.356v-183.28c110.308 9.284 203.447 85.628 234.217 191.956a44.124 44.124 0 0 0-11.558 29.659c0 24.593 19.938 44.531 44.532 44.531 24.592 0 44.531-19.938 44.531-44.531-.021-20.983-14.676-39.095-35.181-43.509z\" /><path d=\"M344.462 478.057h53.904c12.307 0 22.266-9.97 22.266-22.266 0-12.296-9.959-22.266-22.266-22.266h-53.904c-12.296 0-22.266-9.97-22.266-22.267V233.131c0-12.296 9.97-22.266 22.266-22.266h311.722c12.297 0 22.266 9.97 22.266 22.266v178.127c0 12.297-9.969 22.267-22.266 22.267h-63.058c-12.295 0-22.266 9.97-22.266 22.266 0 12.296 9.971 22.266 22.266 22.266h63.058c36.889 0 66.799-29.909 66.799-66.798V233.131c0-36.889-29.91-66.798-66.799-66.798H344.462c-36.889 0-66.797 29.909-66.797 66.798v178.127c0 36.89 29.909 66.799 66.797 66.799z\" /></symbol>"
});
sprite.add(symbol);

var SvgSpriteIcon = function SvgSpriteIcon(props) {
  return React.createElement(
    'svg',
    Object.assign({
      viewBox: symbol.viewBox
    }, props),
    React.createElement(
      'use',
      {
        xlinkHref: '#' + symbol.id
      }
    )
  );
};

SvgSpriteIcon.viewBox = symbol.viewBox;
SvgSpriteIcon.id = symbol.id;
SvgSpriteIcon.content = symbol.content;
SvgSpriteIcon.url = symbol.url;
SvgSpriteIcon.toString = symbol.toString;

module.exports = SvgSpriteIcon;
module.exports.default = SvgSpriteIcon;


/***/ }),

/***/ "AT/M":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _assertThisInitialized; });
function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

/***/ }),

/***/ "BE5S":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return Icon; });
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("kOwS");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("qNsG");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("K2gz");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _svgIcon_less__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("flPq");
/* harmony import */ var _svgIcon_less__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_svgIcon_less__WEBPACK_IMPORTED_MODULE_4__);





function Icon(_ref) {
  var icon = _ref.icon,
      className = _ref.className,
      props = Object(_babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(_ref, ["icon", "className"]);

  return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("svg", Object(_babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])({
    "aria-hidden": "true"
  }, props, {
    className: classnames__WEBPACK_IMPORTED_MODULE_3___default()(_svgIcon_less__WEBPACK_IMPORTED_MODULE_4___default.a.svgIcon, className)
  }), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("use", {
    xlinkHref: "#".concat(icon.id)
  }));
}

/***/ }),

/***/ "Bhuq":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("/+oN");

/***/ }),

/***/ "CUYq":
/***/ (function(module, exports) {

module.exports = require("uuid/v1");

/***/ }),

/***/ "GJh8":
/***/ (function(module, exports, __webpack_require__) {

/* eslint-disable */
var React = __webpack_require__("cDcd");
var SpriteSymbol = __webpack_require__("QAmA");
var sprite = __webpack_require__("TQFg");

var symbol = new SpriteSymbol({
  "id": "FujUWUiE--sprite",
  "use": "FujUWUiE--sprite-usage",
  "viewBox": "0 0 1000.637 1000.678",
  "content": "<symbol xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 1000.637 1000.678\" id=\"FujUWUiE--sprite\"><path d=\"M884.553 203.541c-3.36-14.466-17.807-23.467-32.276-20.112l-140.218 32.487c-14.472 3.343-23.492 17.786-20.146 32.258a26.803 26.803 0 0 0 6.856 12.625l30.607 31.653-163.511 145.872-84.902-80.41c-10.754-10.184-27.721-9.75-37.949.965L260.867 549.871c-29.074-6.068-57.575 12.58-63.649 41.651-6.074 29.073 12.575 57.569 41.654 63.662 29.073 6.067 57.575-12.58 63.649-41.652a54.02 54.02 0 0 0 1.134-11.005c0-5.829-1.154-11.318-2.875-16.558L463.426 415.41l83.399 78.958c10.151 9.605 25.96 9.843 36.388.539l183.539-163.731 34.89 36.12c10.308 10.681 27.341 10.977 38.016.662a26.761 26.761 0 0 0 7.302-12.363l37.347-139.01a26.969 26.969 0 0 0 .246-13.044z\" /><path d=\"M841.52 448.62c-14.849 0-26.893 12.042-26.893 26.894v213.078c0 14.852-12.04 26.893-26.894 26.893H196.082c-14.852 0-26.894-12.041-26.894-26.893v-484.08c0-14.852 12.042-26.894 26.894-26.894h445.973c14.852 0 26.893-12.041 26.893-26.893s-12.041-26.893-26.893-26.893H196.082c-44.555 0-80.68 36.125-80.68 80.68v484.08c0 44.557 36.125 80.679 80.68 80.679h591.652c44.557 0 80.682-36.122 80.682-80.679V475.514c-.001-14.852-12.043-26.894-26.896-26.894zm-13.446 374.437H155.743c-14.853 0-26.893 12.044-26.893 26.894 0 14.853 12.041 26.896 26.893 26.896h672.332c14.853 0 26.894-12.043 26.894-26.896-.001-14.85-12.042-26.894-26.895-26.894z\" /></symbol>"
});
sprite.add(symbol);

var SvgSpriteIcon = function SvgSpriteIcon(props) {
  return React.createElement(
    'svg',
    Object.assign({
      viewBox: symbol.viewBox
    }, props),
    React.createElement(
      'use',
      {
        xlinkHref: '#' + symbol.id
      }
    )
  );
};

SvgSpriteIcon.viewBox = symbol.viewBox;
SvgSpriteIcon.id = symbol.id;
SvgSpriteIcon.content = symbol.content;
SvgSpriteIcon.url = symbol.url;
SvgSpriteIcon.toString = symbol.toString;

module.exports = SvgSpriteIcon;
module.exports.default = SvgSpriteIcon;


/***/ }),

/***/ "Hw11":
/***/ (function(module, exports, __webpack_require__) {

/* eslint-disable */
var React = __webpack_require__("cDcd");
var SpriteSymbol = __webpack_require__("QAmA");
var sprite = __webpack_require__("TQFg");

var symbol = new SpriteSymbol({
  "id": "pBwTpXbP--sprite",
  "use": "pBwTpXbP--sprite-usage",
  "viewBox": "0 0 1000.637 1000.678",
  "content": "<symbol xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 1000.637 1000.678\" id=\"pBwTpXbP--sprite\"><path d=\"M500.318 124.054c-130.59 0-351.552 22.771-351.552 108.17v536.228c0 85.381 220.962 108.172 351.552 108.172 130.565 0 351.553-22.791 351.553-108.172V232.225c0-85.4-220.988-108.171-351.553-108.171zM202.851 456.785c73.798 34.938 207.202 45.865 297.467 45.865 90.319 0 223.84-10.952 297.6-45.945l.08 125.291c-10.063 20.137-117.625 55.867-297.68 55.867-179.235 0-286.586-35.4-297.467-55.564V456.785zm297.467-8.221c-179.235 0-286.586-35.4-297.467-55.569v-98.438c73.798 34.911 207.202 45.839 297.467 45.839 90.293 0 223.723-10.928 297.495-45.892l.053 98.353c-10.512 20.175-117.954 55.707-297.548 55.707zm0-270.424c174.827 0 281.385 33.697 296.624 54.085-15.238 20.387-121.797 54.085-296.624 54.085-174.824 0-281.385-33.699-296.596-54.085 15.211-20.389 121.772-54.085 296.596-54.085zm0 644.398c-180.477 0-288.224-35.914-297.467-54.086V646.075c73.798 34.939 207.202 45.873 297.467 45.873 90.372 0 224-10.986 297.733-46.006l.08 120.582c-9.613 20.1-117.336 56.014-297.813 56.014z\" /></symbol>"
});
sprite.add(symbol);

var SvgSpriteIcon = function SvgSpriteIcon(props) {
  return React.createElement(
    'svg',
    Object.assign({
      viewBox: symbol.viewBox
    }, props),
    React.createElement(
      'use',
      {
        xlinkHref: '#' + symbol.id
      }
    )
  );
};

SvgSpriteIcon.viewBox = symbol.viewBox;
SvgSpriteIcon.id = symbol.id;
SvgSpriteIcon.content = symbol.content;
SvgSpriteIcon.url = symbol.url;
SvgSpriteIcon.toString = symbol.toString;

module.exports = SvgSpriteIcon;
module.exports.default = SvgSpriteIcon;


/***/ }),

/***/ "Jo+v":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("Z6Kq");

/***/ }),

/***/ "K2gz":
/***/ (function(module, exports) {

module.exports = require("classnames");

/***/ }),

/***/ "MI3g":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/symbol/iterator.js
var iterator = __webpack_require__("XVgq");
var iterator_default = /*#__PURE__*/__webpack_require__.n(iterator);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/symbol.js
var symbol = __webpack_require__("Z7t5");
var symbol_default = /*#__PURE__*/__webpack_require__.n(symbol);

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/typeof.js



function typeof_typeof2(obj) { if (typeof symbol_default.a === "function" && typeof iterator_default.a === "symbol") { typeof_typeof2 = function _typeof2(obj) { return typeof obj; }; } else { typeof_typeof2 = function _typeof2(obj) { return obj && typeof symbol_default.a === "function" && obj.constructor === symbol_default.a && obj !== symbol_default.a.prototype ? "symbol" : typeof obj; }; } return typeof_typeof2(obj); }

function typeof_typeof(obj) {
  if (typeof symbol_default.a === "function" && typeof_typeof2(iterator_default.a) === "symbol") {
    typeof_typeof = function _typeof(obj) {
      return typeof_typeof2(obj);
    };
  } else {
    typeof_typeof = function _typeof(obj) {
      return obj && typeof symbol_default.a === "function" && obj.constructor === symbol_default.a && obj !== symbol_default.a.prototype ? "symbol" : typeof_typeof2(obj);
    };
  }

  return typeof_typeof(obj);
}
// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/assertThisInitialized.js
var assertThisInitialized = __webpack_require__("AT/M");

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/possibleConstructorReturn.js
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _possibleConstructorReturn; });


function _possibleConstructorReturn(self, call) {
  if (call && (typeof_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return Object(assertThisInitialized["a" /* default */])(self);
}

/***/ }),

/***/ "NvCX":
/***/ (function(module, exports) {

module.exports = {
	"white-space": "_2X90Y97I",
	"whiteSpace": "_2X90Y97I"
};

/***/ }),

/***/ "O40h":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _asyncToGenerator; });
/* harmony import */ var _core_js_promise__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("eVuF");
/* harmony import */ var _core_js_promise__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_promise__WEBPACK_IMPORTED_MODULE_0__);


function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
  try {
    var info = gen[key](arg);
    var value = info.value;
  } catch (error) {
    reject(error);
    return;
  }

  if (info.done) {
    resolve(value);
  } else {
    _core_js_promise__WEBPACK_IMPORTED_MODULE_0___default.a.resolve(value).then(_next, _throw);
  }
}

function _asyncToGenerator(fn) {
  return function () {
    var self = this,
        args = arguments;
    return new _core_js_promise__WEBPACK_IMPORTED_MODULE_0___default.a(function (resolve, reject) {
      var gen = fn.apply(self, args);

      function _next(value) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
      }

      function _throw(err) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
      }

      _next(undefined);
    });
  };
}

/***/ }),

/***/ "QAmA":
/***/ (function(module, exports) {

module.exports = require("svg-baker-runtime/symbol");

/***/ }),

/***/ "SqZg":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("o5io");

/***/ }),

/***/ "TQFg":
/***/ (function(module, exports) {

module.exports = require("svg-sprite-loader/runtime/sprite.build");

/***/ }),

/***/ "TRZx":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("Wk4r");

/***/ }),

/***/ "TUA0":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/define-property");

/***/ }),

/***/ "Tit0":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/create.js
var create = __webpack_require__("SqZg");
var create_default = /*#__PURE__*/__webpack_require__.n(create);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/set-prototype-of.js
var set_prototype_of = __webpack_require__("TRZx");
var set_prototype_of_default = /*#__PURE__*/__webpack_require__.n(set_prototype_of);

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/setPrototypeOf.js

function _setPrototypeOf(o, p) {
  _setPrototypeOf = set_prototype_of_default.a || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}
// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/inherits.js
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _inherits; });


function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = create_default()(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

/***/ }),

/***/ "UXZV":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("dGr4");

/***/ }),

/***/ "Wk4r":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/set-prototype-of");

/***/ }),

/***/ "XQhW":
/***/ (function(module, exports) {

module.exports = require("rc-scroll-anim");

/***/ }),

/***/ "XVgq":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("gHn/");

/***/ }),

/***/ "Z6Kq":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/get-own-property-descriptor");

/***/ }),

/***/ "Z7t5":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("vqFK");

/***/ }),

/***/ "a7VT":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _getPrototypeOf; });
/* harmony import */ var _core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("Bhuq");
/* harmony import */ var _core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("TRZx");
/* harmony import */ var _core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_1__);


function _getPrototypeOf(o) {
  _getPrototypeOf = _core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_1___default.a ? _core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0___default.a : function _getPrototypeOf(o) {
    return o.__proto__ || _core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0___default()(o);
  };
  return _getPrototypeOf(o);
}

/***/ }),

/***/ "aC71":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/promise");

/***/ }),

/***/ "aStJ":
/***/ (function(module, exports, __webpack_require__) {

/* eslint-disable */
var React = __webpack_require__("cDcd");
var SpriteSymbol = __webpack_require__("QAmA");
var sprite = __webpack_require__("TQFg");

var symbol = new SpriteSymbol({
  "id": "1Yh917mp--sprite",
  "use": "1Yh917mp--sprite-usage",
  "viewBox": "0 0 1000.637 1000.678",
  "content": "<symbol xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 1000.637 1000.678\" id=\"1Yh917mp--sprite\"><path d=\"M769.899 718.598c-25.498.013-48.577 15.132-58.77 38.512H588.875c-5.038-34.425-29.561-62.831-62.882-72.836V577.389H680.04c42.472 0 77.022-34.551 77.022-77.023 0-42.461-34.551-77.023-77.022-77.023H320.598c-42.473 0-77.023 34.562-77.023 77.023 0 42.472 34.55 77.023 77.023 77.023h154.047v106.885c-33.321 10.005-57.843 38.411-62.881 72.836H289.508c-14.115-32.493-51.901-47.375-84.381-33.26-23.457 10.193-38.625 33.36-38.575 58.935.076 35.453 28.872 64.123 64.312 64.061 25.424-.063 48.416-15.119 58.645-38.387h129.965c14.478 30.237 45.129 51.349 80.845 51.349 35.717 0 66.368-21.111 80.848-51.349H711.13c14.115 32.494 51.9 47.375 84.383 33.26 23.454-10.192 38.625-33.36 38.573-58.934 0-35.455-28.733-64.187-64.187-64.187zM320.598 526.041c-14.178-.628-25.161-12.638-24.521-26.816.59-13.302 11.233-23.945 24.521-24.534H680.04c14.178.639 25.16 12.649 24.52 26.816-.589 13.301-11.23 23.932-24.52 24.534H320.598zm179.72 282.417c-21.236 0-38.511-17.274-38.511-38.511 0-21.237 17.274-38.512 38.511-38.512 21.237 0 38.513 17.274 38.513 38.512 0 21.237-17.275 38.511-38.513 38.511z\" /><path d=\"M307.761 680.086h73.401c14.177 0 25.673-11.495 25.673-25.673 0-14.18-11.497-25.675-25.673-25.675h-73.401c-77.951-.089-141.122-63.259-141.209-141.21-.351-69.601 50.334-128.961 119.121-139.516l15.294-2.383 4.989-14.643c28.482-82.977 106.584-138.713 194.363-138.713 87.756-.026 165.845 55.71 194.34 138.713l5.013 14.643 15.295 2.383c68.788 10.555 119.472 69.915 119.12 139.516 0 77.851-63.358 141.21-141.209 141.21h-78.051c-14.18 0-25.675 11.495-25.675 25.675 0 14.178 11.495 25.673 25.675 25.673h78.051c106.184 0 192.558-86.374 192.558-192.558.452-89.145-60.7-166.795-147.477-187.268-53.869-131.243-203.941-193.949-335.173-140.081-63.546 26.088-114.004 76.534-140.08 140.081-86.777 20.46-147.941 98.123-147.503 187.268-.001 106.184 86.375 192.558 192.558 192.558z\" /></symbol>"
});
sprite.add(symbol);

var SvgSpriteIcon = function SvgSpriteIcon(props) {
  return React.createElement(
    'svg',
    Object.assign({
      viewBox: symbol.viewBox
    }, props),
    React.createElement(
      'use',
      {
        xlinkHref: '#' + symbol.id
      }
    )
  );
};

SvgSpriteIcon.viewBox = symbol.viewBox;
SvgSpriteIcon.id = symbol.id;
SvgSpriteIcon.content = symbol.content;
SvgSpriteIcon.url = symbol.url;
SvgSpriteIcon.toString = symbol.toString;

module.exports = SvgSpriteIcon;
module.exports.default = SvgSpriteIcon;


/***/ }),

/***/ "acqn":
/***/ (function(module, exports, __webpack_require__) {

/* eslint-disable */
var React = __webpack_require__("cDcd");
var SpriteSymbol = __webpack_require__("QAmA");
var sprite = __webpack_require__("TQFg");

var symbol = new SpriteSymbol({
  "id": "3TfNHI2_--sprite",
  "use": "3TfNHI2_--sprite-usage",
  "viewBox": "0 0 1000.637 1000.678",
  "content": "<symbol xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 1000.637 1000.678\" id=\"3TfNHI2_--sprite\"><path d=\"M763.666 575.67c-24.427 20.031-54.896 34.412-93.829 46.595-11.267 3.504-22.884 6.761-37.08 10.454-5.257 1.362-27.766 7.048-33.349 8.513-13.709 3.59-27.717-4.608-31.308-18.303-3.595-13.709 4.604-27.718 18.302-31.311 5.869-1.528 28.455-7.224 33.485-8.536a707.246 707.246 0 0 0 34.652-9.766c33.212-10.392 58.162-22.157 76.663-37.306 67.426-55.244 128.366-44.478 163.095 30.921l6.783 14.772-10.427 12.431c-115.56 137.73-215.033 207.771-301.661 207.771l-439.26 12.18c-14.158 0-25.638-11.479-25.638-25.638 0-14.155 11.479-25.639 25.638-25.639l439.26-12.178c64.871 0 149.597-58.101 251.299-176.39-18.202-29.891-39.32-29.104-76.625 1.43zM150.835 691.517c-.238 14.146-11.912 25.438-26.07 25.188-14.159-.237-25.444-11.904-25.206-26.064l2.491-145.114 6.741-7.187c68.221-72.857 135.752-105.675 202.232-95.034 50.25 8.023 78.662 23.69 118.114 57.354l5.564 4.769c17.075 14.586 26.227 21.459 38.149 27.793 9.027 4.817 20.845 7.697 36.774 9.225 7.224.753 12.656 1.027 26.864 1.616 58.713 2.489 82.047 10.463 82.047 52.741 0 57.686-37.956 94.291-106.021 105.781-44.816 7.562-109.781-9.864-197.543-50.975-12.819-6.011-18.337-21.272-12.33-34.089 6.009-12.834 21.276-18.341 34.095-12.331 78.967 36.991 135.602 52.179 167.241 46.843 44.304-7.485 62.507-24.31 63.244-53.329-5.482-1.803-13.759-2.566-32.888-3.392a481.9 481.9 0 0 1-29.692-1.789c-22.021-2.155-39.941-6.537-55.89-15.05-16.099-8.562-27.641-17.2-47.352-34.074l-5.539-4.721c-32.917-28.102-53.512-39.457-92.939-45.755-45.047-7.186-94.915 15.888-149.959 72.395l-2.127 125.199zm104.863-336.894c0 14.159-11.481 25.638-25.639 25.638s-25.638-11.479-25.638-25.638V237.868c0-28.317 22.959-51.276 51.277-51.276H742.82c28.317 0 51.276 22.959 51.276 51.276v153.828c0 28.319-22.959 51.277-51.276 51.277H468.362c-14.158 0-25.638-11.48-25.638-25.639 0-14.158 11.48-25.638 25.638-25.638H742.82V237.868H255.698v116.755z\" /></symbol>"
});
sprite.add(symbol);

var SvgSpriteIcon = function SvgSpriteIcon(props) {
  return React.createElement(
    'svg',
    Object.assign({
      viewBox: symbol.viewBox
    }, props),
    React.createElement(
      'use',
      {
        xlinkHref: '#' + symbol.id
      }
    )
  );
};

SvgSpriteIcon.viewBox = symbol.viewBox;
SvgSpriteIcon.id = symbol.id;
SvgSpriteIcon.content = symbol.content;
SvgSpriteIcon.url = symbol.url;
SvgSpriteIcon.toString = symbol.toString;

module.exports = SvgSpriteIcon;
module.exports.default = SvgSpriteIcon;


/***/ }),

/***/ "bPsq":
/***/ (function(module, exports) {

module.exports = require("less-vars-to-js");

/***/ }),

/***/ "cBsA":
/***/ (function(module, exports) {

module.exports = {
	"container": "_2vAiKw_Q",
	"parallax": "_3Ep7WdDb"
};

/***/ }),

/***/ "cDcd":
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "cu1A":
/***/ (function(module, exports) {

module.exports = require("regenerator-runtime");

/***/ }),

/***/ "dGr4":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/assign");

/***/ }),

/***/ "eVuF":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("aC71");

/***/ }),

/***/ "flPq":
/***/ (function(module, exports) {

module.exports = {
	"svg-icon": "_39UYRa5H",
	"svgIcon": "_39UYRa5H"
};

/***/ }),

/***/ "gHn/":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/symbol/iterator");

/***/ }),

/***/ "hfKm":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("TUA0");

/***/ }),

/***/ "hzsg":
/***/ (function(module, exports) {

module.exports = {
	"about-banner": "_1TVWLq1R",
	"aboutBanner": "_1TVWLq1R",
	"about-banner-content": "_14iy8zBn",
	"aboutBannerContent": "_14iy8zBn",
	"about-banner-title": "_1el29swW",
	"aboutBannerTitle": "_1el29swW",
	"about-banner-1": "_2DJPeNDM",
	"aboutBanner1": "_2DJPeNDM",
	"about-banner-2": "_1_H_3rNX",
	"aboutBanner2": "_1_H_3rNX",
	"about-banner-3": "kGc1Kgg_",
	"aboutBanner3": "kGc1Kgg_",
	"about-block": "_1qIkuhoT",
	"aboutBlock": "_1qIkuhoT",
	"about-banner-block": "_2yC0qIR4",
	"aboutBannerBlock": "_2yC0qIR4",
	"about-block-image": "_23c_6o5B",
	"aboutBlockImage": "_23c_6o5B",
	"about-block-title": "_2v3JcRRa",
	"aboutBlockTitle": "_2v3JcRRa",
	"about-block-dark-title": "_1nDUd0ci",
	"aboutBlockDarkTitle": "_1nDUd0ci",
	"about-block-core-3": "Oem6eYvL",
	"aboutBlockCore3": "Oem6eYvL",
	"about-block-platform-3": "wntgNyC_",
	"aboutBlockPlatform3": "wntgNyC_",
	"icon": "_1_HJRz5R",
	"about-block-advantage": "_37eu4pk7",
	"aboutBlockAdvantage": "_37eu4pk7",
	"ad-1": "_1tHsrUh-",
	"ad1": "_1tHsrUh-",
	"ad-2": "_30_G8Z6R",
	"ad2": "_30_G8Z6R",
	"ad-3": "P3IUue1k",
	"ad3": "P3IUue1k",
	"ad-4": "zZu6csAO",
	"ad4": "zZu6csAO",
	"ad-5": "_3GUrcvRR",
	"ad5": "_3GUrcvRR"
};

/***/ }),

/***/ "k1wZ":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/get-own-property-symbols");

/***/ }),

/***/ "kJFy":
/***/ (function(module, exports) {

module.exports = require("flystore");

/***/ }),

/***/ "kOwS":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _extends; });
/* harmony import */ var _core_js_object_assign__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("UXZV");
/* harmony import */ var _core_js_object_assign__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_assign__WEBPACK_IMPORTED_MODULE_0__);

function _extends() {
  _extends = _core_js_object_assign__WEBPACK_IMPORTED_MODULE_0___default.a || function (target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];

      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }

    return target;
  };

  return _extends.apply(this, arguments);
}

/***/ }),

/***/ "kqMJ":
/***/ (function(module, exports) {

module.exports = require("typed.js");

/***/ }),

/***/ "ln6h":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("cu1A");


/***/ }),

/***/ "o5io":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/create");

/***/ }),

/***/ "pLtp":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("qJj/");

/***/ }),

/***/ "qJj/":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/keys");

/***/ }),

/***/ "qNsG":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/get-own-property-symbols.js
var get_own_property_symbols = __webpack_require__("4mXO");
var get_own_property_symbols_default = /*#__PURE__*/__webpack_require__.n(get_own_property_symbols);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/keys.js
var keys = __webpack_require__("pLtp");
var keys_default = /*#__PURE__*/__webpack_require__.n(keys);

// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/objectWithoutPropertiesLoose.js

function _objectWithoutPropertiesLoose(source, excluded) {
  if (source == null) return {};
  var target = {};

  var sourceKeys = keys_default()(source);

  var key, i;

  for (i = 0; i < sourceKeys.length; i++) {
    key = sourceKeys[i];
    if (excluded.indexOf(key) >= 0) continue;
    target[key] = source[key];
  }

  return target;
}
// CONCATENATED MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/objectWithoutProperties.js
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _objectWithoutProperties; });


function _objectWithoutProperties(source, excluded) {
  if (source == null) return {};
  var target = _objectWithoutPropertiesLoose(source, excluded);
  var key, i;

  if (get_own_property_symbols_default.a) {
    var sourceSymbolKeys = get_own_property_symbols_default()(source);

    for (i = 0; i < sourceSymbolKeys.length; i++) {
      key = sourceSymbolKeys[i];
      if (excluded.indexOf(key) >= 0) continue;
      if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
      target[key] = source[key];
    }
  }

  return target;
}

/***/ }),

/***/ "qRXU":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/keys.js
var keys = __webpack_require__("pLtp");
var keys_default = /*#__PURE__*/__webpack_require__.n(keys);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/extends.js
var esm_extends = __webpack_require__("kOwS");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/classCallCheck.js
var classCallCheck = __webpack_require__("0iUn");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/createClass.js
var createClass = __webpack_require__("sLSF");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/possibleConstructorReturn.js + 1 modules
var possibleConstructorReturn = __webpack_require__("MI3g");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/getPrototypeOf.js
var getPrototypeOf = __webpack_require__("a7VT");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/assertThisInitialized.js
var assertThisInitialized = __webpack_require__("AT/M");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/inherits.js + 1 modules
var inherits = __webpack_require__("Tit0");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/defineProperty.js
var defineProperty = __webpack_require__("vYYK");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/core-js/object/assign.js
var object_assign = __webpack_require__("UXZV");
var assign_default = /*#__PURE__*/__webpack_require__.n(object_assign);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/esm/objectSpread.js
var objectSpread = __webpack_require__("zrwo");

// EXTERNAL MODULE: external "flystore"
var external_flystore_ = __webpack_require__("kJFy");
var external_flystore_default = /*#__PURE__*/__webpack_require__.n(external_flystore_);

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__("cDcd");
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);

// EXTERNAL MODULE: external "object.pick"
var external_object_pick_ = __webpack_require__("6RRd");
var external_object_pick_default = /*#__PURE__*/__webpack_require__.n(external_object_pick_);

// EXTERNAL MODULE: external "less-vars-to-js"
var external_less_vars_to_js_ = __webpack_require__("bPsq");
var external_less_vars_to_js_default = /*#__PURE__*/__webpack_require__.n(external_less_vars_to_js_);

// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__("4Q3z");
var router_default = /*#__PURE__*/__webpack_require__.n(router_);

// CONCATENATED MODULE: ./node_modules/raw-loader/dist/cjs.js!./assets/custom.less
/* harmony default export */ var custom = ("\n// https://github.com/ant-design/ant-design/blob/master/components/style/themes/default.less\n@import (reference) \"~antd/lib/style/themes/default.less\";\n@import (reference) \"~antd/lib/style/mixins/index.less\";\n@import (reference) \"./easings/index.less\";\n\n@gray-1: #ffffff;\n@gray-2: #fafafa;\n@gray-3: #f5f5f5;\n@gray-4: #e8e8e8;\n@gray-5: #d9d9d9;\n@gray-6: #bfbfbf;\n@gray-7: #8c8c8c;\n@gray-8: #595959;\n@gray-9: #262626;\n@gray-10: #000000;\n\n// 暗黑\n@dark-1: rgba(0, 0, 0, .05);\n@dark-2: rgba(0, 0, 0, .15);\n@dark-3: rgba(0, 0, 0, .25);\n@dark-4: rgba(0, 0, 0, .35);\n@dark-5: rgba(0, 0, 0, .45);\n@dark-6: rgba(0, 0, 0, .55);\n@dark-7: rgba(0, 0, 0, .65);\n@dark-8: rgba(0, 0, 0, .75);\n@dark-9: rgba(0, 0, 0, .85);\n@dark-10: rgba(0, 0, 0, 1);\n\n// 亮白\n@light-1: rgba(255, 255, 255, .05);\n@light-2: rgba(255, 255, 255, .15);\n@light-3: rgba(255, 255, 255, .25);\n@light-4: rgba(255, 255, 255, .35);\n@light-5: rgba(255, 255, 255, .45);\n@light-6: rgba(255, 255, 255, .55);\n@light-7: rgba(255, 255, 255, .65);\n@light-8: rgba(255, 255, 255, .75);\n@light-9: rgba(255, 255, 255, .85);\n@light-10: rgba(255, 255, 255, 1);\n\n\n@mask-color: #001529;\n@footer-color: @light-8;\n@footer-link-color: @light-6;\n@footer-link-hover-color: @light-10;\n@footer-background-color: @dark-10;\n@header-background-color: #001529;\n@anchor-background-color: @light-10;\n@anchor-color: #1890ff;\n\n\n@dark-menu-color: @light-7;\n@dark-menu-background-color: @header-background-color;\n\n\n@anim-speed-1: 200ms;\n@anim-speed-2: 375ms;\n@anim-speed-3: 500ms;\n@anim-speed-4: 800ms;\n@anim-speed-5: 1200ms;\n\n\n@page-width: 980px;\n@page-width-lg: 1440px;\n@max-width: 1920px; // 2560px\n@header-height: 64px;\n@header-phone-height: 48px;\n@anchor-height: 48px;\n\n\n// z-index\n@header-zIndex: 1100;\n@anchor-zIndex: @header-zIndex - 10;\n\n// shadow\n@shadow-down: 0 2px 8px rgba(0, 0, 0, 0.08);\n@shadow-down-dark: 0 2px 8px rgba(0, 0, 0, 0.2);\n@shadow-down-sm: 4px 6px 10px rgba(0, 0, 0, 0.1);\n@shadow-down-lg: 8px 12px 20px rgba(0, 0, 0, 0.3);\n\n\n@main-color: #fa8c16;\n@main-background-color: #001529;\n@main-light-background-color: #f1f3ff;\n\n// .function {\n//   .foo(@x) {\n//     return: @x * 2;\n//   }\n// }");
// CONCATENATED MODULE: ./node_modules/raw-loader/dist/cjs.js!./assets/easings/index.less
/* harmony default export */ var easings = ("//https://easings.net/\n//http://cubic-bezier.com/#.17,.67,.83,.67\n@linear         : cubic-bezier(0.250, 0.250, 0.750, 0.750);\n@ease           : cubic-bezier(0.250, 0.100, 0.250, 1.000);\n@ease-in        : cubic-bezier(0.420, 0.000, 1.000, 1.000);\n@ease-out       : cubic-bezier(0.000, 0.000, 0.580, 1.000);\n@ease-in-out    : cubic-bezier(0.420, 0.000, 0.580, 1.000);\n\n@easeInQuad     : cubic-bezier(0.550, 0.085, 0.680, 0.530);\n@easeInCubic    : cubic-bezier(0.550, 0.055, 0.675, 0.190);\n@easeInQuart    : cubic-bezier(0.895, 0.030, 0.685, 0.220);\n@easeInQuint    : cubic-bezier(0.755, 0.050, 0.855, 0.060);\n@easeInSine     : cubic-bezier(0.470, 0.000, 0.745, 0.715);\n@easeInExpo     : cubic-bezier(0.950, 0.050, 0.795, 0.035);\n@easeInCirc     : cubic-bezier(0.600, 0.040, 0.980, 0.335);\n@easeInBack     : cubic-bezier(0.600, -0.280, 0.735, 0.045);\n\n@easeOutQuad    : cubic-bezier(0.250, 0.460, 0.450, 0.940);\n@easeOutCubic   : cubic-bezier(0.215, 0.610, 0.355, 1.000);\n@easeOutQuart   : cubic-bezier(0.165, 0.840, 0.440, 1.000);\n@easeOutQuint   : cubic-bezier(0.230, 1.000, 0.320, 1.000);\n@easeOutSine    : cubic-bezier(0.390, 0.575, 0.565, 1.000);\n@easeOutExpo    : cubic-bezier(0.190, 1.000, 0.220, 1.000);\n@easeOutCirc    : cubic-bezier(0.075, 0.820, 0.165, 1.000);\n@easeOutBack    : cubic-bezier(0.175, 0.885, 0.320, 1.275);\n\n@easeInOutQuad  : cubic-bezier(0.455, 0.030, 0.515, 0.955);\n@easeInOutCubic : cubic-bezier(0.645, 0.045, 0.355, 1.000);\n@easeInOutQuart : cubic-bezier(0.770, 0.000, 0.175, 1.000);\n@easeInOutQuint : cubic-bezier(0.860, 0.000, 0.070, 1.000);\n@easeInOutSine  : cubic-bezier(0.445, 0.050, 0.550, 0.950);\n@easeInOutExpo  : cubic-bezier(1.000, 0.000, 0.000, 1.000);\n@easeInOutCirc  : cubic-bezier(0.785, 0.135, 0.150, 0.860);\n@easeInOutBack  : cubic-bezier(0.680, -0.550, 0.265, 1.550);\n");
// CONCATENATED MODULE: ./components/Themes/index.js
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return themeVariables; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return themeEasings; });
/* unused harmony export defaultThemeConfig */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return Themes_setTheme; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "e", function() { return withTheme; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ThemeContext; });


















var themeVariables = external_less_vars_to_js_default()(custom, {
  resolveVariables: true
});
var themeEasings = external_less_vars_to_js_default()(easings, {
  resolveVariables: true
});
var defaultThemeConfig = {
  footer: true,
  header: true
};
var storeTheme = external_flystore_default()('@theme-config');
storeTheme.set('config', Object(objectSpread["a" /* default */])({}, defaultThemeConfig));
storeTheme.set('change', {});
var Themes_setTheme = function setTheme(config, changeRoute) {
  var route = router_default.a.router.route;

  if (changeRoute && changeRoute !== route) {
    var themeConfig = storeTheme.get("change-".concat(changeRoute));
    storeTheme.set("change-".concat(changeRoute), assign_default()({}, themeConfig, config));
  } else {
    var _themeConfig = storeTheme.get("change-".concat(route));

    var newConfig = assign_default()({}, _themeConfig, config);

    storeTheme.set("change-".concat(route), newConfig);
    storeTheme.dispense('change', newConfig);
  }
};
function withTheme(Comp) {
  var _class, _temp;

  return Object(router_["withRouter"])((_temp = _class =
  /*#__PURE__*/
  function (_React$Component) {
    Object(inherits["a" /* default */])(WithTheme, _React$Component);

    function WithTheme() {
      var _getPrototypeOf2;

      var _this;

      Object(classCallCheck["a" /* default */])(this, WithTheme);

      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }

      _this = Object(possibleConstructorReturn["a" /* default */])(this, (_getPrototypeOf2 = Object(getPrototypeOf["a" /* default */])(WithTheme)).call.apply(_getPrototypeOf2, [this].concat(args)));

      Object(defineProperty["a" /* default */])(Object(assertThisInitialized["a" /* default */])(_this), "state", {
        themeConfig: storeTheme.get('config')
      });

      return _this;
    }

    Object(createClass["a" /* default */])(WithTheme, [{
      key: "componentDidMount",
      value: function componentDidMount() {
        var _this2 = this;

        var route = this.props.router.route;
        var changeConfig = storeTheme.get("change-".concat(route));

        if (changeConfig) {
          this.setState({
            themeConfig: assign_default()(storeTheme.get('config'), changeConfig)
          });
        }

        this.configHandle = storeTheme.watch('change', function (themeConfig) {
          _this2.setState({
            themeConfig: assign_default()(storeTheme.get('config'), themeConfig)
          });
        });
      }
    }, {
      key: "componentWillUnmount",
      value: function componentWillUnmount() {
        if (this.configHandle) {
          this.configHandle.clear();
          this.configHandle = null;
        }
      }
    }, {
      key: "render",
      value: function render() {
        return external_react_default.a.createElement(Comp, Object(esm_extends["a" /* default */])({}, this.props, {
          themeConfig: this.state.themeConfig
        }));
      }
    }]);

    return WithTheme;
  }(external_react_default.a.Component), Object(defineProperty["a" /* default */])(_class, "getDerivedStateFromProps", function (props) {
    var route = props.router.route;

    var newConfig = assign_default()({}, defaultThemeConfig, external_object_pick_default()(props, keys_default()(defaultThemeConfig)));

    var changeConfig = storeTheme.get("change-".concat(route));
    return {
      themeConfig: assign_default()(newConfig, changeConfig)
    };
  }), _temp));
}
var ThemeContext = external_react_default.a.createContext({
  env: {},
  themeConfig: Object(objectSpread["a" /* default */])({}, defaultThemeConfig),
  themeEasings: themeEasings,
  themeVariables: themeVariables,
  isLoaded: false,
  isMobile: false
});

/***/ }),

/***/ "sLSF":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _createClass; });
/* harmony import */ var _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("hfKm");
/* harmony import */ var _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__);


function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;

    _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default()(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

/***/ }),

/***/ "t+JW":
/***/ (function(module, exports, __webpack_require__) {

/* eslint-disable */
var React = __webpack_require__("cDcd");
var SpriteSymbol = __webpack_require__("QAmA");
var sprite = __webpack_require__("TQFg");

var symbol = new SpriteSymbol({
  "id": "2EiMjE6f--sprite",
  "use": "2EiMjE6f--sprite-usage",
  "viewBox": "0 0 1000.637 1000.678",
  "content": "<symbol xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 1000.637 1000.678\" id=\"2EiMjE6f--sprite\"><path d=\"M809.692 190.993c-66.991-66.99-184.871-64.733-309.349-3.056-124.452-61.677-242.358-63.934-309.347 3.056-55.68 55.679-63.449 146.499-29.256 246.884-20.75 30.801-16.373 72.041 10.375 97.804-44.643 109.239-42.673 212.418 18.906 273.995 66.989 66.989 184.921 64.77 309.471 3.019 121.947 60.404 241.036 65.145 309.199-3.019 68.187-68.187 63.397-187.327 2.942-309.322 60.457-122.034 65.246-241.174-2.941-309.361zm-36.115 582.569c-76.94 76.953-265.465 23.471-417.676-128.766-9.975-9.965-26.149-9.965-36.114 0-9.975 9.975-9.975 26.138 0 36.112a728.74 728.74 0 0 0 125.602 100.811c-93.578 38.233-174.87 35.215-218.254-8.183-44.519-44.506-45.142-126.384-8.505-216.931 2.245.213 4.39.699 6.685.699 42.311 0 76.616-34.306 76.616-76.617 0-16.771-5.535-32.161-14.689-44.768a695.072 695.072 0 0 1 68.66-80.045c9.965-9.963 9.965-26.138 0-36.114-9.975-9.964-26.149-9.964-36.114 0a744.492 744.492 0 0 0-74.595 87.267 74.96 74.96 0 0 0-19.877-2.956 76.017 76.017 0 0 0-19.741 2.88c-22.908-76.965-15.787-142.509 21.561-179.845 49.769-49.768 149.441-46.426 260.252 11.373a24.823 24.823 0 0 0 13.221 2.419 24.938 24.938 0 0 0 12.793-2.468c110.785-57.75 210.409-61.091 260.177-11.324 44.694 44.694 45.143 127.06 8.031 218.055a701.898 701.898 0 0 0-53.945-73.799c5.212-9.253 8.429-19.778 8.429-31.138 0-35.253-28.581-63.848-63.848-63.848-35.266 0-63.847 28.594-63.847 63.848 0 35.253 28.581 63.847 63.847 63.847 5.089 0 9.953-.736 14.69-1.858a635.338 635.338 0 0 1 68.163 98.116c-25.165 45.229-59.06 91.045-100.71 134.366-2.543-.313-5.051-.772-7.682-.772-35.266-.05-63.873 28.506-63.921 63.771-.05 35.266 28.506 63.873 63.771 63.924 35.267.048 63.873-28.509 63.921-63.774a63.843 63.843 0 0 0-11.271-36.289 717.123 717.123 0 0 0 82.402-106.045c37.074 90.98 36.662 173.359-8.032 218.052z\" /><path d=\"M506.243 404.071c-56.415 0-102.156 45.728-102.156 102.157 0 56.414 45.741 102.154 102.156 102.154 56.413 0 102.154-45.74 102.154-102.154 0-56.429-45.741-102.157-102.154-102.157zm0 153.234c-28.207 0-51.079-22.895-51.079-51.103 0-28.221 22.896-51.091 51.102-51.079 28.22.013 51.079 22.883 51.079 51.104.001 28.219-22.894 51.078-51.102 51.078z\" /></symbol>"
});
sprite.add(symbol);

var SvgSpriteIcon = function SvgSpriteIcon(props) {
  return React.createElement(
    'svg',
    Object.assign({
      viewBox: symbol.viewBox
    }, props),
    React.createElement(
      'use',
      {
        xlinkHref: '#' + symbol.id
      }
    )
  );
};

SvgSpriteIcon.viewBox = symbol.viewBox;
SvgSpriteIcon.id = symbol.id;
SvgSpriteIcon.content = symbol.content;
SvgSpriteIcon.url = symbol.url;
SvgSpriteIcon.toString = symbol.toString;

module.exports = SvgSpriteIcon;
module.exports.default = SvgSpriteIcon;


/***/ }),

/***/ "vYYK":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _defineProperty; });
/* harmony import */ var _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("hfKm");
/* harmony import */ var _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__);

function _defineProperty(obj, key, value) {
  if (key in obj) {
    _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default()(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}

/***/ }),

/***/ "vqFK":
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/symbol");

/***/ }),

/***/ "zrwo":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _objectSpread; });
/* harmony import */ var _core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("Jo+v");
/* harmony import */ var _core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("4mXO");
/* harmony import */ var _core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _core_js_object_keys__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("pLtp");
/* harmony import */ var _core_js_object_keys__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_keys__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _defineProperty__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("vYYK");




function _objectSpread(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i] != null ? arguments[i] : {};

    var ownKeys = _core_js_object_keys__WEBPACK_IMPORTED_MODULE_2___default()(source);

    if (typeof _core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1___default.a === 'function') {
      ownKeys = ownKeys.concat(_core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1___default()(source).filter(function (sym) {
        return _core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_0___default()(source, sym).enumerable;
      }));
    }

    ownKeys.forEach(function (key) {
      Object(_defineProperty__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"])(target, key, source[key]);
    });
  }

  return target;
}

/***/ })

/******/ });