module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../../../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 3);
/******/ })
/************************************************************************/
/******/ ({

/***/ "./assets/images/scene/banner-1.jpg":
/*!******************************************!*\
  !*** ./assets/images/scene/banner-1.jpg ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/_next/static/images/banner-1-25c788900d80df9d8f0a699d8dbe32a2.jpg";

/***/ }),

/***/ "./assets/images/scene/banner-2.jpg":
/*!******************************************!*\
  !*** ./assets/images/scene/banner-2.jpg ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/_next/static/images/banner-2-ea56f21a63607e4ef44a73e168ada861.jpg";

/***/ }),

/***/ "./assets/images/scene/banner-3.jpg":
/*!******************************************!*\
  !*** ./assets/images/scene/banner-3.jpg ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/_next/static/images/banner-3-76583643b569207b418f7b1a3b379860.jpg";

/***/ }),

/***/ "./assets/images/scene/banner-4.jpg":
/*!******************************************!*\
  !*** ./assets/images/scene/banner-4.jpg ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/_next/static/images/banner-4-2bb69a3e2886340537f17242f6d937ac.jpg";

/***/ }),

/***/ "./assets/images/scene/quote.svg?sprite":
/*!**********************************************!*\
  !*** ./assets/images/scene/quote.svg?sprite ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* eslint-disable */
var React = __webpack_require__(/*! react */ "react");
var SpriteSymbol = __webpack_require__(/*! svg-baker-runtime/symbol */ "svg-baker-runtime/symbol");
var sprite = __webpack_require__(/*! svg-sprite-loader/runtime/sprite.build */ "svg-sprite-loader/runtime/sprite.build");

var symbol = new SpriteSymbol({
  "id": "3aAd7K2X--sprite",
  "use": "3aAd7K2X--sprite-usage",
  "viewBox": "0 0 1195 1024",
  "content": "<symbol class=\"icon\" viewBox=\"0 0 1195 1024\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" id=\"3aAd7K2X--sprite\"><defs><style type=\"text/css\"></style></defs><path d=\"M1125.400405 972.814933 651.636395 972.814933 651.636395 631.106304C651.636395 491.702016 663.719168 382.333696 687.885227 302.997931 712.0512 223.662165 737.181781 170.700459 802.935893 107.231829 868.68992 43.763285 914.312789 24.717568 1010.828373 0L1078.255957 145.030059C1010.828373 170.796971 969.749333 182.289237 906.391381 248.024235 843.033429 313.759232 838.360149 377.340075 838.360149 431.988736L1125.400405 431.988736 1125.400405 972.814933ZM473.764096 972.814933 0 972.814933 0 631.106304C0 491.702016 12.082859 382.333696 36.248832 302.997931 60.414891 223.662165 85.545472 170.700459 151.299499 107.231829 217.053611 43.763285 262.676395 24.717568 359.192064 0L426.619563 145.030059C359.192064 170.796971 318.112939 182.289237 254.754987 248.024235 191.397035 313.759232 186.723755 377.340075 186.723755 431.988736L473.764096 431.988736 473.764096 972.814933Z\" p-id=\"1436\" /></symbol>"
});
sprite.add(symbol);

var SvgSpriteIcon = function SvgSpriteIcon(props) {
  return React.createElement(
    'svg',
    Object.assign({
      viewBox: symbol.viewBox
    }, props),
    React.createElement(
      'use',
      {
        xlinkHref: '#' + symbol.id
      }
    )
  );
};

SvgSpriteIcon.viewBox = symbol.viewBox;
SvgSpriteIcon.id = symbol.id;
SvgSpriteIcon.content = symbol.content;
SvgSpriteIcon.url = symbol.url;
SvgSpriteIcon.toString = symbol.toString;

module.exports = SvgSpriteIcon;
module.exports.default = SvgSpriteIcon;


/***/ }),

/***/ "./components/ResizeImage/index.js":
/*!*****************************************!*\
  !*** ./components/ResizeImage/index.js ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/extends */ "./node_modules/@babel/runtime-corejs2/helpers/esm/extends.js");
/* harmony import */ var _babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime-corejs2/core-js/object/keys */ "./node_modules/@babel/runtime-corejs2/core-js/object/keys.js");
/* harmony import */ var _babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/objectWithoutProperties */ "./node_modules/@babel/runtime-corejs2/helpers/esm/objectWithoutProperties.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/classCallCheck */ "./node_modules/@babel/runtime-corejs2/helpers/esm/classCallCheck.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/possibleConstructorReturn */ "./node_modules/@babel/runtime-corejs2/helpers/esm/possibleConstructorReturn.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/getPrototypeOf */ "./node_modules/@babel/runtime-corejs2/helpers/esm/getPrototypeOf.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/assertThisInitialized */ "./node_modules/@babel/runtime-corejs2/helpers/esm/assertThisInitialized.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/createClass */ "./node_modules/@babel/runtime-corejs2/helpers/esm/createClass.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/inherits */ "./node_modules/@babel/runtime-corejs2/helpers/esm/inherits.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/defineProperty */ "./node_modules/@babel/runtime-corejs2/helpers/esm/defineProperty.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var object_pick__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! object.pick */ "object.pick");
/* harmony import */ var object_pick__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(object_pick__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! rc-util/lib/Dom/css */ "rc-util/lib/Dom/css");
/* harmony import */ var rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var rc_util_lib_Dom_addEventListener__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! rc-util/lib/Dom/addEventListener */ "rc-util/lib/Dom/addEventListener");
/* harmony import */ var rc_util_lib_Dom_addEventListener__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(rc_util_lib_Dom_addEventListener__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _components_Themes__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @components/Themes */ "./components/Themes/index.js");
/* harmony import */ var _lib_requestAnimationFrame__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @lib/requestAnimationFrame */ "./lib/requestAnimationFrame.js");
/* harmony import */ var _resizeImage_less__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./resizeImage.less */ "./components/ResizeImage/resizeImage.less");
/* harmony import */ var _resizeImage_less__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_resizeImage_less__WEBPACK_IMPORTED_MODULE_16__);










var _jsxFileName = "/Users/rainx/Documents/Github/csite/components/ResizeImage/index.js";








var ResizeImage =
/*#__PURE__*/
function (_React$Component) {
  Object(_babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_8__["default"])(ResizeImage, _React$Component);

  Object(_babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_7__["default"])(ResizeImage, null, [{
    key: "getDerivedStateFromProps",
    value: function getDerivedStateFromProps(props, state) {
      if (props.width && !state.width) {
        return {
          width: props.width
        };
      }

      return null;
    }
  }]);

  function ResizeImage(props) {
    var _this;

    Object(_babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_3__["default"])(this, ResizeImage);

    _this = Object(_babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__["default"])(this, Object(_babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__["default"])(ResizeImage).call(this, props));

    Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_9__["default"])(Object(_babel_runtime_corejs2_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_6__["default"])(_this), "handleResize", function () {
      Object(_lib_requestAnimationFrame__WEBPACK_IMPORTED_MODULE_15__["requestAnimationFrame"])(function () {
        if (_this.wrapRef.current) {
          var width = _this.state.width;
          var wrap = _this.wrapRef.current;
          var container = _this.containerRef.current;
          var currentWidth = Object(rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_12__["get"])(wrap, 'width');
          var targetHeight = Object(rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_12__["get"])(container, 'height');
          var scale = currentWidth / width;
          Object(rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_12__["set"])(container, 'transform', "scale(".concat(scale, ")"));
          Object(rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_12__["set"])(wrap, 'height', targetHeight * scale);
        }
      });
    });

    _this.wrapRef = react__WEBPACK_IMPORTED_MODULE_10___default.a.createRef();
    _this.containerRef = react__WEBPACK_IMPORTED_MODULE_10___default.a.createRef();
    _this.state = {
      width: null,
      height: null
    };
    return _this;
  }

  Object(_babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_7__["default"])(ResizeImage, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      var width = this.state.width;
      var themeVariables = this.context.themeVariables; // eslint-disable-next-line

      this.state.width = width === null ? +themeVariables['@page-width'].replace(/px$/, '') - 24 * 2 : width;
      this.resizeHandler = rc_util_lib_Dom_addEventListener__WEBPACK_IMPORTED_MODULE_13___default()(window, 'resize', this.handleResize);
      this.handleResize();
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      if (this.resizeHandler) {
        this.resizeHandler.remove();
        this.resizeHandler = null;
      }
    }
  }, {
    key: "render",
    value: function render() {
      var _this$state = this.state,
          width = _this$state.width,
          height = _this$state.height;
      var themeVariables = this.context.themeVariables;

      var _this$props = this.props,
          children = _this$props.children,
          props = Object(_babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_2__["default"])(_this$props, ["children"]); // width 一定要设置默认


      var style = {
        // 最大宽度减 pandding
        width: width === null ? +themeVariables['@page-width'].replace(/px$/, '') - 24 * 2 : width,
        height: height
      };
      style = object_pick__WEBPACK_IMPORTED_MODULE_11___default()(style, _babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_1___default()(style).filter(function (key) {
        return style[key];
      }));
      return react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", Object(_babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__["default"])({}, props, {
        ref: this.wrapRef,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 78
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_10___default.a.createElement("div", {
        style: style,
        className: _resizeImage_less__WEBPACK_IMPORTED_MODULE_16___default.a.container,
        ref: this.containerRef,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 79
        },
        __self: this
      }, children));
    }
  }]);

  return ResizeImage;
}(react__WEBPACK_IMPORTED_MODULE_10___default.a.Component);

Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_9__["default"])(ResizeImage, "contextType", _components_Themes__WEBPACK_IMPORTED_MODULE_14__["ThemeContext"]);

/* harmony default export */ __webpack_exports__["default"] = (ResizeImage);

/***/ }),

/***/ "./components/ResizeImage/resizeImage.less":
/*!*************************************************!*\
  !*** ./components/ResizeImage/resizeImage.less ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = {
	"container": "container___ZNsC9"
};

/***/ }),

/***/ "./components/SvgIcon/index.js":
/*!*************************************!*\
  !*** ./components/SvgIcon/index.js ***!
  \*************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Icon; });
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/extends */ "./node_modules/@babel/runtime-corejs2/helpers/esm/extends.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/objectWithoutProperties */ "./node_modules/@babel/runtime-corejs2/helpers/esm/objectWithoutProperties.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! classnames */ "classnames");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _svgIcon_less__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./svgIcon.less */ "./components/SvgIcon/svgIcon.less");
/* harmony import */ var _svgIcon_less__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_svgIcon_less__WEBPACK_IMPORTED_MODULE_4__);


var _jsxFileName = "/Users/rainx/Documents/Github/csite/components/SvgIcon/index.js";



function Icon(_ref) {
  var icon = _ref.icon,
      className = _ref.className,
      props = Object(_babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__["default"])(_ref, ["icon", "className"]);

  return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("svg", Object(_babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__["default"])({
    "aria-hidden": "true"
  }, props, {
    className: classnames__WEBPACK_IMPORTED_MODULE_3___default()(_svgIcon_less__WEBPACK_IMPORTED_MODULE_4___default.a.svgIcon, className),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 8
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("use", {
    xlinkHref: "#".concat(icon.id),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 9
    },
    __self: this
  }));
}

/***/ }),

/***/ "./components/SvgIcon/svgIcon.less":
/*!*****************************************!*\
  !*** ./components/SvgIcon/svgIcon.less ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = {
	"svg-icon": "svg-icon___39UYR",
	"svgIcon": "svg-icon___39UYR"
};

/***/ }),

/***/ "./components/Themes/index.js":
/*!************************************!*\
  !*** ./components/Themes/index.js ***!
  \************************************/
/*! exports provided: themeVariables, themeEasings, defaultThemeConfig, setTheme, withTheme, ThemeContext */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "themeVariables", function() { return themeVariables; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "themeEasings", function() { return themeEasings; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "defaultThemeConfig", function() { return defaultThemeConfig; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setTheme", function() { return setTheme; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "withTheme", function() { return withTheme; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ThemeContext", function() { return ThemeContext; });
/* harmony import */ var _babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime-corejs2/core-js/object/keys */ "./node_modules/@babel/runtime-corejs2/core-js/object/keys.js");
/* harmony import */ var _babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/extends */ "./node_modules/@babel/runtime-corejs2/helpers/esm/extends.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/classCallCheck */ "./node_modules/@babel/runtime-corejs2/helpers/esm/classCallCheck.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/createClass */ "./node_modules/@babel/runtime-corejs2/helpers/esm/createClass.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/possibleConstructorReturn */ "./node_modules/@babel/runtime-corejs2/helpers/esm/possibleConstructorReturn.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/getPrototypeOf */ "./node_modules/@babel/runtime-corejs2/helpers/esm/getPrototypeOf.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/assertThisInitialized */ "./node_modules/@babel/runtime-corejs2/helpers/esm/assertThisInitialized.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/inherits */ "./node_modules/@babel/runtime-corejs2/helpers/esm/inherits.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/defineProperty */ "./node_modules/@babel/runtime-corejs2/helpers/esm/defineProperty.js");
/* harmony import */ var _babel_runtime_corejs2_core_js_object_assign__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @babel/runtime-corejs2/core-js/object/assign */ "./node_modules/@babel/runtime-corejs2/core-js/object/assign.js");
/* harmony import */ var _babel_runtime_corejs2_core_js_object_assign__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_core_js_object_assign__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_objectSpread__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/objectSpread */ "./node_modules/@babel/runtime-corejs2/helpers/esm/objectSpread.js");
/* harmony import */ var flystore__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! flystore */ "flystore");
/* harmony import */ var flystore__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(flystore__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var object_pick__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! object.pick */ "object.pick");
/* harmony import */ var object_pick__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(object_pick__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var less_vars_to_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! less-vars-to-js */ "less-vars-to-js");
/* harmony import */ var less_vars_to_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(less_vars_to_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! next/router */ "next/router");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _raw_loader_assets_custom_less__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! !raw-loader!@assets/custom.less */ "./node_modules/raw-loader/dist/cjs.js!./assets/custom.less");
/* harmony import */ var _raw_loader_assets_easings_index_less__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! !raw-loader!@assets/easings/index.less */ "./node_modules/raw-loader/dist/cjs.js!./assets/easings/index.less");











var _jsxFileName = "/Users/rainx/Documents/Github/csite/components/Themes/index.js";







var themeVariables = less_vars_to_js__WEBPACK_IMPORTED_MODULE_14___default()(_raw_loader_assets_custom_less__WEBPACK_IMPORTED_MODULE_16__["default"], {
  resolveVariables: true
});
var themeEasings = less_vars_to_js__WEBPACK_IMPORTED_MODULE_14___default()(_raw_loader_assets_easings_index_less__WEBPACK_IMPORTED_MODULE_17__["default"], {
  resolveVariables: true
});
var defaultThemeConfig = {
  footer: true,
  header: true
};
var storeTheme = flystore__WEBPACK_IMPORTED_MODULE_11___default()('@theme-config');
storeTheme.set('config', Object(_babel_runtime_corejs2_helpers_esm_objectSpread__WEBPACK_IMPORTED_MODULE_10__["default"])({}, defaultThemeConfig));
storeTheme.set('change', {});
var setTheme = function setTheme(config, changeRoute) {
  var route = next_router__WEBPACK_IMPORTED_MODULE_15___default.a.router.route;

  if (changeRoute && changeRoute !== route) {
    var themeConfig = storeTheme.get("change-".concat(changeRoute));
    storeTheme.set("change-".concat(changeRoute), _babel_runtime_corejs2_core_js_object_assign__WEBPACK_IMPORTED_MODULE_9___default()({}, themeConfig, config));
  } else {
    var _themeConfig = storeTheme.get("change-".concat(route));

    var newConfig = _babel_runtime_corejs2_core_js_object_assign__WEBPACK_IMPORTED_MODULE_9___default()({}, _themeConfig, config);

    storeTheme.set("change-".concat(route), newConfig);
    storeTheme.dispense('change', newConfig);
  }
};
function withTheme(Comp) {
  var _class, _temp;

  return Object(next_router__WEBPACK_IMPORTED_MODULE_15__["withRouter"])((_temp = _class =
  /*#__PURE__*/
  function (_React$Component) {
    Object(_babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_7__["default"])(WithTheme, _React$Component);

    function WithTheme() {
      var _getPrototypeOf2;

      var _this;

      Object(_babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_2__["default"])(this, WithTheme);

      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }

      _this = Object(_babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__["default"])(this, (_getPrototypeOf2 = Object(_babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__["default"])(WithTheme)).call.apply(_getPrototypeOf2, [this].concat(args)));

      Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_8__["default"])(Object(_babel_runtime_corejs2_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_6__["default"])(_this), "state", {
        themeConfig: storeTheme.get('config')
      });

      return _this;
    }

    Object(_babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_3__["default"])(WithTheme, [{
      key: "componentDidMount",
      value: function componentDidMount() {
        var _this2 = this;

        var route = this.props.router.route;
        var changeConfig = storeTheme.get("change-".concat(route));

        if (changeConfig) {
          this.setState({
            themeConfig: _babel_runtime_corejs2_core_js_object_assign__WEBPACK_IMPORTED_MODULE_9___default()(storeTheme.get('config'), changeConfig)
          });
        }

        this.configHandle = storeTheme.watch('change', function (themeConfig) {
          _this2.setState({
            themeConfig: _babel_runtime_corejs2_core_js_object_assign__WEBPACK_IMPORTED_MODULE_9___default()(storeTheme.get('config'), themeConfig)
          });
        });
      }
    }, {
      key: "componentWillUnmount",
      value: function componentWillUnmount() {
        if (this.configHandle) {
          this.configHandle.clear();
          this.configHandle = null;
        }
      }
    }, {
      key: "render",
      value: function render() {
        return react__WEBPACK_IMPORTED_MODULE_12___default.a.createElement(Comp, Object(_babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_1__["default"])({}, this.props, {
          themeConfig: this.state.themeConfig,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 83
          },
          __self: this
        }));
      }
    }]);

    return WithTheme;
  }(react__WEBPACK_IMPORTED_MODULE_12___default.a.Component), Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_8__["default"])(_class, "getDerivedStateFromProps", function (props) {
    var route = props.router.route;

    var newConfig = _babel_runtime_corejs2_core_js_object_assign__WEBPACK_IMPORTED_MODULE_9___default()({}, defaultThemeConfig, object_pick__WEBPACK_IMPORTED_MODULE_13___default()(props, _babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_0___default()(defaultThemeConfig)));

    var changeConfig = storeTheme.get("change-".concat(route));
    return {
      themeConfig: _babel_runtime_corejs2_core_js_object_assign__WEBPACK_IMPORTED_MODULE_9___default()(newConfig, changeConfig)
    };
  }), _temp));
}
var ThemeContext = react__WEBPACK_IMPORTED_MODULE_12___default.a.createContext({
  env: {},
  themeConfig: Object(_babel_runtime_corejs2_helpers_esm_objectSpread__WEBPACK_IMPORTED_MODULE_10__["default"])({}, defaultThemeConfig),
  themeEasings: themeEasings,
  themeVariables: themeVariables,
  isLoaded: false,
  isMobile: false
});

/***/ }),

/***/ "./lib/requestAnimationFrame.js":
/*!**************************************!*\
  !*** ./lib/requestAnimationFrame.js ***!
  \**************************************/
/*! exports provided: requestAnimationFrame, cancelAnimationFrame */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "requestAnimationFrame", function() { return requestAnimationFrame; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "cancelAnimationFrame", function() { return cancelAnimationFrame; });
var suffix = 'AnimationFrame';
var vendors = ['', 'moz', 'webkit'];

var getAFFunc = function getAFFunc(name) {
  var func = null;
  return function () {
    if (func) {
      return func.apply(void 0, arguments);
    }

    var win = window;

    for (var i = 0, l = vendors.length; i < l; i++) {
      var prefix = vendors[i];
      var funcName = name + suffix;

      if (prefix) {
        funcName = prefix + funcName.charAt(0).toUpperCase() + funcName.slice(1);
      }

      func = win[funcName];

      if (func) {
        break;
      }
    }

    return func ? func.apply(void 0, arguments) : func;
  };
};

var requestAnimationFrame = getAFFunc('request');
var cancelFunc = getAFFunc('cancel');
var cancelRequestFunc = getAFFunc('cancelRequest');
var cancelAnimationFrame = function cancelAnimationFrame() {
  return cancelFunc.apply(void 0, arguments) || cancelRequestFunc.apply(void 0, arguments);
};

/***/ }),

/***/ "./node_modules/@babel/runtime-corejs2/core-js/array/is-array.js":
/*!***********************************************************************!*\
  !*** ./node_modules/@babel/runtime-corejs2/core-js/array/is-array.js ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! core-js/library/fn/array/is-array */ "core-js/library/fn/array/is-array");

/***/ }),

/***/ "./node_modules/@babel/runtime-corejs2/core-js/get-iterator.js":
/*!*********************************************************************!*\
  !*** ./node_modules/@babel/runtime-corejs2/core-js/get-iterator.js ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! core-js/library/fn/get-iterator */ "core-js/library/fn/get-iterator");

/***/ }),

/***/ "./node_modules/@babel/runtime-corejs2/core-js/object/assign.js":
/*!**********************************************************************!*\
  !*** ./node_modules/@babel/runtime-corejs2/core-js/object/assign.js ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! core-js/library/fn/object/assign */ "core-js/library/fn/object/assign");

/***/ }),

/***/ "./node_modules/@babel/runtime-corejs2/core-js/object/create.js":
/*!**********************************************************************!*\
  !*** ./node_modules/@babel/runtime-corejs2/core-js/object/create.js ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! core-js/library/fn/object/create */ "core-js/library/fn/object/create");

/***/ }),

/***/ "./node_modules/@babel/runtime-corejs2/core-js/object/define-property.js":
/*!*******************************************************************************!*\
  !*** ./node_modules/@babel/runtime-corejs2/core-js/object/define-property.js ***!
  \*******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! core-js/library/fn/object/define-property */ "core-js/library/fn/object/define-property");

/***/ }),

/***/ "./node_modules/@babel/runtime-corejs2/core-js/object/entries.js":
/*!***********************************************************************!*\
  !*** ./node_modules/@babel/runtime-corejs2/core-js/object/entries.js ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! core-js/library/fn/object/entries */ "core-js/library/fn/object/entries");

/***/ }),

/***/ "./node_modules/@babel/runtime-corejs2/core-js/object/get-own-property-descriptor.js":
/*!*******************************************************************************************!*\
  !*** ./node_modules/@babel/runtime-corejs2/core-js/object/get-own-property-descriptor.js ***!
  \*******************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! core-js/library/fn/object/get-own-property-descriptor */ "core-js/library/fn/object/get-own-property-descriptor");

/***/ }),

/***/ "./node_modules/@babel/runtime-corejs2/core-js/object/get-own-property-symbols.js":
/*!****************************************************************************************!*\
  !*** ./node_modules/@babel/runtime-corejs2/core-js/object/get-own-property-symbols.js ***!
  \****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! core-js/library/fn/object/get-own-property-symbols */ "core-js/library/fn/object/get-own-property-symbols");

/***/ }),

/***/ "./node_modules/@babel/runtime-corejs2/core-js/object/get-prototype-of.js":
/*!********************************************************************************!*\
  !*** ./node_modules/@babel/runtime-corejs2/core-js/object/get-prototype-of.js ***!
  \********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! core-js/library/fn/object/get-prototype-of */ "core-js/library/fn/object/get-prototype-of");

/***/ }),

/***/ "./node_modules/@babel/runtime-corejs2/core-js/object/keys.js":
/*!********************************************************************!*\
  !*** ./node_modules/@babel/runtime-corejs2/core-js/object/keys.js ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! core-js/library/fn/object/keys */ "core-js/library/fn/object/keys");

/***/ }),

/***/ "./node_modules/@babel/runtime-corejs2/core-js/object/set-prototype-of.js":
/*!********************************************************************************!*\
  !*** ./node_modules/@babel/runtime-corejs2/core-js/object/set-prototype-of.js ***!
  \********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! core-js/library/fn/object/set-prototype-of */ "core-js/library/fn/object/set-prototype-of");

/***/ }),

/***/ "./node_modules/@babel/runtime-corejs2/core-js/promise.js":
/*!****************************************************************!*\
  !*** ./node_modules/@babel/runtime-corejs2/core-js/promise.js ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! core-js/library/fn/promise */ "core-js/library/fn/promise");

/***/ }),

/***/ "./node_modules/@babel/runtime-corejs2/core-js/symbol.js":
/*!***************************************************************!*\
  !*** ./node_modules/@babel/runtime-corejs2/core-js/symbol.js ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! core-js/library/fn/symbol */ "core-js/library/fn/symbol");

/***/ }),

/***/ "./node_modules/@babel/runtime-corejs2/core-js/symbol/iterator.js":
/*!************************************************************************!*\
  !*** ./node_modules/@babel/runtime-corejs2/core-js/symbol/iterator.js ***!
  \************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! core-js/library/fn/symbol/iterator */ "core-js/library/fn/symbol/iterator");

/***/ }),

/***/ "./node_modules/@babel/runtime-corejs2/helpers/esm/arrayWithHoles.js":
/*!***************************************************************************!*\
  !*** ./node_modules/@babel/runtime-corejs2/helpers/esm/arrayWithHoles.js ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _arrayWithHoles; });
/* harmony import */ var _core_js_array_is_array__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../core-js/array/is-array */ "./node_modules/@babel/runtime-corejs2/core-js/array/is-array.js");
/* harmony import */ var _core_js_array_is_array__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_array_is_array__WEBPACK_IMPORTED_MODULE_0__);

function _arrayWithHoles(arr) {
  if (_core_js_array_is_array__WEBPACK_IMPORTED_MODULE_0___default()(arr)) return arr;
}

/***/ }),

/***/ "./node_modules/@babel/runtime-corejs2/helpers/esm/assertThisInitialized.js":
/*!**********************************************************************************!*\
  !*** ./node_modules/@babel/runtime-corejs2/helpers/esm/assertThisInitialized.js ***!
  \**********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _assertThisInitialized; });
function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

/***/ }),

/***/ "./node_modules/@babel/runtime-corejs2/helpers/esm/asyncToGenerator.js":
/*!*****************************************************************************!*\
  !*** ./node_modules/@babel/runtime-corejs2/helpers/esm/asyncToGenerator.js ***!
  \*****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _asyncToGenerator; });
/* harmony import */ var _core_js_promise__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../core-js/promise */ "./node_modules/@babel/runtime-corejs2/core-js/promise.js");
/* harmony import */ var _core_js_promise__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_promise__WEBPACK_IMPORTED_MODULE_0__);


function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
  try {
    var info = gen[key](arg);
    var value = info.value;
  } catch (error) {
    reject(error);
    return;
  }

  if (info.done) {
    resolve(value);
  } else {
    _core_js_promise__WEBPACK_IMPORTED_MODULE_0___default.a.resolve(value).then(_next, _throw);
  }
}

function _asyncToGenerator(fn) {
  return function () {
    var self = this,
        args = arguments;
    return new _core_js_promise__WEBPACK_IMPORTED_MODULE_0___default.a(function (resolve, reject) {
      var gen = fn.apply(self, args);

      function _next(value) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
      }

      function _throw(err) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
      }

      _next(undefined);
    });
  };
}

/***/ }),

/***/ "./node_modules/@babel/runtime-corejs2/helpers/esm/classCallCheck.js":
/*!***************************************************************************!*\
  !*** ./node_modules/@babel/runtime-corejs2/helpers/esm/classCallCheck.js ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _classCallCheck; });
function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

/***/ }),

/***/ "./node_modules/@babel/runtime-corejs2/helpers/esm/createClass.js":
/*!************************************************************************!*\
  !*** ./node_modules/@babel/runtime-corejs2/helpers/esm/createClass.js ***!
  \************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _createClass; });
/* harmony import */ var _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../core-js/object/define-property */ "./node_modules/@babel/runtime-corejs2/core-js/object/define-property.js");
/* harmony import */ var _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__);


function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;

    _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default()(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

/***/ }),

/***/ "./node_modules/@babel/runtime-corejs2/helpers/esm/defineProperty.js":
/*!***************************************************************************!*\
  !*** ./node_modules/@babel/runtime-corejs2/helpers/esm/defineProperty.js ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _defineProperty; });
/* harmony import */ var _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../core-js/object/define-property */ "./node_modules/@babel/runtime-corejs2/core-js/object/define-property.js");
/* harmony import */ var _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__);

function _defineProperty(obj, key, value) {
  if (key in obj) {
    _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default()(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}

/***/ }),

/***/ "./node_modules/@babel/runtime-corejs2/helpers/esm/extends.js":
/*!********************************************************************!*\
  !*** ./node_modules/@babel/runtime-corejs2/helpers/esm/extends.js ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _extends; });
/* harmony import */ var _core_js_object_assign__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../core-js/object/assign */ "./node_modules/@babel/runtime-corejs2/core-js/object/assign.js");
/* harmony import */ var _core_js_object_assign__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_assign__WEBPACK_IMPORTED_MODULE_0__);

function _extends() {
  _extends = _core_js_object_assign__WEBPACK_IMPORTED_MODULE_0___default.a || function (target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];

      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }

    return target;
  };

  return _extends.apply(this, arguments);
}

/***/ }),

/***/ "./node_modules/@babel/runtime-corejs2/helpers/esm/getPrototypeOf.js":
/*!***************************************************************************!*\
  !*** ./node_modules/@babel/runtime-corejs2/helpers/esm/getPrototypeOf.js ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _getPrototypeOf; });
/* harmony import */ var _core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../core-js/object/get-prototype-of */ "./node_modules/@babel/runtime-corejs2/core-js/object/get-prototype-of.js");
/* harmony import */ var _core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../core-js/object/set-prototype-of */ "./node_modules/@babel/runtime-corejs2/core-js/object/set-prototype-of.js");
/* harmony import */ var _core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_1__);


function _getPrototypeOf(o) {
  _getPrototypeOf = _core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_1___default.a ? _core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0___default.a : function _getPrototypeOf(o) {
    return o.__proto__ || _core_js_object_get_prototype_of__WEBPACK_IMPORTED_MODULE_0___default()(o);
  };
  return _getPrototypeOf(o);
}

/***/ }),

/***/ "./node_modules/@babel/runtime-corejs2/helpers/esm/inherits.js":
/*!*********************************************************************!*\
  !*** ./node_modules/@babel/runtime-corejs2/helpers/esm/inherits.js ***!
  \*********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _inherits; });
/* harmony import */ var _core_js_object_create__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../core-js/object/create */ "./node_modules/@babel/runtime-corejs2/core-js/object/create.js");
/* harmony import */ var _core_js_object_create__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_create__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _setPrototypeOf__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./setPrototypeOf */ "./node_modules/@babel/runtime-corejs2/helpers/esm/setPrototypeOf.js");


function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = _core_js_object_create__WEBPACK_IMPORTED_MODULE_0___default()(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) Object(_setPrototypeOf__WEBPACK_IMPORTED_MODULE_1__["default"])(subClass, superClass);
}

/***/ }),

/***/ "./node_modules/@babel/runtime-corejs2/helpers/esm/iterableToArrayLimit.js":
/*!*********************************************************************************!*\
  !*** ./node_modules/@babel/runtime-corejs2/helpers/esm/iterableToArrayLimit.js ***!
  \*********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _iterableToArrayLimit; });
/* harmony import */ var _core_js_get_iterator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../core-js/get-iterator */ "./node_modules/@babel/runtime-corejs2/core-js/get-iterator.js");
/* harmony import */ var _core_js_get_iterator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_get_iterator__WEBPACK_IMPORTED_MODULE_0__);

function _iterableToArrayLimit(arr, i) {
  var _arr = [];
  var _n = true;
  var _d = false;
  var _e = undefined;

  try {
    for (var _i = _core_js_get_iterator__WEBPACK_IMPORTED_MODULE_0___default()(arr), _s; !(_n = (_s = _i.next()).done); _n = true) {
      _arr.push(_s.value);

      if (i && _arr.length === i) break;
    }
  } catch (err) {
    _d = true;
    _e = err;
  } finally {
    try {
      if (!_n && _i["return"] != null) _i["return"]();
    } finally {
      if (_d) throw _e;
    }
  }

  return _arr;
}

/***/ }),

/***/ "./node_modules/@babel/runtime-corejs2/helpers/esm/nonIterableRest.js":
/*!****************************************************************************!*\
  !*** ./node_modules/@babel/runtime-corejs2/helpers/esm/nonIterableRest.js ***!
  \****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _nonIterableRest; });
function _nonIterableRest() {
  throw new TypeError("Invalid attempt to destructure non-iterable instance");
}

/***/ }),

/***/ "./node_modules/@babel/runtime-corejs2/helpers/esm/objectSpread.js":
/*!*************************************************************************!*\
  !*** ./node_modules/@babel/runtime-corejs2/helpers/esm/objectSpread.js ***!
  \*************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _objectSpread; });
/* harmony import */ var _core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../core-js/object/get-own-property-descriptor */ "./node_modules/@babel/runtime-corejs2/core-js/object/get-own-property-descriptor.js");
/* harmony import */ var _core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../core-js/object/get-own-property-symbols */ "./node_modules/@babel/runtime-corejs2/core-js/object/get-own-property-symbols.js");
/* harmony import */ var _core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _core_js_object_keys__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../core-js/object/keys */ "./node_modules/@babel/runtime-corejs2/core-js/object/keys.js");
/* harmony import */ var _core_js_object_keys__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_keys__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _defineProperty__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./defineProperty */ "./node_modules/@babel/runtime-corejs2/helpers/esm/defineProperty.js");




function _objectSpread(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i] != null ? arguments[i] : {};

    var ownKeys = _core_js_object_keys__WEBPACK_IMPORTED_MODULE_2___default()(source);

    if (typeof _core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1___default.a === 'function') {
      ownKeys = ownKeys.concat(_core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_1___default()(source).filter(function (sym) {
        return _core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_0___default()(source, sym).enumerable;
      }));
    }

    ownKeys.forEach(function (key) {
      Object(_defineProperty__WEBPACK_IMPORTED_MODULE_3__["default"])(target, key, source[key]);
    });
  }

  return target;
}

/***/ }),

/***/ "./node_modules/@babel/runtime-corejs2/helpers/esm/objectWithoutProperties.js":
/*!************************************************************************************!*\
  !*** ./node_modules/@babel/runtime-corejs2/helpers/esm/objectWithoutProperties.js ***!
  \************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _objectWithoutProperties; });
/* harmony import */ var _core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../core-js/object/get-own-property-symbols */ "./node_modules/@babel/runtime-corejs2/core-js/object/get-own-property-symbols.js");
/* harmony import */ var _core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _objectWithoutPropertiesLoose__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./objectWithoutPropertiesLoose */ "./node_modules/@babel/runtime-corejs2/helpers/esm/objectWithoutPropertiesLoose.js");


function _objectWithoutProperties(source, excluded) {
  if (source == null) return {};
  var target = Object(_objectWithoutPropertiesLoose__WEBPACK_IMPORTED_MODULE_1__["default"])(source, excluded);
  var key, i;

  if (_core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_0___default.a) {
    var sourceSymbolKeys = _core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_0___default()(source);

    for (i = 0; i < sourceSymbolKeys.length; i++) {
      key = sourceSymbolKeys[i];
      if (excluded.indexOf(key) >= 0) continue;
      if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
      target[key] = source[key];
    }
  }

  return target;
}

/***/ }),

/***/ "./node_modules/@babel/runtime-corejs2/helpers/esm/objectWithoutPropertiesLoose.js":
/*!*****************************************************************************************!*\
  !*** ./node_modules/@babel/runtime-corejs2/helpers/esm/objectWithoutPropertiesLoose.js ***!
  \*****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _objectWithoutPropertiesLoose; });
/* harmony import */ var _core_js_object_keys__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../core-js/object/keys */ "./node_modules/@babel/runtime-corejs2/core-js/object/keys.js");
/* harmony import */ var _core_js_object_keys__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_keys__WEBPACK_IMPORTED_MODULE_0__);

function _objectWithoutPropertiesLoose(source, excluded) {
  if (source == null) return {};
  var target = {};

  var sourceKeys = _core_js_object_keys__WEBPACK_IMPORTED_MODULE_0___default()(source);

  var key, i;

  for (i = 0; i < sourceKeys.length; i++) {
    key = sourceKeys[i];
    if (excluded.indexOf(key) >= 0) continue;
    target[key] = source[key];
  }

  return target;
}

/***/ }),

/***/ "./node_modules/@babel/runtime-corejs2/helpers/esm/possibleConstructorReturn.js":
/*!**************************************************************************************!*\
  !*** ./node_modules/@babel/runtime-corejs2/helpers/esm/possibleConstructorReturn.js ***!
  \**************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _possibleConstructorReturn; });
/* harmony import */ var _helpers_esm_typeof__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../helpers/esm/typeof */ "./node_modules/@babel/runtime-corejs2/helpers/esm/typeof.js");
/* harmony import */ var _assertThisInitialized__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./assertThisInitialized */ "./node_modules/@babel/runtime-corejs2/helpers/esm/assertThisInitialized.js");


function _possibleConstructorReturn(self, call) {
  if (call && (Object(_helpers_esm_typeof__WEBPACK_IMPORTED_MODULE_0__["default"])(call) === "object" || typeof call === "function")) {
    return call;
  }

  return Object(_assertThisInitialized__WEBPACK_IMPORTED_MODULE_1__["default"])(self);
}

/***/ }),

/***/ "./node_modules/@babel/runtime-corejs2/helpers/esm/setPrototypeOf.js":
/*!***************************************************************************!*\
  !*** ./node_modules/@babel/runtime-corejs2/helpers/esm/setPrototypeOf.js ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _setPrototypeOf; });
/* harmony import */ var _core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../core-js/object/set-prototype-of */ "./node_modules/@babel/runtime-corejs2/core-js/object/set-prototype-of.js");
/* harmony import */ var _core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_0__);

function _setPrototypeOf(o, p) {
  _setPrototypeOf = _core_js_object_set_prototype_of__WEBPACK_IMPORTED_MODULE_0___default.a || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

/***/ }),

/***/ "./node_modules/@babel/runtime-corejs2/helpers/esm/slicedToArray.js":
/*!**************************************************************************!*\
  !*** ./node_modules/@babel/runtime-corejs2/helpers/esm/slicedToArray.js ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _slicedToArray; });
/* harmony import */ var _arrayWithHoles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./arrayWithHoles */ "./node_modules/@babel/runtime-corejs2/helpers/esm/arrayWithHoles.js");
/* harmony import */ var _iterableToArrayLimit__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./iterableToArrayLimit */ "./node_modules/@babel/runtime-corejs2/helpers/esm/iterableToArrayLimit.js");
/* harmony import */ var _nonIterableRest__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./nonIterableRest */ "./node_modules/@babel/runtime-corejs2/helpers/esm/nonIterableRest.js");



function _slicedToArray(arr, i) {
  return Object(_arrayWithHoles__WEBPACK_IMPORTED_MODULE_0__["default"])(arr) || Object(_iterableToArrayLimit__WEBPACK_IMPORTED_MODULE_1__["default"])(arr, i) || Object(_nonIterableRest__WEBPACK_IMPORTED_MODULE_2__["default"])();
}

/***/ }),

/***/ "./node_modules/@babel/runtime-corejs2/helpers/esm/typeof.js":
/*!*******************************************************************!*\
  !*** ./node_modules/@babel/runtime-corejs2/helpers/esm/typeof.js ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _typeof; });
/* harmony import */ var _core_js_symbol_iterator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../core-js/symbol/iterator */ "./node_modules/@babel/runtime-corejs2/core-js/symbol/iterator.js");
/* harmony import */ var _core_js_symbol_iterator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_symbol_iterator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _core_js_symbol__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../core-js/symbol */ "./node_modules/@babel/runtime-corejs2/core-js/symbol.js");
/* harmony import */ var _core_js_symbol__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_core_js_symbol__WEBPACK_IMPORTED_MODULE_1__);



function _typeof2(obj) { if (typeof _core_js_symbol__WEBPACK_IMPORTED_MODULE_1___default.a === "function" && typeof _core_js_symbol_iterator__WEBPACK_IMPORTED_MODULE_0___default.a === "symbol") { _typeof2 = function _typeof2(obj) { return typeof obj; }; } else { _typeof2 = function _typeof2(obj) { return obj && typeof _core_js_symbol__WEBPACK_IMPORTED_MODULE_1___default.a === "function" && obj.constructor === _core_js_symbol__WEBPACK_IMPORTED_MODULE_1___default.a && obj !== _core_js_symbol__WEBPACK_IMPORTED_MODULE_1___default.a.prototype ? "symbol" : typeof obj; }; } return _typeof2(obj); }

function _typeof(obj) {
  if (typeof _core_js_symbol__WEBPACK_IMPORTED_MODULE_1___default.a === "function" && _typeof2(_core_js_symbol_iterator__WEBPACK_IMPORTED_MODULE_0___default.a) === "symbol") {
    _typeof = function _typeof(obj) {
      return _typeof2(obj);
    };
  } else {
    _typeof = function _typeof(obj) {
      return obj && typeof _core_js_symbol__WEBPACK_IMPORTED_MODULE_1___default.a === "function" && obj.constructor === _core_js_symbol__WEBPACK_IMPORTED_MODULE_1___default.a && obj !== _core_js_symbol__WEBPACK_IMPORTED_MODULE_1___default.a.prototype ? "symbol" : _typeof2(obj);
    };
  }

  return _typeof(obj);
}

/***/ }),

/***/ "./node_modules/@babel/runtime-corejs2/regenerator/index.js":
/*!******************************************************************!*\
  !*** ./node_modules/@babel/runtime-corejs2/regenerator/index.js ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! regenerator-runtime */ "regenerator-runtime");


/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./assets/custom.less":
/*!******************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./assets/custom.less ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n// https://github.com/ant-design/ant-design/blob/master/components/style/themes/default.less\n@import (reference) \"~antd/lib/style/themes/default.less\";\n@import (reference) \"~antd/lib/style/mixins/index.less\";\n@import (reference) \"./easings/index.less\";\n\n@gray-1: #ffffff;\n@gray-2: #fafafa;\n@gray-3: #f5f5f5;\n@gray-4: #e8e8e8;\n@gray-5: #d9d9d9;\n@gray-6: #bfbfbf;\n@gray-7: #8c8c8c;\n@gray-8: #595959;\n@gray-9: #262626;\n@gray-10: #000000;\n\n// 暗黑\n@dark-1: rgba(0, 0, 0, .05);\n@dark-2: rgba(0, 0, 0, .15);\n@dark-3: rgba(0, 0, 0, .25);\n@dark-4: rgba(0, 0, 0, .35);\n@dark-5: rgba(0, 0, 0, .45);\n@dark-6: rgba(0, 0, 0, .55);\n@dark-7: rgba(0, 0, 0, .65);\n@dark-8: rgba(0, 0, 0, .75);\n@dark-9: rgba(0, 0, 0, .85);\n@dark-10: rgba(0, 0, 0, 1);\n\n// 亮白\n@light-1: rgba(255, 255, 255, .05);\n@light-2: rgba(255, 255, 255, .15);\n@light-3: rgba(255, 255, 255, .25);\n@light-4: rgba(255, 255, 255, .35);\n@light-5: rgba(255, 255, 255, .45);\n@light-6: rgba(255, 255, 255, .55);\n@light-7: rgba(255, 255, 255, .65);\n@light-8: rgba(255, 255, 255, .75);\n@light-9: rgba(255, 255, 255, .85);\n@light-10: rgba(255, 255, 255, 1);\n\n\n@mask-color: #001529;\n@footer-color: @light-8;\n@footer-link-color: @light-6;\n@footer-link-hover-color: @light-10;\n@footer-background-color: @dark-10;\n@header-background-color: #001529;\n@anchor-background-color: @light-10;\n@anchor-color: #1890ff;\n\n\n@dark-menu-color: @light-7;\n@dark-menu-background-color: @header-background-color;\n\n\n@anim-speed-1: 200ms;\n@anim-speed-2: 375ms;\n@anim-speed-3: 500ms;\n@anim-speed-4: 800ms;\n@anim-speed-5: 1200ms;\n\n\n@page-width: 980px;\n@page-width-lg: 1440px;\n@max-width: 1920px; // 2560px\n@header-height: 64px;\n@header-phone-height: 48px;\n@anchor-height: 48px;\n\n\n// z-index\n@header-zIndex: 1100;\n@anchor-zIndex: @header-zIndex - 10;\n\n// shadow\n@shadow-down: 0 2px 8px rgba(0, 0, 0, 0.08);\n@shadow-down-dark: 0 2px 8px rgba(0, 0, 0, 0.2);\n@shadow-down-sm: 4px 6px 10px rgba(0, 0, 0, 0.1);\n@shadow-down-lg: 8px 12px 20px rgba(0, 0, 0, 0.3);\n\n\n@main-color: #fa8c16;\n@main-background-color: #001529;\n@main-light-background-color: #f1f3ff;\n\n// .function {\n//   .foo(@x) {\n//     return: @x * 2;\n//   }\n// }");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./assets/easings/index.less":
/*!*************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./assets/easings/index.less ***!
  \*************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("//https://easings.net/\n//http://cubic-bezier.com/#.17,.67,.83,.67\n@linear         : cubic-bezier(0.250, 0.250, 0.750, 0.750);\n@ease           : cubic-bezier(0.250, 0.100, 0.250, 1.000);\n@ease-in        : cubic-bezier(0.420, 0.000, 1.000, 1.000);\n@ease-out       : cubic-bezier(0.000, 0.000, 0.580, 1.000);\n@ease-in-out    : cubic-bezier(0.420, 0.000, 0.580, 1.000);\n\n@easeInQuad     : cubic-bezier(0.550, 0.085, 0.680, 0.530);\n@easeInCubic    : cubic-bezier(0.550, 0.055, 0.675, 0.190);\n@easeInQuart    : cubic-bezier(0.895, 0.030, 0.685, 0.220);\n@easeInQuint    : cubic-bezier(0.755, 0.050, 0.855, 0.060);\n@easeInSine     : cubic-bezier(0.470, 0.000, 0.745, 0.715);\n@easeInExpo     : cubic-bezier(0.950, 0.050, 0.795, 0.035);\n@easeInCirc     : cubic-bezier(0.600, 0.040, 0.980, 0.335);\n@easeInBack     : cubic-bezier(0.600, -0.280, 0.735, 0.045);\n\n@easeOutQuad    : cubic-bezier(0.250, 0.460, 0.450, 0.940);\n@easeOutCubic   : cubic-bezier(0.215, 0.610, 0.355, 1.000);\n@easeOutQuart   : cubic-bezier(0.165, 0.840, 0.440, 1.000);\n@easeOutQuint   : cubic-bezier(0.230, 1.000, 0.320, 1.000);\n@easeOutSine    : cubic-bezier(0.390, 0.575, 0.565, 1.000);\n@easeOutExpo    : cubic-bezier(0.190, 1.000, 0.220, 1.000);\n@easeOutCirc    : cubic-bezier(0.075, 0.820, 0.165, 1.000);\n@easeOutBack    : cubic-bezier(0.175, 0.885, 0.320, 1.275);\n\n@easeInOutQuad  : cubic-bezier(0.455, 0.030, 0.515, 0.955);\n@easeInOutCubic : cubic-bezier(0.645, 0.045, 0.355, 1.000);\n@easeInOutQuart : cubic-bezier(0.770, 0.000, 0.175, 1.000);\n@easeInOutQuint : cubic-bezier(0.860, 0.000, 0.070, 1.000);\n@easeInOutSine  : cubic-bezier(0.445, 0.050, 0.550, 0.950);\n@easeInOutExpo  : cubic-bezier(1.000, 0.000, 0.000, 1.000);\n@easeInOutCirc  : cubic-bezier(0.785, 0.135, 0.150, 0.860);\n@easeInOutBack  : cubic-bezier(0.680, -0.550, 0.265, 1.550);\n");

/***/ }),

/***/ "./pages/scene/index.js":
/*!******************************!*\
  !*** ./pages/scene/index.js ***!
  \******************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime-corejs2/core-js/object/keys */ "./node_modules/@babel/runtime-corejs2/core-js/object/keys.js");
/* harmony import */ var _babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime-corejs2/regenerator */ "./node_modules/@babel/runtime-corejs2/regenerator/index.js");
/* harmony import */ var _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/asyncToGenerator */ "./node_modules/@babel/runtime-corejs2/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/slicedToArray */ "./node_modules/@babel/runtime-corejs2/helpers/esm/slicedToArray.js");
/* harmony import */ var _babel_runtime_corejs2_core_js_object_entries__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @babel/runtime-corejs2/core-js/object/entries */ "./node_modules/@babel/runtime-corejs2/core-js/object/entries.js");
/* harmony import */ var _babel_runtime_corejs2_core_js_object_entries__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_core_js_object_entries__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_objectSpread__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/objectSpread */ "./node_modules/@babel/runtime-corejs2/helpers/esm/objectSpread.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/classCallCheck */ "./node_modules/@babel/runtime-corejs2/helpers/esm/classCallCheck.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/createClass */ "./node_modules/@babel/runtime-corejs2/helpers/esm/createClass.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/possibleConstructorReturn */ "./node_modules/@babel/runtime-corejs2/helpers/esm/possibleConstructorReturn.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/getPrototypeOf */ "./node_modules/@babel/runtime-corejs2/helpers/esm/getPrototypeOf.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/assertThisInitialized */ "./node_modules/@babel/runtime-corejs2/helpers/esm/assertThisInitialized.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/inherits */ "./node_modules/@babel/runtime-corejs2/helpers/esm/inherits.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/defineProperty */ "./node_modules/@babel/runtime-corejs2/helpers/esm/defineProperty.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! classnames */ "classnames");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! next/router */ "next/router");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! rc-util/lib/Dom/css */ "rc-util/lib/Dom/css");
/* harmony import */ var rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _components_Themes__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @components/Themes */ "./components/Themes/index.js");
/* harmony import */ var _lib_requestAnimationFrame__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @lib/requestAnimationFrame */ "./lib/requestAnimationFrame.js");
/* harmony import */ var _assets_images_scene_banner_1_jpg__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @assets/images/scene/banner-1.jpg */ "./assets/images/scene/banner-1.jpg");
/* harmony import */ var _assets_images_scene_banner_1_jpg__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(_assets_images_scene_banner_1_jpg__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var _assets_images_scene_banner_2_jpg__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @assets/images/scene/banner-2.jpg */ "./assets/images/scene/banner-2.jpg");
/* harmony import */ var _assets_images_scene_banner_2_jpg__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(_assets_images_scene_banner_2_jpg__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var _assets_images_scene_banner_3_jpg__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @assets/images/scene/banner-3.jpg */ "./assets/images/scene/banner-3.jpg");
/* harmony import */ var _assets_images_scene_banner_3_jpg__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(_assets_images_scene_banner_3_jpg__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var _assets_images_scene_banner_4_jpg__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @assets/images/scene/banner-4.jpg */ "./assets/images/scene/banner-4.jpg");
/* harmony import */ var _assets_images_scene_banner_4_jpg__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(_assets_images_scene_banner_4_jpg__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var _scene1__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./scene1 */ "./pages/scene/scene1/index.js");
/* harmony import */ var _scene2__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./scene2 */ "./pages/scene/scene2.js");
/* harmony import */ var _scene3__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ./scene3 */ "./pages/scene/scene3.js");
/* harmony import */ var _scene4__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ./scene4 */ "./pages/scene/scene4.js");
/* harmony import */ var _scene_less__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ./scene.less */ "./pages/scene/scene.less");
/* harmony import */ var _scene_less__WEBPACK_IMPORTED_MODULE_27___default = /*#__PURE__*/__webpack_require__.n(_scene_less__WEBPACK_IMPORTED_MODULE_27__);














var _class,
    _class2,
    _temp,
    _jsxFileName = "/Users/rainx/Documents/Github/csite/pages/scene/index.js";
















var images = [_assets_images_scene_banner_1_jpg__WEBPACK_IMPORTED_MODULE_19___default.a, _assets_images_scene_banner_2_jpg__WEBPACK_IMPORTED_MODULE_20___default.a, _assets_images_scene_banner_3_jpg__WEBPACK_IMPORTED_MODULE_21___default.a, _assets_images_scene_banner_4_jpg__WEBPACK_IMPORTED_MODULE_22___default.a];
var scenes = [{
  as: '/scene/1',
  url: '/scene?id=1',
  name: '智慧能源'
}, {
  as: '/scene/2',
  url: '/scene?id=2',
  name: '智慧校园'
}, {
  as: '/scene/3',
  url: '/scene?id=3',
  name: '智慧建筑'
}, {
  as: '/scene/4',
  url: '/scene?id=4',
  name: '智慧园区'
}];

var Scene = Object(next_router__WEBPACK_IMPORTED_MODULE_15__["withRouter"])(_class = (_temp = _class2 =
/*#__PURE__*/
function (_React$Component) {
  Object(_babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_11__["default"])(Scene, _React$Component);

  function Scene(props) {
    var _this;

    Object(_babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_6__["default"])(this, Scene);

    _this = Object(_babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_8__["default"])(this, Object(_babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_9__["default"])(Scene).call(this, props));

    Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_12__["default"])(Object(_babel_runtime_corejs2_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_10__["default"])(_this), "handleClick", function (_ref) {
      var index = _ref.index,
          title = _ref.title,
          image = _ref.image,
          className = _ref.className;
      return function (_ref2) {
        var currentTarget = _ref2.currentTarget;
        var selected = _this.state.selected;

        if (!selected.animIn && !selected.animating) {
          _this.state.selected = {
            // eslint-disable-line
            index: index,
            title: title,
            image: image,
            className: className,
            dom: currentTarget
          };

          _this.forceUpdate(function () {
            next_router__WEBPACK_IMPORTED_MODULE_15___default.a.push("/scene?id=".concat(index), "/scene/".concat(index), {
              shallow: true
            });
          });
        }
      };
    });

    Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_12__["default"])(Object(_babel_runtime_corejs2_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_10__["default"])(_this), "handleImageLoad", function () {
      var selected = _this.state.selected;
      var position = selected.dom.getBoundingClientRect();

      var fixedStyle = _this.getBlockStyle(position);

      var viewSize = {
        width: Object(rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_16__["get"])(_this.viewRef.current, 'width'),
        height: Object(rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_16__["get"])(_this.viewRef.current, 'height')
      };

      var imageSize = _this.getImageSize(viewSize);

      var fixedImageStyle = Object(_babel_runtime_corejs2_helpers_esm_objectSpread__WEBPACK_IMPORTED_MODULE_5__["default"])({}, _this.getImageStyle(imageSize, position, 0.75));

      var fixedLastStyle = {
        transition: _this.getTransition(true),
        transform: 'translateX(0) translateY(0) translateZ(0)',
        height: '100vh',
        width: '100vw'
      };
      var fixedImageLastStyle = {
        transition: _this.getImageTransition(true),
        transform: _this.getImageCoverTransform(imageSize, viewSize)
      };
      _this.state.selected = Object(_babel_runtime_corejs2_helpers_esm_objectSpread__WEBPACK_IMPORTED_MODULE_5__["default"])({}, selected, {
        animating: true,
        animIn: true
      }); // eslint-disable-line

      _this.forceUpdate(function () {
        Object(rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_16__["set"])(_this.pageRef.current, fixedStyle);
        Object(rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_16__["set"])(_this.pageImageRef.current, fixedImageStyle); // 火狐延迟一帧

        Object(_lib_requestAnimationFrame__WEBPACK_IMPORTED_MODULE_18__["requestAnimationFrame"])(function () {
          Object(_lib_requestAnimationFrame__WEBPACK_IMPORTED_MODULE_18__["requestAnimationFrame"])(function () {
            Object(rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_16__["set"])(_this.pageRef.current, fixedLastStyle);
            Object(rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_16__["set"])(_this.pageImageRef.current, fixedImageLastStyle);
          });
        });
      });
    });

    Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_12__["default"])(Object(_babel_runtime_corejs2_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_10__["default"])(_this), "handleBack", function () {
      var selected = _this.state.selected;

      if (selected.animIn && !selected.animating) {
        var position = selected.dom.getBoundingClientRect();
        var viewSize = {
          width: Object(rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_16__["get"])(_this.viewRef.current, 'width'),
          height: Object(rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_16__["get"])(_this.viewRef.current, 'height')
        };

        var imageSize = _this.getImageSize(viewSize);

        var fixedStyle = {
          width: '100vw',
          height: '100vh',
          transform: "translateX(0) translateY(0) translateZ(0)"
        };

        var fixedImageStyle = Object(_babel_runtime_corejs2_helpers_esm_objectSpread__WEBPACK_IMPORTED_MODULE_5__["default"])({}, _this.getImageStyle(imageSize, viewSize));

        var fixedLastStyle = {
          width: "".concat(position.width, "px"),
          height: "".concat(position.height, "px"),
          transition: _this.getTransition(false),
          transform: "translateX(".concat(position.left, "px) translateY(").concat(position.top, "px) translateZ(0)")
        };
        var fixedImageLastStyle = {
          transition: _this.getImageTransition(false),
          transform: _this.getImageCoverTransform(imageSize, position, 0.75)
        };
        _this.state.selected = Object(_babel_runtime_corejs2_helpers_esm_objectSpread__WEBPACK_IMPORTED_MODULE_5__["default"])({}, selected, {
          animating: true,
          animIn: false
        }); // eslint-disable-line

        _this.forceUpdate(function () {
          Object(rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_16__["set"])(_this.pageRef.current, fixedStyle);
          Object(rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_16__["set"])(_this.pageImageRef.current, fixedImageStyle);
          Object(_lib_requestAnimationFrame__WEBPACK_IMPORTED_MODULE_18__["requestAnimationFrame"])(function () {
            Object(_lib_requestAnimationFrame__WEBPACK_IMPORTED_MODULE_18__["requestAnimationFrame"])(function () {
              Object(rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_16__["set"])(_this.pageRef.current, fixedLastStyle);
              Object(rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_16__["set"])(_this.pageImageRef.current, fixedImageLastStyle);
            });
          });
        });
      }
    });

    Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_12__["default"])(Object(_babel_runtime_corejs2_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_10__["default"])(_this), "handleTransitionEnd", function (animIn) {
      return function (e) {
        var selected = _this.state.selected;
        var isTransform = e.nativeEvent.propertyName === 'transform';
        var isOpacity = e.nativeEvent.propertyName === 'opacity';

        if (e.target === e.currentTarget) {
          e.preventDefault();
          e.stopPropagation();
        }

        if (isOpacity && e.target === e.currentTarget) {
          _this.state.selected = {}; // eslint-disable-line

          Object(_lib_requestAnimationFrame__WEBPACK_IMPORTED_MODULE_18__["requestAnimationFrame"])(function () {
            _this.pageRef.current.removeAttribute('style');

            _this.pageImageRef.current.removeAttribute('style');

            _this.forceUpdate();
          });
        } else if (selected.animating && e.target === e.currentTarget) {
          if (isTransform) {
            if (animIn) {
              _this.state.selected = Object(_babel_runtime_corejs2_helpers_esm_objectSpread__WEBPACK_IMPORTED_MODULE_5__["default"])({}, selected, {
                animating: false
              }); // eslint-disable-line

              _this.setState({
                index: selected.index
              }, function () {
                Object(_lib_requestAnimationFrame__WEBPACK_IMPORTED_MODULE_18__["requestAnimationFrame"])(function () {
                  _this.pageRef.current.setAttribute('style', 'height:100vh;width:100vw;');
                });
              });
            } else {
              _this.setState({
                index: 0,
                toBack: false
              }, function () {
                Object(_lib_requestAnimationFrame__WEBPACK_IMPORTED_MODULE_18__["requestAnimationFrame"])(function () {
                  Object(rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_16__["set"])(_this.pageRef.current, {
                    opacity: 0.001
                  });
                });
              });
            }
          }
        }
      };
    });

    Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_12__["default"])(Object(_babel_runtime_corejs2_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_10__["default"])(_this), "getTransition", function (isIn) {
      var _this$context = _this.context,
          themeVariables = _this$context.themeVariables,
          themeEasings = _this$context.themeEasings;
      var animSpeed = themeVariables['@anim-speed-3'].replace('ms', '');
      var ease = isIn ? themeEasings['@easeOutExpo'] : themeEasings['@easeOutCirc'];
      return _babel_runtime_corejs2_core_js_object_entries__WEBPACK_IMPORTED_MODULE_4___default()({
        width: {
          ease: ease,
          duration: animSpeed
        },
        height: {
          ease: ease,
          duration: animSpeed
        },
        transform: {
          ease: ease,
          duration: animSpeed
        },
        opacity: {
          ease: '',
          duration: animSpeed / 4
        }
      }).map(function (_ref3) {
        var _ref4 = Object(_babel_runtime_corejs2_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_3__["default"])(_ref3, 2),
            property = _ref4[0],
            _ref4$ = _ref4[1],
            ease = _ref4$.ease,
            duration = _ref4$.duration;

        return "".concat(property, " ").concat(duration, "ms ").concat(ease);
      }).join(',');
    });

    Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_12__["default"])(Object(_babel_runtime_corejs2_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_10__["default"])(_this), "getImageTransition", function (isIn) {
      var _this$context2 = _this.context,
          themeVariables = _this$context2.themeVariables,
          themeEasings = _this$context2.themeEasings;
      var animSpeed = themeVariables['@anim-speed-3'].replace('ms', '');
      return _babel_runtime_corejs2_core_js_object_entries__WEBPACK_IMPORTED_MODULE_4___default()({
        transform: {
          ease: isIn ? themeEasings['@easeOutCirc'] : themeEasings['@easeOutExpo'],
          duration: animSpeed
        }
      }).map(function (_ref5) {
        var _ref6 = Object(_babel_runtime_corejs2_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_3__["default"])(_ref5, 2),
            property = _ref6[0],
            _ref6$ = _ref6[1],
            ease = _ref6$.ease,
            duration = _ref6$.duration;

        return "".concat(property, " ").concat(duration, "ms ").concat(ease);
      }).join(',');
    });

    Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_12__["default"])(Object(_babel_runtime_corejs2_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_10__["default"])(_this), "getBlockStyle", function (position) {
      return {
        width: "".concat(position.width, "px"),
        height: "".concat(position.height, "px"),
        transform: "translateX(".concat(position.left, "px) translateY(").concat(position.top, "px) translateZ(0)")
      };
    });

    Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_12__["default"])(Object(_babel_runtime_corejs2_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_10__["default"])(_this), "getImageSize", function (cover) {
      var image = _this.pageImageRef.current;

      var _ref7 = cover || Object(rc_util_lib_Dom_css__WEBPACK_IMPORTED_MODULE_16__["getClientSize"])(),
          width = _ref7.width,
          height = _ref7.height;

      var imageRatio = image.width / image.height;
      var targetRatio = width / height;
      return {
        width: imageRatio > targetRatio ? imageRatio * height : width,
        height: imageRatio > targetRatio ? height : width / imageRatio
      };
    });

    Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_12__["default"])(Object(_babel_runtime_corejs2_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_10__["default"])(_this), "getImageStyle", function (coverSize, target, percent) {
      return Object(_babel_runtime_corejs2_helpers_esm_objectSpread__WEBPACK_IMPORTED_MODULE_5__["default"])({}, coverSize, {
        transform: _this.getImageCoverTransform(coverSize, target, percent)
      });
    });

    Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_12__["default"])(Object(_babel_runtime_corejs2_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_10__["default"])(_this), "getImageCoverTransform", function (image, target) {
      var percent = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 0.5;
      var imageRatio = image.width / image.height;
      var targetRatio = target.width / target.height;

      if (imageRatio > targetRatio) {
        var _scale = target.height / image.height;

        var imageWidth = image.width * _scale;
        var w = (imageWidth - target.width) * -percent;
        return "translateX(".concat(w, "px) translateY(0) translateZ(0) scale(").concat(Math.ceil(_scale * 1000) / 1000, ")");
      }

      var scale = target.width / image.width;
      var imageHeight = image.height * scale;
      var h = (imageHeight - target.height) * -percent;
      return "translateX(0) translateY(".concat(h, "px) translateZ(0) scale(").concat(Math.ceil(scale * 1000) / 1000, ")");
    });

    var router = _this.props.router;

    var _index = ~~router.query.id;

    _this.state = {
      toBack: false,
      toFront: false,
      index: _index || 0,
      animating: false,
      selected: {}
    };
    _this.viewRef = react__WEBPACK_IMPORTED_MODULE_13___default.a.createRef();
    _this.pageRef = react__WEBPACK_IMPORTED_MODULE_13___default.a.createRef();
    _this.pageFontRef = react__WEBPACK_IMPORTED_MODULE_13___default.a.createRef();
    _this.pageImageRef = react__WEBPACK_IMPORTED_MODULE_13___default.a.createRef();
    _this.sceneRef = react__WEBPACK_IMPORTED_MODULE_13___default.a.createRef();
    return _this;
  }

  Object(_babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_7__["default"])(Scene, [{
    key: "componentDidUpdate",
    value: function componentDidUpdate(prevProps_, prevState) {
      var _this$state = this.state,
          toBack = _this$state.toBack,
          toFront = _this$state.toFront,
          selected = _this$state.selected;

      if (!prevState.toBack && toBack) {
        this.setState({
          toBack: false,
          selected: Object(_babel_runtime_corejs2_helpers_esm_objectSpread__WEBPACK_IMPORTED_MODULE_5__["default"])({}, selected, {
            dom: this.sceneRef.current
          })
        }, this.handleBack);
      }

      if (!prevState.toFront && toFront) {
        this.setState({
          toFront: false,
          selected: Object(_babel_runtime_corejs2_helpers_esm_objectSpread__WEBPACK_IMPORTED_MODULE_5__["default"])({}, selected, {
            dom: this.sceneRef.current
          })
        });
      }
    }
  }, {
    key: "render",
    value: function render() {
      var _classnames,
          _this2 = this,
          _classnames3;

      var _this$state2 = this.state,
          index = _this$state2.index,
          selected = _this$state2.selected;
      return react__WEBPACK_IMPORTED_MODULE_13___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_13___default.a.Fragment, null, react__WEBPACK_IMPORTED_MODULE_13___default.a.createElement("section", {
        ref: this.viewRef,
        className: classnames__WEBPACK_IMPORTED_MODULE_14___default()(_scene_less__WEBPACK_IMPORTED_MODULE_27___default.a.view, _scene_less__WEBPACK_IMPORTED_MODULE_27___default.a.sceneBanner),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 341
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_13___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_14___default()(_scene_less__WEBPACK_IMPORTED_MODULE_27___default.a.solutions, (_classnames = {}, Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_12__["default"])(_classnames, _scene_less__WEBPACK_IMPORTED_MODULE_27___default.a.solutionHover, !selected.animating && !selected.animIn), Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_12__["default"])(_classnames, _scene_less__WEBPACK_IMPORTED_MODULE_27___default.a.unVisibility, selected.animIn && !selected.animating), Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_12__["default"])(_classnames, 'no-events', selected.animating || selected.animIn), _classnames)),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 342
        },
        __self: this
      }, scenes.map(function (_ref8, index) {
        var name = _ref8.name;
        return react__WEBPACK_IMPORTED_MODULE_13___default.a.createElement("div", {
          key: name,
          ref: index + 1 === selected.index ? _this2.sceneRef : null,
          onClick: _this2.handleClick({
            title: name,
            index: index + 1,
            image: images[index],
            className: _scene_less__WEBPACK_IMPORTED_MODULE_27___default.a["sceneBanner".concat(index + 1)]
          }),
          className: classnames__WEBPACK_IMPORTED_MODULE_14___default()(_scene_less__WEBPACK_IMPORTED_MODULE_27___default.a.solutionBlock, _scene_less__WEBPACK_IMPORTED_MODULE_27___default.a["sceneBanner".concat(index + 1)], Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_12__["default"])({}, _scene_less__WEBPACK_IMPORTED_MODULE_27___default.a.unVisibility, selected.animIn ? selected.index === index + 1 && (selected.animating || selected.animIn) : selected.index === index + 1 && _this2.state.index !== 0)),
          __source: {
            fileName: _jsxFileName,
            lineNumber: 349
          },
          __self: this
        }, react__WEBPACK_IMPORTED_MODULE_13___default.a.createElement("h2", {
          className: _scene_less__WEBPACK_IMPORTED_MODULE_27___default.a.solutionBlockTitle,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 363
          },
          __self: this
        }, name));
      }))), react__WEBPACK_IMPORTED_MODULE_13___default.a.createElement("div", {
        ref: this.pageRef,
        onTransitionEnd: this.handleTransitionEnd(selected.animIn),
        className: classnames__WEBPACK_IMPORTED_MODULE_14___default()(_scene_less__WEBPACK_IMPORTED_MODULE_27___default.a.solutionBlockContainer, {
          'no-events': selected.animating
        }),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 369
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_13___default.a.createElement("img", {
        alt: "",
        src: selected.image,
        ref: this.pageImageRef,
        onLoad: !selected.animIn ? this.handleImageLoad : null,
        style: selected.animIn && !selected.animating ? {
          display: 'none'
        } : {},
        className: _scene_less__WEBPACK_IMPORTED_MODULE_27___default.a.solutionBlockContainerImage,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 373
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_13___default.a.createElement("h2", {
        ref: this.pageFontRef,
        className: classnames__WEBPACK_IMPORTED_MODULE_14___default()(_scene_less__WEBPACK_IMPORTED_MODULE_27___default.a.solutionBlockTitle, (_classnames3 = {}, Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_12__["default"])(_classnames3, _scene_less__WEBPACK_IMPORTED_MODULE_27___default.a.hidden, selected.animIn && !selected.animating), Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_12__["default"])(_classnames3, _scene_less__WEBPACK_IMPORTED_MODULE_27___default.a.transparent, selected.animIn && selected.animating), _classnames3)),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 380
        },
        __self: this
      }, selected.title)), !selected.animating && selected.animIn ? index === 1 ? react__WEBPACK_IMPORTED_MODULE_13___default.a.createElement(_scene1__WEBPACK_IMPORTED_MODULE_23__["default"], {
        key: "1",
        router: this.props.router,
        bannerImage: selected.image,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 386
        },
        __self: this
      }) : index === 2 ? react__WEBPACK_IMPORTED_MODULE_13___default.a.createElement(_scene2__WEBPACK_IMPORTED_MODULE_24__["default"], {
        key: "2",
        router: this.props.router,
        bannerImage: selected.image,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 388
        },
        __self: this
      }) : index === 3 ? react__WEBPACK_IMPORTED_MODULE_13___default.a.createElement(_scene3__WEBPACK_IMPORTED_MODULE_25__["default"], {
        key: "3",
        router: this.props.router,
        bannerImage: selected.image,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 390
        },
        __self: this
      }) : react__WEBPACK_IMPORTED_MODULE_13___default.a.createElement(_scene4__WEBPACK_IMPORTED_MODULE_26__["default"], {
        key: "4",
        router: this.props.router,
        bannerImage: selected.image,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 392
        },
        __self: this
      }) : null);
    }
  }]);

  return Scene;
}(react__WEBPACK_IMPORTED_MODULE_13___default.a.Component), Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_12__["default"])(_class2, "contextType", _components_Themes__WEBPACK_IMPORTED_MODULE_17__["ThemeContext"]), Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_12__["default"])(_class2, "getInitialProps",
/*#__PURE__*/
function () {
  var _ref9 = Object(_babel_runtime_corejs2_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_2__["default"])(
  /*#__PURE__*/
  _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_1___default.a.mark(function _callee(ctx_) {
    var layoutProps;
    return _babel_runtime_corejs2_regenerator__WEBPACK_IMPORTED_MODULE_1___default.a.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            layoutProps = {
              header: {
                transparent: true
              },
              footer: false,
              pageProps: {
                scrollClass: {
                  '>=0': 'page-header-hold',
                  '>=100vh-64': 'page-header-dark banner-menu-fixed'
                }
              },
              title: '解决方案'
            };
            return _context.abrupt("return", {
              layoutProps: layoutProps
            });

          case 2:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));

  return function (_x) {
    return _ref9.apply(this, arguments);
  };
}()), Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_12__["default"])(_class2, "getDerivedStateFromProps", function (props, state) {
  // 参数 category: >=1&<=6
  var router = props.router;
  var index = ~~router.query.id;

  if (index > 0 && index <= scenes.length) {
    if (state.index === 0 && _babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_0___default()(state.selected).length) {
      return null;
    } else if (state.index === 0) {
      return {
        toFront: true,
        selected: {
          index: index,
          title: scenes[index - 1].name,
          image: images[index - 1],
          className: _scene_less__WEBPACK_IMPORTED_MODULE_27___default.a["sceneBanner".concat(index)],
          dom: null
        }
      };
    }

    return {
      index: index,
      selected: {
        index: index,
        title: scenes[index - 1].name,
        image: images[index - 1],
        className: _scene_less__WEBPACK_IMPORTED_MODULE_27___default.a["sceneBanner".concat(index)],
        animIn: true,
        animating: false,
        dom: null
      }
    };
  } else if (state.index !== index && index === 0) {
    return !state.toBack ? {
      toBack: true
    } : null;
  } else if (router.query.category) {
    next_router__WEBPACK_IMPORTED_MODULE_15___default.a.replace('/scene', '/scene', {
      shallow: true
    });
  }

  return null;
}), _temp)) || _class;

/* harmony default export */ __webpack_exports__["default"] = (Scene);

/***/ }),

/***/ "./pages/scene/scene.less":
/*!********************************!*\
  !*** ./pages/scene/scene.less ***!
  \********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = {
	"view": "view___VbQvt",
	"scene-banner": "scene-banner___3n-kG",
	"sceneBanner": "scene-banner___3n-kG",
	"scene-banner-1": "scene-banner-1___Lbuqt",
	"sceneBanner1": "scene-banner-1___Lbuqt",
	"scene-banner-2": "scene-banner-2___1JCp-",
	"sceneBanner2": "scene-banner-2___1JCp-",
	"scene-banner-3": "scene-banner-3___1-A6N",
	"sceneBanner3": "scene-banner-3___1-A6N",
	"scene-banner-4": "scene-banner-4___28TGj",
	"sceneBanner4": "scene-banner-4___28TGj",
	"scene-banner-5": "scene-banner-5___MCA8T",
	"sceneBanner5": "scene-banner-5___MCA8T",
	"solutions": "solutions___3KEkI",
	"solution-block": "solution-block___1jRhL",
	"solutionBlock": "solution-block___1jRhL",
	"un-visibility": "un-visibility___2RDX-",
	"unVisibility": "un-visibility___2RDX-",
	"solution-hover": "solution-hover___3e4cK",
	"solutionHover": "solution-hover___3e4cK",
	"solution-block-container": "solution-block-container___3zkm0",
	"solutionBlockContainer": "solution-block-container___3zkm0",
	"solution-block-container-image": "solution-block-container-image___2eHbz",
	"solutionBlockContainerImage": "solution-block-container-image___2eHbz",
	"solution-block-container-banner": "solution-block-container-banner___2Ug_X",
	"solutionBlockContainerBanner": "solution-block-container-banner___2Ug_X",
	"solution-block-title": "solution-block-title___fS2Eg",
	"solutionBlockTitle": "solution-block-title___fS2Eg",
	"transparent": "transparent___3ElDW",
	"hidden": "hidden___2eEuj",
	"animating": "animating___2IAzs"
};

/***/ }),

/***/ "./pages/scene/scene1/index.js":
/*!*************************************!*\
  !*** ./pages/scene/scene1/index.js ***!
  \*************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/extends */ "./node_modules/@babel/runtime-corejs2/helpers/esm/extends.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/objectWithoutProperties */ "./node_modules/@babel/runtime-corejs2/helpers/esm/objectWithoutProperties.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/classCallCheck */ "./node_modules/@babel/runtime-corejs2/helpers/esm/classCallCheck.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/createClass */ "./node_modules/@babel/runtime-corejs2/helpers/esm/createClass.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/possibleConstructorReturn */ "./node_modules/@babel/runtime-corejs2/helpers/esm/possibleConstructorReturn.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/getPrototypeOf */ "./node_modules/@babel/runtime-corejs2/helpers/esm/getPrototypeOf.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/inherits */ "./node_modules/@babel/runtime-corejs2/helpers/esm/inherits.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! classnames */ "classnames");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var rc_tween_one__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rc-tween-one */ "rc-tween-one");
/* harmony import */ var rc_tween_one__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(rc_tween_one__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _components_SvgIcon__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @components/SvgIcon */ "./components/SvgIcon/index.js");
/* harmony import */ var _components_Themes__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @components/Themes */ "./components/Themes/index.js");
/* harmony import */ var _assets_images_scene_quote_svg_sprite__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @assets/images/scene/quote.svg?sprite */ "./assets/images/scene/quote.svg?sprite");
/* harmony import */ var _assets_images_scene_quote_svg_sprite__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_assets_images_scene_quote_svg_sprite__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _section2__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./section2 */ "./pages/scene/scene1/section2.js");
/* harmony import */ var _section3__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./section3 */ "./pages/scene/scene1/section3.js");
/* harmony import */ var _section4__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./section4 */ "./pages/scene/scene1/section4.js");
/* harmony import */ var _scene1_less__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./scene1.less */ "./pages/scene/scene1/scene1.less");
/* harmony import */ var _scene1_less__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_scene1_less__WEBPACK_IMPORTED_MODULE_16__);







var _jsxFileName = "/Users/rainx/Documents/Github/csite/pages/scene/scene1/index.js";











var SectionBlock =
/*#__PURE__*/
function (_React$Component) {
  Object(_babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_6__["default"])(SectionBlock, _React$Component);

  function SectionBlock() {
    Object(_babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_2__["default"])(this, SectionBlock);

    return Object(_babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__["default"])(this, Object(_babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__["default"])(SectionBlock).apply(this, arguments));
  }

  Object(_babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_3__["default"])(SectionBlock, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      Object(_components_Themes__WEBPACK_IMPORTED_MODULE_11__["setTheme"])({
        footer: true
      }, this.props.router.route);
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      Object(_components_Themes__WEBPACK_IMPORTED_MODULE_11__["setTheme"])({
        footer: false
      }, this.props.router.route);
    }
  }, {
    key: "render",
    value: function render() {
      var _this$props = this.props,
          className = _this$props.className,
          bannerImage = _this$props.bannerImage,
          props = Object(_babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__["default"])(_this$props, ["className", "bannerImage"]);

      return react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", Object(_babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__["default"])({}, props, {
        className: classnames__WEBPACK_IMPORTED_MODULE_8___default()(_scene1_less__WEBPACK_IMPORTED_MODULE_16___default.a.block, className),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 27
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("section", {
        className: _scene1_less__WEBPACK_IMPORTED_MODULE_16___default.a.blockBanner,
        style: {
          backgroundImage: "url(".concat(bannerImage, ")")
        },
        __source: {
          fileName: _jsxFileName,
          lineNumber: 28
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(rc_tween_one__WEBPACK_IMPORTED_MODULE_9___default.a, {
        className: _scene1_less__WEBPACK_IMPORTED_MODULE_16___default.a.blockBannerMask,
        animation: {
          opacity: 0.001,
          type: 'from',
          duration: 1000,
          ease: 'easeOutExpo'
        },
        __source: {
          fileName: _jsxFileName,
          lineNumber: 29
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_8___default()('page-content', _scene1_less__WEBPACK_IMPORTED_MODULE_16___default.a.blockBannerContent),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 32
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("h1", {
        className: "SceneZcoolGaoDuanHei",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 33
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("i", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 34
        },
        __self: this
      }, "\u667A\u6167\u80FD\u6E90"), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("span", {
        className: "SceneZcoolXiaoWeiTi",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 35
        },
        __self: this
      }, "\u89E3\u51B3\u65B9\u6848")))), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("section", {
        className: _scene1_less__WEBPACK_IMPORTED_MODULE_16___default.a.blockContent,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 39
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "page-content",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 40
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("blockquote", {
        className: _scene1_less__WEBPACK_IMPORTED_MODULE_16___default.a.dictum,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 41
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("span", {
        className: _scene1_less__WEBPACK_IMPORTED_MODULE_16___default.a.dictumText,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 42
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_components_SvgIcon__WEBPACK_IMPORTED_MODULE_10__["default"], {
        className: _scene1_less__WEBPACK_IMPORTED_MODULE_16___default.a.dictumQuote,
        icon: _assets_images_scene_quote_svg_sprite__WEBPACK_IMPORTED_MODULE_12___default.a,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 43
        },
        __self: this
      }), "\u6570\u636E\u8BA1\u7B97", react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("span", {
        className: classnames__WEBPACK_IMPORTED_MODULE_8___default()('SceneSiYuan', _scene1_less__WEBPACK_IMPORTED_MODULE_16___default.a.dictumPoint),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 45
        },
        __self: this
      }, "\u4E25\u8C28"), "\uFF0C\u4F7F\u7528\u65B9\u4FBF", react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("span", {
        className: classnames__WEBPACK_IMPORTED_MODULE_8___default()('SceneSiYuan', _scene1_less__WEBPACK_IMPORTED_MODULE_16___default.a.dictumPoint),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 47
        },
        __self: this
      }, "\u7B80\u5355"), "\uFF0C\u662F\u6211\u4EEC\u4EA7\u54C1\u7684\u8BBE\u8BA1\u5B97\u65E8")), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("p", {
        className: "page-poem",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 51
        },
        __self: this
      }, "\u6C5F\u82CF\u6B23\u52A8\u4FE1\u606F\u79D1\u6280", react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("br", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 52
        },
        __self: this
      }), "\u4E3A\u4E0D\u540C\u7684\u5BA2\u6237\u63D0\u4F9B\u5B9A\u5236\u5316\u7684\u89E3\u51B3\u65B9\u6848", react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("br", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 52
        },
        __self: this
      }), "\u5305\u62EC\u8BE5\u89E3\u51B3\u65B9\u6848\u9488\u5BF9\u5BA2\u6237\u7684\u6210\u672C\u548C\u6548\u679C\u987E\u8651", react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("br", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 53
        },
        __self: this
      }), "\u63D0\u4F9B\u4E0D\u540C\u7684\u5B9E\u65BD\u65B9\u6848\u3002"), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("p", {
        className: "page-poem",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 55
        },
        __self: this
      }, "\u6211\u4EEC\u901A\u8FC7", react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("br", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 56
        },
        __self: this
      }), "\u5BF9\u56ED\u533A\u3001\u9AD8\u7B49\u9662\u6821\u3001\u5546\u4E1A\u5EFA\u7B51\u3001\u653F\u5E9C\u673A\u5173\u3001\u5927\u578B\u516C\u5171\u5EFA\u7B51\u7B49\u8BBE\u65BD", react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("br", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 56
        },
        __self: this
      }), "\u7528\u6237\u7684\u7528\u80FD\u4E60\u60EF\u548C\u7528\u80FD\u60C5\u51B5\u8FDB\u884C\u5206\u6790", react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("br", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 57
        },
        __self: this
      }), "\u63D0\u4F9B\u5168\u9762\u7684\u80FD\u6E90\u7BA1\u7406", react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("br", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 57
        },
        __self: this
      }), "\u5B9E\u73B0\u80FD\u6E90\u5229\u7528\u6700\u4F18"))), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("section", {
        className: _scene1_less__WEBPACK_IMPORTED_MODULE_16___default.a.blockContent,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 61
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "page-content",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 62
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("h2", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 63
        },
        __self: this
      }, "\u67B6\u6784\u5347\u7EA7"), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_section2__WEBPACK_IMPORTED_MODULE_13__["default"], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 64
        },
        __self: this
      }))), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("section", {
        className: _scene1_less__WEBPACK_IMPORTED_MODULE_16___default.a.blockContent,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 67
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "page-content",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 68
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _scene1_less__WEBPACK_IMPORTED_MODULE_16___default.a.sectionContent,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 69
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("h2", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 70
        },
        __self: this
      }, "\u4F18\u52BF"), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_section3__WEBPACK_IMPORTED_MODULE_14__["default"], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 71
        },
        __self: this
      })))), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("section", {
        className: _scene1_less__WEBPACK_IMPORTED_MODULE_16___default.a.blockContent,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 75
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "page-content",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 76
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("h2", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 77
        },
        __self: this
      }, "\u5E73\u53F0\u67B6\u6784"), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_section4__WEBPACK_IMPORTED_MODULE_15__["default"], {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 78
        },
        __self: this
      }))), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("section", {
        className: _scene1_less__WEBPACK_IMPORTED_MODULE_16___default.a.blockContent,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 81
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "page-content",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 82
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("h2", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 83
        },
        __self: this
      }, "\u6280\u672F\u67B6\u6784"))), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("section", {
        className: _scene1_less__WEBPACK_IMPORTED_MODULE_16___default.a.blockContent,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 86
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "page-content",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 87
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("h2", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 88
        },
        __self: this
      }, "\u6280\u672F\u7279\u70B9"), react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: _scene1_less__WEBPACK_IMPORTED_MODULE_16___default.a.characteristic,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 89
        },
        __self: this
      }))));
    }
  }]);

  return SectionBlock;
}(react__WEBPACK_IMPORTED_MODULE_7___default.a.Component);

/* harmony default export */ __webpack_exports__["default"] = (SectionBlock);

/***/ }),

/***/ "./pages/scene/scene1/scene1.less":
/*!****************************************!*\
  !*** ./pages/scene/scene1/scene1.less ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = {
	"block": "block___5hoKY",
	"block-banner": "block-banner___2M2Pe",
	"blockBanner": "block-banner___2M2Pe",
	"block-banner-mask": "block-banner-mask___pKloF",
	"blockBannerMask": "block-banner-mask___pKloF",
	"block-banner-image": "block-banner-image___2GIiR",
	"blockBannerImage": "block-banner-image___2GIiR",
	"block-banner-content": "block-banner-content___3_MrN",
	"blockBannerContent": "block-banner-content___3_MrN",
	"block-content": "block-content___2PY1w",
	"blockContent": "block-content___2PY1w",
	"dictum": "dictum___3DGtQ",
	"dictum-text": "dictum-text___1AOrj",
	"dictumText": "dictum-text___1AOrj",
	"dictum-quote": "dictum-quote___3KfqH",
	"dictumQuote": "dictum-quote___3KfqH",
	"dictum-point": "dictum-point___v2ZXv",
	"dictumPoint": "dictum-point___v2ZXv",
	"platform": "platform___KGkWt"
};

/***/ }),

/***/ "./pages/scene/scene1/section2.js":
/*!****************************************!*\
  !*** ./pages/scene/scene1/section2.js ***!
  \****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/classCallCheck */ "./node_modules/@babel/runtime-corejs2/helpers/esm/classCallCheck.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/createClass */ "./node_modules/@babel/runtime-corejs2/helpers/esm/createClass.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/possibleConstructorReturn */ "./node_modules/@babel/runtime-corejs2/helpers/esm/possibleConstructorReturn.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/getPrototypeOf */ "./node_modules/@babel/runtime-corejs2/helpers/esm/getPrototypeOf.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/inherits */ "./node_modules/@babel/runtime-corejs2/helpers/esm/inherits.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _section2_less__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./section2.less */ "./pages/scene/scene1/section2.less");
/* harmony import */ var _section2_less__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_section2_less__WEBPACK_IMPORTED_MODULE_6__);





var _jsxFileName = "/Users/rainx/Documents/Github/csite/pages/scene/scene1/section2.js";


var tableData = [{
  key: '1',
  col1: '驱动力',
  col2: '外部驱动力（政策和措施）',
  col3: '内部驱动力（机制和标准）'
}, {
  key: '2',
  col1: '目标',
  col2: '节能降耗',
  col3: '整体提高建筑和设施设备的能效、运行效率和使用寿命'
}, {
  key: '3',
  col1: '工作重点',
  col2: '能耗检测、水电管理',
  col3: '运行管理'
}, {
  key: '4',
  col1: '管理对象',
  col2: '各类能耗计量器具',
  col3: '各类基础设施和用能设备'
}, {
  key: '5',
  col1: '参与者',
  col2: '能源管理部门孤军奋战',
  col3: '能源管理部门和物业、安防、基建房产等工作相融合，转型升级，跨界发展'
}];

var Section =
/*#__PURE__*/
function (_React$Component) {
  Object(_babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_4__["default"])(Section, _React$Component);

  function Section() {
    Object(_babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_0__["default"])(this, Section);

    return Object(_babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__["default"])(this, Object(_babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_3__["default"])(Section).apply(this, arguments));
  }

  Object(_babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_1__["default"])(Section, [{
    key: "render",
    value: function render() {
      return react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("table", {
        className: _section2_less__WEBPACK_IMPORTED_MODULE_6___default.a.table,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 36
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("thead", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 37
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("tr", {
        className: _section2_less__WEBPACK_IMPORTED_MODULE_6___default.a.tableHead,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 38
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("th", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 39
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("th", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 40
        },
        __self: this
      }, "\u80FD\u6E90\u7BA1\u7406 1.0"), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("th", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 41
        },
        __self: this
      }, "\u667A\u6167\u80FD\u6E90 2.0"))), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("tbody", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 44
        },
        __self: this
      }, tableData.map(function (data) {
        return react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("tr", {
          key: data.key,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 47
          },
          __self: this
        }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("td", {
          className: _section2_less__WEBPACK_IMPORTED_MODULE_6___default.a.col1,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 48
          },
          __self: this
        }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("span", {
          className: _section2_less__WEBPACK_IMPORTED_MODULE_6___default.a.chspan,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 49
          },
          __self: this
        }, data.col1)), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("td", {
          className: _section2_less__WEBPACK_IMPORTED_MODULE_6___default.a.col2,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 51
          },
          __self: this
        }, data.col2), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("td", {
          className: _section2_less__WEBPACK_IMPORTED_MODULE_6___default.a.col3,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 52
          },
          __self: this
        }, data.col3));
      })));
    }
  }]);

  return Section;
}(react__WEBPACK_IMPORTED_MODULE_5___default.a.Component);

/* harmony default export */ __webpack_exports__["default"] = (Section);

/***/ }),

/***/ "./pages/scene/scene1/section2.less":
/*!******************************************!*\
  !*** ./pages/scene/scene1/section2.less ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = {
	"table": "table___1X-uk",
	"table-head": "table-head___16-0o",
	"tableHead": "table-head___16-0o",
	"col1": "col1___2cVZN",
	"chspan": "chspan___1Onf7",
	"col2": "col2___QPkA2",
	"col3": "col3___1rOKZ"
};

/***/ }),

/***/ "./pages/scene/scene1/section3.js":
/*!****************************************!*\
  !*** ./pages/scene/scene1/section3.js ***!
  \****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/classCallCheck */ "./node_modules/@babel/runtime-corejs2/helpers/esm/classCallCheck.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/createClass */ "./node_modules/@babel/runtime-corejs2/helpers/esm/createClass.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/possibleConstructorReturn */ "./node_modules/@babel/runtime-corejs2/helpers/esm/possibleConstructorReturn.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/getPrototypeOf */ "./node_modules/@babel/runtime-corejs2/helpers/esm/getPrototypeOf.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/inherits */ "./node_modules/@babel/runtime-corejs2/helpers/esm/inherits.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _section3_less__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./section3.less */ "./pages/scene/scene1/section3.less");
/* harmony import */ var _section3_less__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_section3_less__WEBPACK_IMPORTED_MODULE_6__);





var _jsxFileName = "/Users/rainx/Documents/Github/csite/pages/scene/scene1/section3.js";


var adv = [{
  key: '1',
  title: '为能源计量提供数据基础',
  content: ''
}, {
  key: '2',
  title: '为节能减排提供管控平台',
  content: ''
}, {
  key: '3',
  title: '为节能控制提供有效手段',
  content: ''
}, {
  key: '4',
  title: '为用能决策提供科学依据',
  content: ''
}, {
  key: '5',
  title: '为科学管理提供技术支撑',
  content: ''
}, {
  key: '6',
  title: '为统计分析提供科学方法',
  content: ''
}];

var Section =
/*#__PURE__*/
function (_React$Component) {
  Object(_babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_4__["default"])(Section, _React$Component);

  function Section() {
    Object(_babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_0__["default"])(this, Section);

    return Object(_babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__["default"])(this, Object(_babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_3__["default"])(Section).apply(this, arguments));
  }

  Object(_babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_1__["default"])(Section, [{
    key: "render",
    value: function render() {
      return react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: _section3_less__WEBPACK_IMPORTED_MODULE_6___default.a.wrap,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 35
        },
        __self: this
      }, adv.map(function (_ref) {
        var key = _ref.key,
            title = _ref.title,
            content = _ref.content;
        return react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
          key: key,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 38
          },
          __self: this
        }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
          className: _section3_less__WEBPACK_IMPORTED_MODULE_6___default.a.blockTitle,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 39
          },
          __self: this
        }, title), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
          className: _section3_less__WEBPACK_IMPORTED_MODULE_6___default.a.blockContent,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 42
          },
          __self: this
        }, content));
      }));
    }
  }]);

  return Section;
}(react__WEBPACK_IMPORTED_MODULE_5___default.a.Component);

/* harmony default export */ __webpack_exports__["default"] = (Section);

/***/ }),

/***/ "./pages/scene/scene1/section3.less":
/*!******************************************!*\
  !*** ./pages/scene/scene1/section3.less ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = {
	"wrap": "wrap___Ic_X-",
	"block-title": "block-title___1Rdd_",
	"blockTitle": "block-title___1Rdd_",
	"block-content": "block-content___2ax8_",
	"blockContent": "block-content___2ax8_"
};

/***/ }),

/***/ "./pages/scene/scene1/section4.js":
/*!****************************************!*\
  !*** ./pages/scene/scene1/section4.js ***!
  \****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/classCallCheck */ "./node_modules/@babel/runtime-corejs2/helpers/esm/classCallCheck.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/createClass */ "./node_modules/@babel/runtime-corejs2/helpers/esm/createClass.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/possibleConstructorReturn */ "./node_modules/@babel/runtime-corejs2/helpers/esm/possibleConstructorReturn.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/getPrototypeOf */ "./node_modules/@babel/runtime-corejs2/helpers/esm/getPrototypeOf.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/inherits */ "./node_modules/@babel/runtime-corejs2/helpers/esm/inherits.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! classnames */ "classnames");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _components_ResizeImage__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @components/ResizeImage */ "./components/ResizeImage/index.js");
/* harmony import */ var _section4_less__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./section4.less */ "./pages/scene/scene1/section4.less");
/* harmony import */ var _section4_less__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_section4_less__WEBPACK_IMPORTED_MODULE_8__);





var _jsxFileName = "/Users/rainx/Documents/Github/csite/pages/scene/scene1/section4.js";





var Section =
/*#__PURE__*/
function (_React$Component) {
  Object(_babel_runtime_corejs2_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_4__["default"])(Section, _React$Component);

  function Section() {
    Object(_babel_runtime_corejs2_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_0__["default"])(this, Section);

    return Object(_babel_runtime_corejs2_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_2__["default"])(this, Object(_babel_runtime_corejs2_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_3__["default"])(Section).apply(this, arguments));
  }

  Object(_babel_runtime_corejs2_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_1__["default"])(Section, [{
    key: "render",
    value: function render() {
      return react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement(_components_ResizeImage__WEBPACK_IMPORTED_MODULE_7__["default"], {
        className: _section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.wrap,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 11
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: _section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layer,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 12
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: _section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerTitle,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 13
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 14
        },
        __self: this
      }, "\u7528\u6237\u573A\u666F")), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: _section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerContent,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 16
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_6___default()(_section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerItem, _section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerCol5),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 17
        },
        __self: this
      }, "\u8FDC\u7A0B\u63A7\u5236"), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_6___default()(_section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerItem, _section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerCol5),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 18
        },
        __self: this
      }, "\u6D88\u9632\u5B89\u5168"), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_6___default()(_section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerItem, _section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerCol5),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 19
        },
        __self: this
      }, "\u7BA1\u7F51\u68C0\u6D4B"), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_6___default()(_section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerItem, _section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerCol5),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 20
        },
        __self: this
      }, "\u5145\u503C\u67E5\u8BE2"), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_6___default()(_section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerItem, _section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerCol5),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 21
        },
        __self: this
      }, "..."))), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: _section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layer,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 24
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: _section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerTitle,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 25
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 26
        },
        __self: this
      }, "\u5E94\u7528\u7CFB\u7EDF")), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_6___default()(_section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerContent, _section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.flexCol),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 28
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: _section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerBlock,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 29
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: _section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.blockTitle,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 30
        },
        __self: this
      }, "\u6807\u51C6\u5E94\u7528"), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_6___default()(_section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerItem, _section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerCol5),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 31
        },
        __self: this
      }, "\u5EFA\u7B51\u80FD\u8017\u7BA1\u7406"), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_6___default()(_section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerItem, _section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerCol5),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 32
        },
        __self: this
      }, "\u90E8\u95E8\u80FD\u8017\u7BA1\u7406"), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_6___default()(_section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerItem, _section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerCol5),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 33
        },
        __self: this
      }, "\u8BBE\u65BD\u80FD\u8017\u7BA1\u7406"), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_6___default()(_section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerItem, _section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerCol5),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 34
        },
        __self: this
      }, "\u7528\u80FD\u5E73\u8861\u68C0\u6D4B"), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_6___default()(_section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerItem, _section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerCol5),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 35
        },
        __self: this
      }, "\u80FD\u8017\u6570\u636E\u4E0A\u62A5")), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: _section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerBlock,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 37
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: _section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.blockTitle,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 38
        },
        __self: this
      }, "\u6269\u5C55\u5E94\u7528"), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_6___default()(_section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerItem, _section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerCol4),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 39
        },
        __self: this
      }, "\u5546\u4E1A\u7528\u80FD\u6536\u8D39"), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_6___default()(_section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerItem, _section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerCol4),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 40
        },
        __self: this
      }, "\u7528\u80FD\u8D26\u76EE\u7BA1\u7406"), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_6___default()(_section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerItem, _section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerCol4),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 41
        },
        __self: this
      }, "\u4E2D\u592E\u7A7A\u8C03\u76D1\u63A7"), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_6___default()(_section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerItem, _section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerCol4),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 42
        },
        __self: this
      }, "\u5206\u4F53\u7A7A\u8C03\u76D1\u63A7"), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_6___default()(_section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerItem, _section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerCol4),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 43
        },
        __self: this
      }, "\u591A\u8054\u673A\u7A7A\u8C03\u76D1\u63A7"), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_6___default()(_section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerItem, _section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerCol4),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 44
        },
        __self: this
      }, "\u667A\u80FD\u7167\u660E\u76D1\u63A7"), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_6___default()(_section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerItem, _section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerCol4),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 45
        },
        __self: this
      }, "\u4F9B\u6696\u8282\u80FD\u76D1\u63A7"), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_6___default()(_section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerItem, _section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerCol4),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 46
        },
        __self: this
      }, "...")))), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: _section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layer,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 57
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: _section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerTitle,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 58
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 59
        },
        __self: this
      }, "\u6570\u636E\u4E2D\u5FC3")), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: _section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.flexRow,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 61
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: _section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerContent,
        style: {
          paddingRight: 0
        },
        __source: {
          fileName: _jsxFileName,
          lineNumber: 62
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_6___default()(_section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerItem, _section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerCol4),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 63
        },
        __self: this
      }, "\u8EAB\u4EFD\u8BA4\u8BC1"), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_6___default()(_section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerItem, _section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerCol4),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 64
        },
        __self: this
      }, "\u8D22\u52A1\u7ED3\u7B97"), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_6___default()(_section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerItem, _section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerCol4),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 65
        },
        __self: this
      }, "\u95E8\u6237\u96C6\u6210"), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_6___default()(_section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerItem, _section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerCol4),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 66
        },
        __self: this
      }, "\u7CFB\u7EDF\u96C6\u6210"), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_6___default()(_section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerItem, _section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerCol4),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 67
        },
        __self: this
      }, "\u7EC4\u7EC7\u67B6\u6784"), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_6___default()(_section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerItem, _section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerCol4),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 68
        },
        __self: this
      }, "\u6570\u636E\u6316\u6398"), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_6___default()(_section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerItem, _section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerCol4),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 69
        },
        __self: this
      }, "\u6570\u636E\u5BF9\u63A5"), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_6___default()(_section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerItem, _section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerCol4),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 70
        },
        __self: this
      }, "...")), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_6___default()(_section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerContent, _section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerThird),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 72
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: _section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.blockTitle,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 73
        },
        __self: this
      }, "\u7B2C\u4E09\u65B9\u5BF9\u63A5"), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_6___default()(_section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerItem, _section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerCol2),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 74
        },
        __self: this
      }, "\u5206\u6790\u62A5\u8868"), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_6___default()(_section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerItem, _section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerCol2),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 75
        },
        __self: this
      }, "\u6536\u8D39\u7ED3\u7B97"), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_6___default()(_section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerItem, _section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerCol2),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 76
        },
        __self: this
      }, "\u8EAB\u4EFD\u8BA4\u8BC1"), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_6___default()(_section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerItem, _section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerCol2),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 77
        },
        __self: this
      }, "...")))), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: _section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layer,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 81
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: _section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerTitle,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 82
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 83
        },
        __self: this
      }, "\u667A\u80FD\u7269\u8054")), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: _section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerContent,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 85
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_6___default()(_section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerItem, _section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerCol5),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 86
        },
        __self: this
      }, "\u8BBE\u5907\u5BF9\u63A5"), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_6___default()(_section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerItem, _section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerCol5),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 87
        },
        __self: this
      }, "\u6570\u636E\u6574\u7406"), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_6___default()(_section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerItem, _section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerCol5),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 88
        },
        __self: this
      }, "\u6D77\u91CF\u5B58\u50A8"), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_6___default()(_section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerItem, _section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerCol5),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 89
        },
        __self: this
      }, "\u9A71\u52A8\u5F00\u53D1"), react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_6___default()(_section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerItem, _section4_less__WEBPACK_IMPORTED_MODULE_8___default.a.layerCol5),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 90
        },
        __self: this
      }, "\u8BBE\u5907\u76D1\u542C"))));
    }
  }]);

  return Section;
}(react__WEBPACK_IMPORTED_MODULE_5___default.a.Component);

/* harmony default export */ __webpack_exports__["default"] = (Section);

/***/ }),

/***/ "./pages/scene/scene1/section4.less":
/*!******************************************!*\
  !*** ./pages/scene/scene1/section4.less ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = {
	"wrap": "wrap___3Xqvd",
	"layer-title": "layer-title___t0vLE",
	"layerTitle": "layer-title___t0vLE",
	"layer-content": "layer-content___1AqLx",
	"layerContent": "layer-content___1AqLx",
	"layer-item": "layer-item___MkdEH",
	"layerItem": "layer-item___MkdEH",
	"flex-row": "flex-row___3ZI7k",
	"flexRow": "flex-row___3ZI7k",
	"flex-col": "flex-col___2TeO8",
	"flexCol": "flex-col___2TeO8",
	"layer-block": "layer-block___3h1xP",
	"layerBlock": "layer-block___3h1xP",
	"block-title": "block-title___6bQfW",
	"blockTitle": "block-title___6bQfW",
	"layer-third": "layer-third___2EXl8",
	"layerThird": "layer-third___2EXl8",
	"layer-col-6": "layer-col-6___3M3ed",
	"layerCol6": "layer-col-6___3M3ed",
	"layer-col-5": "layer-col-5___1Qmt8",
	"layerCol5": "layer-col-5___1Qmt8",
	"layer-col-4": "layer-col-4___1wM1x",
	"layerCol4": "layer-col-4___1wM1x",
	"layer-col-2": "layer-col-2___3Oxr4",
	"layerCol2": "layer-col-2___3Oxr4",
	"layer": "layer___3xcUB"
};

/***/ }),

/***/ "./pages/scene/scene2.js":
/*!*******************************!*\
  !*** ./pages/scene/scene2.js ***!
  \*******************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/extends */ "./node_modules/@babel/runtime-corejs2/helpers/esm/extends.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/objectWithoutProperties */ "./node_modules/@babel/runtime-corejs2/helpers/esm/objectWithoutProperties.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! classnames */ "classnames");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _scene2_less__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./scene2.less */ "./pages/scene/scene2.less");
/* harmony import */ var _scene2_less__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_scene2_less__WEBPACK_IMPORTED_MODULE_4__);


var _jsxFileName = "/Users/rainx/Documents/Github/csite/pages/scene/scene2.js";

 // import back from '@assets/images/scene/back.svg?sprite';
// import zhinengfenxi from '@assets/images/scene/zhinengfenxi.svg?sprite';
// import SvgIcon from '@components/SvgIcon';



function SectionBlock(_ref) {
  var className = _ref.className,
      bannerImage = _ref.bannerImage,
      props = Object(_babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__["default"])(_ref, ["className", "bannerImage"]);

  return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("section", Object(_babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__["default"])({}, props, {
    className: classnames__WEBPACK_IMPORTED_MODULE_3___default()(_scene2_less__WEBPACK_IMPORTED_MODULE_4___default.a.block, className),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 11
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("div", {
    className: _scene2_less__WEBPACK_IMPORTED_MODULE_4___default.a.blockContent,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 12
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("div", {
    className: "page-content",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 13
    },
    __self: this
  })));
}

/* harmony default export */ __webpack_exports__["default"] = (SectionBlock);

/***/ }),

/***/ "./pages/scene/scene2.less":
/*!*********************************!*\
  !*** ./pages/scene/scene2.less ***!
  \*********************************/
/*! no static exports found */
/***/ (function(module, exports) {



/***/ }),

/***/ "./pages/scene/scene3.js":
/*!*******************************!*\
  !*** ./pages/scene/scene3.js ***!
  \*******************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/extends */ "./node_modules/@babel/runtime-corejs2/helpers/esm/extends.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/objectWithoutProperties */ "./node_modules/@babel/runtime-corejs2/helpers/esm/objectWithoutProperties.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! classnames */ "classnames");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _scene3_less__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./scene3.less */ "./pages/scene/scene3.less");
/* harmony import */ var _scene3_less__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_scene3_less__WEBPACK_IMPORTED_MODULE_4__);


var _jsxFileName = "/Users/rainx/Documents/Github/csite/pages/scene/scene3.js";

 // import back from '@assets/images/scene/back.svg?sprite';
// import zhinengfenxi from '@assets/images/scene/zhinengfenxi.svg?sprite';
// import SvgIcon from '@components/SvgIcon';



function SectionBlock(_ref) {
  var className = _ref.className,
      bannerImage = _ref.bannerImage,
      props = Object(_babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__["default"])(_ref, ["className", "bannerImage"]);

  return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("section", Object(_babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__["default"])({}, props, {
    className: classnames__WEBPACK_IMPORTED_MODULE_3___default()(_scene3_less__WEBPACK_IMPORTED_MODULE_4___default.a.block, className),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 11
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("div", {
    className: _scene3_less__WEBPACK_IMPORTED_MODULE_4___default.a.blockContent,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 12
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("div", {
    className: "page-content",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 13
    },
    __self: this
  })));
}

/* harmony default export */ __webpack_exports__["default"] = (SectionBlock);

/***/ }),

/***/ "./pages/scene/scene3.less":
/*!*********************************!*\
  !*** ./pages/scene/scene3.less ***!
  \*********************************/
/*! no static exports found */
/***/ (function(module, exports) {



/***/ }),

/***/ "./pages/scene/scene4.js":
/*!*******************************!*\
  !*** ./pages/scene/scene4.js ***!
  \*******************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/extends */ "./node_modules/@babel/runtime-corejs2/helpers/esm/extends.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/objectWithoutProperties */ "./node_modules/@babel/runtime-corejs2/helpers/esm/objectWithoutProperties.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! classnames */ "classnames");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _scene4_less__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./scene4.less */ "./pages/scene/scene4.less");
/* harmony import */ var _scene4_less__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_scene4_less__WEBPACK_IMPORTED_MODULE_4__);


var _jsxFileName = "/Users/rainx/Documents/Github/csite/pages/scene/scene4.js";

 // import back from '@assets/images/scene/back.svg?sprite';
// import zhinengfenxi from '@assets/images/scene/zhinengfenxi.svg?sprite';
// import SvgIcon from '@components/SvgIcon';



function SectionBlock(_ref) {
  var className = _ref.className,
      bannerImage = _ref.bannerImage,
      props = Object(_babel_runtime_corejs2_helpers_esm_objectWithoutProperties__WEBPACK_IMPORTED_MODULE_1__["default"])(_ref, ["className", "bannerImage"]);

  return react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("section", Object(_babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__["default"])({}, props, {
    className: classnames__WEBPACK_IMPORTED_MODULE_3___default()(_scene4_less__WEBPACK_IMPORTED_MODULE_4___default.a.block, className),
    __source: {
      fileName: _jsxFileName,
      lineNumber: 11
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("div", {
    className: _scene4_less__WEBPACK_IMPORTED_MODULE_4___default.a.blockContent,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 12
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("div", {
    className: "page-content",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 13
    },
    __self: this
  })));
}

/* harmony default export */ __webpack_exports__["default"] = (SectionBlock);

/***/ }),

/***/ "./pages/scene/scene4.less":
/*!*********************************!*\
  !*** ./pages/scene/scene4.less ***!
  \*********************************/
/*! no static exports found */
/***/ (function(module, exports) {



/***/ }),

/***/ 3:
/*!************************************!*\
  !*** multi ./pages/scene/index.js ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! /Users/rainx/Documents/Github/csite/pages/scene/index.js */"./pages/scene/index.js");


/***/ }),

/***/ "classnames":
/*!*****************************!*\
  !*** external "classnames" ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("classnames");

/***/ }),

/***/ "core-js/library/fn/array/is-array":
/*!****************************************************!*\
  !*** external "core-js/library/fn/array/is-array" ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/array/is-array");

/***/ }),

/***/ "core-js/library/fn/get-iterator":
/*!**************************************************!*\
  !*** external "core-js/library/fn/get-iterator" ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/get-iterator");

/***/ }),

/***/ "core-js/library/fn/object/assign":
/*!***************************************************!*\
  !*** external "core-js/library/fn/object/assign" ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/assign");

/***/ }),

/***/ "core-js/library/fn/object/create":
/*!***************************************************!*\
  !*** external "core-js/library/fn/object/create" ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/create");

/***/ }),

/***/ "core-js/library/fn/object/define-property":
/*!************************************************************!*\
  !*** external "core-js/library/fn/object/define-property" ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/define-property");

/***/ }),

/***/ "core-js/library/fn/object/entries":
/*!****************************************************!*\
  !*** external "core-js/library/fn/object/entries" ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/entries");

/***/ }),

/***/ "core-js/library/fn/object/get-own-property-descriptor":
/*!************************************************************************!*\
  !*** external "core-js/library/fn/object/get-own-property-descriptor" ***!
  \************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/get-own-property-descriptor");

/***/ }),

/***/ "core-js/library/fn/object/get-own-property-symbols":
/*!*********************************************************************!*\
  !*** external "core-js/library/fn/object/get-own-property-symbols" ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/get-own-property-symbols");

/***/ }),

/***/ "core-js/library/fn/object/get-prototype-of":
/*!*************************************************************!*\
  !*** external "core-js/library/fn/object/get-prototype-of" ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/get-prototype-of");

/***/ }),

/***/ "core-js/library/fn/object/keys":
/*!*************************************************!*\
  !*** external "core-js/library/fn/object/keys" ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/keys");

/***/ }),

/***/ "core-js/library/fn/object/set-prototype-of":
/*!*************************************************************!*\
  !*** external "core-js/library/fn/object/set-prototype-of" ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/set-prototype-of");

/***/ }),

/***/ "core-js/library/fn/promise":
/*!*********************************************!*\
  !*** external "core-js/library/fn/promise" ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/promise");

/***/ }),

/***/ "core-js/library/fn/symbol":
/*!********************************************!*\
  !*** external "core-js/library/fn/symbol" ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/symbol");

/***/ }),

/***/ "core-js/library/fn/symbol/iterator":
/*!*****************************************************!*\
  !*** external "core-js/library/fn/symbol/iterator" ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/symbol/iterator");

/***/ }),

/***/ "flystore":
/*!***************************!*\
  !*** external "flystore" ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("flystore");

/***/ }),

/***/ "less-vars-to-js":
/*!**********************************!*\
  !*** external "less-vars-to-js" ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("less-vars-to-js");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/router");

/***/ }),

/***/ "object.pick":
/*!******************************!*\
  !*** external "object.pick" ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("object.pick");

/***/ }),

/***/ "rc-tween-one":
/*!*******************************!*\
  !*** external "rc-tween-one" ***!
  \*******************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("rc-tween-one");

/***/ }),

/***/ "rc-util/lib/Dom/addEventListener":
/*!***************************************************!*\
  !*** external "rc-util/lib/Dom/addEventListener" ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("rc-util/lib/Dom/addEventListener");

/***/ }),

/***/ "rc-util/lib/Dom/css":
/*!**************************************!*\
  !*** external "rc-util/lib/Dom/css" ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("rc-util/lib/Dom/css");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "regenerator-runtime":
/*!**************************************!*\
  !*** external "regenerator-runtime" ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("regenerator-runtime");

/***/ }),

/***/ "svg-baker-runtime/symbol":
/*!*******************************************!*\
  !*** external "svg-baker-runtime/symbol" ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("svg-baker-runtime/symbol");

/***/ }),

/***/ "svg-sprite-loader/runtime/sprite.build":
/*!*********************************************************!*\
  !*** external "svg-sprite-loader/runtime/sprite.build" ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("svg-sprite-loader/runtime/sprite.build");

/***/ })

/******/ });
//# sourceMappingURL=scene.js.map